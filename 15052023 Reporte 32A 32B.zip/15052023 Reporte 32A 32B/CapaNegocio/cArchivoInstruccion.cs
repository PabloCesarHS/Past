﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using System.Data;
using System.Globalization;

namespace CapaNegocio
{
    public class cArchivoInstruccion : cArchivo
    {

        cDatos oDatos = new cDatosSQL();

        public void Insertar_Pago(String cUser, String cAgencia, DateTime dFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            String[] cCampos = cLinea.Split(new Char[] { ',' });

            try
            {
                if (nNroLinea > 0)
                {
                    if (cCampos[0].ToString() == "PAY")
                    {
                        string cCampo2;
                        if (String.IsNullOrEmpty(cCampos[2].ToString()))
                            cCampo2 = "1999-01-01 00:00:00";
                        else
                            cCampo2 = cCampos[2].ToString();

                        oDatos.Ejecutar("spu_Bim_InsertaPago", cUser, cAgencia, DateTime.Now, cNombreArchivo, nNroLinea,
                            cCampos[0].ToString(), cCampos[1].ToString(), cCampo2, Convert.ToDouble(validaCampoNumerico(cCampos[3].ToString())), cCampos[4].ToString(),
                            cCampos[5].ToString(), cCampos[6].ToString(), cCampos[7].ToString(), cCampos[8].ToString(), cCampos[9].ToString(),0);
                    }
                    if (cCampos[0].ToString() == "REVDEPR")
                    {
                        oDatos.Ejecutar("spu_Bim_ActualizarReversaDeposito", cUser, cAgencia, dFechaSistema, cNombreArchivo, nNroLinea,
                            cCampos[0].ToString(), cCampos[1].ToString(), cCampos[2].ToString(), cCampos[3].ToString(), cCampos[4].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public DataTable Generar_RespuestaPago(String cUser, String cAgencia, DateTime dFechaSistema, String cCodigoBanco, Double nMonto, DateTime dFecha, String cMensaje, String nIDInstruccionPago, int nIDPago, Boolean bEsSuccess) //UQMA Se agrego parametro bEsSuccess
        {
            return oDatos.TraerDataTable("spu_Bim_GenerarRespuestaPago", cUser, cAgencia, dFechaSistema, cCodigoBanco, nMonto, dFecha, cMensaje, nIDInstruccionPago, nIDPago, bEsSuccess); //UQMA Se agrego parametro bEsSuccess
            //oDatos.Ejecutar("spu_Bim_RespuestaPago", cUser, cAgencia, dFechaSistema, cCodigoBanco, nMonto, dFecha, cMensaje, nIDInstruccionPago, nIDPago);
        }

        public DataSet Obtener_RespuestaPago(int nMovNro)
        {
            return oDatos.TraerDataSet("spu_Bim_ObtenerRespuestaPago", nMovNro);
            //oDatos.Ejecutar("spu_Bim_RespuestaPago", cUser, cAgencia, dFechaSistema, cCodigoBanco, nMonto, dFecha, cMensaje, nIDInstruccionPago, nIDPago);
        }

        public String validaCampoNumerico(String cValor)
        {
            if (String.IsNullOrEmpty(cValor))
            {
                return "0";
            }
            else
                return cValor.ToString();
        }

        public DataTable Mostrar_Pagos(DateTime dFechaSistema)
        {
            DataTable Pagos;
            try
            {
                Pagos = oDatos.TraerDataTable("spu_Bim_MostrarPagos", dFechaSistema);
                //oDatos.Ejecutar("spu_Bim_ObtenerPagos", dFechaSistema);                
            }
            catch (Exception)
            {
                //throw new Exception(ex.Message);
                Pagos = null;
            }
            return Pagos;
        }

        public DataSet ObtenerCabecera()
        {
            return oDatos.TraerDataSet("spu_Bim_ObtieneCabecera");
        }

        public DateTime Obtiene_FechaSistema()
        {
            String cFecha = "01/01/1900";
            DataSet oFecha = oDatos.TraerDataSet("spu_Bim_ObtieneFechaSistema");

            foreach (DataRow row in oFecha.Tables[0].Rows)
            {
                cFecha = row["cFecha"].ToString();

            }
            IFormatProvider cultura = new CultureInfo("es-PE");

            return DateTime.Parse(cFecha, cultura);
        }
        public DataSet BuscarPersona(String txtBuscar)
        {
            return oDatos.TraerDataSet("spu_Bim_BuscarPersona", txtBuscar);
        }
        
        //public DataTable Insertar_Deposito(String cUser, String cAgencia, DateTime dFechaSistema, String cNroCelular, String cNombre, String cApellido, Double nMonto, String cMensaje, int nEsCompensacion) //UQMA Se comento
        public DataTable Insertar_Deposito(String cUser, String cAgencia, DateTime dFechaSistema, String cNroCelular, String cNombre, String cApellido, Double nMonto, String cMensaje, int nEsCompensacion, int nidlogArchivosNetting, int nidlogArchProcDep, Boolean EsSuccess) // UQMA Para insertar deposito
        {
            //return oDatos.TraerDataTable("spu_Bim_InsertarDeposito", cUser, cAgencia, dFechaSistema, cNroCelular, cNombre, cApellido, nMonto, cMensaje, nEsCompensacion);  //UQMA Se comento
            //oDatos.Ejecutar("spu_Bim_RespuestaPago", cUser, cAgencia, dFechaSistema, cCodigoBanco, nMonto, dFecha, cMensaje, nIDInstruccionPago, nIDPago);

            // UQMA Para insertar deposito
            return oDatos.TraerDataTable("spu_Bim_InsertarDeposito", cUser, cAgencia, dFechaSistema, cNroCelular, cNombre, cApellido, nMonto, cMensaje, nEsCompensacion, nidlogArchivosNetting, nidlogArchProcDep, EsSuccess); 
            
        }
        public DataTable Buscar_Deposito(DateTime dFechaIni, DateTime dFechaFin, int nEstado)
        {
            return oDatos.TraerDataTable("spu_Bim_BuscarDeposito", dFechaIni, dFechaFin, nEstado);            
        }
        public DataSet Obtener_Deposito(String cNombreArchivo,int nMovNro)
        {
            return oDatos.TraerDataSet("spu_Bim_ObtenerDeposito", cNombreArchivo, nMovNro);            
        }
        public DataSet Confirmar_Deposito(int nMovNro)
        {
            return oDatos.TraerDataSet("spu_Bim_ConfirmarDeposito", nMovNro);            
        }
        public DataTable Revertir_Deposito(String cNombreArchivo, int nMovNro)
        {
            return oDatos.TraerDataTable("spu_Bim_RevertirDeposito", cNombreArchivo, nMovNro);            
        }
        public DataTable Insertar_ReversaDeposito(String cUser, String cAgencia, DateTime dFechaSistema, int nMovDeposito, String cMensaje)
        {
            return oDatos.TraerDataTable("spu_Bim_InsertarReversaDeposito", cUser, cAgencia, dFechaSistema, nMovDeposito,cMensaje);
        }
        public DataSet Obtener_ReversaDeposito(String cNombreArchivo, int nMovNro)
        {
            return oDatos.TraerDataSet("spu_Bim_RevertirDeposito", cNombreArchivo, nMovNro);
        }
        public DataTable Buscar_Compensacion(DateTime dFechaIni, DateTime dFechaFin)
        {
            return oDatos.TraerDataTable("spu_Bim_MontosRecibidosNetting", dFechaIni, dFechaFin);
        }

        //UQMA 03/10/2017 para obtener el nro de referencia para los depositos por compensacion
        public String Obtiene_Ref_DepComp(int nIdLogArchivosNet, String cBancoDestino, String cBancoOrigen, String cMoneda, Double nMonto, ref int nIdLogArchiProcDep)
        {
            String cRef = "";
            DataSet oFecha = oDatos.TraerDataSet("spu_Bim_ObtenerRefDepComp", nIdLogArchivosNet, cBancoDestino, cBancoOrigen, cMoneda, nMonto);

            foreach (DataRow row in oFecha.Tables[0].Rows)
            {
                cRef = row["cID"].ToString();
                nIdLogArchiProcDep = int.Parse(row["nIdLogArchivos"].ToString());

            }
            return cRef;
        }

        //UQMA 17/10/2017 Buscamos las compensaciones
        public void Buscar_y_EnviarCorreo(DateTime dFechaIni, DateTime dFechaFin)
        {
            DataSet oConsulta = oDatos.TraerDataSet("spu_Bim_BI_CompensacionCorreo", dFechaIni, dFechaFin);
            String sHTMLCuerpo = "";

            string fechas = "";
            if (dFechaIni == dFechaFin)
            {
                fechas = "DEL " + dFechaIni.ToString("dd-MM-yyyy");
            }
            else
            {
                fechas = "DEL " + dFechaIni.ToString("dd-MM-yyyy") + " AL " + dFechaFin.ToString("dd-MM-yyyy");
            }

            if (oConsulta.Tables[0].Rows.Count > 0) //si encuentra resultados, establecemos cabecera
            {

                //sHTMLCuerpo = "<table border = 1 bordercolor= #d14646 cellpadding =8 cellspacing = 0>"
                sHTMLCuerpo = "<table>"
                            + "<tr>"
                            + "<th > Moneda</th>"
                            + "<th > Banco Origen</th>"
                            + "<th> Banco Destino </th>"
                            + "<th > Monto Por Pagar</th>"
                            + "<th > Monto Por Cobrar </th>"
                            + "<th > Diferencia Monto </th>"
                            + "</tr>";

            }

            foreach (DataRow row in oConsulta.Tables[0].Rows)
            {
                sHTMLCuerpo = sHTMLCuerpo + "<tr>"
                                         + "<td>" + row["cMoneda"].ToString() + "</td>"
                                         + "<td>" + row["cBancoOrigen"].ToString() + "</td>"
                                         + "<td>" + row["cBancoDestino"].ToString() + "</td>"
                                         + "<td>" + Double.Parse(row["nMontoEnviado"].ToString()).ToString("N2") + "</td>"
                                         + "<td>" + Double.Parse(row["nMontoRecibido"].ToString()).ToString("N2") + "</td>"
                                         + "<td>" + Double.Parse(row["nDiferenciaMonto"].ToString()).ToString("N2") + "</td>"
                                         + "</tr>";

            }
            if (sHTMLCuerpo != "")
            {
                sHTMLCuerpo = "<p align=center> <b> COMPENSACIONES " + fechas + " </b> </p>" + sHTMLCuerpo + "</table>";
                // sHTMLCuerpo += "</table>";
            }
            else
            {
                sHTMLCuerpo = "<p align=center> <b> COMPENSACIONES " + fechas + " </b> </p> <p> No se encontro Compensaciones. </p>";
            }

            int i = oDatos.Ejecutar("spu_Bim_EnvioAlerta", sHTMLCuerpo);
        }
        public void EnviarCorreo(string mensaje)
        {
            int i = oDatos.Ejecutar("spu_Bim_EnvioAlerta", mensaje);
        }
    }
}
