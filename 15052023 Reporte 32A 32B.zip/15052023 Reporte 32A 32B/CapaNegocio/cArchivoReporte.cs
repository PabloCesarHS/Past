﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using System.Data;
using System.Globalization;
using System.Reflection; /* 04072023 HSPC - Se agrega nueva referencia */

namespace CapaNegocio
{
    public class cArchivoReporte : cArchivo
    {
        cDatos oDatos = new cDatosSQL();

        public void Insertar_BalanceCuentas(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            String[] cCampos = cLinea.Split(new Char[] { ',' });
            try
            {
                if (nNroLinea > 0)
                {
                    //oDatos.Ejecutar("spu_Bim_InsertaSaldosBilletera", cUser, cAgencia, cFechaSistema, cNombreArchivo, nNroLinea,
                    //        cCampos[0].ToString(), cCampos[1].ToString(), cCampos[2].ToString(), cCampos[3].ToString(), cCampos[4].ToString(),
                    //        cCampos[5].ToString(), Convert.ToDouble(cCampos[6].ToString()), cCampos[7].ToString(), cCampos[8].ToString());
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message);
                throw new Exception("Error en archivo " + cNombreArchivo.ToString() + ", " + ex.Message);
            }
        }

        public String validaCampoNumerico(String cValor)
        {
            if (String.IsNullOrEmpty(cValor))
            {                
                return "0";
            }
            else
                return cValor.ToString(); 
        }
        //public String validaCampo(String cValor)
        //{
        //    if (String.IsNullOrEmpty(cValor))
        //    {
        //        return "";
        //    }
        //    else
        //        return cValor.ToString();
        //}

        public void Insertar_LogTransacciones(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            String cIdTransaccion;
            String cTransaccionFinancieraID;
            String cExternalTransactionID;

            String[] cCampos = cLinea.Split(new Char[] { ',' });
            try
            {
                cIdTransaccion = validaCampoNumerico(cCampos[0].ToString());
                cTransaccionFinancieraID = validaCampoNumerico(cCampos[1].ToString()); 
                cExternalTransactionID = cCampos[2].ToString(); 

                //oDatos.Ejecutar("spu_Bim_InsertaLogTransacciones", cUser, cAgencia, cFechaSistema, cNombreArchivo, nNroLinea,
                //        cIdTransaccion, cTransaccionFinancieraID, cExternalTransactionID,cCampos[3].ToString(), cCampos[4].ToString(),
                //        cCampos[5].ToString(), cCampos[6].ToString(), cCampos[7].ToString(), cCampos[8].ToString(), cCampos[9].ToString(),
                //        cCampos[10].ToString(), cCampos[11].ToString(), validaCampoNumerico(cCampos[12].ToString()), validaCampoNumerico(cCampos[13].ToString()), validaCampoNumerico(cCampos[14].ToString()),
                //        cCampos[15].ToString(), cCampos[16].ToString(), cCampos[17].ToString(), cCampos[18].ToString(), cCampos[19].ToString(),
                //        cCampos[20].ToString(), validaCampoNumerico(cCampos[21].ToString()), validaCampoNumerico(cCampos[22].ToString()), validaCampoNumerico(cCampos[23].ToString()), cCampos[24].ToString(),
                //        validaCampoNumerico(cCampos[25].ToString()), cCampos[26].ToString(), cCampos[27].ToString(), cCampos[28].ToString(), cCampos[29].ToString());
            }
            catch (Exception ex)
            {
                throw new Exception("Error en archivo " + cNombreArchivo.ToString() +", "+ ex.Message);
            }
        }

        //public void Insertar_LogUser(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        //{
        //    String[] cCampos = cLinea.Split(new Char[] { ',' });
        //    try
        //    {
        //        oDatos.Ejecutar("spu_Bim_InsertaLogUsuarios", cUser, cAgencia, cFechaSistema, cNombreArchivo, nNroLinea,
        //                cCampos[0].Trim().ToString(), cCampos[1].ToString(), cCampos[2].ToString(), cCampos[3].ToString(), cCampos[4].ToString(),
        //                cCampos[5].ToString(), cCampos[6].ToString(), cCampos[7].ToString(), cCampos[8].ToString(), cCampos[9].ToString(),
        //                cCampos[10].ToString(), cCampos[11].ToString(), cCampos[12].ToString(), cCampos[13].ToString(), cCampos[14].ToString(),
        //                cCampos[15].ToString(), cCampos[16].ToString(), cCampos[17].ToString(), cCampos[18].ToString(), cCampos[19].ToString(),
        //                cCampos[20].ToString(), cCampos[21].ToString(), cCampos[22].ToString());

        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.Message);
        //    }
        //} // 15/08/2017 UQMA Comento

        public void Insertar_Netting(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            //Obtener los caampos

            String[] cCampos = cLinea.Split(new Char[] { ',' });
            try
            {
                if (cCampos.Length == 6)
                {
                    //oDatos.Ejecutar("spu_Bim_InsertaReporteNetting", cUser, cAgencia, cFechaSistema, cNombreArchivo, nNroLinea, cCampos[0].ToString(), cCampos[1].ToString(), Convert.ToDouble(cCampos[2].ToString()), Convert.ToDouble(cCampos[3].ToString()),
                        //Convert.ToDouble(cCampos[4].ToString()), cCampos[5].ToString(), "", "");
                }
                else
                {
                    //oDatos.Ejecutar("spu_Bim_InsertaReporteNetting", cUser, cAgencia, cFechaSistema, cNombreArchivo, nNroLinea, cCampos[0].ToString(), cCampos[1].ToString(), cCampos[2].ToString(), cCampos[3].ToString(),
                        //cCampos[4].ToString(), cCampos[5].ToString(), cCampos[6].ToString(), cCampos[7].ToString());
                }
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message);
                throw new Exception("Error en archivo " + cNombreArchivo.ToString() + ", " + ex.Message);
            }
        }

        public void Insertar_Comisiones(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            //Obtener los caampos
            String[] cCampos = cLinea.Split(new Char[] { ',' });
            try
            {
                //Double nMonto = Double.Parse(cCampos[9].ToString().Replace("PEN", ""));
                //Double nComision = Double.Parse(cCampos[10].ToString().Replace("PEN", ""));
                //oDatos.Ejecutar("spu_Bim_InsertaComision", cUser, cAgencia, cFechaSistema, cNombreArchivo, nNroLinea,
                //        cCampos[0].ToString(), cCampos[1].ToString(), cCampos[2].ToString(), cCampos[3].ToString(), cCampos[4].ToString(),
                //        cCampos[5].ToString(), cCampos[6].ToString(), cCampos[7].ToString(), cCampos[8].ToString(), Convert.ToDouble(cCampos[9].ToString().Replace("PEN","").Trim()),
                //        Convert.ToDouble(cCampos[10].ToString().Replace("PEN", "").Trim()), cCampos[11].ToString(), cCampos[12].ToString(), cCampos[13].ToString(), cCampos[14].ToString());
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message);
                throw new Exception("Error en archivo " + cNombreArchivo.ToString() + ", " + ex.Message);
            }
        }

        public void Insertar_Interoperabilidad(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            String[] cCampos = cLinea.Split(new Char[] { ',' });
            try
            {
                String cTranExterna;
                if (String.IsNullOrEmpty(cCampos[2].ToString()))
                    cTranExterna = "0";
                else
                    cTranExterna = cCampos[2].ToString();

                //oDatos.Ejecutar("spu_Bim_Interoperabilidad", cUser, cAgencia, cFechaSistema, cNombreArchivo, nNroLinea,
                //        cCampos[0].ToString(), cCampos[1].ToString(), cTranExterna, cCampos[3].ToString(), cCampos[4].ToString(),
                //        cCampos[5].ToString(), cCampos[6].ToString(), cCampos[7].ToString(), cCampos[8].ToString(), cCampos[9].ToString(),
                //        cCampos[10].ToString(), cCampos[11].ToString(), Convert.ToDouble(cCampos[12].ToString()), Convert.ToDouble(cCampos[13].ToString()), Convert.ToDouble(cCampos[14].ToString()),
                //        cCampos[15].ToString(), cCampos[16].ToString(), cCampos[17].ToString(), cCampos[18].ToString(), cCampos[19].ToString(),
                //        cCampos[20].ToString(), Convert.ToDouble(cCampos[21].ToString()),Convert.ToDouble(cCampos[22].ToString()),Convert.ToDouble(cCampos[23].ToString()), cCampos[24].ToString(),
                //        Convert.ToDouble(cCampos[25].ToString()), cCampos[26].ToString(), cCampos[27].ToString(), cCampos[28].ToString(), cCampos[29].ToString());
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message);
                throw new Exception("Error en archivo " + cNombreArchivo.ToString() + ", " + ex.Message);
            }
            
        }
        public void Insertar_Fee(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            String[] cCampos = cLinea.Split(new Char[] { ',' });
            try
            {
                //oDatos.Ejecutar("spu_Bim_InsertarFee", cUser, cAgencia, cFechaSistema, cNombreArchivo, nNroLinea,
                //        cCampos[0].ToString(), cCampos[1].ToString(), cCampos[2].ToString(), cCampos[3].ToString(), cCampos[4].ToString(),
                //        cCampos[5].ToString(), Convert.ToDouble(cCampos[6].ToString()));
            }
            catch (Exception ex)    
            {
                //throw new Exception(ex.Message);
                throw new Exception("Error en archivo " + cNombreArchivo.ToString() + ", " + ex.Message);
            }
        }

        public void Insertar_InformacionComercial(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            String[] cCampos = cLinea.Split(new Char[] { ',' });
            try
            {
                //oDatos.Ejecutar("spu_Bim_InsertarInfoComercial", cUser, cAgencia, cFechaSistema, cNombreArchivo, nNroLinea,
                //        cCampos[0].ToString(), cCampos[1].ToString(), cCampos[2].ToString(), cCampos[3].ToString(), cCampos[4].ToString(),
                //        cCampos[5].ToString(), cCampos[6].ToString(), cCampos[7].ToString());
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message);
                throw new Exception("Error en archivo " + cNombreArchivo.ToString() + ", " + ex.Message);
            }
        }

        //public void Insertar_Reporte32A(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        //{
        //    String cCodigoFormato;
        //    String cAnexo;
        //    String cEntidad;
        //    String cFecha;            
        //    String cExpMontos;
        //    String cDatosControl;
        //    String cCodFila;
        //    Double nDineroCirculacion;
        //    Double nFideicomiso;
        //    String cDetalle;
        //    String cEntidadNull;
            
        //    String[] cCampos = cLinea.Split(new Char[] { ',' });
        //    String cCampo = cCampos[0].ToString();

        //    IFormatProvider cultura = new CultureInfo("es-PE");
        //    try
        //    {
        //        if (nNroLinea == 0)//Cabecera
        //        {

        //           cEntidadNull = cCampo.Substring(6,4);    //Validacion null
        //           cCodigoFormato = cCampo.Substring(0, 4);
        //           cAnexo = cCampo.Substring(4, 2);

        //           if (cEntidadNull != "null")
        //           {
        //               cEntidad = cCampo.Substring(6, 5);
        //               cFecha = cCampo.Substring(11, 8).ToString(); //Obtine fecha yyyymmdd
        //               cFecha = cFecha.Substring(6, 2) + "/" + cFecha.Substring(4, 2) + "/" + cFecha.Substring(0, 4);//Establece formaro fecha 
        //               cExpMontos = cCampo.Substring(19, 3);
        //               cDatosControl = cCampo.Substring(22, 15);
        //           }
        //           else
        //           {
        //               cEntidad = "00106";
        //               cFecha = cCampo.Substring(10, 8).ToString(); //Obtine fecha yyyymmdd
        //               cFecha = cFecha.Substring(6, 2) + "/" + cFecha.Substring(4, 2) + "/" + cFecha.Substring(0, 4);//Establece formaro fecha 
        //               cExpMontos = cCampo.Substring(18, 3);
        //               cDatosControl = cCampo.Substring(21, 15);
        //           }
                    
        //           oDatos.Ejecutar("spu_Bim_Insertar_Reporte32ACabecera", cUser, cAgencia, cFechaSistema, cNombreArchivo, nNroLinea,
        //                   cCodigoFormato, cAnexo, cEntidad, DateTime.Parse(cFecha,cultura), cExpMontos,cDatosControl);
        //        }
        //        else                
        //        {                    
        //            cCodFila = cCampo.Substring(0, 6);
        //            nDineroCirculacion = Convertir_AMonto(cCampo.Substring(6, 18));
        //            nFideicomiso = Convertir_AMonto(cCampo.Substring(24, 18));
        //            cDetalle="";

        //            oDatos.Ejecutar("spu_Bim_Actualiza_Reporte32A", cUser, cAgencia, cFechaSistema, cNombreArchivo, nNroLinea,
        //                   cCodFila, nDineroCirculacion, nFideicomiso,cDetalle);
        //        }                
        //    }
        //    catch (Exception ex)
        //    {                
        //        throw new Exception("Error en archivo " + cNombreArchivo.ToString() + ", " + ex.Message);
        //    }
        //} // 15/08/2017 UQMA Comento



        // 15/08/2017 INICIO UQMA inserta datos de los reportes 32 A Y B

        public void Insertar_LogUser(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            String[] cCampos = cLinea.Split(new Char[] { ',' });
            string cCampo24 = "";
            string cCampo25 = "";
            string cCampo26 = "";
            string cCampo27 = "";
            string cCampo28 = "";
            string cCampo29 = "";


            try
            {
                switch (cCampos.Length)
                {
                    case 25:
                        cCampo24 = cCampos[24].ToString();
                        break;
                    case 26:
                        cCampo24 = cCampos[24].ToString();
                        cCampo25 = cCampos[25].ToString();
                        break;
                    case 27:
                        cCampo24 = cCampos[24].ToString();
                        cCampo25 = cCampos[25].ToString();
                        cCampo26 = cCampos[26].ToString();
                        break;
                    case 28:
                        cCampo24 = cCampos[24].ToString();
                        cCampo25 = cCampos[25].ToString();
                        cCampo26 = cCampos[26].ToString();
                        cCampo27 = cCampos[27].ToString();
                        break;
                    case 29:
                        cCampo24 = cCampos[24].ToString();
                        cCampo25 = cCampos[25].ToString();
                        cCampo26 = cCampos[26].ToString();
                        cCampo27 = cCampos[27].ToString();
                        cCampo28 = cCampos[28].ToString();
                        break;
                    case 30:
                        cCampo24 = cCampos[24].ToString();
                        cCampo25 = cCampos[25].ToString();
                        cCampo26 = cCampos[26].ToString();
                        cCampo27 = cCampos[27].ToString();
                        cCampo28 = cCampos[28].ToString();
                        cCampo29 = cCampos[29].ToString();
                        break;
                }
                //oDatos.Ejecutar("spu_Bim_InsertaLogUsuarios", cUser, cAgencia, cFechaSistema, cNombreArchivo, nNroLinea,
                //            cCampos[0].Trim().ToString(), cCampos[1].ToString(), cCampos[2].ToString(), cCampos[3].ToString(), cCampos[4].ToString(),
                //            cCampos[5].ToString(), cCampos[6].ToString(), cCampos[7].ToString(), cCampos[8].ToString(), cCampos[9].ToString(),
                //            cCampos[10].ToString(), cCampos[11].ToString(), cCampos[12].ToString(), cCampos[13].ToString(), cCampos[14].ToString(),
                //            cCampos[15].ToString(), cCampos[16].ToString(), cCampos[17].ToString(), cCampos[18].ToString(), cCampos[19].ToString(),
                //            cCampos[20].ToString(), cCampos[21].ToString(), cCampos[22].ToString()
                //            , cCampo24, cCampo25, cCampo26, cCampo27, cCampo28, cCampo29);


            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #region Reporte32A
        public void Insertar_Reporte32A(String cUser, String cAgencia, DateTime dFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            //Para obtener datos de la cabecera
            String cCodigoFormato;
            String cAnexo;
            String cCodigoEmpresa;
            String cFecha;
            String cExpMontos;
            int cDatosControl;
            //para los datos de la columna
            int nCodFila;
            Double nDineroElectronico;
            Double nFideicometido;

            /* INICIO 04072023 HSPC - Se agrega nuevos datos */
            Double nValorDisposicionInmediata = 0;
            Double nValorGarantia = 0;
            /* FIN 04072023 HSPC - Se agrega nuevos datos */

            String[] cCampos = cLinea.Split(new Char[] { ',' });
            String cCampo = cCampos[0].ToString();

            IFormatProvider cultura = new CultureInfo("es-PE");

            try
            {
                if (nNroLinea == 0)//Cabecera
                {
                    //para la cabecera
                    cCodigoFormato = cCampo.Substring(0, 4);
                    cAnexo = cCampo.Substring(4, 2);
                    cCodigoEmpresa = cCampo.Substring(6, 5);
                    cFecha = cCampo.Substring(11, 8);
                    cExpMontos = cCampo.Substring(19, 3);
                    cDatosControl = int.Parse(cCampo.Substring(22, 15));


                    //oDatos.Ejecutar("spu_Bim_Insertar_Reporte32Cabecera", cUser, cAgencia, dFechaSistema, cNombreArchivo, nNroLinea
                    //   , cCodigoFormato, cAnexo, cCodigoEmpresa, Convert.ToDateTime(cFecha), cExpMontos, Int32.Parse(cDatosControl));

                    cFecha = cFecha.Substring(6, 2) + "/" + cFecha.Substring(4, 2) + "/" + cFecha.Substring(0, 4);

                    oDatos.Ejecutar("spu_Bim_Insertar_Reporte32Cabecera", cUser, cAgencia, dFechaSistema, cNombreArchivo
                      , cCodigoFormato, cAnexo, cCodigoEmpresa, cFecha, cExpMontos, cDatosControl);
                }
                else
                {
                    //para los datos de la columna
                    nCodFila = int.Parse(cCampo.Substring(0, 6));
                    nDineroElectronico = Convertir_AMonto(cCampo.Substring(6, 18));
                    nFideicometido = Convertir_AMonto(cCampo.Substring(24, 18));

                    /* INICIO 04072023 HSPC - Se agrega nuevos datos */
                    if (cCampo.Length > 42)
                    {
                        nValorDisposicionInmediata = Convertir_AMonto(cCampo.Substring(42, 18));
                        nValorGarantia = Convertir_AMonto(cCampo.Substring(60, 18));
                    }
                    /* FIN 04072023 HSPC - Se agrega nuevos datos */

                    //oDatos.Ejecutar("spu_Bim_Insertar_Reporte32A", cNombreArchivo, nNroLinea, nCodFila, nDineroElectronico, nFideicometido);

                    oDatos.Ejecutar("spu_Bim_Insertar_Reporte32A", cNombreArchivo, nNroLinea, nCodFila, nDineroElectronico, nFideicometido, nValorDisposicionInmediata, nValorGarantia);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error en Archivo " + cNombreArchivo.ToString() + ", " + ex.Message);
            }
        }

        public DataTable Recuperar_Reporte32A(string fecha)
        {
            try
            {
                return oDatos.TraerDataTable("BimReporte32ARecuperar_spu", DateTime.Parse(fecha));

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /* INICIO 04072023 HSPC - Se agrega nuevo metodo que devuelve una lista de objetos */
        public List<cDataReporte32A> Recuperar_Reporte32ALista(string fecha)
        {
            try
            {
                return cTransformador.ConvertirDataTableAClase<cDataReporte32A>(oDatos.TraerDataTable("BimReporte32ARecuperar_spu", DateTime.Parse(fecha)));
            }
            catch (Exception ex)
            {                
                //return null;
                return new List<cDataReporte32A>();
                throw new Exception(ex.Message);
            }
        }

        /* FIN 04072023 HSPC - Se agrega nuevo metodo que devuelve una lista de objetos */
        public void Editar_Reporte32A(int id_RepA, string cfidecometido)
        {
            try
            {
                oDatos.Ejecutar("BimReporte32AEditar_spu", id_RepA, cfidecometido);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /* INICIO 04072023 HSPC - Se agrega nuevo metodo con parametros adicionales */
        public void Editar_Reporte32A(int id_RepA, string cfidecometido, double nValorDisposicionInmediata, double nValorGarantia)
        {
            try
            {
                oDatos.Ejecutar("BimReporte32AEditar_spu", id_RepA, cfidecometido, nValorDisposicionInmediata, nValorGarantia);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        /* FIN 04072023 HSPC - Se agrega nuevo metodo con parametros adicionales */

        #endregion Reporte32A

        #region Reporte32BI
        public void Insertar_Reporte32B_I(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            //Para obtener datos de la cabecera
            String cCodigoFormato;
            String cAnexo;
            String cCodigoEmpresa;
            String cFecha;
            String cExpMontos;
            int cDatosControl;
            //para los datos de la columna
            int nCodFila;
            Double nMontoConver;
            int nNroOperacionesConver;
            Double nMontoTransfPago;
            int nNroOperacionesTransfPago;
            Double nMontoReconversiones;
            int nNroOperacionesReconversiones;
            Double nMontoOtros;
            int nNroOperacionesotros;
            Double nTipoCambio;

            /*  */
            //int nNroOperacionesotros;
            //Double nTipoCambio;
            //int nNroOperacionesotros;
            //Double nTipoCambio;
            /*  */

            String[] cCampos = cLinea.Split(new Char[] { ',' });
            String cCampo = cCampos[0].ToString();

            IFormatProvider cultura = new CultureInfo("es-PE");

            try
            {
                if (nNroLinea == 0)//Cabecera
                {
                    //para la cabecera
                    cCodigoFormato = cCampo.Substring(0, 4);
                    cAnexo = cCampo.Substring(4, 2);
                    cCodigoEmpresa = cCampo.Substring(6, 5);
                    cFecha = cCampo.Substring(11, 8);
                    cExpMontos = cCampo.Substring(19, 3);
                    cDatosControl = int.Parse(cCampo.Substring(22, 15));

                    cFecha = cFecha.Substring(6, 2) + "/" + cFecha.Substring(4, 2) + "/" + cFecha.Substring(0, 4);

                    //oDatos.Ejecutar("spu_Bim_Insertar_Reporte32Cabecera", cUser, cAgencia, cFechaSistema, cNombreArchivo
                    //    , cCodigoFormato, cAnexo, cCodigoEmpresa, cFecha, cExpMontos, cDatosControl);
                }
                else
                {
                    //para los datos de la columna
                    nCodFila = int.Parse(cCampo.Substring(0, 6));
                    nMontoConver = Convertir_AMonto(cCampo.Substring(6, 18));
                    nNroOperacionesConver = int.Parse(cCampo.Substring(24, 18));
                    nMontoTransfPago = Convertir_AMonto(cCampo.Substring(42, 18));
                    nNroOperacionesTransfPago = int.Parse(cCampo.Substring(60, 18));

                    nMontoReconversiones = Convertir_AMonto(cCampo.Substring(78, 18));
                    nNroOperacionesReconversiones = int.Parse(cCampo.Substring(96, 18));
                    nMontoOtros = Convertir_AMonto(cCampo.Substring(114, 18));
                    nNroOperacionesotros = int.Parse(cCampo.Substring(132, 18));
                    nTipoCambio = Convertir_ATipoCambio(cCampo.Substring(150, 6));

                    /*  */

                    /*  */

                    //oDatos.Ejecutar("spu_Bim_Insertar_Reporte32B_I", cNombreArchivo, nNroLinea, nCodFila, nMontoConver, nNroOperacionesConver
                    //    , nMontoTransfPago, nNroOperacionesTransfPago, nMontoReconversiones, nNroOperacionesReconversiones
                    //    , nMontoOtros, nNroOperacionesotros, nTipoCambio);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error en Archivo " + cNombreArchivo.ToString() + ", " + ex.Message);
            }
        }

        public DataTable Recuperar_Reporte32BI(string fecha) // 19/03/2018 LVCH recupera registros del reporte32B_I
        {
            try
            {
                return oDatos.TraerDataTable("BimReporte32BIRecuperar_spu", DateTime.Parse(fecha));

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        /* INICIO 04072023 HSPC - Se agrega nuevo metodo que devuelve una lista de objetos */
        public List<cDataReporte32BI> Recuperar_Reporte32BILista(string fecha)
        {
            try
            {
                return cTransformador.ConvertirDataTableAClase<cDataReporte32BI>(oDatos.TraerDataTable("BimReporte32BIRecuperar_spu", DateTime.Parse(fecha)));

            }
            catch (Exception ex)
            {
                //return null;
                return new List<cDataReporte32BI>();
                throw new Exception(ex.Message);
            }
        }
        /* FIN 04072023 HSPC - Se agrega nuevo metodo que devuelve una lista de objetos */
        public void Editar_Reporte32BI(int id_RepBI, double nTipoCambio) // 20/03/2018 LVCH para editar el tipo de cambio en el reporte 32B_I
        {
            try
            {
                oDatos.Ejecutar("BimReporte32BIEditar_spu", id_RepBI, nTipoCambio);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        /* INICIO 04072023 HSPC - Se agrega nuevo metodo con parametros adicionales */
        public void Editar_Reporte32BI(int id_RepBI, double nMontoConver, int nNroOperacionesConver, double nMontoTransfPago, int nNroOperacionesTransfPago, double nMontoReconversiones, int nNroOperacionesReconversiones, double nMontoOtros, int nNroOperacionesotros, double nTipoCambio)
        {
            try
            {
                oDatos.Ejecutar("BimReporte32BIEditar_spu", id_RepBI, nMontoConver, nNroOperacionesConver, nMontoTransfPago, nNroOperacionesTransfPago, nMontoReconversiones, nNroOperacionesReconversiones, nMontoOtros, nNroOperacionesotros, nTipoCambio);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        /* FIN 04072023 HSPC - Se agrega nuevo metodo con parametros adicionales */
        #endregion Reporte32BI

        #region Reporte32BII
        public void Insertar_Reporte32B_II(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            //Para obtener datos de la cabecera
            String cCodigoFormato;
            String cAnexo;
            String cCodigoEmpresa;
            String cFecha;
            String cExpMontos;
            int cDatosControl;
            //para los datos de la columna
            int nCodFila;
            Double nMonedaNacional;
            Double nMonedaExtranjera;
            Double nTotal;

            String[] cCampos = cLinea.Split(new Char[] { ',' });
            String cCampo = cCampos[0].ToString();

            IFormatProvider cultura = new CultureInfo("es-PE");

            try
            {
                if (nNroLinea == 0)//Cabecera
                {
                    //para la cabecera
                    cCodigoFormato = cCampo.Substring(0, 4);
                    cAnexo = cCampo.Substring(4, 2);
                    cCodigoEmpresa = cCampo.Substring(6, 5);
                    cFecha = cCampo.Substring(11, 8);
                    cExpMontos = cCampo.Substring(19, 3);
                    cDatosControl = int.Parse(cCampo.Substring(22, 15));

                    cFecha = cFecha.Substring(6, 2) + "/" + cFecha.Substring(4, 2) + "/" + cFecha.Substring(0, 4);

                    //oDatos.Ejecutar("spu_Bim_Insertar_Reporte32Cabecera", cUser, cAgencia, cFechaSistema, cNombreArchivo
                    //    , cCodigoFormato, cAnexo, cCodigoEmpresa, cFecha, cExpMontos, cDatosControl);
                }
                else
                {
                    //para los datos de la columna
                    nCodFila = int.Parse(cCampo.Substring(0, 6));
                    nMonedaNacional = Convertir_AMonto(cCampo.Substring(6, 18));
                    nMonedaExtranjera = Convertir_AMonto(cCampo.Substring(24, 18));
                    nTotal = Convertir_AMonto(cCampo.Substring(42, 18));

                    //oDatos.Ejecutar("spu_Bim_Insertar_Reporte32B_II", cNombreArchivo, nNroLinea, nCodFila, nMonedaNacional, nMonedaExtranjera, nTotal);
                }

            }
            catch (Exception ex)
            {
                throw new Exception("Error en Archivo " + cNombreArchivo.ToString() + ", " + ex.Message);
            }
        }

        /* INICIO 04072023 HSPC - Se agrega nuevo metodo que devuelve una lista de objetos */
        public List<cDataReporte32BII> Recuperar_Reporte32BIILista(string fecha)
        {
            try
            {
                return cTransformador.ConvertirDataTableAClase<cDataReporte32BII>(oDatos.TraerDataTable("BimReporte32BIIRecuperar_spu", DateTime.Parse(fecha)));
            }
            catch (Exception ex)
            {
                //return null;
                return new List<cDataReporte32BII>();
                throw new Exception(ex.Message);
            }
        }
        /* FIN 04072023 HSPC - Se agrega nuevo metodo que devuelve una lista de objetos */

        /* INICIO 04072023 HSPC - Se agrega nuevo metodo con parametros adicionales */
        public void Editar_Reporte32BII(int id_RepBII, double nMonedaNacional, double nMonedaExtranjera, double nTotal)
        {
            try
            {
                oDatos.Ejecutar("BimReporte32BIIEditar_spu", id_RepBII, nMonedaNacional, nMonedaExtranjera, nTotal);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        /* FIN 04072023 HSPC - Se agrega nuevo metodo con parametros adicionales */

        #endregion Reporte32BII

        #region Reporte32BIII
        public void Insertar_Reporte32B_III(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            //Para obtener datos de la cabecera
            String cCodigoFormato;
            String cAnexo;
            String cCodigoEmpresa;
            String cFecha;
            String cExpMontos;
            int cDatosControl;
            //para los datos de la columna
            int nCodFila;
            //para cuentas simplificadas
            String nCtaSimNroDeCuentas;
            String nCtaSimNroDeTitu;
            //Cuentas Generales
            String nCtaGnrlNroDeCuentas;
            String nCtaGnrlNroDeTitu;


            String[] cCampos = cLinea.Split(new Char[] { ',' });
            String cCampo = cCampos[0].ToString();

            IFormatProvider cultura = new CultureInfo("es-PE");

            try
            {
                if (nNroLinea == 0)//Cabecera
                {
                    //para la cabecera
                    cCodigoFormato = cCampo.Substring(0, 4);
                    cAnexo = cCampo.Substring(4, 2);
                    cCodigoEmpresa = cCampo.Substring(6, 5);
                    cFecha = cCampo.Substring(11, 8);
                    cExpMontos = cCampo.Substring(19, 3);
                    cDatosControl = int.Parse(cCampo.Substring(22, 15));

                    cFecha = cFecha.Substring(6, 2) + "/" + cFecha.Substring(4, 2) + "/" + cFecha.Substring(0, 4);

                    oDatos.Ejecutar("spu_Bim_Insertar_Reporte32Cabecera", cUser, cAgencia, cFechaSistema, cNombreArchivo
                        , cCodigoFormato, cAnexo, cCodigoEmpresa, cFecha, cExpMontos, cDatosControl);
                }
                else
                {
                    //para los datos de la columna
                    nCodFila = int.Parse(cCampo.Substring(0, 6));
                    nCtaSimNroDeCuentas = cCampo.Substring(6, 18);
                    nCtaSimNroDeTitu = cCampo.Substring(24, 18);
                    nCtaGnrlNroDeCuentas = cCampo.Substring(42, 18);
                    nCtaGnrlNroDeTitu = cCampo.Substring(60, 18);

                    oDatos.Ejecutar("spu_Bim_Insertar_Reporte32B_III", cNombreArchivo, nNroLinea, nCodFila, nCtaSimNroDeCuentas
                        , nCtaSimNroDeTitu, nCtaGnrlNroDeCuentas, nCtaGnrlNroDeTitu);
                }

            }
            catch (Exception ex)
            {
                throw new Exception("Error en Archivo " + cNombreArchivo.ToString() + ", " + ex.Message);
            }
        }

        /* INICIO 04072023 HSPC - Se agrega nuevo metodo que devuelve una lista de objetos */
        public List<cDataReporte32BIII> Recuperar_Reporte32BIIILista(string fecha)
        {
            try
            {
                return cTransformador.ConvertirDataTableAClase<cDataReporte32BIII>(oDatos.TraerDataTable("BimReporte32BIIIRecuperar_spu", DateTime.Parse(fecha)));

            }
            catch (Exception ex)
            {
                //return null;
                return new List<cDataReporte32BIII>();
                throw new Exception(ex.Message);
            }
        }
        /* FIN 04072023 HSPC - Se agrega nuevo metodo que devuelve una lista de objetos */

        /* INICIO 04072023 HSPC - Se agrega nuevo metodo con parametros adicionales */
        public void Editar_Reporte32BIII(int id_RepBIII, int nCtaSimNroDeCuentas, int nCtaSimNroDeTitu, int nCtaGnrlNroDeCuentas, int nCtaGnrlNroDeTitu)
        {
            try
            {
                oDatos.Ejecutar("BimReporte32BIIIEditar_spu", id_RepBIII, nCtaSimNroDeCuentas, nCtaSimNroDeTitu, nCtaGnrlNroDeCuentas, nCtaGnrlNroDeTitu);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        /* FIN 04072023 HSPC - Se agrega nuevo metodo con parametros adicionales */

        #endregion Reporte32BIII

        #region Reporte32BIV
        public void Insertar_Reporte32B_IV(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            //Para obtener datos de la cabecera
            String cCodigoFormato;
            String cAnexo;
            String cCodigoEmpresa;
            String cFecha;
            String cExpMontos;
            int cDatosControl;
            //para los datos de la columna
            int nCodFila;
            Double nTotDineroElec;
            Double nValPatriFideicometido;

            /* INICIO 04072023 HSPC - Se agrega nuevos datos */
            Double nValorDisposicionInmediata = 0;
            Double nValorGarantia = 0;
            /* FIN 04072023 HSPC - Se agrega nuevos datos */

            String[] cCampos = cLinea.Split(new Char[] { ',' });
            String cCampo = cCampos[0].ToString();

            IFormatProvider cultura = new CultureInfo("es-PE");

            try
            {
                if (nNroLinea == 0)//Cabecera
                {
                    //para la cabecera
                    cCodigoFormato = cCampo.Substring(0, 4);
                    cAnexo = cCampo.Substring(4, 2);
                    cCodigoEmpresa = cCampo.Substring(6, 5);
                    cFecha = cCampo.Substring(11, 8);
                    cExpMontos = cCampo.Substring(19, 3);
                    cDatosControl = int.Parse(cCampo.Substring(22, 15));

                    cFecha = cFecha.Substring(6, 2) + "/" + cFecha.Substring(4, 2) + "/" + cFecha.Substring(0, 4);

                    //oDatos.Ejecutar("spu_Bim_Insertar_Reporte32Cabecera", cUser, cAgencia, cFechaSistema, cNombreArchivo
                    //     , cCodigoFormato, cAnexo, cCodigoEmpresa, cFecha, cExpMontos, cDatosControl);
                }
                else
                {
                    //para los datos de la columna
                    nCodFila = int.Parse(cCampo.Substring(0, 6));
                    nTotDineroElec = Convertir_AMonto(cCampo.Substring(6, 18));
                    nValPatriFideicometido = Convertir_AMonto(cCampo.Substring(24, 18));

                    /* INICIO 04072023 HSPC - Se agrega nuevos datos */
                    if (cCampo.Length > 42)
                    {
                        nValorDisposicionInmediata = Convertir_AMonto(cCampo.Substring(42, 18));
                        nValorGarantia = Convertir_AMonto(cCampo.Substring(60, 18));
                    }
                    /* FIN 04072023 HSPC - Se agrega nuevos datos */

                    //oDatos.Ejecutar("spu_Bim_Insertar_Reporte32B_IV", cNombreArchivo, nNroLinea, nCodFila, nTotDineroElec, nValPatriFideicometido);
                    //oDatos.Ejecutar("spu_Bim_Insertar_Reporte32B_IV", cNombreArchivo, nNroLinea, nCodFila, nTotDineroElec, nValPatriFideicometido, nValorDisposicionInmediata, nValorGarantia);
                }

            }
            catch (Exception ex)
            {
                throw new Exception("Error en Archivo " + cNombreArchivo.ToString() + ", " + ex.Message);
            }
        }

        public DataTable Recuperar_Reporte32BIV(string fecha)
        {
            try
            {
                return oDatos.TraerDataTable("BimReporte32BIVRecuperar_spu", DateTime.Parse(fecha));

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /* INICIO 04072023 HSPC - Se agrega nuevo metodo que devuelve una lista de objetos */
        public List<cDataReporte32BIV> Recuperar_Reporte32BIVLista(string fecha)
        {
            try
            {
                return cTransformador.ConvertirDataTableAClase<cDataReporte32BIV>(oDatos.TraerDataTable("BimReporte32BIVRecuperar_spu", DateTime.Parse(fecha)));

            }
            catch (Exception ex)
            {
                //return null;
                return new List<cDataReporte32BIV>();
                throw new Exception(ex.Message);                
            }
        }
        /* FIN 04072023 HSPC - Se agrega nuevo metodo que devuelve una lista de objetos */

        /* INICIO 04072023 HSPC - Se agrega nuevo metodo con parametros adicionales */
        public void Editar_Reporte32BIV(int id_RepBIV, double nTotDineroElec, double nValPatriFideicometido, double nValorDisposicionInmediata, double nValorGarantia)
        {
            try
            {
                oDatos.Ejecutar("BimReporte32BIVEditar_spu", id_RepBIV, nTotDineroElec, nValPatriFideicometido, nValorDisposicionInmediata, nValorGarantia);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        /* FIN 04072023 HSPC - Se agrega nuevo metodo con parametros adicionales */

        #endregion Reporte32BIV

        #region Reporte32BV

        /* INICIO 04072023 HSPC - Se agrega nueva clase ReporteBV */
        public class cDataReporte32BV : cDataReporteCabecera
        {
            public string nIdRepBV { get; set; }
            public string nIdCabecera { get; set; }
            public string cCodFila { get; set; }
            public string nTeléfono { get; set; }
            public string nTarjetaPrepago { get; set; }
            public string nOtro { get; set; }
            public string bEstado { get; set; }
            /*otros*/

            /*
            */

            public cDataReporte32BV()
            {
            }
        }
        /* FIN 04072023 HSPC - Se agrega nueva clase ReporteBV */

        public void Insertar_Reporte32B_V(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            //Para obtener datos de la cabecera
            String cCodigoFormato;
            String cAnexo;
            String cCodigoEmpresa;
            String cFecha;
            String cExpMontos;
            int cDatosControl;
            //para los datos de la columna
            int nCodFila;
            Double nTeléfonoMovil;
            Double nTarjetaPrepago;
            Double nOtro;

            String[] cCampos = cLinea.Split(new Char[] { ',' });
            String cCampo = cCampos[0].ToString();

            IFormatProvider cultura = new CultureInfo("es-PE");

            try
            {
                if (nNroLinea == 0)//Cabecera
                {
                    //para la cabecera
                    cCodigoFormato = cCampo.Substring(0, 4);
                    cAnexo = cCampo.Substring(4, 2);
                    cCodigoEmpresa = cCampo.Substring(6, 5);
                    cFecha = cCampo.Substring(11, 8);
                    cExpMontos = cCampo.Substring(19, 3);
                    cDatosControl = int.Parse(cCampo.Substring(22, 15));


                    cFecha = cFecha.Substring(6, 2) + "/" + cFecha.Substring(4, 2) + "/" + cFecha.Substring(0, 4);

                    oDatos.Ejecutar("spu_Bim_Insertar_Reporte32Cabecera", cUser, cAgencia, cFechaSistema, cNombreArchivo
                         , cCodigoFormato, cAnexo, cCodigoEmpresa, cFecha, cExpMontos, cDatosControl);
                }
                else
                {
                    //para los datos de la columna
                    nCodFila = int.Parse(cCampo.Substring(0, 6));
                    nTeléfonoMovil = Convertir_AMonto(cCampo.Substring(6, 9));
                    nTarjetaPrepago = Convertir_AMonto(cCampo.Substring(14, 18));
                    nOtro = Convertir_AMonto(cCampo.Substring(32, 18));

                    oDatos.Ejecutar("spu_Bim_Insertar_Reporte32B_V", cNombreArchivo, nNroLinea, nCodFila, nTeléfonoMovil, nTarjetaPrepago, nOtro);
                }

            }
            catch (Exception ex)
            {
                throw new Exception("Error en Archivo " + cNombreArchivo.ToString() + ", " + ex.Message);
            }
        }

        public DataTable Recuperar_Reporte32BV(string fecha)
        {
            try
            {
                return oDatos.TraerDataTable("BimReporte32BVRecuperar_spu", DateTime.Parse(fecha));

            }
            catch (Exception ex)
            {
                return null;
                throw new Exception(ex.Message);
            }
        }

        /* INICIO 04072023 HSPC - Se agrega nuevo metodo que devuelve una lista de objetos */
        public List<cDataReporte32BV> Recuperar_Reporte32BVLista(string fecha)
        {
            try
            {
                return cTransformador.ConvertirDataTableAClase<cDataReporte32BV>(oDatos.TraerDataTable("BimReporte32BVRecuperar_spu", DateTime.Parse(fecha)));

            }
            catch (Exception ex)
            {
                //return null;
                return new List<cDataReporte32BV>();
                throw new Exception(ex.Message);
            }
        }
        /* FIN 04072023 HSPC - Se agrega nuevo metodo que devuelve una lista de objetos */

        /* INICIO 04072023 HSPC - Se agrega nuevo metodo con parametros adicionales */
        public void Editar_Reporte32BV(int id_RepBIV, double nTeléfono, double nTarjetaPrepago, double nOtro)
        {
            try
            {
                oDatos.Ejecutar("BimReporte32BVEditar_spu", id_RepBIV, nTeléfono, nTarjetaPrepago, nOtro);

    }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        /* FIN 04072023 HSPC - Se agrega nuevo metodo con parametros adicionales */

        #endregion Reporte32BIV

        /* INICIO 04072023 HSPC - Se agrega nuevo metodo para listar detalle de carga de archivos */
        public cResultado Reporte_CargaListaArchivo(string ndTipo, string pdFechainicio)
        {
            try
            {
                return new cResultado(
                    0,
                    "Registro recuperado", oDatos.TraerDataTable("spu_Bim_Reporte_Carga_Detalle", ndTipo, pdFechainicio));
            }
            catch (Exception ex)
            {
                return new cResultado(3, ex.Message, null);
            }
        }
        /* FIN 04072023 HSPC - Se agrega nuevo metodo para listar detalle de carga de archivos */

        /* INICIO 04072023 HSPC - Se agrega nuevo metodo para listar detalle de carga de archivos */
        public cResultado Reporte_VerificacionArchivo(string NombreArchivo)
        {
            try
            {
                return new cResultado(
                    0,
                    "Registro recuperado",
                    oDatos.TraerDataTable("spu_Bim_ObtenerArchivoXNombreArchivo", NombreArchivo));
            }
            catch (Exception ex)
            {
                return new cResultado(3, ex.Message, null);
            }
        }
        /* FIN 04072023 HSPC - Se agrega nuevo metodo para listar detalle de carga de archivos */

        public Double Convertir_ATipoCambio(String cMonto)
        {
            Double nTipoCambio;
            int cParteEntera = Convert.ToInt16(cMonto.Substring(0, 3));
            int cParteDecimal = Convert.ToInt16(cMonto.Substring(3, 3));

            nTipoCambio = Convert.ToDouble(cParteEntera + "." + cParteDecimal);

            return nTipoCambio;
        }

        // 15/08/2017 FIN UQMA inserta datos de los reportes 32 A Y B

        public Double Convertir_AMonto(String cMonto)
        {
            Double nMonto;
            //int cParteEntera=Convert.ToInt16(cMonto.Substring(0,16));
            //int cParteDecimal = Convert.ToInt16(cMonto.Substring(16, 2));
            int cParteEntera = Convert.ToInt32(cMonto.Substring(0, 16)); //LVCH - 01/06/2020 se amplia cantidad maxima para conversion
            int cParteDecimal = Convert.ToInt32(cMonto.Substring(16, 2)); //LVCH - 01/06/2020 se amplia cantidad maxima para conversion

            nMonto = Convert.ToDouble(cParteEntera + "." + cParteDecimal);

            return nMonto; 
        }

        public void Insertar_Depositos(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea)
        {
            String[] cCampos = cLinea.Split(new Char[] { ',' });
            try
            {
                //oDatos.Ejecutar("spu_Bim_InsertarInfoComercial", cUser, cAgencia, cFechaSistema, cNombreArchivo, nNroLinea,
                //        cCampos[0].ToString(), cCampos[1].ToString(), cCampos[2].ToString(), cCampos[3].ToString(), cCampos[4].ToString(),
                //        cCampos[5].ToString(), cCampos[6].ToString(), cCampos[7].ToString());
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message);
                throw new Exception("Error en archivo " + cNombreArchivo.ToString() + ", " + ex.Message);
            }
        }

        //UQMA 03/10/2017 Para registrar los numeros de referencia de Depositos/Retiros
        public void Insertar_Compensacion(String cUser, String cAgencia, DateTime cFechaSistema, String cNombreArchivo, int nNroLinea, String cLinea
           , String cId, DateTime dFecha, String cEstado, String cParEstado, String cDepEstado, String cDescripcion, String cMotivoError, String cDe, String cPara, String cMoneda, Double nMonto, int EsDeposito)
        {

            try
            {
                oDatos.Ejecutar("spu_Bim_InsertaCompensacion", cUser
                    , cAgencia
                    , cFechaSistema
                    , cNombreArchivo
                    , nNroLinea
                    , cId
                    , dFecha
                    , cEstado
                    , cParEstado
                    , cDepEstado
                    , cDescripcion
                    , cMotivoError
                    , cDe
                    , cPara
                    , cMoneda
                    , nMonto
                    , EsDeposito
                    );

            }
            catch (Exception ex)
            {
                throw new Exception("Error en archivo " + cNombreArchivo.ToString() + ", " + ex.Message);
            }
        }        
    }
}