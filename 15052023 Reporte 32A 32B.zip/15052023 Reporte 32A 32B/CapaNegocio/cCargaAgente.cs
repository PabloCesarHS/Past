﻿using CapaDatos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class cCargaAgente //UQMA para cargar batch de agentes
    {
        cDatos oDatos = new cDatosSQL();

        public DataSet Listar(int pTipo)
        {
            //pTipo: 1 --Listamos los perfiles
            //pTipo: 2 --Listamos los grupos de Usuario
            return oDatos.TraerDataSet("spu_Bim_Listar", pTipo);
        }
        public DataTable Insertar_BatchAgente(String MSISDN, int Username, String Idioma, String ID, String Profilename
                                        , String CelularPadre, String cOperadorMovil, String PerfilGrupo, int GrupoID)
        {
            return oDatos.TraerDataTable("spu_Bim_InsertaBatchAgente", MSISDN, Username, Idioma, ID, Profilename
                                                            , CelularPadre, cOperadorMovil, PerfilGrupo
                                                            , GrupoID, Environment.UserName.ToString().ToUpper());
        }

        public int Recuperar_IdGroup(string ambiente)
        {
            int IdGroup = -1;
            DataSet oDatosId = oDatos.TraerDataSet("spu_BimRecuperaGroupId");
            foreach (DataRow row in oDatosId.Tables[0].Rows)
            {
                if (ambiente == "PRODUCCION")
                {
                    IdGroup = int.Parse(row["nGroupIdProd"].ToString());
                }
                else //ES TEST
                {
                    IdGroup = int.Parse(row["nGroupIdTest"].ToString());
                }
            }
            return IdGroup;
        }
        public string Recuperar_Inicial()
        {
            string sInicial = "";
            DataSet oDatosId = oDatos.TraerDataSet("spu_BimRecuperaGroupId");
            foreach (DataRow row in oDatosId.Tables[0].Rows)
            {
                sInicial = row["cIniciales"].ToString();
            }
            return sInicial;
        }
        public string Recuperar_SecAgentes()
        {
            string susername = "";
            DataSet oDatosId = oDatos.TraerDataSet("spu_Bim_ObtenerSecAgentes");
            foreach (DataRow row in oDatosId.Tables[0].Rows)
            {
                susername = row["cUsername"].ToString();
            }
            return susername;
        }

        public bool Existe_BatchAgente(string sMSISDN, string sDNI)
        {

            DataSet oDatosAgente = oDatos.TraerDataSet("spu_Bim_VerificarAgente", sMSISDN, sDNI);
            foreach (DataRow row in oDatosAgente.Tables[0].Rows)
            {
                return true;
            }

            return false;
        }

        public DataSet Obtener_BatchAgente(int nIdBimBatchAgentes, String cNombreArchivo)
        {
            return oDatos.TraerDataSet("spu_Bim_ObtenerBatchAgente",nIdBimBatchAgentes,cNombreArchivo);
        }
    }
}
