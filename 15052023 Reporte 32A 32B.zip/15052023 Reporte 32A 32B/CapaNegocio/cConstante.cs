﻿using CapaDatos;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static CapaNegocio.cConfiguracion; /* HSPC*/

namespace CapaNegocio
{
    public class cConstante
    {
        cDatos oDatos = new cDatosSQL(); //UQMA   05/10/2017


        /*                     Desarrollo  REPORTES PDP                       */
        //public string cpRutaOrigen = @"D:\PDP\PDPReportes\03-04-05-06-2016\";
        //public string cpRutaDestino = @"D:\PDP\PDPReportes\03-04-05-06-2016\" + DateTime.Now.ToString("yyyyMMdd");
        //public string cpDirectoryInfo =@"D:\PDP\PDPReportes\03-04-05-06-2016\";

        /*                     PRODUCCION  REPORTES PDP                       */
        //UQMA 05/10/2017 INICIO COMENTO
        //public string cpRutaOrigen = @"C:\Modelo Peru\PDPReportes\";
        //public string cpRutaDestino = @"C:\Modelo Peru\PDPReportes\" + DateTime.Now.ToString("yyyyMMdd");
        //public string cpDirectoryInfo = @"C:\Modelo Peru\PDPReportes\";
        //UQMA 05/10/2017 FIN COMENTO


        //UQMA 05/10/2017 Inicializa variables
        public string cpRutaOrigen = "";
        public string cpRutaDestino = "";
        public string cpDirectoryInfo = "";


        /*                       DESARROLLO  INSTRUCCIONES ERICKSON                      */
        //public string cpRutaOrigenEricKson = @"D:\PDP\Incoming\03-04-05-06-2016\";
        //public string cpRutaDestinoErickson = @"D:\PDP\Incoming\03-04-05-06-2016\" + DateTime.Now.ToString("yyyyMMdd");
        //public string cpDirectoryInfoErickson = @"D:\PDP\Incoming\03-04-05-06-2016\";

        /*                       PRODUCCION  INSTRUCCIONES ERICKSON                      */
        //UQMA 05/10/2017 INICIO COMENTO
        //public string cpRutaOrigenEricKson = @"C:\Modelo Peru\Incoming\";
        //public string cpRutaDestinoErickson = @"C:\Modelo Peru\Incoming\" + DateTime.Now.ToString("yyyyMMdd");
        //public string cpDirectoryInfoErickson = @"C:\Modelo Peru\Incoming\";
        //public string cpRutaOrigenOutgoing = @"C:\Modelo Peru\Outgoing\";
        //public string cpRutaDestinoOutgoing = @"C:\Modelo Peru\Outgoing\" + DateTime.Now.ToString("yyyyMMdd");
        //UQMA 05/10/2017 FIN COMENTO

        //UQMA 05/10/2017 Inicializa variables
        public string cpRutaOrigenEricKson = "";
        public string cpRutaDestinoErickson = "";
        public string cpDirectoryInfoErickson = "";
        public string cpRutaOrigenOutgoing = "";
        public string cpRutaDestinoOutgoing = "";
        public string cpRutaDestinoOutAgentes = "";

        //LVCH 19/04/2018  se agrega variables de nuevas rutas
        public string cpRutaFirmaDigital = "";

        public List<cConfiguracionSistema> vgListaRutasConfiguracion;

        public cConstante()
        {
            InicilizarConfiguracionSistema(); /* Se obtiene de nueva tabla de Configuracion (DBTARJETA..) */
            //InicilizarRutas(); //UQMA 05/10/2017 /* Se comenta por nueva validacion y obtencion de rutas*/
        }
        
        public String FirmaArchivo(String cNombreArchivo)
        {
            String cMensaje="";
            try
            {
                cConstante cConstante = new cConstante();
                System.Diagnostics.Process process = new System.Diagnostics.Process();
                System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
                startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Minimized;
                startInfo.FileName = "cmd.exe";
                //startInfo.Arguments = "/C copy /b Image1.jpg + Archive.rar Image2.jpg";
                //startInfo.Arguments = "/C c:>openssl dgst -sha256 -sign C:\\Certificado\\cajacusco_filesigning_privatekey.key -out " + cConstante.cpRutaOrigenOutgoing + cNombreArchivo + ".signature " + cConstante.cpRutaDestinoOutgoing + cNombreArchivo;
                //startInfo.Arguments = "/C openssl dgst -sha256 -sign C:\\Certificado\\cajacusco_filesigning_privatekey.key -out " + cConstante.cpRutaOrigenOutgoing + cNombreArchivo + ".signature " + cConstante.cpRutaDestinoOutgoing + cNombreArchivo;
                //startInfo.Arguments = "/C openssl dgst -sha256 -sign C:\\Certificado\\cajacusco_filesigning_privatekey.key -out " + cConstante.cpRutaOrigenOutgoing + cNombreArchivo + ".signature " + cpRutaDestinoOutgoing + cNombreArchivo;
                //startInfo.Arguments = "/C openssl dgst -sha256 -sign C:\\Certificado\\cajacusco_filesigning_privatekey.key -out " + cConstante.cpRutaOrigenOutgoing + cNombreArchivo + ".signature " + cpRutaOrigenOutgoing + cNombreArchivo; //19-04-2018 LVCH se comenta para cambiar la ruta de certificado desde BD
                startInfo.Arguments = "/C openssl dgst -sha256 -sign " + cConstante.cpRutaFirmaDigital + " -out " + cConstante.cpRutaOrigenOutgoing + cNombreArchivo + ".signature " + cpRutaOrigenOutgoing + cNombreArchivo;
                process.StartInfo = startInfo;
                process.Start();
                //c:>openssl dgst -sha256 -sign C:\Certificado\cajacusco_filesigning_privatekey.key -out c:\SFTP\EWP\Outgoing\CCUSCO-REVDEP-20160202172600.csv.signature c:\SFTP\EWP\Outgoing\CCUSCO-REVDEP-20160202172600.csv
            }
            catch (Exception ex)
            {
                cMensaje=ex.ToString();
                //MessageBox.Show("Error: " + ex.ToString());
            }
            return cMensaje;
        }

        //UQMA  05/10/2017 Para traer las rutas desde la BD
        public void InicilizarRutas()
        {
            ////@nTipoRuta: 0: REPORTES PDP     1: INSTRUCCIONES INPUT ERICKSON  2: INSTRUCCIONES OUTPUT ERICKSON
            //@nTipoRuta: 0: REPORTES PDP     1: INSTRUCCIONES INPUT ERICKSON  2: INSTRUCCIONES OUTPUT ERICKSON 3:INSTRUCCIONES OUTPUT AGENTES  4: INSTRUCCIONES FIRMAS DIGITALES  //19/04/2018 LVCH SE AGREGA NUEVAS RUTAS

            DataSet oRuta = oDatos.TraerDataSet("spu_Bim_ObtenerRutas"); //0: REPORTES PDP  
            int ruta = -1;
            foreach (DataRow row in oRuta.Tables[0].Rows)
            {
                ruta = int.Parse(row["nTipoRuta"].ToString());

                switch (ruta)
                {
                    case 0: // 0: REPORTES PDP 
                        cpRutaOrigen = row["cRuta"].ToString();
                        cpRutaDestino = row["cRuta"].ToString() + DateTime.Now.ToString("yyyyMMdd");
                        cpDirectoryInfo = row["cRuta"].ToString();
                        break;
                    case 1: // 1: INSTRUCCIONES INPUT ERICKSON 
                        cpRutaOrigenEricKson = row["cRuta"].ToString();
                        cpRutaDestinoErickson = row["cRuta"].ToString() + DateTime.Now.ToString("yyyyMMdd");
                        cpDirectoryInfoErickson = row["cRuta"].ToString();
                        break;
                    case 2: //2: INSTRUCCIONES OUTPUT ERICKSON
                        cpRutaOrigenOutgoing = row["cRuta"].ToString();
                        cpRutaDestinoOutgoing = row["cRuta"].ToString() + DateTime.Now.ToString("yyyyMMdd");
                        break;
                    case 3: //3: OUTPUT AGENTES
                        cpRutaDestinoOutAgentes = row["cRuta"].ToString();
                        break;
                    case 4: //4: FIRMAS DIGITALES  //19/04/2018 LVCH
                        cpRutaFirmaDigital = row["cRuta"].ToString();                        
                        break;
                }


            }
        }

        public void InicilizarConfiguracionSistema()
        {
            cResultado cResultado = new cResultado();
            cConfiguracion vgConfiguracion = new cConfiguracion();
            vgListaRutasConfiguracion = new List<cConfiguracionSistema>();

            cResultado = vgConfiguracion.Listar_ConfiguracionSistema();

            try
            {
                if (cResultado.Estado == 0)
                {
                    vgListaRutasConfiguracion = cTransformador.ConvertirDataTableAClase<cConfiguracionSistema>(cResultado.Datos);

                    /* Inicializacion de variables */
                    string vReportes = "Ruta Inicializada";
                    string vIncoming = "Ruta Inicializada";
                    string vOutgoing = "Ruta Inicializada";
                    string vAgentes = "Ruta Inicializada";
                    string vCertificado = "Ruta Inicializada";

                    /* INICIO - Obtenion de RUTAS - produccion */
                    //vReportes = vgListaRutasConfiguracion.Where(item => item.cTag == "REPORTES").First().cRuta.ToString();
                    //vIncoming = vgListaRutasConfiguracion.Where(item => item.cTag == "INCOMING").First().cRuta.ToString();
                    //vOutgoing = vgListaRutasConfiguracion.Where(item => item.cTag == "OUTGOING").First().cRuta.ToString();
                    //vAgentes = vgListaRutasConfiguracion.Where(item => item.cTag == "AGENTES").First().cRuta.ToString();
                    //vCertificado = vgListaRutasConfiguracion.Where(item => item.cTag == "CERTIFICADO").First().cRuta.ToString();
                    /* FIN - produccion */

                    /* INICIO - Obtenion de RUTAS - desarrollo (modificar o insertar la ruta en la tabla de DBTarjeta..Configuraciones_Sistemas) */
                    vReportes = vgListaRutasConfiguracion.Where(item => item.cTag == "NUEVO").First().cRuta.ToString();
                    vIncoming = vgListaRutasConfiguracion.Where(item => item.cTag == "NUEVO").First().cRuta.ToString();
                    vOutgoing = vgListaRutasConfiguracion.Where(item => item.cTag == "NUEVO").First().cRuta.ToString();
                    vAgentes = vgListaRutasConfiguracion.Where(item => item.cTag == "NUEVO").First().cRuta.ToString();
                    vCertificado = vgListaRutasConfiguracion.Where(item => item.cTag == "NUEVO").First().cRuta.ToString();

                    //vReportes = @"D:\\22 Archivos Carga\\";
                    //vIncoming = @"D:\\22 Archivos Carga\\";
                    //vOutgoing = @"D:\\22 Archivos Carga\\";
                    //vAgentes = @"D:\\22 Archivos Carga\\";
                    //vCertificado = @"D:\\22 Archivos Carga\\";
                    /* FIN - desarrollo */

                    // 0: REPORTES PDP 
                    cpRutaOrigen = vReportes;
                    cpRutaDestino = vReportes + DateTime.Now.ToString("yyyyMMdd");
                    cpDirectoryInfo = vReportes;
                    /*
                        cpRutaOrigen	- C:\\SFTP\\PDP\\PDPReportes\\
                        cpRutaDestino	- C:\\SFTP\\PDP\\PDPReportes\\20231007
                        cpDirectoryInfo	- C:\\SFTP\\PDP\\PDPReportes\\
                    */

                    // 1: INSTRUCCIONES INPUT ERICKSON 
                    cpRutaOrigenEricKson = vIncoming;
                    cpRutaDestinoErickson = vIncoming + DateTime.Now.ToString("yyyyMMdd");
                    cpDirectoryInfoErickson = vIncoming;
                    /*
                        cpRutaOrigenEricKson	- C:\\SFTP\\EWP\\Incoming\\
                        cpRutaDestinoErickson	- C:\\SFTP\\EWP\\Incoming\\20231007
                        cpDirectoryInfoErickson	- C:\\SFTP\\EWP\\Incoming\\
                    */

                    //2: INSTRUCCIONES OUTPUT ERICKSON
                    cpRutaOrigenOutgoing = vOutgoing;
                    cpRutaDestinoOutgoing = vOutgoing + DateTime.Now.ToString("yyyyMMdd");
                    /*
                        cpRutaOrigenOutgoing	- C:\\SFTP\\EWP\\Outgoing\\
                        cpRutaDestinoOutgoing	- C:\\SFTP\\EWP\\Outgoing\\20231007
                    */

                    //3: OUTPUT AGENTES
                    cpRutaDestinoOutAgentes = vAgentes;
                    /*
                        cpRutaDestinoOutAgentes	- C:\\ModeloPeru\\OutAgentes\\
                    */

                    //4: CRTIFICADO
                    cpRutaFirmaDigital = vCertificado;
                    /*
                        cpRutaFirmaDigital	- C:\\Certificado\\cajacusco_filesigning_privateKey.key
                    */
                }
                else
                {
                    MessageBox.Show(cResultado.Mensaje);
                    ClaseXDefecto();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public cConstante(string cpRutaOrigen, string cpRutaDestino, string cpDirectoryInfo, string cpRutaOrigenEricKson, string cpRutaDestinoErickson, string cpDirectoryInfoErickson, string cpRutaOrigenOutgoing, string cpRutaDestinoOutgoing, string cpRutaDestinoOutAgentes, string cpRutaFirmaDigital)
        {
            this.cpRutaOrigen = cpRutaOrigen;
            this.cpRutaDestino = cpRutaDestino;
            this.cpDirectoryInfo = cpDirectoryInfo;
            this.cpRutaOrigenEricKson = cpRutaOrigenEricKson;
            this.cpRutaDestinoErickson = cpRutaDestinoErickson;
            this.cpDirectoryInfoErickson = cpDirectoryInfoErickson;
            this.cpRutaOrigenOutgoing = cpRutaOrigenOutgoing;
            this.cpRutaDestinoOutgoing = cpRutaDestinoOutgoing;
            this.cpRutaDestinoOutAgentes = cpRutaDestinoOutAgentes;
            this.cpRutaFirmaDigital = cpRutaFirmaDigital;
        }

        public cConstante ClaseXDefecto()
        {
            cConstante oConstantes = new cConstante(
            "Ruta Vacia: error al obtener ruta de DB",
            "Ruta Vacia: error al obtener ruta de DB",
            "Ruta Vacia: error al obtener ruta de DB",
            "Ruta Vacia: error al obtener ruta de DB",
            "Ruta Vacia: error al obtener ruta de DB",
            "Ruta Vacia: error al obtener ruta de DB",
            "Ruta Vacia: error al obtener ruta de DB",
            "Ruta Vacia: error al obtener ruta de DB",
            "Ruta Vacia: error al obtener ruta de DB",
            "Ruta Vacia: error al obtener ruta de DB");

            return oConstantes;
        }
    }
}
