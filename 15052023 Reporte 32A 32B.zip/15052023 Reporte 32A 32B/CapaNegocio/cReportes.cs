﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class cReportes
    {

    }

    /* INICIO 04072023 HSPC - Se agrega nueva clase ReporteBi */
    public class cDataArchivosProcesados
    {
        public string nIdCabezera { get; set; }
        public string nIdLogArchivos { get; set; }
        public string cNombreArchivo { get; set; }
        public string dFechaSistema { get; set; }
        public string dFechaReal { get; set; }
        public string cFecha { get; set; }
        public string cUSer { get; set; }
        public string cAgencia { get; set; }
        public string bEstadoInactivo { get; set; }

        /*
         nIdLogArchivos	cNombreArchivo	dFechaSistema	dFechaReal	cFecha	cUSer	cAgencia	bEstadoInactivo
            730	INF-COMERCIAL-CCUSCO-20161125010006.csv	2016-11-25 00:00:00.000	2016-11-25 11:54:11.687	20161125	CHME	01	NULL
         */

        public cDataArchivosProcesados()
        {
        }
    }

    /* INICIO 04072023 HSPC - Se agrega nueva clase ReporteBi */
    public class cDataReporteCabecera
    {
        public string nIdCabezera { get; set; }
        public string nIdLogArchivos { get; set; }
        public string cCodigoFormato { get; set; }
        public string cAnexo { get; set; }
        public string cEntidad { get; set; }
        public string dFecha { get; set; }
        public string cExpMontos { get; set; }
        public string nDatosControl { get; set; }
        /*otros*/
        public string cNombreArchivo { get; set; }

        /*
         nIdCabezera	nIdLogArchivos	cCodigoFormato	cAnexo	cEntidad	dFecha	cExpMontos	nDatosControl
            1	2286	0232	01	00106	2017-08-16 00:00:00.000	012	0
         */

        public cDataReporteCabecera()
        {
        }
    }

    /* INICIO 04072023 HSPC - Se agrega nueva clase ReporteBi */
    public class cDataReporte32A : cDataReporteCabecera
    {
        public string nIdRepA { get; set; }
        public string nIdCabecera { get; set; }
        public string cCodFila { get; set; }
        public string nDineroElectronico { get; set; }
        public string nFideicometido { get; set; }
        public string bEstado { get; set; }
        /* Nuevos */
        public string nValorDisposicionInmediata { get; set; }
        public string nValorGarantia { get; set; }

        /*
         nIdRepA	nIdCabecera	cCodFila	nDineroElectronico	nFideicometido	bEstado	nValorDisposicionInmediata	nValorGarantia
            2111	2357	100	59023.91	0.00	0	0.00	0.00
         */

        public cDataReporte32A()
        {
        }
    }
    /* INICIO 04072023 HSPC - Se agrega nueva clase ReporteBi */
    public class cDataReporte32BI : cDataReporteCabecera
    {
        public string nIdRepBI { get; set; }
        public string nIdCabecera { get; set; }
        public string cCodFila { get; set; }
        public string nMontoConver { get; set; }
        public string nNroOperacionesConver { get; set; }
        public string nMontoTransfPago { get; set; }
        public string nNroOperacionesTransfPago { get; set; }
        public string nMontoReconversiones { get; set; }
        public string nNroOperacionesReconversiones { get; set; }
        public string nMontoOtros { get; set; }
        public string nNroOperacionesotros { get; set; }
        public string nTipoCambio { get; set; }
        public string bEstado { get; set; }

        /*
         nIdRepBI	nIdCabecera	cCodFila	nMontoConver	nNroOperacionesConver	nMontoTransfPago	nNroOperacionesTransfPago	nMontoReconversiones	nNroOperacionesReconversiones	nMontoOtros	nNroOperacionesotros	nTipoCambio	bEstado
            1	19	1000	0.00	0	0.00	0	0.00	0	0.00	0	0.00	0
         */

        public cDataReporte32BI()
        {
        }
    }
    /* FIN 04072023 HSPC - Se agrega nueva clase ReporteBi */
    /* INICIO 04072023 HSPC - Se agrega nueva clase ReporteBII */
    public class cDataReporte32BII : cDataReporteCabecera
    {
        public string nIdRepBII { get; set; }
        public string nIdCabecera { get; set; }
        public string cCodFila { get; set; }
        public string nMonedaNacional { get; set; }
        public string nMonedaExtranjera { get; set; }
        public string nTotal { get; set; }
        public string bEstado { get; set; }

        /*
        nIdRepBII	nIdCabecera	cCodFila	nMonedaNacional	nMonedaExtranjera	nTotal	bEstado
            1	20	100	18.70	0.00	18.70	0
        */

        public cDataReporte32BII()
        {
        }
    }
    /* FIN 04072023 HSPC - Se agrega nueva clase ReporteBII */
    /* INICIO 04072023 HSPC - Se agrega nueva clase ReporteBIII */
    public class cDataReporte32BIII : cDataReporteCabecera
    {
        public string nIdRepBIII { get; set; }
        public string cFecha { get; set; }
        public string cCodFila { get; set; }
        public string nCtaSimNroDeCuentas { get; set; }
        public string nCtaSimNroDeTitu { get; set; }
        public string nCtaGnrlNroDeCuentas { get; set; }
        public string nCtaGnrlNroDeTitu { get; set; }
        public string bEstado { get; set; }

        /*
         nIdRepBIII	nIdCabecera	cCodFila	nCtaSimNroDeCuentas	nCtaSimNroDeTitu	nCtaGnrlNroDeCuentas	nCtaGnrlNroDeTitu	bEstado
            1	21	100	442	442	0	0	0
         */

        public cDataReporte32BIII()
        {
        }
    }
    /* FIN 04072023 HSPC - Se agrega nueva clase ReporteBIII */
    /* INICIO 04072023 HSPC - Se agrega nueva clase ReporteBIV */
    public class cDataReporte32BIV : cDataReporteCabecera
    {
        public string nIdRepBIV { get; set; }
        public string nIdCabecera { get; set; }
        public string cCodFila { get; set; }
        public string nTotDineroElec { get; set; }
        public string nValPatriFideicometido { get; set; }
        public string bEstado { get; set; }
        /*otros*/
        public string nValorDisposicionInmediata { get; set; }
        public string nValorGarantia { get; set; }

        /*
         nIdRepBIV	nIdCabecera	cCodFila	nTotDineroElec	nValPatriFideicometido	bEstado
            1	22	100	9968.20	100000.00	0
         */

        public cDataReporte32BIV()
        {
        }
    }
    /* FIN 04072023 HSPC - Se agrega nueva clase ReporteBIV */
}
