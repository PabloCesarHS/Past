﻿using System.Data;

namespace CapaNegocio
{
    public class cResultado
    {
        private int estado;
        private string mensaje;
        private DataTable datos;

        public int Estado { get => estado; set => estado = value; }
        public string Mensaje { get => mensaje; set => mensaje = value; }
        public DataTable Datos { get => datos; set => datos = value; }

        public cResultado()
        {
        }

        public cResultado(int estado, string mensaje, DataTable datos)
        {
            Estado = estado;
            Mensaje = mensaje;
            Datos = datos;
        }
    }

    public class cCombo
    {
        private string codigo;
        private string valor;

        public string Codigo { get => codigo; set => codigo = value; }
        public string Valor { get => valor; set => valor = value; }

        public cCombo()
        {
        }

        public cCombo(string codigo, string valor)
        {
            Codigo = codigo;
            Valor = valor;
        }
    }
}
