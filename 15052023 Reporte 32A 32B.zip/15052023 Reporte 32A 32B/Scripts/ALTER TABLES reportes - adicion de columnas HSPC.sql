USE DBTarjeta
GO

/* AGREGAR COLUMNAS A REPORTE 32A */
ALTER TABLE BimReporte32A
	   ADD nValorDisposicionInmediata MONEY DEFAULT 0, nValorGarantia MONEY DEFAULT 0;

UPDATE BimReporte32A SET nValorDisposicionInmediata=0,nValorGarantia=0

/* AGREGAR COLUMNAS A REPORTE 32B1 */
ALTER TABLE BimReporte32B_I
	   ADD nValorDisposicionInmediata MONEY DEFAULT 0, nValorGarantia MONEY DEFAULT 0;

UPDATE BimReporte32B_I SET nValorDisposicionInmediata=0,nValorGarantia=0

/* AGREGAR COLUMNAS A REPORTE 32B1 */
ALTER TABLE BimReporte32B_II
	   ADD nValorDisposicionInmediata MONEY DEFAULT 0, nValorGarantia MONEY DEFAULT 0;

UPDATE BimReporte32B_II SET nValorDisposicionInmediata=0,nValorGarantia=0

/* AGREGAR COLUMNAS A REPORTE 32B1 */
ALTER TABLE BimReporte32B_IIi
	   ADD nValorDisposicionInmediata MONEY DEFAULT 0, nValorGarantia MONEY DEFAULT 0;

UPDATE BimReporte32B_IIi SET nValorDisposicionInmediata=0,nValorGarantia=0

/* AGREGAR COLUMNAS A REPORTE 32B1v */
ALTER TABLE BimReporte32B_IV 
	   ADD nValorDisposicionInmediata MONEY DEFAULT 0, nValorGarantia MONEY DEFAULT 0;

UPDATE BimReporte32B_IV SET nValorDisposicionInmediata=0,nValorGarantia=0