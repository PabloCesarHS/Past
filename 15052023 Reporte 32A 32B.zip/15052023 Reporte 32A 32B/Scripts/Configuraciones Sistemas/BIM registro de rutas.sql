USE DBTarjeta
GO

EXEC Registrar_ConfiguracionSistema 'BIM MANAGER','RUTA','REPORTES','C:\SFTP\PDP\PDPReportes\','','','',0
EXEC Registrar_ConfiguracionSistema 'BIM MANAGER','RUTA','INCOMING','C:\SFTP\EWP\Incoming\','','','',0
EXEC Registrar_ConfiguracionSistema 'BIM MANAGER','RUTA','OUTGOING','C:\SFTP\EWP\Outgoing\','','','',0
EXEC Registrar_ConfiguracionSistema 'BIM MANAGER','RUTA','AGENTES','C:\ModeloPeru\OutAgentes\','','','',0
EXEC Registrar_ConfiguracionSistema 'BIM MANAGER','RUTA','CERTIFICADO','C:\Certificado\cajacusco_filesigning_privateKey.key','','','',0