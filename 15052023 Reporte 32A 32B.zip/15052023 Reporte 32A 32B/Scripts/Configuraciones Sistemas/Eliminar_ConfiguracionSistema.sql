USE DBTarjeta
GO

/* ===================================
NOMBRE             : Eliminar_ConfiguracionSistema              
PROPOSITO          : 
CREACION           : 
MODIFICACION       : 07/04/2023 HSPC
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  : EXEC Eliminar_ConfiguracionSistema 8,0,0
=================================== */
CREATE PROCEDURE dbo.Eliminar_ConfiguracionSistema
(
    @nIdConfiguracion INT,
    @bEstado BIT = 0,
    @bTipo BIT = 0
)
AS
BEGIN
	SET NOCOUNT ON

	/*
	RESULTADO = 0 : CORRECTO
	RESULTADO = 1 : NO EXISTE
	RESULTADO = 2 : REGISTRO MODIFICADO
	RESULTADO = 3 : REGISTRO ELIMINADO
	*/

	IF EXISTS (SELECT nIdConfiguracion FROM DBTarjeta..Configuraciones_Sistemas WHERE nIdConfiguracion = @nIdConfiguracion)
	BEGIN
		IF (@bTipo = 1)
		BEGIN
		    DELETE
		    FROM DBTarjeta.Configuraciones_Sistemas
		    WHERE nIdConfiguracion = @nIdConfiguracion

		    SELECT '0' AS RESULTADO
		END
		IF (@bTipo = 0)
		BEGIN
		    UPDATE DBTarjeta.Configuraciones_Sistemas
		    SET bEstado = @bEstado
		    WHERE nIdConfiguracion = @nIdConfiguracion

		    SELECT '0' AS RESULTADO
		END
	END
	ELSE
	BEGIN
		SELECT '1' AS RESULTADO
	END

	SET NOCOUNT OFF
END
GO