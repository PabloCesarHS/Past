USE DBTarjeta
GO

/* ===================================
NOMBRE            : Listar_ConfiguracionSistema
PROPOSITO         : Obtiene la ruta para la importacion o exportacion de archivos
USADO POR         : Modelo Peru - Bim Manager
FECHA CREACION    : 06/06/2018 USUARIO:
EJECUTAR EN       : DBTarjeta
MODO EJECUCION    : EXEC Listar_ConfiguracionSistema 'BIM MANAGER','RUTA'
=================================== */
CREATE PROCEDURE Listar_ConfiguracionSistema
(
    @CProyecto VARCHAR(15),
    @cTipo VARCHAR(10) NULL
)
AS
BEGIN
	SET NOCOUNT ON

	SELECT nIdConfiguracion,
		CProyecto,
		cTipo,
		cTag,
		cRuta,
		cBaseDatos,
		cDireccionIP,
		cParametros,
		bEstado
	FROM DBTarjeta..Configuraciones_Sistemas
	WHERE CProyecto = @CProyecto
	 AND cTipo= @cTipo

	SET NOCOUNT OFF
END
