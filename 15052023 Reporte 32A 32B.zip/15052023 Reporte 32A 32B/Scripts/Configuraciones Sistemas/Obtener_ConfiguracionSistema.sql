USE DBTarjeta
GO

/* ===================================
NOMBRE            : Obtener_ConfiguracionSistema
PROPOSITO         : Obtiene la ruta para la importacion o exportacion de archivos
USADO POR         : Modelo Peru - Bim Manager
FECHA CREACION    : 06/06/2018		USUARIO:
EJECUTAR EN       : DBTarjeta
MODO EJECUCION    : EXEC dbo.Obtener_ConfiguracionSistema 'BIM MANAGER','RUTA','INCOMING'
=================================== */
CREATE PROCEDURE dbo.Obtener_ConfiguracionSistema
(
    @CProyecto VARCHAR(15),
    @cTipo VARCHAR(10) NULL,
    @cTag VARCHAR(20) NULL
)
AS
BEGIN
	SET NOCOUNT ON

	SELECT nIdConfiguracion,
		CProyecto,
		cTipo,
		cTag,
		cRuta,
		cBaseDatos,
		cDireccionIP,
		cParametros,
		bEstado
	FROM DBTarjeta..Configuraciones_Sistemas
	WHERE CProyecto = @CProyecto
	 AND cTipo= @cTipo
	 AND cTag = @cTag
	 AND bEstado = 0

	SET NOCOUNT OFF
END
