USE DBTarjeta
GO

/* ===================================
NOMBRE             : Registrar_ConfiguracionSistema              
PROPOSITO          : Registra las configuraciones  
CREACION           : HSPC
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  :                     
				EXEC Registrar_ConfiguracionSistema 
				    'BIM MANAGER',
				    'RUTA',
				    'NUEVO',
				    'D:\22 Archivos Carga\',
				    'DBTarjeta',
				    '0.0.0.0',
				    '[administrador=1212];[tipo=1]',
				    0
=================================== */
CREATE PROCEDURE dbo.Registrar_ConfiguracionSistema
(
	@CProyecto VARCHAR(15),
	@cTipo VARCHAR(10),
	@cTag VARCHAR(20),
	@cRuta VARCHAR(150),
	@cBaseDatos VARCHAR(30),
	@cDireccionIP VARCHAR(24),
	@cParametros VARCHAR(150),
	@bEstado INT
)
AS
BEGIN
	SET NOCOUNT ON

	/*
	RESULTADO = 0 : CORRECTO
	RESULTADO = 1 : NO EXISTE
	RESULTADO = 2 : REGISTRO MODIFICADO
	RESULTADO = 3 : REGISTRO ELIMINADO
	*/

	IF NOT EXISTS (SELECT nIdConfiguracion FROM DBTarjeta..Configuraciones_Sistemas
							 WHERE CProyecto = @CProyecto 
								 AND cTipo = @cTipo
								 AND cTag = @cTag)
	BEGIN
		INSERT INTO DBTarjeta..Configuraciones_Sistemas (
			CProyecto,
			cTipo,
			cTag,
			cRuta,
			cBaseDatos,
			cDireccionIP,
			cParametros,
			bEstado
			)
		VALUES (
			@CProyecto,
			@cTipo,
			@cTag,
			@cRuta,
			@cBaseDatos,
			@cDireccionIP,
			@cParametros,
			@bEstado
			)

		SELECT '0' AS RESULTADO
	END
	ELSE
	BEGIN
		UPDATE DBTarjeta..Configuraciones_Sistemas
		SET CProyecto = @CProyecto,
			cTipo = @cTipo,
			cTag = @cTag,
			cRuta = @cRuta,
			cBaseDatos = @cBaseDatos,
			cDireccionIP = @cDireccionIP,
			cParametros = @cParametros,
			bEstado = @bEstado
		WHERE nIdConfiguracion = (SELECT nIdConfiguracion FROM DBTarjeta..Configuraciones_Sistemas
							 WHERE CProyecto = @CProyecto 
								 AND cTipo = @cTipo
								 AND cTag = @cTag)

		SELECT '2' AS RESULTADO
	END

	SET NOCOUNT OFF
END
