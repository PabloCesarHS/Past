USE DBTarjeta
GO

/* ===============================================================================================================================       
NOMBRE            : spu_Bim_ObtenerRutas
PROPOSITO         : Obtiene la ruta para la importacion o exportacion de archivos
USADO POR         : Modelo Peru - Bim Manager
FECHA CREACION    : 06/06/2018		USUARIO:	UQMA
EJECUTAR EN       : DBTarjeta
MODO EJECUCION    : 					
				exec dbo.spu_Bim_ObtenerRutas
				exec dbo.spu_Bim_ObtenerRutas 'todos'
================================================================================================================================= */
ALTER PROCEDURE dbo.spu_Bim_ObtenerRutas
    @cResultado VARCHAR(5) = NULL
AS
BEGIN
	SET NOCOUNT ON

	--@nTipoRuta: 0: REPORTES PDP     1: INSTRUCCIONES INPUT ERICKSON  2: INSTRUCCIONES OUTPUT ERICKSON 3: OUTPUT AGENTES

	IF (@cResultado IS NULL)
	BEGIN
		SELECT cRuta,
			nTipoRuta
		FROM DBTarjeta..BimRutas

	END

	IF (@cResultado IS NOT NULL)
	BEGIN
		SELECT nid,
			cRuta,
			nTipoRuta
		FROM DBTarjeta..BimRutaS
	END

	SET NOCOUNT OFF
END