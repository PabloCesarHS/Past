USE DBTarjeta
GO

/********************************************************************                    
NOMBRE             : BimReporte32BIEditar_spu              
PROPOSITO          : Actualizar el valor nValPatriFideicometido del Reporte 32BI
CREACION           :         
EJECUTAR EN        : DBTarjeta  
CREACION           : 
MODIFICACION       : 07/04/2023 HSPC - Se agregan nuevos parametros en la modificacion de registros       
          
MODO DE EJECUCION  : 
				EXEC BimReporte32BIEditar_spu 1,10,10,10,10,10,10,10,10,10
*********************************************************************/
ALTER PROCEDURE dbo.BimReporte32BIEditar_spu
	   @nIdRepBI INT,
	   @nMontoConver MONEY = NULL,
	   @nNroOperacionesConver MONEY = NULL,
	   @nMontoTransfPago MONEY = NULL,
	   @nNroOperacionesTransfPago MONEY = NULL,
	   @nMontoReconversiones MONEY = NULL,
	   @nNroOperacionesReconversiones MONEY = NULL,
	   @nMontoOtros MONEY = NULL,
	   @nNroOperacionesotros MONEY = NULL,
	   @nTipoCambio MONEY = NULL
AS
BEGIN
	SET NOCOUNT ON
	/* VERIFICACION DE PARAMETROS EN NULO */
	IF (@nMontoConver IS NULL)
	BEGIN
		SET @nMontoConver = 0
	END

	IF (@nNroOperacionesConver IS NULL)
	BEGIN
		SET @nNroOperacionesConver = 0
	END

	IF (@nNroOperacionesConver IS NULL)
	BEGIN
		SET @nNroOperacionesConver = 0
	END

	IF (@nMontoTransfPago IS NULL)
	BEGIN
		SET @nMontoTransfPago = 0
	END

	IF (@nNroOperacionesTransfPago IS NULL)
	BEGIN
		SET @nNroOperacionesTransfPago = 0
	END

	IF (@nMontoReconversiones IS NULL)
	BEGIN
		SET @nMontoReconversiones = 0
	END

	IF (@nNroOperacionesReconversiones IS NULL)
	BEGIN
		SET @nNroOperacionesReconversiones = 0
	END

	IF (@nMontoOtros IS NULL)
	BEGIN
		SET @nMontoOtros = 0
	END

	IF (@nNroOperacionesotros IS NULL)
	BEGIN
		SET @nNroOperacionesotros = 0
	END

	IF (@nTipoCambio IS NULL)
	BEGIN
		SET @nTipoCambio = 0
	END
	/* MODIFICACION DEL REGISTRO */
	UPDATE [DBTarjeta].[dbo].[BimReporte32B_I]
	SET nMontoConver = @nMontoConver,
		nNroOperacionesConver = @nNroOperacionesConver,
		nMontoTransfPago = @nMontoTransfPago,
		nNroOperacionesTransfPago = @nNroOperacionesTransfPago,
		nMontoReconversiones = @nMontoReconversiones,
		nNroOperacionesReconversiones = @nNroOperacionesReconversiones,
		nMontoOtros = @nMontoOtros,
		nNroOperacionesotros = @nNroOperacionesotros,
		nTipoCambio = @nTipoCambio
	WHERE nIdRepBI = @nIdRepBI

	SELECT '0' AS RESULTADO

	SET NOCOUNT OFF
END
GO