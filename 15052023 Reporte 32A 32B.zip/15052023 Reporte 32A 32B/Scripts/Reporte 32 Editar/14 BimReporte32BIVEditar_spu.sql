USE DBTarjeta
GO

/********************************************************************                    
NOMBRE             : BimReporte32BIVEditar_spu              
PROPOSITO          : Actualizar el valor nValPatriFideicometido del Reporte 32BIV
CREACION           : 11/08/2017 UQMA         
EJECUTAR EN        : DBTarjeta       
MODIFICACION       : 07/04/2023 HSPC - Se agregan nuevos parametros en la modificacion de registros       
          
MODO DE EJECUCION  : 
				EXEC BimReporte32BIVEditar_spu
*********************************************************************/
ALTER PROCEDURE dbo.BimReporte32BIVEditar_spu
	   @nIdRepBIV INT,
	   @nTotDineroElec MONEY = NULL,
	   @nValPatriFideicometido MONEY = NULL,
	   @nValorDisposicionInmediata MONEY = NULL,
	   @nValorGarantia MONEY = NULL
AS
BEGIN
	SET NOCOUNT ON

	/* VERIFICACION DE PARAMETROS EN NULO */
	IF (@nTotDineroElec IS NULL)
	BEGIN
		SET @nTotDineroElec = 0
	END

	IF (@nValPatriFideicometido IS NULL)
	BEGIN
		SET @nValPatriFideicometido = 0
	END

	IF (@nValorDisposicionInmediata IS NULL)
	BEGIN
		SET @nValorDisposicionInmediata = 0
	END

	IF (@nValorGarantia IS NULL)
	BEGIN
		SET @nValorGarantia = 0
	END

	/* MODIFICACION DEL REGISTRO */
	UPDATE [DBTarjeta].[dbo].[BimReporte32B_IV]
	SET nTotDineroElec = @nTotDineroElec,
		nValPatriFideicometido = @nValPatriFideicometido,
		nValorDisposicionInmediata = @nValorDisposicionInmediata,
		nValorGarantia = @nValorGarantia
	WHERE nIdRepBIV = @nIdRepBIV

	SELECT '0' AS RESULTADO

	SET NOCOUNT OFF
END
GO