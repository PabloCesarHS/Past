USE DBTarjeta
GO

/********************************************************************                    
NOMBRE             : BimReporte32BIIIEditar_spu                
PROPOSITO          : Actualizar el valor nTipoCambio del Reporte 32BI
EJECUTAR EN        : DBTarjeta
CREACION           : 
MODIFICACION       : 07/04/2023 HSPC - Se agregan nuevos parametros en la modificacion de registros       
          
MODO DE EJECUCION  :                     
                   
*********************************************************************/
ALTER PROCEDURE dbo.BimReporte32BIIIEditar_spu
	   @nIdRepBIII INT,
	   @nCtaSimNroDeCuentas MONEY = NULL,
	   @nCtaSimNroDeTitu MONEY = NULL,
	   @nCtaGnrlNroDeCuentas MONEY = NULL,
	   @nCtaGnrlNroDeTitu MONEY = NULL
AS
BEGIN
	SET NOCOUNT ON

	/* VERIFICACION DE PARAMETROS EN NULO */
	IF (@nCtaSimNroDeCuentas IS NULL)
	BEGIN
		SET @nCtaSimNroDeCuentas = 0
	END

	IF (@nCtaSimNroDeTitu IS NULL)
	BEGIN
		SET @nCtaSimNroDeTitu = 0
	END

	IF (@nCtaGnrlNroDeCuentas IS NULL)
	BEGIN
		SET @nCtaGnrlNroDeCuentas = 0
	END

	IF (@nCtaGnrlNroDeTitu IS NULL)
	BEGIN
		SET @nCtaGnrlNroDeTitu = 0
	END

	/* MODIFICACION DEL REGISTRO */
	UPDATE [DBTarjeta].[dbo].[BimReporte32B_III]
	SET nCtaSimNroDeCuentas = @nCtaSimNroDeCuentas,
		nCtaSimNroDeTitu = @nCtaSimNroDeTitu,
		nCtaGnrlNroDeCuentas = @nCtaGnrlNroDeCuentas,
		nCtaGnrlNroDeTitu = @nCtaGnrlNroDeTitu
	WHERE nIdRepBIII = @nIdRepBIII

	SELECT '0' AS RESULTADO

	SET NOCOUNT OFF
END
GO