USE DBTarjeta
GO

/********************************************************************                    
NOMBRE             : BimReporte32BVEditar_spu              
PROPOSITO          : Actualizar el valor nValPatriFideicometido del Reporte 32BV
CREACION           : 11/08/2017 UQMA         
EJECUTAR EN        : DBTarjeta  
CREACION           : 
MODIFICACION       : 07/04/2023 HSPC - Se agregan nuevos parametros en la modificacion de registros       
          
MODO DE EJECUCION  :                     
                   
*********************************************************************/
ALTER PROCEDURE dbo.BimReporte32BVEditar_spu
	   @nIdRepBV INT,
	   @nTel�fono MONEY = NULL,
	   @nTarjetaPrepago MONEY = NULL,
	   @nOtro MONEY = NULL
AS
BEGIN
	SET NOCOUNT ON

	/* VERIFICACION DE PARAMETROS EN NULO */
	IF (@nTel�fono IS NULL)
	BEGIN
		SET @nTel�fono = 0
	END

	IF (@nTarjetaPrepago IS NULL)
	BEGIN
		SET @nTarjetaPrepago = 0
	END

	IF (@nOtro IS NULL)
	BEGIN
		SET @nOtro = 0
	END

	/* MODIFICACION DEL REGISTRO */
	UPDATE [DBTarjeta].[dbo].[BimReporte32B_V]
	SET nTel�fono = @nTel�fono,
		nTarjetaPrepago = @nTarjetaPrepago,
		nOtro = @nOtro
	WHERE nIdRepBV = @nIdRepBV

	SELECT '0' AS RESULTADO

	SET NOCOUNT OFF
END
GO