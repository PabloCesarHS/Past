USE DBTarjeta
GO

/***********************************************************************************************************************************                        
NOMBRE             : BimReporte32BIVEditar_spu              
PROPOSITO          : Actualizar el valor nValPatriFideicometido del Reporte 32BIV
CREACION           : 11/08/2017 UQMA         
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  :                     
                 
***********************************************************************************************************************************/
CREATE PROCEDURE dbo.BimReporte32BIVEditar_spu
     @nIdRepBIV INT,
	@nValPatriFideicometido MONEY
AS
BEGIN
	--Para actualizar el valor nValPatriFideicometido
	UPDATE [DBTarjeta].[dbo].[BimReporte32B_IV]
	SET nValPatriFideicometido = @nValPatriFideicometido
	WHERE nIdRepBIV = @nIdRepBIV
END
GO