USE DBTarjeta
GO

/***********************************************************************************************************************************                        
NOMBRE             : spu_Bim_Insertar_Reporte32A              
PROPOSITO          : Inserta las filas del Reporte32 A       
CREACION           : 11/08/2017 UQMA         
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  : 
				EXEC spu_Bim_Insertar_Reporte32A                 
***********************************************************************************************************************************/
ALTER PROCEDURE dbo.spu_Bim_Insertar_Reporte32A 
	   @pcNombreArchivo VARCHAR(250),
	   @pnNroLinea INT,
	   @cCodFila INT,
	   @nDineroElectronico MONEY,
	   @nFideicometido MONEY,
	   @nValorDisposicionInmediata MONEY = NULL,
	   @nValorGarantia MONEY = NULL
AS
BEGIN
	SET NOCOUNT ON

	/* VALIDACION DE PARAMETROS */
	IF(@nValorDisposicionInmediata IS NULL)
	BEGIN
	   SET @nValorDisposicionInmediata = 0
	END

	IF(@nValorGarantia IS NULL)
	BEGIN
	   SET @nValorGarantia = 0
	END

	DECLARE @inIdCabezera INT

	--Recuperamos el Id de la cabecera
	SELECT @inIdCabezera = brc.nIdCabezera
	FROM [DBTarjeta].[dbo].[BimLogArchivosProcesados] bla WITH (NOLOCK)
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK) ON bla.nIdLogArchivos = brc.nIdLogArchivos
	WHERE bla.cNombreArchivo = @pcNombreArchivo

	IF (@pnNroLinea = 1)
	BEGIN
		--Verificamos si ha sido leido el archivo con esa cabecera
		UPDATE bra
		SET bEstado = 1 --Actualizamos el estado a inactivo
		FROM [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK)
		INNER JOIN [DBTarjeta].[dbo].[BimReporte32A] bra WITH (NOLOCK) ON brc.nIdCabezera = bra.nIdCabecera
		WHERE brc.nIdCabezera = @inIdCabezera
	END

	INSERT INTO [DBTarjeta].[dbo].[BimReporte32A] (
		[nIdCabecera],
		[cCodFila],
		[nDineroElectronico],
		[nFideicometido],
		[bEstado],
		[nValorDisposicionInmediata],
		[nValorGarantia]
		)
	VALUES (
		@inIdCabezera,
		@cCodFila,
		@nDineroElectronico,
		@nFideicometido,
		0,
		@nValorDisposicionInmediata,
		@nValorGarantia
		)

     SELECT '0' AS RESULTADO

	SET NOCOUNT OFF
END