USE DBTarjeta
GO

/***********************************************************************************************************************************                        
NOMBRE             : spu_Bim_Insertar_Reporte32B_I              
PROPOSITO          : Inserta las filas del ReportePDP BI       
CREACION           : 11/08/2017 UQMA         
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  : 
				EXEC spu_Bim_Insertar_Reporte32B_I
***********************************************************************************************************************************/
ALTER PROCEDURE dbo.spu_Bim_Insertar_Reporte32B_I 
	   @pcNombreArchivo VARCHAR(250),
	   @pnNroLinea INT,
	   @cCodFila INT,
	   @nMontoConver MONEY,
	   @nNroOperacionesConver INT,
	   @nMontoTransfPago MONEY,
	   @nNroOperacionesTransfPago INT,
	   @nMontoReconversiones MONEY,
	   @nNroOperacionesReconversiones INT,
	   @nMontoOtros MONEY,
	   @nNroOperacionesotros INT,
	   @nTipoCambio MONEY
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @inIdCabezera INT

	--Recuperamos el Id de la cabecera
	SELECT @inIdCabezera = brc.nIdCabezera
	FROM [DBTarjeta].[dbo].[BimLogArchivosProcesados] bla WITH (NOLOCK)
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK) ON bla.nIdLogArchivos = brc.nIdLogArchivos
	WHERE bla.cNombreArchivo = @pcNombreArchivo

	IF (@pnNroLinea = 1)
	BEGIN
		--Verificamos si ha sido leido el archivo con esa cabecera
		UPDATE brb
		SET bEstado = 1 --Actualizamos el estado a inactivo
		FROM [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK)
		INNER JOIN [DBTarjeta].[dbo].[BimReporte32B_I] brb WITH (NOLOCK) ON brc.nIdCabezera = brb.nIdCabecera
		WHERE brc.nIdCabezera = @inIdCabezera
	END

	INSERT INTO [DBTarjeta].[dbo].[BimReporte32B_I] (
		[nIdCabecera],
		[cCodFila],
		[nMontoConver],
		[nNroOperacionesConver],
		[nMontoTransfPago],
		[nNroOperacionesTransfPago],
		[nMontoReconversiones],
		[nNroOperacionesReconversiones],
		[nMontoOtros],
		[nNroOperacionesotros],
		[nTipoCambio],
		[bestado]
		)
	VALUES (
		@inIdCabezera,
		@cCodFila,
		@nMontoConver,
		@nNroOperacionesConver,
		@nMontoTransfPago,
		@nNroOperacionesTransfPago,
		@nMontoReconversiones,
		@nNroOperacionesReconversiones,
		@nMontoOtros,
		@nNroOperacionesotros,
		@nTipoCambio,
		0
		)
     SELECT '0' AS RESULTADO

	SET NOCOUNT OFF
END
GO