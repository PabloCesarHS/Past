USE DBTarjeta
GO

/***********************************************************************************************************************************                        
NOMBRE             : spu_Bim_Insertar_Reporte32B_III              
PROPOSITO          : Inserta las filas del ReportePDP BIII     
CREACION           : 11/08/2017 UQMA
MODIFICACION       : 
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  :                     
				EXEC spu_Bim_Insertar_Reporte32B_III 
***********************************************************************************************************************************/
ALTER PROCEDURE dbo.spu_Bim_Insertar_Reporte32B_III 
	   @pcNombreArchivo VARCHAR(250),
	   @pnNroLinea INT,
	   @cCodFila INT,
	   @nCtaSimNroDeCuentas INT,
	   @nCtaSimNroDeTitu INT,
	   @nCtaGnrlNroDeCuentas INT,
	   @nCtaGnrlNroDeTitu INT
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @inIdCabezera INT

	--para recuperar el id de cabecera
	SELECT TOP 1 @inIdCabezera = nIdCabezera
	FROM [DBTarjeta].[dbo].[BimLogArchivosProcesados] bla WITH (NOLOCK)
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK) ON bla.nIdLogArchivos = brc.nIdLogArchivos
	WHERE bla.cNombreArchivo = @pcNombreArchivo

	IF (@pnNroLinea = 1)
	BEGIN
		--Verificamos si ha sido leido el archivo con esa cabecera
		UPDATE brb
		SET bEstado = 1 --Actualizamos el estado a inactivo
		FROM [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK)
		INNER JOIN [DBTarjeta].[dbo].[BimReporte32B_III] brb WITH (NOLOCK) ON brc.nIdCabezera = brb.nIdCabecera
		WHERE brc.nIdCabezera = @inIdCabezera
	END

	INSERT INTO [DBTarjeta].[dbo].[BimReporte32B_III] (
		[nIdCabecera],
		[cCodFila],
		[nCtaSimNroDeCuentas],
		[nCtaSimNroDeTitu],
		[nCtaGnrlNroDeCuentas],
		[nCtaGnrlNroDeTitu],
		[bEstado]
		)
	VALUES (
		@inIdCabezera,
		@cCodFila,
		@nCtaSimNroDeCuentas,
		@nCtaSimNroDeTitu,
		@nCtaGnrlNroDeCuentas,
		@nCtaGnrlNroDeTitu,
		0
		)

     SELECT '0' AS RESULTADO

	SET NOCOUNT OFF
END
GO