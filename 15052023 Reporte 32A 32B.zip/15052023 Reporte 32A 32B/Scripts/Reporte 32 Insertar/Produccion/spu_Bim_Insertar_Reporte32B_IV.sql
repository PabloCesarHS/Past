USE DBTarjeta
GO

/***********************************************************************************************************************************                        
NOMBRE             : spu_Bim_Insertar_Reporte32B_IV              
PROPOSITO          : Inserta las filas del ReportePDP BIV
CREACION           : 15/08/2017 UQMA         
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  :                     
                 
***********************************************************************************************************************************/
CREATE PROCEDURE dbo.spu_Bim_Insertar_Reporte32B_IV
     @pcNombreArchivo VARCHAR(250),
	@pnNroLinea INT,
	@cCodFila INT,
	@nTotDineroElec MONEY,
	@nValPatriFideicometido MONEY
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @inIdCabezera INT

	--para recuperar el id de cabecera
	SELECT TOP 1 @inIdCabezera = nIdCabezera
	FROM [DBTarjeta].[dbo].[BimLogArchivosProcesados] bla WITH (NOLOCK)
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK) ON bla.nIdLogArchivos = brc.nIdLogArchivos
	WHERE bla.cNombreArchivo = @pcNombreArchivo

	IF (@pnNroLinea = 1)
	BEGIN
		--Verificamos si ha sido leido el archivo con esa cabecera
		UPDATE brb
		SET bEstado = 1 --Actualizamos el estado a inactivo
		FROM [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK)
		INNER JOIN [DBTarjeta].[dbo].[BimReporte32B_IV] brb WITH (NOLOCK) ON brc.nIdCabezera = brb.nIdCabecera
		WHERE brc.nIdCabezera = @inIdCabezera
	END

	INSERT INTO [DBTarjeta].[dbo].[BimReporte32B_IV] (
		[nIdCabecera],
		[cCodFila],
		[nTotDineroElec],
		[nValPatriFideicometido],
		[bEstado]
		)
	VALUES (
		@inIdCabezera,
		@cCodFila,
		@nTotDineroElec,
		@nValPatriFideicometido,
		0
		)

	SET NOCOUNT OFF
END
GO