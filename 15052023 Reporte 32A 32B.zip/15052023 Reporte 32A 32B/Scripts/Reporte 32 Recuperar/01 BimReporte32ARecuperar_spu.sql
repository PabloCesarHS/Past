USE DBTarjeta
GO

/***********************************************************************************************************************************                        
NOMBRE             : BimReporte32ARecuperar_spu              
PROPOSITO          : Recuperar el Reporte32A segun la fecha
EJECUTAR EN        : DBTarjeta
CREACION           : 15/08/2017 UQMA
MODIFICACION       : 30/05/2023 HSPC - Modificacion de seleccion de columnas para el cambio de Reporte 32A
MODO DE EJECUCION  :                     
				 exec BimReporte32ARecuperar_spu '20221210'
***********************************************************************************************************************************/
ALTER PROCEDURE dbo.BimReporte32ARecuperar_spu
    @fecha DATETIME
AS
BEGIN
	SET NOCOUNT ON
	--Para recuperar el Reporte32A segun la fecha
	SELECT bla.cNombreArchivo,
		bla.cFecha,
		brc.nIdCabezera,
		brc.cCodigoFormato,
		brc.cAnexo,
		brc.cEntidad,
		brc.dFecha,
		brc.cExpMontos,
		brc.nDatosControl,
		br.nIdRepA,
		br.nIdCabecera,
		br.cCodFila,
		br.nDineroElectronico,
		br.nFideicometido,
		br.nValorDisposicionInmediata,
		br.nValorGarantia,
		br.bEstado
	FROM [DBTarjeta].[dbo].[BimLogArchivosProcesados] bla WITH (NOLOCK)
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK) ON bla.nIdLogArchivos = brc.nIdLogArchivos
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32A] br WITH (NOLOCK) ON brc.nIdCabezera = br.nIdCabecera
	WHERE br.bEstado = 0
		AND brc.dFecha = @fecha
		-- 0 activos
    SET NOCOUNT OFF
END
GO