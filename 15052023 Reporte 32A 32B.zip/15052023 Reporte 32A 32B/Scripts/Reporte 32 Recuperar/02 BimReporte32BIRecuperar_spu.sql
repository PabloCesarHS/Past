USE DBTarjeta
GO

/***********************************************************************************************************************************                          
NOMBRE             : BimReporte32BIRecuperar_spu                
PROPOSITO          : Recuperar el Reporte32BI segun la fecha
EJECUTAR EN        : DBTarjeta
CREACION           : 06/06/2018 LVCH
MODIFICACION       : 30/05/2023 HSPC - Modificacion de seleccion de columnas para el cambio de Reporte 32A
MODO DE EJECUCION  : exec BimReporte32BIRecuperar_spu '20220210'
				 exec BimReporte32BIRecuperar_spu '20221212'                    
                   
***********************************************************************************************************************************/
ALTER PROCEDURE dbo.BimReporte32BIRecuperar_spu 
    @dFecha DATETIME
AS
BEGIN
	SET NOCOUNT ON

	--Para recuperar el Reporte32BIV segun la fecha

	/* INICIO 30/05/2023 HSPC - Se comenta por modificar las columnas de la seleccion */
	--SELECT bla.cNombreArchivo,
	--	bla.cFecha,
	--	br.nIdRepBI,
	--	br.cCodFila 'C�digo de Fila',
	--	br.nMontoConver 'Monto Conversiones',
	--	br.nMontoTransfPago 'Monto Transferencias y Pagos',
	--	br.nMontoReconversiones 'Monto Reconversiones',
	--	br.nTipoCambio 'Tipo de Cambio',
	--	brc.nIdCabezera,
	--	t.nValVent Venta,
	--	t.nValComp Compra,
	--	t.nValPondVenta
	/* FIN 30/05/2023 HSPC - Se comenta por modificar las columnas de la seleccion */

	/* INICIO 30/05/2023 HSPC - Se modifica los nombres de las columnas de la seleccion */
	SELECT bla.cNombreArchivo,
		bla.cFecha,
		br.nIdRepBI,
		br.cCodFila,
		br.nMontoConver,
		br.nNroOperacionesConver,
		br.nMontoTransfPago,
		br.nNroOperacionesTransfPago,
		br.nMontoReconversiones,
		br.nNroOperacionesReconversiones,
		br.nMontoOtros,
		br.nNroOperacionesotros,
		brc.nIdCabezera,
		brc.cCodigoFormato,
		brc.cAnexo,
		brc.cEntidad,
		brc.dFecha,
		brc.cExpMontos,
		brc.nDatosControl,
		t.nValVent Venta,
		t.nValComp Compra,
		t.nValPondVenta
     /* FIN 30/05/2023 HSPC - Se modifica los nombres de las columnas de la seleccion */
	FROM [DBTarjeta].[dbo].[BimLogArchivosProcesados] bla WITH (NOLOCK)
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK) ON bla.nIdLogArchivos = brc.nIdLogArchivos
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32B_I] br WITH (NOLOCK) ON brc.nIdCabezera = br.nIdCabecera
	LEFT JOIN DBCMAC..TipoCambio t WITH (NOLOCK) ON year(brc.dFecha) = year(t.dFecCamb) --19/03/2018 LVCH - se aumenta para recuperar el tipo de cambio  
	WHERE br.bEstado = 0
		AND brc.dFecha = @dFecha
		AND @dFecha = (
			SELECT TOP 1 t.dFecCamb
			FROM DBCMAC..TipoCambio WITH (NOLOCK)
			WHERE YEAR(dFecCamb) = YEAR(@dFecha)
				AND month(dFecCamb) = month(@dFecha)
			ORDER BY 1 DESC
			) --19/03/2018 LVCH - para recuperar el tipo de cambio del ultimo d�a del mes 
	SET NOCOUNT OFF
END
GO