USE DBTarjeta
GO

/***********************************************************************************************************************************                            
NOMBRE             : BimReporte32BIVRecuperar_spu                  
PROPOSITO          : Recuperar el Reporte32BIV segun la fecha    
CREACION           : 15/08/2017 UQMA
MODIFICACION       : 06/06/2018 LVCH - Se cambian los nombre de las columnas para agregar en el DGV del formulario
EJECUTAR EN        : DBTarjeta
MODO DE EJECUCION  : exec BimReporte32BIVRecuperar_spu '20230331'
                     
***********************************************************************************************************************************/
ALTER PROCEDURE dbo.BimReporte32BIVRecuperar_spu 
    @dFecha DATETIME
AS
BEGIN
	SET NOCOUNT ON
	--Para recuperar el Reporte32BIV segun la fecha   

	/* INICIO 30/05/2023 HSPC - Se comenta por modificar las columnas de la seleccion */
	--SELECT bla.cNombreArchivo,
	--	bla.cFecha,
	--	br.nIdRepBIV,
	--	br.cCodFila 'C�digo de Fila',
	--	br.nTotDineroElec 'Total Dinero Electr�nico Emitido (en S/.)',
	--	br.nValPatriFideicometido 'Valor del Patrimonio Fideicometido (en S/.)',
	--	brc.nIdCabezera --19/03/2018 LVCH
	/* FIN 30/05/2023 HSPC - Se comenta por modificar las columnas de la seleccion */

	/* INICIO 30/05/2023 HSPC - Se modifica los nombres de las columnas de la seleccion */
	SELECT bla.cNombreArchivo,
		bla.cFecha,
		br.nIdRepBIV,
		br.cCodFila,
		br.nTotDineroElec,
		br.nValPatriFideicometido,
		br.nValorDisposicionInmediata,
		br.nValorGarantia,
		br.bEstado,
		brc.nIdCabezera,
		brc.cCodigoFormato,
		brc.cAnexo,
		brc.cEntidad,
		brc.dFecha,
		brc.cExpMontos,
		brc.nDatosControl,
		t.nValVent Venta,
		t.nValComp Compra,
		t.nValPondVenta
	/* FIN 30/05/2023 HSPC - Se modifica los nombres de las columnas de la seleccion */
	FROM [DBTarjeta].[dbo].[BimLogArchivosProcesados] bla WITH (NOLOCK)
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK) ON bla.nIdLogArchivos = brc.nIdLogArchivos
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32B_IV] br WITH (NOLOCK) ON brc.nIdCabezera = br.nIdCabecera
	LEFT JOIN DBCMAC..TipoCambio t WITH (NOLOCK) ON YEAR(brc.dFecha) = YEAR(t.dFecCamb) /* 30/05/2023 HSPC - Se agrega nueva tabla de para tipo de cambio */
	WHERE br.bEstado = 0
		AND brc.dFecha = @dFecha
		/* INICIO 30/05/2023 HSPC - Se agrega condicional de fecha del tipo de cambio */
		AND @dFecha = (
			SELECT TOP 1 t.dFecCamb
			FROM DBCMAC..TipoCambio WITH (NOLOCK)
			WHERE YEAR(dFecCamb) = YEAR(@dFecha)
				AND MONTH(dFecCamb) = MONTH(@dFecha)
			ORDER BY 1 DESC
			)
	     /* FIN 30/05/2023 HSPC - Se agrega condicional de fecha del tipo de cambio */
	-- 0 activos
	SET NOCOUNT OFF
END
GO