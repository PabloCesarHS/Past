USE DBTarjeta
GO

/***********************************************************************************************************************************                            
NOMBRE             : BimReporte32BVRecuperar_spu                  
PROPOSITO          : Recuperar el Reporte32BV segun la fecha    
CREACION           :    
MODIFICACION       :       
EJECUTAR EN        : DBTarjeta                 
MODO DE EJECUCION  : exec BimReporte32BVRecuperar_spu '20221210'                      
                     
***********************************************************************************************************************************/
CREATE PROCEDURE dbo.BimReporte32BVRecuperar_spu 
    @dFecha DATETIME
AS
BEGIN
	SET NOCOUNT ON
	--Para recuperar el Reporte32BV segun la fecha

	SELECT bla.cNombreArchivo,
		bla.cFecha,
		br.nIdRepBV,
		br.cCodFila,
		br.nTel�fono,
		br.nTarjetaPrepago,
		br.nOtro,
		brc.nIdCabezera,
		brc.cCodigoFormato,
		brc.cAnexo,
		brc.cEntidad,
		brc.dFecha,
		brc.cExpMontos,
		brc.nDatosControl
	FROM [DBTarjeta].[dbo].[BimLogArchivosProcesados] bla WITH (NOLOCK)
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK) ON bla.nIdLogArchivos = brc.nIdLogArchivos
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32B_V] br WITH (NOLOCK) ON brc.nIdCabezera = br.nIdCabecera
	WHERE br.bEstado = 0
		AND brc.dFecha = @dFecha
	SET NOCOUNT OFF
END
GO