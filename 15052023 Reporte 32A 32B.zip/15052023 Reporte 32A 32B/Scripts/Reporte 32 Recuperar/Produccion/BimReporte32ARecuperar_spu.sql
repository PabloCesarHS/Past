USE DBTarjeta
GO

/***********************************************************************************************************************************                        
NOMBRE             : BimReporte32ARecuperar_spu              
PROPOSITO          : Recuperar el Reporte32A segun la fecha
CREACION           : 15/08/2017 UQMA         
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  :                     
                 
***********************************************************************************************************************************/
CREATE PROCEDURE dbo.BimReporte32ARecuperar_spu
    @fecha DATETIME
AS
BEGIN
	--Para recuperar el Reporte32A segun la fecha
	SELECT bla.cNombreArchivo,
		bla.cFecha,
		br.nIdRepA,
		br.cCodFila,
		br.nDineroElectronico,
		br.nFideicometido,
		brc.nIdCabezera
	FROM [DBTarjeta].[dbo].[BimLogArchivosProcesados] bla WITH (NOLOCK)
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK) ON bla.nIdLogArchivos = brc.nIdLogArchivos
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32A] br WITH (NOLOCK) ON brc.nIdCabezera = br.nIdCabecera
	WHERE br.bEstado = 0
		AND brc.dFecha = @fecha
		-- 0 activos
END
GO