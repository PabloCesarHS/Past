USE DBTarjeta
GO

/***********************************************************************************************************************************                            
NOMBRE             : BimReporte32BIVRecuperar_spu                  
PROPOSITO          : Recuperar el Reporte32BIV segun la fecha    
CREACION           : 15/08/2017 UQMA    
MODIFICACION       : 06/06/2018 LVCH - Se cambian los nombre de las columnas para agregar en el DGV del formulario           
EJECUTAR EN        : DBTarjeta                 
MODO DE EJECUCION  : exec  BimReporte32BIVRecuperar_spu '2018/02/28'                      
                     
***********************************************************************************************************************************/
CREATE PROCEDURE dbo.BimReporte32BIVRecuperar_spu
    @fecha DATETIME
AS
BEGIN
	SET NOCOUNT ON

	--Para recuperar el Reporte32BIV segun la fecha   
	SELECT bla.cNombreArchivo,
		bla.cFecha,
		br.nIdRepBIV,
		br.cCodFila 'C�digo de Fila',
		br.nTotDineroElec 'Total Dinero Electr�nico Emitido (en S/.)',
		br.nValPatriFideicometido 'Valor del Patrimonio Fideicometido (en S/.)',
		brc.nIdCabezera --19/03/2018 LVCH
	FROM [DBTarjeta].[dbo].[BimLogArchivosProcesados] bla WITH (NOLOCK)
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK) ON bla.nIdLogArchivos = brc.nIdLogArchivos
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32B_IV] br WITH (NOLOCK) ON brc.nIdCabezera = br.nIdCabecera
	WHERE br.bEstado = 0
		AND brc.dFecha = @fecha

	-- 0 activos      
	SET NOCOUNT ON
END
GO