USE DBTarjeta
GO

/* ===================================
NOMBRE             : spu_Bim_EditarRutas              
PROPOSITO          : 
CREACION           : 
MODIFICACION       : 07/04/2023 HSPC - Se agregan nuevos parametros en la modificacion de registros
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  : EXEC spu_Bim_EditarRutas 8,'D:\\21 Tramas-Archivos\\PDP\',0              
=================================== */
CREATE PROCEDURE dbo.spu_Bim_EditarRutas
	   @nid INT,
	   @cRuta VARCHAR(80) = NULL,
	   @nTipoRuta INT = NULL
AS
BEGIN
    SET NOCOUNT ON

	/* VERIFICACION DE PARAMETROS EN NULO */
	IF (@cRuta IS NULL OR @cRuta = '')
	BEGIN
		SET @cRuta = 'Vacio'
	END

	IF (@nTipoRuta IS NULL or @nTipoRuta = '')
	BEGIN
		SET @nTipoRuta = (SELECT MAX(nTipoRuta) + 1
					   FROM DBTarjeta..BimRutas)
	END

	/* MODIFICACION DEL REGISTRO */
	UPDATE DBTarjeta..BIMRutas
	SET cRuta = @cRuta,
		nTipoRuta = @nTipoRuta
	WHERE nid = @nid

	SELECT '0' AS RESULTADO

	SET NOCOUNT OFF
END
GO