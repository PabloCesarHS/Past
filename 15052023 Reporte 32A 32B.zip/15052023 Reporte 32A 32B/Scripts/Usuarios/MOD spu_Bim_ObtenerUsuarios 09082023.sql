USE DBTarjeta
GO

/* ===================================================      
NOMBRE            : spu_Bim_ObtenerUsuarios
PROPOSITO         : Obtiene los usuarios
USADO POR         : Modelo Peru - Bim Manager
FECHA CREACION    : 06/06/2018		USUARIO:
EJECUTAR EN       : DBTarjeta
MODO EJECUCION    : 					
			   exec dbo.spu_Bim_ObtenerUsuarios
==================================================== */
CREATE PROCEDURE dbo.spu_Bim_ObtenerUsuarios
AS
BEGIN
	SET NOCOUNT ON

	SELECT cUsuario
		FROM DBTarjeta..Bim_PermisosMenuUsuario
		GROUP BY cUsuario

	SET NOCOUNT OFF
END