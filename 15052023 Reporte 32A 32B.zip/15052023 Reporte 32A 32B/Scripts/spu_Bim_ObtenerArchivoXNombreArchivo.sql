USE DBTarjeta
GO

/* ===================================
NOMBRE             : spu_Bim_ObtenerRutaXNombre              
PROPOSITO          : 
CREACION           : 
MODIFICACION       : 07/04/2023 HSPC - Se agregan nuevos parametros en la modificacion de registros
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  :                     
				 EXEC spu_Bim_ObtenerArchivoXNombreArchivo 'REPORTE32B-V-CCUSCO-202307.txt'
				 EXEC spu_Bim_ObtenerArchivoXNombreArchivo 'DEPOSITOS-CCUSCO-20230703044505.xls'
=================================== */
CREATE PROCEDURE dbo.spu_Bim_ObtenerArchivoXNombreArchivo
(
    @cNombreArchivo VARCHAR(80) = NULL
)
AS
BEGIN
	SET NOCOUNT ON

	/* OBTENER REGISTRO */
	IF EXISTS (
			SELECT cNombreArchivo
			FROM DBTarjeta..BimLogArchivosProcesados
			WHERE cNombreArchivo = @cNombreArchivo
			)
	BEGIN
		SELECT nIdLogArchivos,
			cNombreArchivo,
			dFechaSistema,
			dFechaReal,
			cUSer,
			bEstadoInactivo
		FROM DBTarjeta..BimLogArchivosProcesados
		WHERE cNombreArchivo = @cNombreArchivo
	END
	ELSE
	BEGIN
		SELECT 0 AS nIdLogArchivos,
			'VACIO' AS cNombreArchivo,
			GETDATE() AS dFechaSistema,
			GETDATE() AS dFechaReal,
			'BIM1' AS cUSer,
			0 AS bEstadoInactivo
	END

	SET NOCOUNT OFF
END
GO