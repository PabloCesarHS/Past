﻿namespace miBIM.Forms
{
    partial class FrmDepositoCompensacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDepositoCompensacion));
            this.paHeader = new System.Windows.Forms.Panel();
            this.laTitulo = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnSalir_Comp = new System.Windows.Forms.Button();
            this.btnGenerar_comp = new System.Windows.Forms.Button();
            this.btnBuscar_Comp = new System.Windows.Forms.Button();
            this.dgvCompensacion = new System.Windows.Forms.DataGridView();
            this.Col_EsSuccess = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.nReferencia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nIdLogArchiProcDep = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dtpFechaFin_Comp = new System.Windows.Forms.DateTimePicker();
            this.dtpFechaIni_Comp = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.paHeader.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCompensacion)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // paHeader
            // 
            this.paHeader.BackColor = System.Drawing.SystemColors.ControlLight;
            this.paHeader.Controls.Add(this.laTitulo);
            this.paHeader.Location = new System.Drawing.Point(7, 7);
            this.paHeader.Name = "paHeader";
            this.paHeader.Size = new System.Drawing.Size(830, 49);
            this.paHeader.TabIndex = 30;
            // 
            // laTitulo
            // 
            this.laTitulo.AutoSize = true;
            this.laTitulo.BackColor = System.Drawing.Color.YellowGreen;
            this.laTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laTitulo.ForeColor = System.Drawing.Color.Transparent;
            this.laTitulo.Location = new System.Drawing.Point(301, 14);
            this.laTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laTitulo.Name = "laTitulo";
            this.laTitulo.Size = new System.Drawing.Size(287, 20);
            this.laTitulo.TabIndex = 0;
            this.laTitulo.Text = "DEPÓSITO POR COMPENSACIÓN";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel5.Controls.Add(this.btnSalir_Comp);
            this.panel5.Controls.Add(this.btnGenerar_comp);
            this.panel5.Location = new System.Drawing.Point(7, 387);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(830, 50);
            this.panel5.TabIndex = 29;
            // 
            // btnSalir_Comp
            // 
            this.btnSalir_Comp.Location = new System.Drawing.Point(720, 8);
            this.btnSalir_Comp.Name = "btnSalir_Comp";
            this.btnSalir_Comp.Size = new System.Drawing.Size(90, 35);
            this.btnSalir_Comp.TabIndex = 1;
            this.btnSalir_Comp.Text = "&Salir";
            this.btnSalir_Comp.UseVisualStyleBackColor = true;
            this.btnSalir_Comp.Click += new System.EventHandler(this.btnSalir_Comp_Click);
            // 
            // btnGenerar_comp
            // 
            this.btnGenerar_comp.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnGenerar_comp.Enabled = false;
            this.btnGenerar_comp.Location = new System.Drawing.Point(23, 8);
            this.btnGenerar_comp.Name = "btnGenerar_comp";
            this.btnGenerar_comp.Size = new System.Drawing.Size(90, 35);
            this.btnGenerar_comp.TabIndex = 0;
            this.btnGenerar_comp.Text = "&Generar";
            this.btnGenerar_comp.UseVisualStyleBackColor = true;
            this.btnGenerar_comp.Click += new System.EventHandler(this.btnGenerar_comp_Click);
            // 
            // btnBuscar_Comp
            // 
            this.btnBuscar_Comp.Image = global::miBIM.Properties.Resources.buscar;
            this.btnBuscar_Comp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscar_Comp.Location = new System.Drawing.Point(722, 16);
            this.btnBuscar_Comp.Name = "btnBuscar_Comp";
            this.btnBuscar_Comp.Size = new System.Drawing.Size(88, 23);
            this.btnBuscar_Comp.TabIndex = 2;
            this.btnBuscar_Comp.Text = "&Buscar";
            this.btnBuscar_Comp.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscar_Comp.UseVisualStyleBackColor = true;
            this.btnBuscar_Comp.Click += new System.EventHandler(this.btnBuscar_Comp_Click);
            // 
            // dgvCompensacion
            // 
            this.dgvCompensacion.AllowUserToAddRows = false;
            this.dgvCompensacion.AllowUserToDeleteRows = false;
            this.dgvCompensacion.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvCompensacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCompensacion.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Col_EsSuccess,
            this.nReferencia,
            this.nIdLogArchiProcDep});
            this.dgvCompensacion.Location = new System.Drawing.Point(22, 46);
            this.dgvCompensacion.Name = "dgvCompensacion";
            this.dgvCompensacion.Size = new System.Drawing.Size(790, 258);
            this.dgvCompensacion.TabIndex = 3;
            // 
            // Col_EsSuccess
            // 
            this.Col_EsSuccess.Frozen = true;
            this.Col_EsSuccess.HeaderText = "";
            this.Col_EsSuccess.Items.AddRange(new object[] {
            "-- Seleccione Estado --",
            "SUCCESS",
            "FAILED"});
            this.Col_EsSuccess.Name = "Col_EsSuccess";
            this.Col_EsSuccess.Width = 5;
            // 
            // nReferencia
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            this.nReferencia.DefaultCellStyle = dataGridViewCellStyle1;
            this.nReferencia.Frozen = true;
            this.nReferencia.HeaderText = "NroReferencia";
            this.nReferencia.Name = "nReferencia";
            this.nReferencia.ReadOnly = true;
            this.nReferencia.Width = 101;
            // 
            // nIdLogArchiProcDep
            // 
            this.nIdLogArchiProcDep.HeaderText = "nIdLogArchiProcDep";
            this.nIdLogArchiProcDep.Name = "nIdLogArchiProcDep";
            this.nIdLogArchiProcDep.Visible = false;
            this.nIdLogArchiProcDep.Width = 131;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(571, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 22;
            this.label6.Text = "Fecha Fin";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(394, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "Fecha Inicio";
            // 
            // dtpFechaFin_Comp
            // 
            this.dtpFechaFin_Comp.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaFin_Comp.Location = new System.Drawing.Point(631, 15);
            this.dtpFechaFin_Comp.Name = "dtpFechaFin_Comp";
            this.dtpFechaFin_Comp.Size = new System.Drawing.Size(85, 20);
            this.dtpFechaFin_Comp.TabIndex = 1;
            // 
            // dtpFechaIni_Comp
            // 
            this.dtpFechaIni_Comp.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaIni_Comp.Location = new System.Drawing.Point(465, 15);
            this.dtpFechaIni_Comp.Name = "dtpFechaIni_Comp";
            this.dtpFechaIni_Comp.Size = new System.Drawing.Size(100, 20);
            this.dtpFechaIni_Comp.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnBuscar_Comp);
            this.groupBox1.Controls.Add(this.dgvCompensacion);
            this.groupBox1.Controls.Add(this.dtpFechaIni_Comp);
            this.groupBox1.Controls.Add(this.dtpFechaFin_Comp);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Location = new System.Drawing.Point(7, 62);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(830, 319);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DEPÓSITOS A COMPENSAR";
            // 
            // FrmDepositoCompensacion
            // 
            this.AcceptButton = this.btnBuscar_Comp;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(849, 445);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.paHeader);
            this.Controls.Add(this.panel5);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmDepositoCompensacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Depósito por Compensación";
            this.paHeader.ResumeLayout(false);
            this.paHeader.PerformLayout();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCompensacion)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel paHeader;
        private System.Windows.Forms.Label laTitulo;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnSalir_Comp;
        private System.Windows.Forms.Button btnGenerar_comp;
        private System.Windows.Forms.Button btnBuscar_Comp;
        private System.Windows.Forms.DataGridView dgvCompensacion;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtpFechaFin_Comp;
        private System.Windows.Forms.DateTimePicker dtpFechaIni_Comp;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridViewComboBoxColumn Col_EsSuccess;
        private System.Windows.Forms.DataGridViewTextBoxColumn nReferencia;
        private System.Windows.Forms.DataGridViewTextBoxColumn nIdLogArchiProcDep;
    }
}