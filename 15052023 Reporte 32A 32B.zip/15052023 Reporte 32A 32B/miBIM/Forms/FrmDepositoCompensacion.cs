﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading; //LVCH 24082018
using System.Windows.Forms;

namespace miBIM.Forms
{
    public partial class FrmDepositoCompensacion : Form
    {
        public String cUser = Environment.UserName.ToString().ToUpper();
        public String cAgencia = "01";

        public FrmDepositoCompensacion()
        {
            InitializeComponent();
        }

        //UQMA 04/10/2017 para habilitar botonGeneraComp
        public void Hab_Des_Boton()
        {
            if (dgvCompensacion.Rows.Count > 0)
            {
                btnGenerar_comp.Enabled = true;
            }
            else
                btnGenerar_comp.Enabled = false;
        }

        private void btnBuscar_Comp_Click(object sender, EventArgs e)
        {
            dgvCompensacion.DataSource = null;
            cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
            DataTable dtDepCompensacion = new DataTable();
            dtDepCompensacion = oInstruccion.Buscar_Compensacion(dtpFechaIni_Comp.Value, dtpFechaFin_Comp.Value);
            dgvCompensacion.DataSource = dtDepCompensacion;

            //UQMA 03/10/2017 Para cargar los nro de referencia
            Cargar_RefDepCompensacion();
            //UQMA 04/10/2017 Para que las solumnas sean solo de lectura
            dgvCompensacion.Columns["BancoOrigen"].ReadOnly = true;
            dgvCompensacion.Columns["BancoDestino"].ReadOnly = true;
            dgvCompensacion.Columns["FechaTransaccion"].ReadOnly = true;
            dgvCompensacion.Columns["MontoEnviado"].ReadOnly = true;
            dgvCompensacion.Columns["MontoRecibido"].ReadOnly = true;
            dgvCompensacion.Columns["DiferenciaMonto"].ReadOnly = true;
            dgvCompensacion.Columns["Moneda"].ReadOnly = true;
            dgvCompensacion.Columns["IdLogArchivos"].ReadOnly = true;
            //UQMA 04/10/2017 Para dar formato a las columnas
            dgvCompensacion.Columns["MontoEnviado"].DefaultCellStyle.Format = "N2";
            dgvCompensacion.Columns["MontoRecibido"].DefaultCellStyle.Format = "N2";
            dgvCompensacion.Columns["DiferenciaMonto"].DefaultCellStyle.Format = "N2";
            dgvCompensacion.Columns["IdLogArchivos"].Visible = false;
            dgvCompensacion.Columns["IdNetting"].Visible = false;
            //UQMA 04/10/2017 para habilitar boton
            Hab_Des_Boton();

        }

        //UQMA 23/10/2017 Para verificar que selecciono un estado
        private bool Selecciono_Estados()
        {
            foreach (DataGridViewRow row in dgvCompensacion.Rows)
            {
                //verifica que hayga cargado el nro de referencia
                if (row.Cells["nReferencia"].Value == null )
                {
                    MessageBox.Show("No se cargo el Nro de Referencia, comuniquese con TI", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return false;
                }
                else
                {
                    if (row.Cells["nReferencia"].Value.ToString().Trim() == "")
                    {
                        MessageBox.Show("No se cargo el Nro de Referencia, comuniquese con TI", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return false;
                    }
                }

                //Verifica si selecciono un estado
                if (row.Cells["Col_EsSuccess"].Value.ToString() == "-- Seleccione Estado --")
                {
                    MessageBox.Show("Seleccione un estado", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); 
                    return false;
                }
            }
            return true;
        }

        //UQMA 03/10/2017 Para cargar los nro de referencia
        private void Cargar_RefDepCompensacion()
        {
            int idLog = 0;
            string sBancodestino = "";
            string sBancoOrigen = "";
            string sMoneda = "";
            double dMonto = 0;
            string sRef = "";
            int nIdLogArchiProcDep = 0;
            cArchivoInstruccion oInstruccion = new cArchivoInstruccion();

            foreach (DataGridViewRow row in dgvCompensacion.Rows)
            {
                //UQMA 04/10/2017 para seleccionar por defecto SUCCESS
                row.Cells["Col_EsSuccess"].Value = "-- Seleccione Estado --";

                idLog = int.Parse(row.Cells["IdLogArchivos"].Value.ToString());
                sBancodestino = row.Cells["BancoDestino"].Value.ToString();
                sBancoOrigen = row.Cells["BancoOrigen"].Value.ToString();
                sMoneda = row.Cells["Moneda"].Value.ToString();
                dMonto = double.Parse(row.Cells["DiferenciaMonto"].Value.ToString()) * (-1);
                nIdLogArchiProcDep = 0;
                sRef = oInstruccion.Obtiene_Ref_DepComp(idLog, sBancodestino, sBancoOrigen, sMoneda, dMonto, ref nIdLogArchiProcDep);
                row.Cells["nReferencia"].Value = sRef;
                row.Cells["nIdLogArchiProcDep"].Value = nIdLogArchiProcDep;

            }
        }

        private void btnGenerar_comp_Click(object sender, EventArgs e)
        {
            if (Selecciono_Estados())
            {
                DialogResult oResultadoMsg = MessageBox.Show("¿Seguro que desea Generar archivo plano de Depósito por Compensación?", "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Question); //UQMA 17/10/2017

                if (oResultadoMsg == DialogResult.Yes) //UQMA 17/10/2017
                {
                    String cNroCelular;
                    String cNombre;
                    String cApellido;
                    Double nMonto;
                    String cMensaje = "";
                    int nRespuesta;
                    int[] nNroMovimientos;
                    int i = 0;
                    int nEscompensacion = 0;
                    string[] cSuccessFailed; //LVCH 24082018
                    cSuccessFailed = new string[dgvCompensacion.Rows.Count]; //LVCH 24082018

                    Boolean bEsRespuesta;

                    cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
                    DataTable oResultado = new DataTable();
                    DateTime dFechaSistema = oInstruccion.Obtiene_FechaSistema();
                    nNroMovimientos = new int[dgvCompensacion.Rows.Count];

                    foreach (DataGridViewRow row in dgvCompensacion.Rows)
                    {
                        //Inicio UQMA 04/10/2017 Se comento
                        //if (row.Cells[0].Value == null)
                        //{
                        //    row.Cells[0].Value = false;
                        //}
                        //Fin UQMA 04/10/2017 Se comento

                        if (row.Cells["nReferencia"].Value != null)
                        {
                            cMensaje = row.Cells["nReferencia"].Value.ToString().ToUpper().Trim();//UQMA  03/10/2017 para obtener el nro de referencia
                        }


                        //UQMA bEsRespuesta: TRUE: SUCCESS, FALSE: FAILED
                        if (row.Cells["Col_EsSuccess"].Value.ToString() == "SUCCESS")
                        {
                            bEsRespuesta = true;
                            cSuccessFailed[i] = "S"; //LVCH 24082018
                        }
                        else
                        {
                            bEsRespuesta = false;
                            cSuccessFailed[i] = "F"; //LVCH 24082018
                        }

                        // if (bEsRespuesta) //UQMA 29/09/2017 Se comento
                        // {  //UQMA 29/09/2017 Se comento
                        cNroCelular = "";
                        cNombre = "";//row.Cells["Nombre"].Value.ToString();
                        cApellido = "";// row.Cells["Apellido"].Value.ToString();
                        nMonto = Math.Abs(Double.Parse(row.Cells["DiferenciaMonto"].Value.ToString()));

                        //Inicio UQMA 29/09/2017 Se comento
                        //try
                        //{
                        //    cMensaje = row.Cells[1].Value.ToString().ToUpper().Trim();
                        //}
                        //catch (Exception)
                        //{
                        //    MessageBox.Show("Ingrese Numero de Referencia", "Alerta");
                        //    return;
                        //}
                        //Fin UQMA 29/09/2017 Se comento

                        nEscompensacion = 1;
                        // UQMA 29 /09/2017 Recupera nidlogArchivos
                        int nidlogArchivos = int.Parse(row.Cells["IdNetting"].Value.ToString());
                        int nidlogArchProcDep = int.Parse(row.Cells["nIdLogArchiProcDep"].Value.ToString());
                        oResultado = oInstruccion.Insertar_Deposito(cUser, cAgencia, dFechaSistema, cNroCelular, cNombre, cApellido, nMonto, cMensaje, nEscompensacion, nidlogArchivos,nidlogArchProcDep, bEsRespuesta);
                        nRespuesta = int.Parse(oResultado.Rows[0][0].ToString());
                        switch (nRespuesta)
                        {
                            case -1:
                                MessageBox.Show("Error al registrar depósito.", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            case -2:
                                MessageBox.Show("El numero de Referencia ya se registro.", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            default:
                                nNroMovimientos[i] = nRespuesta;
                                i++;
                                break;

                        }

                        //if (nRespuesta == -1)
                        //{
                        //    MessageBox.Show("Error al registrar deposito");
                        //}
                        //else
                        //{
                        //    nNroMovimientos[i] = nRespuesta;
                        //}

                    }
                    //}  //UQMA 29/09/2017 Se comento

                    if (i > 0)
                    {
                        //INICIO - LVCH 24082018 - Se divide en dos arreglos (success - failed)
                        int[] nNroMovimientosTipoS;
                        int[] nNroMovimientosTipoF;
                        nNroMovimientosTipoS = new int[nNroMovimientos.Length];
                        nNroMovimientosTipoF = new int[nNroMovimientos.Length];
                        int s = 0;
                        int f = 0;
                        for (int j = 0; j < nNroMovimientos.Length; j++)
                        {
                            if (cSuccessFailed[j] == "S")
                            {
                                nNroMovimientosTipoS[s] = nNroMovimientos[j];
                                s++;
                            }
                            else
                            {
                                nNroMovimientosTipoF[f] = nNroMovimientos[j];
                                f++;
                            }
                        }

                        if (s > 0)
                            EscribirDeposito(nNroMovimientosTipoS);
                        if (f > 0)
                        {
                            Thread.Sleep(1000);
                            EscribirDeposito(nNroMovimientosTipoF);
                        }

                        //EscribirDeposito(nNroMovimientos); //LVCH 24082018

                        //FIN - LVCH 24082018 - Se divide en dos arreglos (success - failed)
                        i = 0;
                    }
                    //else
                    //    MessageBox.Show("No ha seleccionado deposito valido","Alerta");
                }
            }
        }

        private void EscribirDeposito(int[] nNroMovimientos)
        {
            DataSet dsCompensacion = new DataSet();
            cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
            String cTipoOperacion;
            //String cTipo;
            DateTime dFehaHoraTransaccion;
            DateTime dFehaHoraRecepcion;
            Double nMonto;
            String cMSISDN;
            int nMovBIM;
            String cNombre;
            String cApellido;
            //String IdIntruccionPago;
            //int IdTransaccion;
            String cRemitenteCodigo;
            String cRemitenteCuenta;
            String cMensaje;
            int nMov;

            StreamWriter sw = null;
            DateTime dFecha = DateTime.Now;
            String cNombreArchivo;
            cConstante oConstante = new cConstante();
            cNombreArchivo = "CCUSCO-DEP-" + dFecha.ToString("yyyyMMddHHmmss") + ".csv";
            string path = oConstante.cpRutaOrigenOutgoing + cNombreArchivo;
            DataSet oCabecera;
            int nPrimera = 0;

            if (nPrimera == 0)
            {
                nPrimera = nPrimera + 1;
                //Obtener cabecera 
                oCabecera = oInstruccion.ObtenerCabecera();
                sw = File.CreateText(path);

                foreach (DataRow row in oCabecera.Tables[0].Rows)
                {
                    sw.WriteLine(row["cCabecera"].ToString());
                }
                sw.Flush();
                sw.Close();
            }
            else
            {
                File.Delete(path);
                sw = File.CreateText(path);
                sw.Flush();
                sw.Close();
            }

            for (int i = 0; i < nNroMovimientos.Length; i++)
            {
                nMov = nNroMovimientos[i];

                if (nMov != 0)
                {
                    dsCompensacion = oInstruccion.Obtener_Deposito(cNombreArchivo, nMov);

                    if (dsCompensacion.Tables[0].Rows.Count == 0)
                    {
                        MessageBox.Show("No existen operaciones registradas en la fecha. ", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        foreach (DataRow row in dsCompensacion.Tables[0].Rows)
                        {
                            //cTipoOperacion, dFehaHoraTransaccion,dFehaHoraRecepcion,nMonto, cMSISDN, nMovBIM,cNombre, cApellido,cRemitenteCodigo,cRemitenteCuenta
                            cTipoOperacion = row["cTipoOperacion"].ToString();
                            dFehaHoraTransaccion = DateTime.Parse(row["dFechaHoraTransaccion"].ToString());
                            dFehaHoraRecepcion = DateTime.Parse(row["dFechaHoraRecepcion"].ToString());
                            nMonto = Double.Parse(row["nMonto"].ToString());
                            cMSISDN = row["cMSISDN"].ToString();
                            nMovBIM = int.Parse(row["nMovBIM"].ToString());
                            cNombre = row["cNombre"].ToString();
                            cApellido = row["cApellido"].ToString();
                            cRemitenteCodigo = row["cRemitenteCodigo"].ToString();
                            cRemitenteCuenta = row["cRemitenteCuenta"].ToString();
                            cMensaje = row["cMensaje"].ToString().ToUpper();


                            sw = File.AppendText(path);
                            sw.WriteLine(cTipoOperacion + "," + dFehaHoraTransaccion.ToString("yyyy-MM-dd HH:mm:ss") + "," + "" + "," + String.Format("{0,12:0.00}", nMonto).Trim() + "," + cMSISDN + "," + nMovBIM + "," + cNombre + "," + cApellido + "," + cRemitenteCodigo + "," + cRemitenteCuenta + "," + cMensaje);
                            sw.Flush();
                            sw.Close();
                        }
                    }
                }
            }

            String cMensajeFirma = oConstante.FirmaArchivo(cNombreArchivo);
            if (cMensajeFirma != "")
            {
                MessageBox.Show(cMensajeFirma.ToString(), "Alerta");
                return;
            }

            //FirmaArchivo(cNombreArchivo);
            dgvCompensacion.DataSource = null;
            Hab_Des_Boton(); //UQMA 17/10/2017
            MessageBox.Show("Archivo Generado de forma satisfactoria, " + path);
            //return path;
        }

        private void btnSalir_Comp_Click(object sender, EventArgs e)
        {
            this.Close(); //UQMA 04/10/2017
        }

    }
}
