﻿namespace miBIM.Forms
{
    partial class FrmModificarReporte32
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmModificarReporte32));
            this.btn_GenerarReporte32 = new System.Windows.Forms.Button();
            this.gb_nombre = new System.Windows.Forms.GroupBox();
            this.dgv_DatosReporte32A = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.dtpck_Fecha = new System.Windows.Forms.DateTimePicker();
            this.cb_TipoReportes = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.paHeader = new System.Windows.Forms.Panel();
            this.laTitulo = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblMensaje = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnTipoCambio = new System.Windows.Forms.Button();
            this.lbTipoCambio = new System.Windows.Forms.Label();
            this.txtTipoCambio = new System.Windows.Forms.TextBox();
            this.btnSalir = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.gb_nombre.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_DatosReporte32A)).BeginInit();
            this.paHeader.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_GenerarReporte32
            // 
            this.btn_GenerarReporte32.Location = new System.Drawing.Point(544, 27);
            this.btn_GenerarReporte32.Name = "btn_GenerarReporte32";
            this.btn_GenerarReporte32.Size = new System.Drawing.Size(100, 24);
            this.btn_GenerarReporte32.TabIndex = 0;
            this.btn_GenerarReporte32.Text = "Leer Reporte 32";
            this.btn_GenerarReporte32.UseVisualStyleBackColor = true;
            this.btn_GenerarReporte32.Click += new System.EventHandler(this.btn_GenerarReporte32_Click);
            // 
            // gb_nombre
            // 
            this.gb_nombre.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gb_nombre.Controls.Add(this.dgv_DatosReporte32A);
            this.gb_nombre.Location = new System.Drawing.Point(15, 59);
            this.gb_nombre.Name = "gb_nombre";
            this.gb_nombre.Size = new System.Drawing.Size(896, 283);
            this.gb_nombre.TabIndex = 1;
            this.gb_nombre.TabStop = false;
            this.gb_nombre.Text = "Reporte 32-A Reporte Diario de Dinero Electrónico";
            // 
            // dgv_DatosReporte32A
            // 
            this.dgv_DatosReporte32A.AllowUserToAddRows = false;
            this.dgv_DatosReporte32A.AllowUserToDeleteRows = false;
            this.dgv_DatosReporte32A.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_DatosReporte32A.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_DatosReporte32A.Location = new System.Drawing.Point(10, 19);
            this.dgv_DatosReporte32A.Name = "dgv_DatosReporte32A";
            this.dgv_DatosReporte32A.Size = new System.Drawing.Size(878, 252);
            this.dgv_DatosReporte32A.TabIndex = 1;
            this.dgv_DatosReporte32A.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_DatosReporte32A_CellEndEdit);
            this.dgv_DatosReporte32A.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgv_DatosReporte32A_EditingControlShowing);
            this.dgv_DatosReporte32A.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dgv_DatosReporte32A_KeyPress);
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(418, 16);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 36);
            this.button1.TabIndex = 4;
            this.button1.Text = "Guardar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dtpck_Fecha
            // 
            this.dtpck_Fecha.CustomFormat = "dd/MM/yyyy";
            this.dtpck_Fecha.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpck_Fecha.Location = new System.Drawing.Point(279, 28);
            this.dtpck_Fecha.Name = "dtpck_Fecha";
            this.dtpck_Fecha.Size = new System.Drawing.Size(108, 20);
            this.dtpck_Fecha.TabIndex = 3;
            // 
            // cb_TipoReportes
            // 
            this.cb_TipoReportes.FormattingEnabled = true;
            this.cb_TipoReportes.Location = new System.Drawing.Point(393, 28);
            this.cb_TipoReportes.Name = "cb_TipoReportes";
            this.cb_TipoReportes.Size = new System.Drawing.Size(121, 21);
            this.cb_TipoReportes.TabIndex = 5;
            this.cb_TipoReportes.SelectedIndexChanged += new System.EventHandler(this.cb_TipoReportes_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(207, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Seleccione Fecha de Generación de Rep.";
            // 
            // paHeader
            // 
            this.paHeader.BackColor = System.Drawing.SystemColors.ControlLight;
            this.paHeader.Controls.Add(this.laTitulo);
            this.paHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.paHeader.Location = new System.Drawing.Point(0, 0);
            this.paHeader.Name = "paHeader";
            this.paHeader.Size = new System.Drawing.Size(925, 49);
            this.paHeader.TabIndex = 29;
            // 
            // laTitulo
            // 
            this.laTitulo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.laTitulo.AutoSize = true;
            this.laTitulo.BackColor = System.Drawing.Color.YellowGreen;
            this.laTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laTitulo.ForeColor = System.Drawing.Color.Transparent;
            this.laTitulo.Location = new System.Drawing.Point(244, 9);
            this.laTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laTitulo.Name = "laTitulo";
            this.laTitulo.Size = new System.Drawing.Size(380, 20);
            this.laTitulo.TabIndex = 0;
            this.laTitulo.Text = "MODIFICAR REPORTE 32 A / 32 B-I / 32 B-IV";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblMensaje);
            this.groupBox1.Controls.Add(this.cb_TipoReportes);
            this.groupBox1.Controls.Add(this.btn_GenerarReporte32);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.gb_nombre);
            this.groupBox1.Controls.Add(this.dtpck_Fecha);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(925, 348);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "MODIFICACION DE REPORTE 32A - 32BI -32BIV";
            // 
            // lblMensaje
            // 
            this.lblMensaje.AutoSize = true;
            this.lblMensaje.ForeColor = System.Drawing.Color.Red;
            this.lblMensaje.Location = new System.Drawing.Point(691, 34);
            this.lblMensaje.Name = "lblMensaje";
            this.lblMensaje.Size = new System.Drawing.Size(16, 13);
            this.lblMensaje.TabIndex = 2;
            this.lblMensaje.Text = "...";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.btnTipoCambio);
            this.panel1.Controls.Add(this.lbTipoCambio);
            this.panel1.Controls.Add(this.txtTipoCambio);
            this.panel1.Controls.Add(this.btnSalir);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 397);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(925, 67);
            this.panel1.TabIndex = 31;
            // 
            // btnTipoCambio
            // 
            this.btnTipoCambio.Location = new System.Drawing.Point(222, 18);
            this.btnTipoCambio.Name = "btnTipoCambio";
            this.btnTipoCambio.Size = new System.Drawing.Size(111, 26);
            this.btnTipoCambio.TabIndex = 8;
            this.btnTipoCambio.Text = "Pasar Valor";
            this.btnTipoCambio.UseVisualStyleBackColor = true;
            this.btnTipoCambio.Click += new System.EventHandler(this.btnTipoCambio_Click);
            // 
            // lbTipoCambio
            // 
            this.lbTipoCambio.AutoSize = true;
            this.lbTipoCambio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTipoCambio.Location = new System.Drawing.Point(43, 25);
            this.lbTipoCambio.Name = "lbTipoCambio";
            this.lbTipoCambio.Size = new System.Drawing.Size(99, 13);
            this.lbTipoCambio.TabIndex = 7;
            this.lbTipoCambio.Text = "Tipo de Cambio:";
            this.toolTip1.SetToolTip(this.lbTipoCambio, "Valor Recuperado del último día del mes seleccionado.");
            // 
            // txtTipoCambio
            // 
            this.txtTipoCambio.Location = new System.Drawing.Point(148, 22);
            this.txtTipoCambio.MaxLength = 7;
            this.txtTipoCambio.Name = "txtTipoCambio";
            this.txtTipoCambio.Size = new System.Drawing.Size(66, 20);
            this.txtTipoCambio.TabIndex = 6;
            this.txtTipoCambio.Text = "0.00";
            this.toolTip1.SetToolTip(this.txtTipoCambio, "Permite digitar hasta con 3 decimales separados por un punto \".\"\r\nValor Referenci" +
        "al obtenido de la base de datos.");
            this.txtTipoCambio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTipoCambio_KeyPress);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(537, 16);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(113, 36);
            this.btnSalir.TabIndex = 5;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // FrmModificarReporte32
            // 
            this.AcceptButton = this.btn_GenerarReporte32;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(925, 464);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.paHeader);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmModificarReporte32";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Modificar Reporte 32A - 32BIV";
            this.gb_nombre.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_DatosReporte32A)).EndInit();
            this.paHeader.ResumeLayout(false);
            this.paHeader.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_GenerarReporte32;
        private System.Windows.Forms.GroupBox gb_nombre;
        private System.Windows.Forms.DateTimePicker dtpck_Fecha;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cb_TipoReportes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel paHeader;
        private System.Windows.Forms.Label laTitulo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Label lbTipoCambio;
        private System.Windows.Forms.TextBox txtTipoCambio;
        private System.Windows.Forms.Button btnTipoCambio;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.DataGridView dgv_DatosReporte32A;
        private System.Windows.Forms.Label lblMensaje;
    }
}