﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static CapaNegocio.cArchivoReporte; /* 04072023 HSPC - Se agrega nueva referencia a la clase para validar datos */

namespace miBIM.Forms
{
    public partial class FrmModificarReporte32 : Form
    {
        bool esreporteA = true;

        /* INICIO 04072023 HSPC - Se crea variables globales de las listas a mostrar */
        /* variables globales */
        List<cDataReporte32A> vgLista32A = new List<cDataReporte32A>();
        List<cDataReporte32BI> vgLista32BI = new List<cDataReporte32BI>();
        List<cDataReporte32BII> vgLista32BII = new List<cDataReporte32BII>();
        List<cDataReporte32BIII> vgLista32BIII = new List<cDataReporte32BIII>();
        List<cDataReporte32BIV> vgLista32BIV = new List<cDataReporte32BIV>();
        List<cDataReporte32BV> vgLista32BV = new List<cDataReporte32BV>();
        /* FIN 04072023 HSPC - Se crea variables globales de las listas a mostrar */

        public FrmModificarReporte32()
        {
            InitializeComponent();
            Listar_Reportes(); /* 04072023 HSPC - Se llama al metodo para listar los reportes */
            cb_TipoReportes.SelectedItem = "Reporte 32-A";

            dtpck_Fecha.Value = new DateTime(2023, 03, 31);
        }

        /* INICIO 04072023 HSPC - Se crea metodo que devuelve los reportes a listar */
        void Listar_Reportes()
        {
            cb_TipoReportes.Items.Add("Reporte 32-A");
            cb_TipoReportes.Items.Add("Reporte 32-BI");
            cb_TipoReportes.Items.Add("Reporte 32-BII");
            cb_TipoReportes.Items.Add("Reporte 32-BIII");
            cb_TipoReportes.Items.Add("Reporte 32-BIV");
            cb_TipoReportes.Items.Add("Reporte 32-BV");
        }
        /* FIN 04072023 HSPC - Se crea metodo que devuelve los reportes a listar */
        public bool VerificarArchivos(string cnombre_archivo)
        {
            cConstante oConstante = new cConstante(); //UQMA 28/11/2017 

            if (esreporteA)
            {
                if (!File.Exists(oConstante.cpRutaOrigen + @"\REPORTE 32A\" + cnombre_archivo)) //UQMA 28/11/2017  se cambio de ruta @"C:\Modelo Peru\PDPReportes\" por  oConstante.cpRutaOrigen
                {
                    MessageBox.Show("Error: Copie el archivo " + cnombre_archivo + " en la ruta:" + oConstante.cpRutaOrigen + "REPORTE 32A ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); //UQMA 28/11/2017  se cambio de ruta @"C:\Modelo Peru\PDPReportes\" por  oConstante.cpRutaOrigen
                    return false;
                }

            }
            else
            {
                if (!File.Exists(oConstante.cpRutaOrigen + @"\REPORTE 32B\" + cnombre_archivo)) //UQMA 28/11/2017  se cambio de ruta @"C:\Modelo Peru\PDPReportes\" por  oConstante.cpRutaOrigen
                {
                    MessageBox.Show("Error: Copie el archivo " + cnombre_archivo + " en la ruta:" + oConstante.cpRutaOrigen + "REPORTE 32B", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); //UQMA 28/11/2017  se cambio de ruta @"C:\Modelo Peru\PDPReportes\" por  oConstante.cpRutaOrigen
                    return false;
                }
            }

            return true;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //bool continuar = true; /* 04072023 HSPC - Se comenta por nueva logica */
            try
            {
                /* INICIO 04072023 HSPC - Se comenta por nueva logica */
                ////string cnombre_archivo = dgv_DatosReporte32A.Rows[0].Cells["Col_nombre_archivo"].Value.ToString();
                //string cnombre_archivo = dgv_DatosReporte32A.Rows[0].Cells[0].Value.ToString(); // 20/03/2018 LVCH para agregar el nombre de Reporte
                //if (VerificarArchivos(cnombre_archivo)) //Verificamos que los archivos esten copiados en la ruta
                //{
                //    cArchivoReporte oReportes = new cArchivoReporte();
                //    if (cb_TipoReportes.SelectedItem.Equals("Reporte 32-BI")) // 20/03/2018 LVCH condicional para editar el Tipo de Cambio en Reporte32_BI
                //    {
                //        string nTipoCambio = dgv_DatosReporte32A.Rows[0].Cells[7].Value.ToString();

                //        if (Es_FormatoCorrecto(nTipoCambio))
                //        {
                //            for (int i = 0; i < dgv_DatosReporte32A.Rows.Count; i++)
                //            {
                //                oReportes.Editar_Reporte32BI(int.Parse(dgv_DatosReporte32A.Rows[i].Cells[2].Value.ToString()), float.Parse(dgv_DatosReporte32A.Rows[i].Cells[7].Value.ToString()));
                //            }
                //        }
                //        else
                //        {
                //            continuar = false;
                //        }

                //        // 20/03/2018 LVCH Generar Reporte32_BI y actualizar Tipo de cambio 
                //        if (continuar)
                //        {
                //            if (dgv_DatosReporte32A.Rows.Count > 0)
                //            {
                //                ExportarReportes("REPORTE 32B", cnombre_archivo, nTipoCambio, "BI");
                //                dgv_DatosReporte32A.Rows.Clear();
                //            }
                //        }
                //    }
                //    else // 20/03/2018 LVCH
                //    {
                //        string cfidecometido = "";
                //        for (int i = 0; i < dgv_DatosReporte32A.Rows.Count; i++)
                //        {
                //            //cfidecometido = dgv_DatosReporte32A.Rows[i].Cells["Col_ValorPatriFidecometido"].Value.ToString().Trim();
                //            cfidecometido = dgv_DatosReporte32A.Rows[i].Cells[5].Value.ToString().Trim();// 20/03/2018 LVCH el nombre de columna ya no esta
                //            if (Es_FormatoCorrecto(cfidecometido))
                //            {
                //                if (esreporteA)
                //                {
                //                    //oReportes.Editar_Reporte32A(int.Parse(dgv_DatosReporte32A.Rows[i].Cells["Col_IdRepA"].Value.ToString()), cfidecometido);
                //                    oReportes.Editar_Reporte32A(int.Parse(dgv_DatosReporte32A.Rows[i].Cells[2].Value.ToString()), cfidecometido);// 20/03/2018 LVCH el nombre de columna ya no esta
                //                }
                //                else
                //                {
                //                    //oReportes.Editar_Reporte32BIV(int.Parse(dgv_DatosReporte32A.Rows[i].Cells["Col_IdRepA"].Value.ToString()), cfidecometido);
                //                    oReportes.Editar_Reporte32BIV(int.Parse(dgv_DatosReporte32A.Rows[i].Cells[2].Value.ToString()), cfidecometido);// 20/03/2018 LVCH el nombre de columna ya no esta
                //                }
                //            }
                //            else
                //            {
                //                continuar = false;
                //                break;
                //            }
                //        }
                //        //Generar Reporte32
                //        if (continuar)
                //        {
                //            if (dgv_DatosReporte32A.Rows.Count > 0)
                //            {
                //                if (esreporteA)
                //                    ExportarReportes("REPORTE 32A", cnombre_archivo, cfidecometido, "A");
                //                else
                //                    ExportarReportes("REPORTE 32B", cnombre_archivo, cfidecometido, "BIV");

                //                dgv_DatosReporte32A.Rows.Clear();
                //            }
                //        }
                //    }
                //}
                /* FIN 04072023 HSPC - Se comenta por nueva logica */

                /* INICIO 04072023 HSPC - Se guarda los datos del reporte */

                cArchivoReporte oReportes = new cArchivoReporte();

                switch (cb_TipoReportes.SelectedItem.ToString())
                {
                    case "Reporte 32-A":

                        foreach (cDataReporte32A clase in vgLista32A)
                        {
                            oReportes.Editar_Reporte32A(
                                cConverciones.ConvertirAEntero(clase.nIdRepA, 0),
                                cConverciones.ConvertirACadena(clase.nFideicometido, ""),
                                cConverciones.ConvertirADouble(clase.nValorDisposicionInmediata, 0),
                                cConverciones.ConvertirADouble(clase.nValorGarantia, 0)
                                );
                        }

                        ExportarReporte("REPORTE 32A", vgLista32A[0].cNombreArchivo, cb_TipoReportes.SelectedItem.ToString());

                        dgv_DatosReporte32A.Columns.Clear();

                        break;

                    case "Reporte 32-BI":

                        foreach (cDataReporte32BI clase in vgLista32BI)
                        {
                            oReportes.Editar_Reporte32BI(
                                cConverciones.ConvertirAEntero(clase.nIdRepBI, 0),
                                cConverciones.ConvertirADouble(clase.nMontoConver, 0),
                                cConverciones.ConvertirAEntero(clase.nNroOperacionesConver, 0),
                                cConverciones.ConvertirADouble(clase.nMontoTransfPago, 0),
                                cConverciones.ConvertirAEntero(clase.nNroOperacionesTransfPago, 0),
                                cConverciones.ConvertirADouble(clase.nMontoReconversiones, 0),
                                cConverciones.ConvertirAEntero(clase.nNroOperacionesReconversiones, 0),
                                cConverciones.ConvertirADouble(clase.nMontoOtros, 0),
                                cConverciones.ConvertirAEntero(clase.nNroOperacionesotros, 0),
                                cConverciones.ConvertirADouble(clase.nTipoCambio, 0)
                                );
                        }

                        ExportarReporte("REPORTE 32B", vgLista32BI[0].cNombreArchivo, cb_TipoReportes.SelectedItem.ToString());

                        dgv_DatosReporte32A.Columns.Clear();

                        break;

                    case "Reporte 32-BII":

                        foreach (cDataReporte32BII clase in vgLista32BII)
                        {
                            oReportes.Editar_Reporte32BII(
                                cConverciones.ConvertirAEntero(clase.nIdRepBII, 0),
                                cConverciones.ConvertirADouble(clase.nMonedaNacional, 0),
                                cConverciones.ConvertirADouble(clase.nMonedaExtranjera, 0),
                                cConverciones.ConvertirADouble(clase.nTotal, 0)
                                );
                        }

                        ExportarReporte("REPORTE 32B", vgLista32A[0].cNombreArchivo, cb_TipoReportes.SelectedItem.ToString());

                        dgv_DatosReporte32A.Columns.Clear();

                        break;

                    case "Reporte 32-BIII":

                        foreach (cDataReporte32BIII clase in vgLista32BIII)
                        {
                            oReportes.Editar_Reporte32BIII(
                                cConverciones.ConvertirAEntero(clase.nIdRepBIII, 0),
                                cConverciones.ConvertirAEntero(clase.nCtaSimNroDeCuentas, 0),
                                cConverciones.ConvertirAEntero(clase.nCtaSimNroDeTitu, 0),
                                cConverciones.ConvertirAEntero(clase.nCtaGnrlNroDeCuentas, 0),
                                cConverciones.ConvertirAEntero(clase.nCtaGnrlNroDeTitu, 0)                                
                                );
                        }

                        ExportarReporte("REPORTE 32B", vgLista32A[0].cNombreArchivo, cb_TipoReportes.SelectedItem.ToString());

                        dgv_DatosReporte32A.Columns.Clear();

                        break;

                    case "Reporte 32-BIV":

                        foreach (cDataReporte32BIV clase in vgLista32BIV)
                        {
                            oReportes.Editar_Reporte32BIV(
                                cConverciones.ConvertirAEntero(clase.nIdRepBIV, 0),
                                cConverciones.ConvertirADouble(clase.nTotDineroElec, 0),
                                cConverciones.ConvertirADouble(clase.nValPatriFideicometido, 0),
                                cConverciones.ConvertirADouble(clase.nValorDisposicionInmediata, 0),
                                cConverciones.ConvertirADouble(clase.nValorGarantia, 0)
                                );
                        }

                        ExportarReporte("REPORTE 32B", vgLista32A[0].cNombreArchivo, cb_TipoReportes.SelectedItem.ToString());

                        dgv_DatosReporte32A.Columns.Clear();

                        break;

                    case "Reporte 32-BV":

                        foreach (cDataReporte32BV clase in vgLista32BV)
                        {
                            oReportes.Editar_Reporte32BV(
                                cConverciones.ConvertirAEntero(clase.nIdRepBV, 0),
                                cConverciones.ConvertirADouble(clase.nTeléfono, 0),
                                cConverciones.ConvertirADouble(clase.nTarjetaPrepago, 0),
                                cConverciones.ConvertirADouble(clase.nOtro, 0)
                                );
                        }

                        ExportarReporte("REPORTE 32B", vgLista32A[0].cNombreArchivo, cb_TipoReportes.SelectedItem.ToString());

                        dgv_DatosReporte32A.Columns.Clear();

                        break;

                    default:
                        break;
                }
                /* FIN 04072023 HSPC - Se guarda los datos del reporte */
            }
            catch (Exception error)
            {
                MessageBox.Show("Error: " + error.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private bool Es_FormatoCorrecto(string cfidecometido)
        {
            if (cfidecometido.StartsWith(".") )
            {
                MessageBox.Show("Existe un punto al comienzo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else
            {
                if ( cfidecometido.EndsWith("."))
                {
                    MessageBox.Show("Existe un punto al final.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
 
            }
            return true;
            //string[] cafidecometido = cfidecometido.Split('.');

            //if (cafidecometido.Length > 1)
            //{
            //    if (cafidecometido[1].Length <= 2)
            //    {
            //        return true;
            //    }
            //    else
            //    {
            //        MessageBox.Show("Solo debe tener dos decimales.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        return false;
            //    }
            //}
            //return true;
        }

        private void ExportarReportes(string cTipoReporte, string cNombreArchivo, string nuevo_cfidecometido, string cReporteActualizar)
        {
            cConstante oConstante = new cConstante(); //UQMA 28/11/2017  para la obtencion de de ruta

            StreamReader lectura;
            StreamWriter escritura;
            string linea;
            string campos;
            int contadorLinea;
            long cfidecometido;
            int fila=0;
            string cfidecometido_aux;

            lectura = File.OpenText(oConstante.cpRutaOrigen + cTipoReporte + "//" + cNombreArchivo);  //UQMA 28/11/2017  se cambio de ruta @"C:\Modelo Peru\PDPReportes\" por  oConstante.cpRutaOrigen
            if (File.Exists(oConstante.cpRutaOrigen + cTipoReporte + "//temp" + cNombreArchivo))
            {
                File.Delete(oConstante.cpRutaOrigen + cTipoReporte + "//temp" + cNombreArchivo); //UQMA 28/11/2017  se cambio de ruta @"C:\Modelo Peru\PDPReportes\" por  oConstante.cpRutaOrigen
            }

            escritura = File.CreateText(oConstante.cpRutaOrigen + cTipoReporte + "//temp" + cNombreArchivo); //UQMA 28/11/2017  se cambio de ruta @"C:\Modelo Peru\PDPReportes\" por  oConstante.cpRutaOrigen

            try
            {
                //if (File.Exists(@"C:\Modelo Peru\PDPReportes\" + cTipoReporte + "//temp" + cNombreArchivo))
                //{
                //    File.Delete(@"C:\Modelo Peru\PDPReportes\" + cTipoReporte + "//temp" + cNombreArchivo);
                //}

                //lectura = File.OpenText(@"C:\Modelo Peru\PDPReportes\" + cTipoReporte + "//" + cNombreArchivo);
                //escritura = File.CreateText(@"C:\Modelo Peru\PDPReportes\" + cTipoReporte + "//temp" + cNombreArchivo);

                linea = lectura.ReadLine().Trim();

                contadorLinea = 1;

                while (linea != null)
                {
                    if (cReporteActualizar == "BI" && contadorLinea>=2) // 20/03/2018 LVCH para modificar TipoCambio en el reporte 32 BI
                    {
                        cfidecometido_aux = dgv_DatosReporte32A.Rows[fila].Cells[7].Value.ToString();                        
                        campos = linea.Substring(0, 150);
                        string[] cadenaTipoCambio = cfidecometido_aux.Split('.');
                        while (cadenaTipoCambio[0].ToString().Length != 3) // 20/03/2018 LVCH para completar la cadena de enteros a 3 digitos
                        {
                            cadenaTipoCambio[0] = "0" + cadenaTipoCambio[0];
                        }
                        while (cadenaTipoCambio[1].ToString().Length != 3) // 20/03/2018 LVCH para completar la cadena de decimales a 3 digitos
                        {
                            cadenaTipoCambio[1] = cadenaTipoCambio[1] + "0";
                        }
                        string TipoCambioValidado = cadenaTipoCambio[0] + cadenaTipoCambio[1]; // 23/03/2018 LVCH cadena de tipo de cambio con 6 digitos                        
                        escritura.WriteLine(campos + TipoCambioValidado);
                        fila++;
                    }
                    else
                    {
                        if (esreporteA)
                        {
                            if (contadorLinea == 2)
                            {
                                campos = linea.Substring(0, 24);
                                cfidecometido = Convert.ToInt64(BorrarPunto(nuevo_cfidecometido));
                                escritura.WriteLine(campos + cfidecometido.ToString("D18"));
                            }
                            else
                            {
                                escritura.WriteLine(linea);
                            }
                        }
                        else
                        {
                            if (contadorLinea == 2 || contadorLinea == 3)
                            {
                                //cfidecometido_aux = dgv_DatosReporte32A.Rows[fila].Cells["Col_ValorPatriFidecometido"].Value.ToString();
                                cfidecometido_aux = dgv_DatosReporte32A.Rows[fila].Cells[5].Value.ToString(); // 20/03/2018 LVCH el nombre de columna ya no esta
                                campos = linea.Substring(0, 24);
                                cfidecometido = Convert.ToInt64(BorrarPunto(cfidecometido_aux));
                                escritura.WriteLine(campos + cfidecometido.ToString("D18"));
                                fila++;
                            }
                            else
                            {
                                escritura.WriteLine(linea);
                            }
                        }
                    }

                    contadorLinea++;
                    linea = lectura.ReadLine();
                }

                lectura.Close();
                escritura.Close();

                File.Delete(oConstante.cpRutaOrigen + cTipoReporte + "//" + cNombreArchivo);  //UQMA 28/11/2017  se cambio de ruta @"C:\Modelo Peru\PDPReportes\" por  oConstante.cpRutaOrigen
                File.Move(oConstante.cpRutaOrigen + cTipoReporte + "//temp" + cNombreArchivo, oConstante.cpRutaOrigen + cTipoReporte + "//" + cNombreArchivo);  //UQMA 28/11/2017 se cambio de ruta @"C:\Modelo Peru\PDPReportes\" por  oConstante.cpRutaOrigen

                MessageBox.Show("Se modifico correctamente", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
                button1.Enabled = false; //UQMA 28/11/2017  
            }
            catch (IOException error)
            {
                lectura.Close();
                escritura.Close();

                if (File.Exists(oConstante.cpRutaOrigen + cTipoReporte + "//temp" + cNombreArchivo)) //UQMA 28/11/2017  se cambio de ruta @"C:\Modelo Peru\PDPReportes\" por  oConstante.cpRutaOrigen
                {
                    File.Delete(oConstante.cpRutaOrigen + cTipoReporte + "//temp" + cNombreArchivo); //UQMA 28/11/2017  se cambio de ruta @"C:\Modelo Peru\PDPReportes\" por  oConstante.cpRutaOrigen
                }

                MessageBox.Show("Error: " + error.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExportarReporte(string _TipoReporte, string _NombreArchivo, string _ReporteExportar)
        {
            /* OBTENER LISTA DE RUTAS DE DB AL MOMENTO DE REALIZAR LA INSTACIA DE LA CLASE */
            cConstante oConstante = new cConstante();

            StreamReader lectura; /* COMPLEMENTO DE LECTURA DE ARCHIVO */
            StreamWriter escritura; /* COMPLEMENTO DE ESCRITURA DE ARCHIVOS */
            //string linea;

            /* INICIO DESARROLLO */
            /* INSTANCIA DE CUADRO DE DIALOGO - PRUEBAS EN DESARROLLO */
            OpenFileDialog oFD = new OpenFileDialog();
            oFD.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            oFD.Multiselect = false;
            oFD.ShowDialog();

            string RutaArchivoElegido = oFD.FileName;

            /* INSTANCIA DE CUADRO DE GUARDADO DE ARCHIVOS PLANOS - PRUEBDE DE DESARROLLO */
            SaveFileDialog sFD = new SaveFileDialog();
            sFD.FileName = _NombreArchivo;
            sFD.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            sFD.ShowDialog();

            string RutaArchivoGuardar = sFD.FileName;

            string sRutaCompleta = RutaArchivoGuardar.Replace(_NombreArchivo, "") + "\\" + _TipoReporte + "\\" + _NombreArchivo;
            string sRutaCarpetas = RutaArchivoGuardar.Replace(_NombreArchivo, "") + "\\" + _TipoReporte;

            if (!File.Exists(sRutaCompleta))
            {
                //string fullPath = Path.GetFullPath(sRuta);
                Directory.CreateDirectory(sRutaCarpetas);
                //StreamWriter sw = File.CreateText(sRutaCompleta);
            }
            
            /* Lectura de archivo existente para poder compararlo */
            lectura = File.OpenText(RutaArchivoElegido);

            /* Eliminacion de archivo existente para crear uno nuevo */
            if (File.Exists(sRutaCompleta))
            {
                File.Delete(sRutaCompleta);
            }
            /* Creacion de archivo dupliacdo para crear nuevo contenido */
            escritura = File.CreateText(sRutaCompleta);
            /* FIN DESARROLLO */

            /* INICIO PRODUCCION */
            /* Lectura de archivo existente para poder compararlo */
            //lectura = File.OpenText(oConstante.cpRutaOrigen + _TipoReporte + "//" + _NombreArchivo);

            ///* Eliminacion de archivo existente para crear uno nuevo */
            //if (File.Exists(oConstante.cpRutaOrigen + _TipoReporte + "//temp" + _NombreArchivo))
            //{
            //    File.Delete(oConstante.cpRutaOrigen + _TipoReporte + "//temp" + _NombreArchivo);
            //}

            ///* Creacion de archivo dupliacdo para crear nuevo contenido */
            //escritura = File.CreateText(oConstante.cpRutaOrigen + _TipoReporte + "//temp" + _NombreArchivo);
            /* FIN PRODUCCION */

            try
            {
                /* verificar el tipo de reporte a exportar */
                switch (_ReporteExportar)
                {
                    case "Reporte 32-A":

                        /* REPORTE 32A
                         * 0232010010620230703012000000000000000
                         * 000100000000000006194459000000000000000000000000000000000000000000000000000000
                         * 
                         * 0232 01 00106 20230703 012 000000000000000
                         * 000100 000000000006194459 000000000000000000 000000000000000000 000000000000000000
                         */

                        /* CABECERA DE ARCHIVO */
                        /*
                         4	1	Código de formato			
                         2	2	Código de Anexo			
                         5	3	Código de la empresa informante (entidad)	
                         8	4	Fecha de reporte			
                         3	5	Código de Expresión de Montos			
                         15	6	Datos de control
                         */
                        escritura.WriteLine(String.Concat(
                                cFormato.FormatoCaracterIzquierda(4, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cCodigoFormato, "0000", "."), "0000"),
                                cFormato.FormatoCaracterIzquierda(2, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cAnexo, "00", "."), "00"),
                                cFormato.FormatoCaracterIzquierda(5, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cEntidad, "00000", "."), "00000"),
                                cFormato.FormatoCaracterIzquierda(8, '0', cFormato.QuitarCaracterCadena(cConverciones.ConvertirAFecha(vgLista32A[0].dFecha, DateTime.Now).ToString("yyyyMMdd"), "00000000", "/"), "00000000"),
                                cFormato.FormatoCaracterIzquierda(3, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cExpMontos, "000", "."), "000"),
                                cFormato.FormatoCaracterIzquierda(15, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].nDatosControl, "000000000000000", "."), "000000000000000")
                                ));

                        /* CUERPO DE ARCHIVO */
                        foreach (cDataReporte32A clase in vgLista32A)
                        {
                            /* REPORTE 32A (longitud-posicion-descripcion)
                             6	0	Código de fila			
                            18	10	Total de Dinero Electrónico Emitido ( en S/.)			
                            18	20	Valor del Patrimonio Fideicometido (en S/.)			
                            18	30	Valor de los Depósitos de Disposición Inmediata (en S/.)			
                            18	40	Total Valor de la Garantía (en S/.)
                             */
                            escritura.WriteLine(String.Concat(
                                cFormato.FormatoCaracterIzquierda(6, '0', cFormato.QuitarCaracterCadena(clase.cCodFila, "000000", "."), "000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nDineroElectronico, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nFideicometido, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nValorDisposicionInmediata, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nValorGarantia, "000000000000000000", "."), "000000000000000000")
                                ));
                        }

                        /* PIE DE ARCHIVO */

                        break;

                    case "Reporte 32-BI":

                        /* REPORTE 32BI
                         *0232020010620230630012000000000000000
                         *001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
                         *
                         *0232 02 00106 20230703 012 000000000000000
                         *
                         */

                        /* CABECERA DE ARCHIVO */
                        /*
                         4	1	Código de formato			
                         2	2	Código de Anexo			
                         5	3	Código de la empresa informante (entidad)	
                         8	4	Fecha de reporte			
                         3	5	Código de Expresión de Montos			
                         15	6	Datos de control
                         */
                        escritura.WriteLine(String.Concat(
                                cFormato.FormatoCaracterIzquierda(4, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cCodigoFormato, "0000", "."), "0000"),
                                cFormato.FormatoCaracterIzquierda(2, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cAnexo, "00", "."), "00"),
                                cFormato.FormatoCaracterIzquierda(5, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cEntidad, "00000", "."), "00000"),
                                cFormato.FormatoCaracterIzquierda(8, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].dFecha, "00000000", "."), "00000000"),
                                cFormato.FormatoCaracterIzquierda(3, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cExpMontos, "000", "."), "000"),
                                cFormato.FormatoCaracterIzquierda(15, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].nDatosControl, "000000000000000", "."), "000000000000000")
                                ));

                        /* CUERPO DE ARCHIVO */
                        foreach (cDataReporte32BI clase in vgLista32BI)
                        {
                            /* REPORTE 32BI (longitud-posicion-descripcion)
                            6	0	Código de fila			
                            -10	Conversiones			
                            18	20	    Monto			
                            18	30	    N° de Operaciones			
                            -40	Transferencias y Pagos			
                            18	50	    Monto			
                            18	60	    N° de Operaciones			
                            -0	Reconversiones			
                            18	80	    Monto			
                            18	90	    N° de Operaciones			
                            -100	Otras			
                            18	110	    Monto			
                            18	120	    N° de Operaciones			
                            6	130     Tipo de Cambio Contable del último día hábil del mes
                             */

                            escritura.WriteLine(String.Concat(
                                cFormato.FormatoCaracterIzquierda(6, '0', cFormato.QuitarCaracterCadena(clase.cCodFila, "000000", "."), "000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nMontoConver, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nNroOperacionesConver, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nMontoTransfPago, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nNroOperacionesTransfPago, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nMontoReconversiones, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nNroOperacionesReconversiones, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nMontoOtros, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nNroOperacionesotros, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(6, '0', cFormato.QuitarCaracterCadena(clase.nTipoCambio, "000000", "."), "000000")
                                ));
                        }
                        break;

                    case "Reporte 32-BII":

                        /* REPORTE 32BII
                         *0232030010620230630012000000000000000
                         *000100000000000005039696000000000000000000000000000005039696
                         *
                         *
                         *
                         */

                        /* CABECERA DE ARCHIVO */
                        /*
                         4	1	Código de formato			
                         2	2	Código de Anexo			
                         5	3	Código de la empresa informante (entidad)	
                         8	4	Fecha de reporte			
                         3	5	Código de Expresión de Montos			
                         15	6	Datos de control
                         */
                        escritura.WriteLine(String.Concat(
                                cFormato.FormatoCaracterIzquierda(4, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cCodigoFormato, "0000", "."), "0000"),
                                cFormato.FormatoCaracterIzquierda(2, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cAnexo, "00", "."), "00"),
                                cFormato.FormatoCaracterIzquierda(5, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cEntidad, "00000", "."), "00000"),
                                cFormato.FormatoCaracterIzquierda(8, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].dFecha, "00000000", "."), "00000000"),
                                cFormato.FormatoCaracterIzquierda(3, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cExpMontos, "000", "."), "000"),
                                cFormato.FormatoCaracterIzquierda(15, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].nDatosControl, "000000000000000", "."), "000000000000000")
                                ));

                        /* CUERPO DE ARCHIVO */
                        foreach (cDataReporte32BII clase in vgLista32BII)
                        {
                            /* REPORTE 32BII (longitud-posicion-descripcion)
                             6	0	Código de fila			
                            18	10	Moneda Nacional (en S/.)			
                            18	20	Moneda Extranjera ( en $)			
                            18	30	Total (en S/.)
                             */

                            escritura.WriteLine(String.Concat(
                                cFormato.FormatoCaracterIzquierda(6, '0', cFormato.QuitarCaracterCadena(clase.cCodFila, "000000", "."), "000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nMonedaNacional, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nMonedaExtranjera, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nTotal, "000000000000000000", "."), "000000000000000000")
                                ));
                        }
                        break;

                    case "Reporte 32-BIII":

                        /* RWPORTE 32BIII
                         *0232040010620230630010000000000000000
                         *000100000000000000007336000000000000007336000000000000000000000000000000000000
                         *
                         *
                         *
                         */

                        /* CABECERA DE ARCHIVO */
                        /*
                         4	1	Código de formato			
                         2	2	Código de Anexo			
                         5	3	Código de la empresa informante (entidad)	
                         8	4	Fecha de reporte			
                         3	5	Código de Expresión de Montos			
                         15	6	Datos de control
                         */
                        escritura.WriteLine(String.Concat(
                                cFormato.FormatoCaracterIzquierda(4, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cCodigoFormato, "0000", "."), "0000"),
                                cFormato.FormatoCaracterIzquierda(2, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cAnexo, "00", "."), "00"),
                                cFormato.FormatoCaracterIzquierda(5, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cEntidad, "00000", "."), "00000"),
                                cFormato.FormatoCaracterIzquierda(8, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].dFecha, "00000000", "."), "00000000"),
                                cFormato.FormatoCaracterIzquierda(3, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cExpMontos, "000", "."), "000"),
                                cFormato.FormatoCaracterIzquierda(15, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].nDatosControl, "000000000000000", "."), "000000000000000")
                                ));

                        /* CUERPO DE ARCHIVO */
                        foreach (cDataReporte32BIII clase in vgLista32BIII)
                        {
                            /* RWPORTE 32BIII (longitud-posicion-descripcion)
                             6	0	Código de fila			
                                10	Cuentas Simplificadas			
                            18	20	    Número de Cuentas			
                            18	30	    Número de Titulares			
                                40	Cuentas Generales			
                            18	50	    Número de Cuentas			
                            18	60	    Número de Titulares
                             */
                            escritura.WriteLine(String.Concat(
                                cFormato.FormatoCaracterIzquierda(6, '0', cFormato.QuitarCaracterCadena(clase.cCodFila, "000000", "."), "000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nCtaSimNroDeCuentas, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nCtaSimNroDeTitu, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nCtaGnrlNroDeCuentas, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nCtaGnrlNroDeTitu, "000000000000000000", "."), "000000000000000000")
                                ));
                        }
                        break;

                    case "Reporte 32-BIV":

                        /* REPORTE 32BIV
                         *0232050010620230630012000000000000000
                         *000100000000000006023696000000000000000000000000000000000000000000000000000000
                         *
                         *
                         *
                         */

                        /* CABECERA DE ARCHIVO */
                        /*
                         4	1	Código de formato			
                         2	2	Código de Anexo			
                         5	3	Código de la empresa informante (entidad)	
                         8	4	Fecha de reporte			
                         3	5	Código de Expresión de Montos			
                         15	6	Datos de control
                         */
                        escritura.WriteLine(String.Concat(
                                cFormato.FormatoCaracterIzquierda(4, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cCodigoFormato, "0000", "."), "0000"),
                                cFormato.FormatoCaracterIzquierda(2, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cAnexo, "00", "."), "00"),
                                cFormato.FormatoCaracterIzquierda(5, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cEntidad, "00000", "."), "00000"),
                                cFormato.FormatoCaracterIzquierda(8, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].dFecha, "00000000", "."), "00000000"),
                                cFormato.FormatoCaracterIzquierda(3, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cExpMontos, "000", "."), "000"),
                                cFormato.FormatoCaracterIzquierda(15, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].nDatosControl, "000000000000000", "."), "000000000000000")
                                ));

                        /* CUERPO DE ARCHIVO */
                        foreach (cDataReporte32BIV clase in vgLista32BIV)
                        {
                            /* REPORTE 32BIV (longitud-posicion-descripcion)
                             6	0	Código de fila			
                            18	10	Total Dinero Electrónico Emitido (en S/.)			
                            18	20	Valor del Patrimonio Fideicometido (en S/.)			
                            18	30	Valor de los Depósitos de Disposición Inmediata (en S/.)			
                            18	40	Total Valor de la Garantía (en S/.)
                             */

                            escritura.WriteLine(String.Concat(
                                cFormato.FormatoCaracterIzquierda(6, '0', cFormato.QuitarCaracterCadena(clase.cCodFila, "000000", "."), "000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nTotDineroElec, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nValPatriFideicometido, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nValorDisposicionInmediata, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nValorGarantia, "000000000000000000", "."), "000000000000000000")
                                ));
                        }
                        break;

                    case "Reporte 3B2-BV":

                        /* REPORTE 32BV
                         *0232060010620230630010000000000000000
                         *000100000007389000000000000000000000000000000000000
                         *
                         *
                         *
                         */

                        /* CABECERA DE ARCHIVO */
                        /*
                         4	1	Código de formato			
                         2	2	Código de Anexo			
                         5	3	Código de la empresa informante (entidad)	
                         8	4	Fecha de reporte			
                         3	5	Código de Expresión de Montos			
                         15	6	Datos de control
                         */
                        escritura.WriteLine(String.Concat(
                                cFormato.FormatoCaracterIzquierda(4, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cCodigoFormato, "0000", "."), "0000"),
                                cFormato.FormatoCaracterIzquierda(2, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cAnexo, "00", "."), "00"),
                                cFormato.FormatoCaracterIzquierda(5, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cEntidad, "00000", "."), "00000"),
                                cFormato.FormatoCaracterIzquierda(8, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].dFecha, "00000000", "."), "00000000"),
                                cFormato.FormatoCaracterIzquierda(3, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].cExpMontos, "000", "."), "000"),
                                cFormato.FormatoCaracterIzquierda(15, '0', cFormato.QuitarCaracterCadena(vgLista32A[0].nDatosControl, "000000000000000", "."), "000000000000000")
                                ));

                        /* CUERPO DE ARCHIVO */
                        foreach (cDataReporte32BV clase in vgLista32BV)
                        {
                            /* REPORTE 32BV (longitud-posicion-descripcion)
                            6 	O  	Codigo de fila
                            9 	10  Telefono Móvil
                            18 	20  Tarjeta Prepago
                            18 	30  Otro
                             */
                            escritura.WriteLine(String.Concat(
                                cFormato.FormatoCaracterIzquierda(6, '0', cFormato.QuitarCaracterCadena(clase.cCodFila, "000000", "."), "000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nTeléfono, "000000000", "."), "000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nTarjetaPrepago, "000000000000000000", "."), "000000000000000000"),
                                cFormato.FormatoCaracterIzquierda(18, '0', cFormato.QuitarCaracterCadena(clase.nOtro, "000000000000000000", "."), "000000000000000000")
                                ));
                        }
                        break;

                    default:
                        break;
                }

                //linea = lectura.ReadLine();

                lectura.Close();
                escritura.Close();

                /* INICIO DESARROLLO */
                //File.Delete(RutaArchivoGuardar);
                //File.Move(RutaArchivoElegido, RutaArchivoGuardar);
                /* FIN DESARROLLO */

                /* INICIO PRODUCCION */
                //File.Delete(oConstante.cpRutaOrigen + _TipoReporte + "//" + _NombreArchivo);
                //File.Move(oConstante.cpRutaOrigen + _TipoReporte + "//temp" + _NombreArchivo, oConstante.cpRutaOrigen + _TipoReporte + "//" + _NombreArchivo);
                /* FIN PRODUCCION */

                MessageBox.Show("Se modifico correctamente", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
                button1.Enabled = false; //UQMA 28/11/2017  
            }
            catch (IOException error)
            {
                lectura.Close();
                escritura.Close();

                if (File.Exists(oConstante.cpRutaOrigen + _TipoReporte + "//temp" + _NombreArchivo))
                {
                    File.Delete(oConstante.cpRutaOrigen + _TipoReporte + "//temp" + _NombreArchivo);
                }

                MessageBox.Show("Error: " + error.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public string BorrarPunto(string cfidecomentico)
        {
            string[] cfidecometido_a = cfidecomentico.Split('.');

            if (cfidecometido_a.Length > 1)
            {
                return Double.Parse(cfidecometido_a[0]).ToString() + cfidecometido_a[1];
            }
            return cfidecomentico + "00";
        }

        private void cb_TipoReportes_SelectedIndexChanged(object sender, EventArgs e)
        {
            CambiarEncabezadosColumnas(); // 19/03/2018 LVCH para cambiar las columnas segun reporte
            HabilitarControlesReporte32B_I(); // 20/03/2018 LVCH para habilitar registros de Tipo de Cambio
            //dgv_DatosReporte32A.Rows.Clear(); /* 04072023 HSPC - Se comenta */
            button1.Enabled = false;
            if (cb_TipoReportes.SelectedItem != null)
            {
                if (cb_TipoReportes.SelectedItem.Equals("Reporte 32-A"))
                {
                    
                    gb_nombre.Text = "Reporte 32-A Reporte Diario de Dinero Electrónico";
                }
                else if (cb_TipoReportes.SelectedItem.Equals("Reporte 32-BIV")) // 19/03/2018  LVCH else if para determinar tipo de Reporte
                {
                    gb_nombre.Text = "Reporte 32-BIV Reporte de Dinero Electrónico";

                }
                else // 19/03/2018 LVCH se agrega reporte 32 BI al combobox
                {
                    gb_nombre.Text = "Reporte 32-BI Reporte de Dinero Electrónico";
                }
            }
            else
            {
                MessageBox.Show("Error: Seleccione un tipo de reporte.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CambiarEncabezadosColumnas(int _Modo = 0) // 19/03/2018 LVCH para cambiar las columnas según reporte seleccionado
        {
            /* INICIO 04072023 HSPC - Se comenta por nueva logica */
            //if (cb_TipoReportes.SelectedItem.Equals("Reporte 32-BI"))
            //{
            //    if (dgv_DatosReporte32A.Columns.Count == 6)
            //    {
            //        dgv_DatosReporte32A.Columns.Remove("Nombre_Archivo");
            //        dgv_DatosReporte32A.Columns.Remove("cFecha");
            //        dgv_DatosReporte32A.Columns.Remove("Id");
            //        dgv_DatosReporte32A.Columns.Remove("CodFila");
            //        dgv_DatosReporte32A.Columns.Remove("TotalDinero");
            //        dgv_DatosReporte32A.Columns.Remove("ValorFideicometido");
            //    }
            //    else if (dgv_DatosReporte32A.Columns.Count > 0)
            //    {
            //        dgv_DatosReporte32A.Columns.Remove("Nombre_Archivo");
            //        dgv_DatosReporte32A.Columns.Remove("cFecha");
            //        dgv_DatosReporte32A.Columns.Remove("Id");
            //        dgv_DatosReporte32A.Columns.Remove("CodFila");
            //        dgv_DatosReporte32A.Columns.Remove("Monto Conversiones");
            //        dgv_DatosReporte32A.Columns.Remove("Monto Transferencias y Pagos");
            //        dgv_DatosReporte32A.Columns.Remove("Monto Reconversiones");
            //        dgv_DatosReporte32A.Columns.Remove("Tipo de Cambio");
            //    }

            //    dgv_DatosReporte32A.Columns.Add("Nombre_Archivo", "Nombre Archivo");
            //    dgv_DatosReporte32A.Columns.Add("cFecha", "Fecha");
            //    dgv_DatosReporte32A.Columns.Add("Id", "Id");
            //    dgv_DatosReporte32A.Columns.Add("CodFila", "Código de fila");
            //    dgv_DatosReporte32A.Columns.Add("Monto Conversiones", "Monto Conversiones");
            //    dgv_DatosReporte32A.Columns.Add("Monto Transferencias y Pagos", "Monto Transferencias y Pagos");
            //    dgv_DatosReporte32A.Columns.Add("Monto Reconversiones", "Monto Reconversiones");
            //    dgv_DatosReporte32A.Columns.Add("Tipo de Cambio", "Tipo de Cambio");
            //    dgv_DatosReporte32A.Columns[0].Width = 0;
            //    dgv_DatosReporte32A.Columns[1].Width = 0;
            //    dgv_DatosReporte32A.Columns[2].Width = 0;
            //    dgv_DatosReporte32A.Columns[3].Width = 100;
            //    dgv_DatosReporte32A.Columns[4].Width = 100;
            //    dgv_DatosReporte32A.Columns[5].Width = 100;
            //    dgv_DatosReporte32A.Columns[6].Width = 100;
            //    dgv_DatosReporte32A.Columns[7].Width = 100;

            //    dgv_DatosReporte32A.Columns[0].Visible = false;
            //    dgv_DatosReporte32A.Columns[1].Visible = false;
            //    dgv_DatosReporte32A.Columns[2].Visible = false;
            //    dgv_DatosReporte32A.Columns[3].Visible = true;
            //    dgv_DatosReporte32A.Columns[4].Visible = true;
            //    dgv_DatosReporte32A.Columns[5].Visible = true;
            //    dgv_DatosReporte32A.Columns[6].Visible = true;
            //    dgv_DatosReporte32A.Columns[7].Visible = true;

            //    dgv_DatosReporte32A.Columns[3].ReadOnly = true;
            //    dgv_DatosReporte32A.Columns[4].ReadOnly = true;
            //    dgv_DatosReporte32A.Columns[5].ReadOnly = true;
            //    dgv_DatosReporte32A.Columns[6].ReadOnly = true;
            //    dgv_DatosReporte32A.Columns[7].ReadOnly = true;
            //}
            //else //Encabezados 32A y 32B_IV 
            //{
            //    if (dgv_DatosReporte32A.Columns.Count == 8)
            //    {
            //        dgv_DatosReporte32A.Columns.Remove("Nombre_Archivo");
            //        dgv_DatosReporte32A.Columns.Remove("cFecha");
            //        dgv_DatosReporte32A.Columns.Remove("Id");
            //        dgv_DatosReporte32A.Columns.Remove("CodFila");
            //        dgv_DatosReporte32A.Columns.Remove("Monto Conversiones");
            //        dgv_DatosReporte32A.Columns.Remove("Monto Transferencias y Pagos");
            //        dgv_DatosReporte32A.Columns.Remove("Monto Reconversiones");
            //        dgv_DatosReporte32A.Columns.Remove("Tipo de Cambio");
            //    }
            //    else if (dgv_DatosReporte32A.Columns.Count > 0)
            //    {
            //        dgv_DatosReporte32A.Columns.Remove("Nombre_Archivo");
            //        dgv_DatosReporte32A.Columns.Remove("cFecha");
            //        dgv_DatosReporte32A.Columns.Remove("Id");
            //        dgv_DatosReporte32A.Columns.Remove("CodFila");
            //        dgv_DatosReporte32A.Columns.Remove("TotalDinero");
            //        dgv_DatosReporte32A.Columns.Remove("ValorFideicometido");
            //    }
            //    dgv_DatosReporte32A.Columns.Add("Nombre_Archivo", "Nombre Archivo");
            //    dgv_DatosReporte32A.Columns.Add("cFecha", "Fecha");
            //    dgv_DatosReporte32A.Columns.Add("Id", "Id");
            //    dgv_DatosReporte32A.Columns.Add("CodFila", "Código de fila");
            //    dgv_DatosReporte32A.Columns.Add("TotalDinero", "Total Dinero Electrónico Emitido (en S/.)");
            //    dgv_DatosReporte32A.Columns.Add("ValorFideicometido", "Valor del Patrimonio Fideicometido (en S/.)");
            //    dgv_DatosReporte32A.Columns[0].Width = 0;
            //    dgv_DatosReporte32A.Columns[1].Width = 0;
            //    dgv_DatosReporte32A.Columns[2].Width = 0;
            //    dgv_DatosReporte32A.Columns[3].Width = 100;
            //    dgv_DatosReporte32A.Columns[4].Width = 150;
            //    dgv_DatosReporte32A.Columns[5].Width = 150;

            //    dgv_DatosReporte32A.Columns[0].Visible = false;
            //    dgv_DatosReporte32A.Columns[1].Visible = false;
            //    dgv_DatosReporte32A.Columns[2].Visible = false;
            //    dgv_DatosReporte32A.Columns[3].Visible = true;
            //    dgv_DatosReporte32A.Columns[4].Visible = true;
            //    dgv_DatosReporte32A.Columns[5].Visible = true;

            //    dgv_DatosReporte32A.Columns[3].ReadOnly = true;
            //    dgv_DatosReporte32A.Columns[4].ReadOnly = true;
            //    dgv_DatosReporte32A.Columns[5].ReadOnly = false;
            //}
            /* FIN 04072023 HSPC - Se comenta por nueva logica */

            /* INICIO 04072023 HSPC - Se agrega nueva logica para mostrar las columnas por cada tipo de reporte */

            /* Asignar nuevo valor a las variables globales */
            //vgLista32A = new List<cDataReporte32A>();
            //vgLista32BI = new List<cDataReporte32BI>();
            //vgLista32BII = new List<cDataReporte32BII>();
            //vgLista32BIII = new List<cDataReporte32BIII>();
            //vgLista32BIV = new List<cDataReporte32BIV>();

            // Se crea Lista<Variable> para poder asignar un comportamiento por reporte
            List<cReporte32Columnas> ListaColumnas = new List<cReporte32Columnas>();
            // Se limpia las columnas por cada listado de reporte
            //dgv_DatosReporte32A.Columns.Clear();

            // Se asignan comportamientos a las columnas dependiento del tipo de reporte seleccionado
            switch (cb_TipoReportes.SelectedItem.ToString())
            {
                case "Reporte 32-A":
                    if(_Modo == 0)
                    {
                        vgLista32A = new List<cDataReporte32A>();
                    }                    
                    dgv_DatosReporte32A.DataSource = vgLista32A;

                    ListaColumnas.Add(new cReporte32Columnas("cNombreArchivo", "Nombre Archivo", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("cFecha", "Fecha", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("nIdRepA", "Id", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("bEstado", "bEstado", 150, false, true));

                    ListaColumnas.Add(new cReporte32Columnas("cCodFila", "Código de fila", 100, true, true));
                    ListaColumnas.Add(new cReporte32Columnas("nDineroElectronico", "Total Dinero Electrónico Emitido (en S/.)", 150, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("nFideicometido", "Valor del Patrimonio Fideicometido (en S/.)", 150, true, false));
                    ListaColumnas.Add(new cReporte32Columnas("nValorDisposicionInmediata", "Valor de los Depósitos de Disposición Inmediata (en S/.)", 150, true, false));
                    ListaColumnas.Add(new cReporte32Columnas("nValorGarantia", "Total Valor de la Garantía (en S/.)", 150, true, true));

                    break;

                case "Reporte 32-BI":
                    if (_Modo == 0)
                    {
                        vgLista32BI = new List<cDataReporte32BI>();
                    }
                    dgv_DatosReporte32A.DataSource = vgLista32BI;

                    ListaColumnas.Add(new cReporte32Columnas("cNombreArchivo", "Nombre Archivo", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("cFecha", "Fecha",  100, false, true));                    
                    ListaColumnas.Add(new cReporte32Columnas("nIdRepBI", "nIdRepBI", 100, false, false));
                    ListaColumnas.Add(new cReporte32Columnas("bEstado", "bEstado", 150, false, true));

                    ListaColumnas.Add(new cReporte32Columnas("cCodFila", "Código de fila", 100, true, true));
                    ListaColumnas.Add(new cReporte32Columnas("nMontoConver", "Monto Conversiones",   100, true, true));
                    ListaColumnas.Add(new cReporte32Columnas("nNroOperacionesConver", "N° Operaciones Conversiones", 100, true, false));
                    ListaColumnas.Add(new cReporte32Columnas("nMontoTransfPago", "Monto Transferencias y Pagos",  100, true, false));
                    ListaColumnas.Add(new cReporte32Columnas("nNroOperacionesTransfPago", "N° Operaciones Transferencias y Pagos", 100, true, false));
                    ListaColumnas.Add(new cReporte32Columnas("nMontoReconversiones", "Monto Reconversiones",  100, true, false));
                    ListaColumnas.Add(new cReporte32Columnas("nNroOperacionesReconversiones", "N° Operaciones Reconversiones", 100, true, false));
                    ListaColumnas.Add(new cReporte32Columnas("nMontoOtros", "Monto Otras", 100, true, false));
                    ListaColumnas.Add(new cReporte32Columnas("nNroOperacionesotros", "N° de Operaciones Otras", 100, true, false));
                    ListaColumnas.Add(new cReporte32Columnas("nTipoCambio", "Tipo de Cambio Contable del último día hábil del mes",  200, true, false));
                    
                    break;

                case "Reporte 32-BII":
                    if (_Modo == 0)
                    {
                        vgLista32BII = new List<cDataReporte32BII>();
                    }
                    dgv_DatosReporte32A.DataSource = vgLista32BII;

                    ListaColumnas.Add(new cReporte32Columnas("cNombreArchivo", "Nombre Archivo", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("cFecha", "Fecha", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("nIdRepBII", "Id", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("bEstado", "bEstado", 150, false, true));

                    ListaColumnas.Add(new cReporte32Columnas("cCodFila", "Código de fila", 100, true, true));
                    ListaColumnas.Add(new cReporte32Columnas("nMonedaNacional", "Moneda Nacional (en S/.)", 100, true, true));
                    ListaColumnas.Add(new cReporte32Columnas("nMonedaExtranjera", "Moneda Extranjera ( en $)", 150, true, true));
                    ListaColumnas.Add(new cReporte32Columnas("nTotal", "Total (en S/.)", 150, true, false));

                    break;
                case "Reporte 32-BIII":
                    if (_Modo == 0)
                    {
                        vgLista32BIII = new List<cDataReporte32BIII>();
                    }
                    dgv_DatosReporte32A.DataSource = vgLista32BIII;

                    ListaColumnas.Add(new cReporte32Columnas("cNombreArchivo", "Nombre Archivo", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("cFecha", "Fecha", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("nIdRepBIII", "Id", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("bEstado", "bEstado", 150, false, true));

                    ListaColumnas.Add(new cReporte32Columnas("cCodFila", "Código de fila", 100, true, true));
                    ListaColumnas.Add(new cReporte32Columnas("nCtaSimNroDeCuentas", "Número de Cuentas", 120, true, true));
                    ListaColumnas.Add(new cReporte32Columnas("nCtaSimNroDeTitu", "Número de Titulares", 120, true, true));
                    ListaColumnas.Add(new cReporte32Columnas("nCtaGnrlNroDeCuentas", "Número de Cuentas", 120, true, true));
                    ListaColumnas.Add(new cReporte32Columnas("nCtaGnrlNroDeTitu", "Número de Titulares", 120, true, true));
                    

                    break;

                case "Reporte 32-BIV":
                    if (_Modo == 0)
                    {
                        vgLista32BIV = new List<cDataReporte32BIV>();
                    }
                    dgv_DatosReporte32A.DataSource = vgLista32BIV;

                    ListaColumnas.Add(new cReporte32Columnas("cNombreArchivo", "Nombre Archivo", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("cFecha", "Fecha", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("nIdRepBIV", "Id", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("bEstado", "bEstado", 150, false, true));

                    ListaColumnas.Add(new cReporte32Columnas("cCodFila", "Código de fila", 100, true, true));
                    ListaColumnas.Add(new cReporte32Columnas("nTotDineroElec", "Total Dinero Electrónico Emitido (en S/.)", 150, true, true));
                    ListaColumnas.Add(new cReporte32Columnas("nValPatriFideicometido", "Valor del Patrimonio Fideicometido (en S/.)", 150, true, false));
                    ListaColumnas.Add(new cReporte32Columnas("nValorDisposicionInmediata", "Valor de los Depósitos de Disposición Inmediata (en S/.)", 150, true, false));
                    ListaColumnas.Add(new cReporte32Columnas("nValorGarantia", "Total Valor de la Garantía (en S/.)", 150, true, true));

                    break;

                case "Reporte 32-BV":
                    if (_Modo == 0)
                    {
                        vgLista32BV = new List<cDataReporte32BV>();
                    }
                    dgv_DatosReporte32A.DataSource = vgLista32BV;

                    ListaColumnas.Add(new cReporte32Columnas("cNombreArchivo", "Nombre Archivo", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("cFecha", "Fecha", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("nIdRepBV", "Id", 100, false, true));
                    ListaColumnas.Add(new cReporte32Columnas("bEstado", "bEstado", 150, false, true));

                    ListaColumnas.Add(new cReporte32Columnas("cCodFila", "Código de fila", 100, true, true));
                    ListaColumnas.Add(new cReporte32Columnas("nTeléfono", "Telefono", 150, true, true));
                    ListaColumnas.Add(new cReporte32Columnas("nTarjetaPrepago", "Tarjeta Prepago", 150, true, false));
                    ListaColumnas.Add(new cReporte32Columnas("nOtro", "Otro", 150, true, false));
                    

                    break;

                default:
                    break;
            }

            // Se ocultan todas las columnas
            foreach (DataGridViewColumn dgvColumna in dgv_DatosReporte32A.Columns)
            {
                dgvColumna.Visible = false;
            }

            // Se asignan comportamientos a las columnas
            foreach (cReporte32Columnas vColumna in ListaColumnas)
            {                
                foreach (DataGridViewColumn dgvColumna in dgv_DatosReporte32A.Columns)
                {
                    if (dgvColumna.Name == vColumna.Valor)
                    {
                        dgvColumna.HeaderText = vColumna.Titulo;
                        dgvColumna.Width = vColumna.Ancho;
                        dgvColumna.Visible = vColumna.Visible;
                        dgvColumna.ReadOnly = vColumna.SoloLeer;
                    }
                }
            }
            /* FIN 04072023 HSPC - Se agrega nueva logica para mostrar las columnas por cada tipo de reporte */
        }

        /* INICIO 04072023 HSPC - Se crea clase para poder asignar comportamientos a las columnas */
        public class cReporte32Columnas
        {
            public string Valor { get; set; }
            public string Titulo { get; set; }            
            public int Ancho { get; set; }
            public bool Visible { get; set; }
            public bool SoloLeer { get; set; }

            public cReporte32Columnas()
            {
            }

            public cReporte32Columnas(string valor, string titulo, int ancho, bool visible, bool soloLeer)
            {                
                Valor = valor;
                Titulo = titulo;
                Ancho = ancho;
                Visible = visible;
                SoloLeer = soloLeer;
            }
        }
        /* FIN 04072023 HSPC - Se crea clase para poder asignar comportamientos a las columnas */

        private void HabilitarControlesReporte32B_I() // 20/03/2018 LVCH para habilitar controles del reporte 32 BI
        {
            if (cb_TipoReportes.SelectedItem.Equals("Reporte 32-BI"))
            {
                lbTipoCambio.Visible = true;
                txtTipoCambio.Visible = true;
                btnTipoCambio.Visible = true;
            }
            else
            {
                lbTipoCambio.Visible = false;
                txtTipoCambio.Visible = false;
                btnTipoCambio.Visible = false;
            }
        }

        private void btn_GenerarReporte32_Click(object sender, EventArgs e)
        {
            //limpiamos los datos del DGV
            //dgv_DatosReporte32A.Rows.Clear(); /* 04072023 HSPC - Se Comenta por nueva logica */

            //Recuperar fecha 
            string fecha = dtpck_Fecha.Text;
            cArchivoReporte oReportes = new cArchivoReporte();
            //DataTable odatos;  /* 04072023 HSPC - Se Comenta por nueva logica */

            /* INICIO 04072023 HSPC - Se comenta por nueva logica */
            //if (cb_TipoReportes.SelectedItem != null)
            //{
            //    if (cb_TipoReportes.SelectedItem.Equals("Reporte 32-A"))
            //    {
            //        //recuperamos los datos del reporte 32A
            //        odatos = oReportes.Recuperar_Reporte32A(fecha);
            //        esreporteA = true;
            //    }
            //    else if (cb_TipoReportes.SelectedItem.Equals("Reporte 32-BIV")) // 19/03/2018  LVCH else if para determinar tipo de Reporte
            //    {
            //        //recuperamos los datos del reporte 32BIV
            //        odatos = oReportes.Recuperar_Reporte32BIV(fecha);
            //        esreporteA = false;

            //    }
            //    else // 19/03/2018 LVCH recupera registros del Reporte 32B_I
            //    {
            //        odatos = oReportes.Recuperar_Reporte32BI(fecha);                    
            //        esreporteA = false;
            //    }

            //    //recorremos el dgv
            //    int i = 0;

            //    if (odatos.Rows.Count == 0)
            //    {
            //        MessageBox.Show("No se encontraron resultados.", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //        button1.Enabled = false;
            //    }
            //    else
            //    {
            //        button1.Enabled = true;
            //        //if (cb_TipoReportes.SelectedItem.Equals("Reporte 32-A"))
            //        if (cb_TipoReportes.SelectedItem.Equals("Reporte 32-BI")) // 19/03/2018 LVCH muestra datos del reporte 32 BI
            //        {
            //            //dgv_DatosReporte32A.Columns[6].Visible = false;
            //            while (i < odatos.Rows.Count)
            //            {
            //                //dgv_DatosReporte32A.Rows.Add(odatos.Rows[i][0], odatos.Rows[i][1], odatos.Rows[i][2], odatos.Rows[i][3], Math.Round(Convert.ToDecimal(odatos.Rows[i][4]), 2), Math.Round(Convert.ToDecimal(odatos.Rows[i][5]), 2));
            //                //dgv_DatosReporte32A.Rows.Add(odatos.Rows[i][0], odatos.Rows[i][1], odatos.Rows[i][2], odatos.Rows[i][3], Double.Parse(odatos.Rows[i][4].ToString()).ToString("N"), Double.Parse(odatos.Rows[i][5].ToString()).ToString("N"), Double.Parse(odatos.Rows[i][6].ToString()).ToString("N"), float.Parse(odatos.Rows[i][7].ToString()).ToString());
            //                dgv_DatosReporte32A.Rows.Add(odatos.Rows[i][0], odatos.Rows[i][1], odatos.Rows[i][2], odatos.Rows[i][3], Double.Parse(odatos.Rows[i][4].ToString()).ToString("N"), Double.Parse(odatos.Rows[i][5].ToString()).ToString("N"), Double.Parse(odatos.Rows[i][6].ToString()).ToString("N"), float.Parse(odatos.Rows[i][7].ToString()).ToString("N3")); //LVCH 10082018 se agrega formato al tipo de cambio
            //                i++;
            //            }
            //            txtTipoCambio.Text = float.Parse(odatos.Rows[0][11].ToString()).ToString(); // 19/03/2018 LVCH para recuperar el Tipo de Cambio de la BD de la tabla TipoCambio(último día del mes seleccionado)
            //        }
            //        else // 19/03/2018 LVCH muestra datos de los reportes 32 A y 32BIV
            //        {
            //            //dgv_DatosReporte32A.Columns[6].Visible = true;
            //            while (i < odatos.Rows.Count)
            //            {
            //                //dgv_DatosReporte32A.Rows.Add(odatos.Rows[i][0], odatos.Rows[i][1], odatos.Rows[i][2], odatos.Rows[i][3], Math.Round(Convert.ToDecimal(odatos.Rows[i][4]), 2), Math.Round(Convert.ToDecimal(odatos.Rows[i][5]), 2));
            //                dgv_DatosReporte32A.Rows.Add(odatos.Rows[i][0], odatos.Rows[i][1], odatos.Rows[i][2], odatos.Rows[i][3], Double.Parse(odatos.Rows[i][4].ToString()).ToString("N"), Double.Parse(odatos.Rows[i][5].ToString()).ToString("N"));                         
            //                i++;
            //            }
            //        }
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("Error: Seleccione un tipo de reporte.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}

            /* FIN 04072023 HSPC - Se comenta por nueva logica */

            /* INICIO 04072023 HSPC - Se carga los datos dependiendo de la seleccion del tipo de reporte */
            switch (cb_TipoReportes.SelectedItem.ToString())
            {
                case "Reporte 32-A":
                    vgLista32A = oReportes.Recuperar_Reporte32ALista(fecha);

                    dgv_DatosReporte32A.DataSource = vgLista32A;
                    button1.Enabled = true;
                    break;
                case "Reporte 32-BI":
                    vgLista32BI = oReportes.Recuperar_Reporte32BILista(fecha);

                   dgv_DatosReporte32A.DataSource = vgLista32BI;
                    button1.Enabled = true;
                    break;
                case "Reporte 32-BII":
                    vgLista32BII = oReportes.Recuperar_Reporte32BIILista(fecha);

                    dgv_DatosReporte32A.DataSource = vgLista32BII;
                    button1.Enabled = true;
                    break;
                case "Reporte 32-BIII":
                    vgLista32BIII = oReportes.Recuperar_Reporte32BIIILista(fecha);

                    dgv_DatosReporte32A.DataSource = vgLista32BIII;
                    button1.Enabled = true;
                    break;
                case "Reporte 32-BIV":
                    vgLista32BIV = oReportes.Recuperar_Reporte32BIVLista(fecha);

                    dgv_DatosReporte32A.DataSource = vgLista32BIV;
                    button1.Enabled = true;
                    break;
                case "Reporte 32-BV":
                    vgLista32BV = oReportes.Recuperar_Reporte32BVLista(fecha);

                    dgv_DatosReporte32A.DataSource = vgLista32BV;
                    button1.Enabled = true;
                    break;
                default:
                    break;
            }
            /* FIN 04072023 HSPC - Se carga los datos dependiendo de la seleccion del tipo de reporte */
            
            CambiarEncabezadosColumnas(1); /* 04072023 HSPC - Se modifica los columnas */

            Formato_Datos(); /* 04072023 HSPC - Se modifica los columnas */

            dgv_DatosReporte32A.Refresh(); /* 04072023 HSPC - Se recarga los datos de GRIDVIEW */
        }

        private void dgv_DatosReporte32A_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (dgv_DatosReporte32A.CurrentCell.ColumnIndex == 5)
            {
                TextBox txt = e.Control as TextBox;

                if (txt.Text != null)
                {
                    txt.KeyPress -= new System.Windows.Forms.KeyPressEventHandler(this.dgv_DatosReporte32A_KeyPress);
                    txt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dgv_DatosReporte32A_KeyPress);
                }
            }
        }

        private void dgv_DatosReporte32A_KeyPress(object sender, KeyPressEventArgs e)
        {
            char aux = e.KeyChar;

            if (char.IsControl(e.KeyChar)) //
            {
                e.Handled = false;
            }
            else
            {

                if (char.IsDigit(e.KeyChar)) //Si es numero
                {
                    TextBox txt = sender as TextBox;
                    if (txt != null) /* INICIO 04072023 HSPC - Se valida si el TEXTBOX es nulo */
                    {
                        int ubicacion_cursor = txt.SelectionStart;

                        if (ubicacion_cursor < txt.Text.Split('.')[0].Length + 1)
                        {
                            e.Handled = false; //agregamos numeros al lado izquierdo
                        }
                        else
                        {
                            if (txt.Text.Split('.')[1].Length <= 1)
                                e.Handled = false; //permitimos solo dos decimales 
                            else
                                e.Handled = true;
                        }
                    } /* FIN 04072023 HSPC - Se valida si el TEXTBOX es nulo */
                }
                else
                {
                    if (e.KeyChar == 46) // si es punto
                    {
                        TextBox txt = sender as TextBox;

                        if (txt.Text != "")
                            e.Handled = txt.Text.Contains("."); //validamos poner solo un punto
                        else
                            e.Handled = true;
                    }
                    else
                        e.Handled = true;
                }
            }
        }

        private void dgv_DatosReporte32A_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            /* INICIO 04072023 HSPC - Se comenta por nueva logica */
            //Double Valor = Double.Parse(dgv_DatosReporte32A.Rows[e.RowIndex].Cells[5].Value.ToString());
            //dgv_DatosReporte32A.Rows[e.RowIndex].Cells[5].Value = Valor.ToString("N");
            /* FIN 04072023 HSPC - Se comenta por nueva logica */

            /* INICIO 04072023 HSPC - Se edita las columnas del reporte seleccionado para generar la edicion y sumatoria segun corresponda */
            switch (cb_TipoReportes.SelectedItem.ToString())
            {
                case "Reporte 32-A":                   
                    Double d32anFideicometido = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(vgLista32A[e.RowIndex].nFideicometido), 0);
                    Double d32anValorDisposicionInmediata = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(vgLista32A[e.RowIndex].nValorDisposicionInmediata), 0);

                    vgLista32A[e.RowIndex].nFideicometido = d32anFideicometido.ToString("N");
                    vgLista32A[e.RowIndex].nValorDisposicionInmediata = d32anValorDisposicionInmediata.ToString("N");
                    vgLista32A[e.RowIndex].nValorGarantia = (d32anFideicometido + d32anValorDisposicionInmediata).ToString("N");
                    dgv_DatosReporte32A.Refresh();
                    break;

                case "Reporte 32-BI":
                    Double d32binTipoCambio = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(vgLista32BI[e.RowIndex].nTipoCambio), 0);
                    //Double d32binValorDisposicionInmediata = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(vgLista32BI[e.RowIndex].nValorDisposicionInmediata), 0);

                    vgLista32BI[e.RowIndex].nTipoCambio = d32binTipoCambio.ToString("N");
                    //vgLista32BI[e.RowIndex].nValorDisposicionInmediata = d32binValorDisposicionInmediata.ToString("N");
                    //vgLista32BI[e.RowIndex].nValorGarantia = (d32binTipoCambio + d32binValorDisposicionInmediata).ToString("N");

                    dgv_DatosReporte32A.DataSource = vgLista32BI;
                    dgv_DatosReporte32A.Refresh();
                    break;

                case "Reporte 32-BII":
                    //Double d32biinTipoCambio = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(vgLista32BII[e.RowIndex].nValorGarantia), 0);
                    //Double d32biinValorDisposicionInmediata = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(vgLista32BII[e.RowIndex].nValorDisposicionInmediata), 0);

                    //vgLista32BII[e.RowIndex].nValorDisposicionInmediata = d32biinValorDisposicionInmediata.ToString("N");
                    //vgLista32BII[e.RowIndex].nValorGarantia = (d32biinTipoCambio + d32biinValorDisposicionInmediata).ToString("N");

                    dgv_DatosReporte32A.DataSource = vgLista32BII;
                    dgv_DatosReporte32A.Refresh();
                    break;

                case "Reporte 32-BIII":
                    //Double d32biiinValorDisposicionInmediata = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(vgLista32BIII[e.RowIndex].nValorDisposicionInmediata), 0);

                    //vgLista32BIII[e.RowIndex].nValorDisposicionInmediata = d32biiinValorDisposicionInmediata.ToString("N");

                    dgv_DatosReporte32A.DataSource = vgLista32BIII;
                    dgv_DatosReporte32A.Refresh();
                    break;

                case "Reporte 32-BIV":
                    Double d32bivnValPatriFideicometido = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(vgLista32BIV[e.RowIndex].nValPatriFideicometido), 0);
                    Double d32bivnValorDisposicionInmediata = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(vgLista32BIV[e.RowIndex].nValorDisposicionInmediata), 0);

                    vgLista32BIV[e.RowIndex].nValPatriFideicometido = d32bivnValPatriFideicometido.ToString("N");
                    vgLista32BIV[e.RowIndex].nValorDisposicionInmediata = d32bivnValorDisposicionInmediata.ToString("N");
                    vgLista32BIV[e.RowIndex].nValorGarantia = (d32bivnValPatriFideicometido + d32bivnValorDisposicionInmediata).ToString("N");

                    dgv_DatosReporte32A.DataSource = vgLista32BIV;
                    dgv_DatosReporte32A.Refresh();
                    break;

                case "Reporte 32-BV":
                    Double d32vnOtro = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(vgLista32BV[e.RowIndex].nOtro), 0);
                    Double d32vnTeléfono = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(vgLista32BV[e.RowIndex].nTeléfono), 0);
                    Double d32vnTarjetaPrepago = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(vgLista32BV[e.RowIndex].nTarjetaPrepago), 0);

                    vgLista32BV[e.RowIndex].nOtro = d32vnOtro.ToString("N");
                    vgLista32BV[e.RowIndex].nTeléfono = d32vnTeléfono.ToString("N");
                    vgLista32BV[e.RowIndex].nTarjetaPrepago = d32vnTarjetaPrepago.ToString("N");

                    dgv_DatosReporte32A.DataSource = vgLista32BV;
                    dgv_DatosReporte32A.Refresh();
                    break;

                default:
                    break;
            }
            /* FIN 04072023 HSPC - Se edita las columnas del reporte seleccionado para generar la edicion y sumatoria segun corresponda */
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtTipoCambio_KeyPress(object sender, KeyPressEventArgs e)  // 19/03/2018 LVCH para validar solo numeros en el textbox
        {
            char aux = e.KeyChar;

            if (char.IsControl(e.KeyChar)) //
            {
                e.Handled = false;
            }
            else
            {
                if (char.IsDigit(e.KeyChar)) //Si es numero
                {
                    if (txtTipoCambio.SelectionLength > 0) //LVCH 10082018 --para borrar el texto seleccionado luego de presionar una tecla
                        txtTipoCambio.Clear();

                    TextBox txt = sender as TextBox;
                    int ubicacion_cursor = txt.SelectionStart;
                    if (ubicacion_cursor < txt.Text.Split('.')[0].Length + 1)
                    {
                        if (txt.Text.Length >= 3) // validar para digitar hasta 3 enteros
                            e.Handled = true;
                        else
                            e.Handled = false; //agregamos numeros al lado izquierdo
                    }
                    else
                    {
                        if (txt.Text.Split('.')[1].Length <= 2)
                            e.Handled = false; //permitimos 3 decimales 
                        else
                            e.Handled = true;
                    }
                }
                else
                {
                    if (e.KeyChar == 46) // si es punto
                    {
                        TextBox txt = sender as TextBox;

                        if (txt.Text != "")
                            e.Handled = txt.Text.Contains("."); //validamos poner solo un punto
                        else
                            e.Handled = true;
                    }
                    else
                        e.Handled = true;
                }
            }
        }

        private void btnTipoCambio_Click(object sender, EventArgs e) // 20/03/2018 LVCH para asignar Tipo de Cambio al reporte 32B_I
        {
            /* INICIO 04072023 HSPC - Se comenta por nueva logica */
            //int i = 0;
            //bool contiene = false;  //LVCH 10082018 INICIO --Para colocar punto decimal caso no se le haya puesto
            //contiene=  txtTipoCambio.Text.Contains(".");
            //string[] dec = txtTipoCambio.Text.Split('.');
            //if (contiene == false)
            //{
            //    txtTipoCambio.Text = txtTipoCambio.Text + ".00";
            //}
            //else
            //{
            //    if (dec[1].ToString()=="")
            //        txtTipoCambio.Text = txtTipoCambio.Text + "00";
            //}
            ////LVCH 10082018 FIN

            //while (i < dgv_DatosReporte32A.Rows.Count)
            //{
            //    dgv_DatosReporte32A.Rows[i].Cells[7].Value = txtTipoCambio.Text;
            //    i++;
            //}
            /* FIN 04072023 HSPC - Se comenta por nueva logica */

            /* INICIO 04072023 HSPC - Se edita el tipo de cambio dependiendo del tipo de reporte */
            switch (cb_TipoReportes.SelectedItem.ToString())
            {
                case "Reporte 32-A":
                    Double d32anTipoCambio = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(txtTipoCambio.Text), 0);
                    
                    foreach (cDataReporte32A clase in vgLista32A)
                    {
                        //clase.nTipoCambio = d32binTipoCambio.ToString("N");
                    }

                    dgv_DatosReporte32A.DataSource = vgLista32A;
                    dgv_DatosReporte32A.Refresh();
                    break;

                case "Reporte 32-BI":
                    Double d32binTipoCambio = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(txtTipoCambio.Text), 0);

                    foreach (cDataReporte32BI clase in vgLista32BI)
                    {
                        clase.nTipoCambio = d32binTipoCambio.ToString("N");
                    }

                    dgv_DatosReporte32A.DataSource = vgLista32BI;
                    dgv_DatosReporte32A.Refresh();
                    break;

                case "Reporte 32-BII":
                    Double d32biinTipoCambio = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(txtTipoCambio.Text), 0);
                    
                    foreach (cDataReporte32BII clase in vgLista32BII)
                    {
                        //clase.nTipoCambio = d32biinTipoCambio.ToString("N");
                    }

                    dgv_DatosReporte32A.DataSource = vgLista32BII;
                    dgv_DatosReporte32A.Refresh();
                    break;

                case "Reporte 32-BIII":
                    Double d32biiinTipoCambio = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(txtTipoCambio.Text), 0);

                    foreach (cDataReporte32BIII clase in vgLista32BIII)
                    {
                        //clase.nTipoCambio = d32biiinTipoCambio.ToString("N");
                    }

                    dgv_DatosReporte32A.DataSource = vgLista32BIII;
                    dgv_DatosReporte32A.Refresh();
                    break;

                case "Reporte 32-BIV":
                    Double d32bivnTipoCambio = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(txtTipoCambio.Text), 0);
                    
                    foreach (cDataReporte32BIV clase in vgLista32BIV)
                    {
                        //clase.nTipoCambio = d32bivnTipoCambio.ToString("N");
                    }

                    dgv_DatosReporte32A.DataSource = vgLista32BIV;
                    dgv_DatosReporte32A.Refresh();
                    break;

                case "Reporte 32-BV":
                    Double d32vnTipoCambio = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(txtTipoCambio.Text), 0);
                    
                    foreach (cDataReporte32BV clase in vgLista32BV)
                    {
                        //clase.nTipoCambio = d32vnTipoCambio.ToString("N");
                    }

                    dgv_DatosReporte32A.DataSource = vgLista32BV;
                    dgv_DatosReporte32A.Refresh();
                    break;

                default:
                    break;
            }
            /* FIN 04072023 HSPC - Se edita el tipo de cambio dependiendo del tipo de reporte */
        }

        /* INICIO 04072023 HSPC - Metodo para formatear datos recuperados de las clases */
        private void Formato_Datos()
        {
            switch (cb_TipoReportes.SelectedItem.ToString())
            {
                case "Reporte 32-A":

                    foreach (cDataReporte32A clase in vgLista32A)
                    {
                        clase.nFideicometido = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(clase.nFideicometido), 0).ToString("N");
                        clase.nValorGarantia = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(clase.nValorGarantia), 0).ToString("N");
                        clase.nValorDisposicionInmediata = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(clase.nValorDisposicionInmediata), 0).ToString("N");
                    }

                    dgv_DatosReporte32A.DataSource = vgLista32A;
                    dgv_DatosReporte32A.Refresh();
                    break;

                case "Reporte 32-BI":

                    foreach (cDataReporte32BI clase in vgLista32BI)
                    {
                        clase.nMontoConver = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(clase.nMontoConver), 0).ToString("N");
                        clase.nNroOperacionesConver = cConverciones.ConvertirAEntero(cConverciones.ValidarVacioONulo(clase.nNroOperacionesConver), 0).ToString();
                        clase.nMontoTransfPago = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(clase.nMontoTransfPago), 0).ToString("N");
                        clase.nNroOperacionesTransfPago = cConverciones.ConvertirAEntero(cConverciones.ValidarVacioONulo(clase.nNroOperacionesTransfPago), 0).ToString();
                        clase.nMontoReconversiones = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(clase.nMontoReconversiones), 0).ToString("N");
                        clase.nNroOperacionesReconversiones = cConverciones.ConvertirAEntero(cConverciones.ValidarVacioONulo(clase.nNroOperacionesReconversiones), 0).ToString();
                        clase.nMontoOtros = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(clase.nMontoOtros), 0).ToString("N");
                        clase.nNroOperacionesotros = cConverciones.ConvertirAEntero(cConverciones.ValidarVacioONulo(clase.nNroOperacionesotros), 0).ToString();
                        clase.nTipoCambio = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(clase.nTipoCambio), 0).ToString("N");
                    }

                    dgv_DatosReporte32A.DataSource = vgLista32BI;
                    dgv_DatosReporte32A.Refresh();
                    break;

                case "Reporte 32-BII":

                    foreach (cDataReporte32BII clase in vgLista32BII)
                    {
                        clase.nMonedaNacional = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(clase.nMonedaNacional), 0).ToString("N");
                        clase.nMonedaExtranjera = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(clase.nMonedaExtranjera), 0).ToString("N");
                        clase.nTotal = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(clase.nTotal), 0).ToString("N");
                    }

                    dgv_DatosReporte32A.DataSource = vgLista32BII;
                    dgv_DatosReporte32A.Refresh();
                    break;

                case "Reporte 32-BIII":

                    foreach (cDataReporte32BIII clase in vgLista32BIII)
                    {
                        
                    }

                    dgv_DatosReporte32A.DataSource = vgLista32BIII;
                    dgv_DatosReporte32A.Refresh();
                    break;

                case "Reporte 32-BIV":

                    foreach (cDataReporte32BIV clase in vgLista32BIV)
                    {
                        clase.nTotDineroElec = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(clase.nTotDineroElec), 0).ToString("N");
                        clase.nValPatriFideicometido = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(clase.nValPatriFideicometido), 0).ToString("N");
                        clase.nValorDisposicionInmediata = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(clase.nValorDisposicionInmediata), 0).ToString("N");
                        clase.nValorGarantia = cConverciones.ConvertirADouble(cConverciones.ValidarVacioONulo(clase.nValorGarantia), 0).ToString("N");
                    }

                    dgv_DatosReporte32A.DataSource = vgLista32BIV;
                    dgv_DatosReporte32A.Refresh();
                    break;

                case "Reporte 32-BV":

                    foreach (cDataReporte32BV clase in vgLista32BV)
                    {
                        
                    }

                    dgv_DatosReporte32A.DataSource = vgLista32BV;
                    dgv_DatosReporte32A.Refresh();
                    break;

                default:
                    break;
            }
        }
        /* FIN 04072023 HSPC - Metodo para formatear datos recuperados de las clases */
    }
}
