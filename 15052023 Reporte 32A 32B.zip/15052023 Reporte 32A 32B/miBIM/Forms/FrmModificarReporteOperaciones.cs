﻿using System;
using System.Windows.Forms;

namespace miBIM.Forms
{
    public partial class FrmModificarReporteOperaciones : Form
    {
        public FrmModificarReporteOperaciones()
        {
            InitializeComponent();

            dtpck_Fecha.Value = new DateTime(2023, 03, 31);
        }
    }
}
