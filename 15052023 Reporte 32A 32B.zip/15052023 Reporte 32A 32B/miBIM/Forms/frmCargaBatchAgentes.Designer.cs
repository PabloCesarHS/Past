﻿namespace miBIM.Forms
{
    partial class frmCargaBatchAgentes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCargaBatchAgentes));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkb_EsPartnerWeb = new System.Windows.Forms.CheckBox();
            this.btn_Agregar = new System.Windows.Forms.Button();
            this.txtb_MSISDN = new System.Windows.Forms.TextBox();
            this.chkb_Produccion = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chkb_Test = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cb_PerfilGrupo = new System.Windows.Forms.ComboBox();
            this.txtb_idioma = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cb_OperadorMovil = new System.Windows.Forms.ComboBox();
            this.txtb_dni = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtb_CelPadre = new System.Windows.Forms.TextBox();
            this.cb_Perfil = new System.Windows.Forms.ComboBox();
            this.la_celPadre = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgvAgentes = new System.Windows.Forms.DataGridView();
            this.Col_Eliminar = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Col_MSIDN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_UsernameG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_Username = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_Idioma = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_DNI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_ProfileName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_CelPadre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_OpMovil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_PerfilGrupo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_GrupoId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnGenerar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.paHeader = new System.Windows.Forms.Panel();
            this.laTitulo = new System.Windows.Forms.Label();
            this.ErrorP = new System.Windows.Forms.ErrorProvider(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAgentes)).BeginInit();
            this.panel5.SuspendLayout();
            this.paHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorP)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chkb_EsPartnerWeb);
            this.groupBox2.Controls.Add(this.btn_Agregar);
            this.groupBox2.Controls.Add(this.txtb_MSISDN);
            this.groupBox2.Controls.Add(this.chkb_Produccion);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.chkb_Test);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.cb_PerfilGrupo);
            this.groupBox2.Controls.Add(this.txtb_idioma);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.cb_OperadorMovil);
            this.groupBox2.Controls.Add(this.txtb_dni);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txtb_CelPadre);
            this.groupBox2.Controls.Add(this.cb_Perfil);
            this.groupBox2.Controls.Add(this.la_celPadre);
            this.groupBox2.Location = new System.Drawing.Point(10, 65);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(657, 228);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DATOS AGENTE";
            // 
            // chkb_EsPartnerWeb
            // 
            this.chkb_EsPartnerWeb.AutoSize = true;
            this.chkb_EsPartnerWeb.Location = new System.Drawing.Point(393, 38);
            this.chkb_EsPartnerWeb.Name = "chkb_EsPartnerWeb";
            this.chkb_EsPartnerWeb.Size = new System.Drawing.Size(101, 17);
            this.chkb_EsPartnerWeb.TabIndex = 1;
            this.chkb_EsPartnerWeb.Text = "Es Partner Web";
            this.toolTip1.SetToolTip(this.chkb_EsPartnerWeb, "Si es Partner Web se generara un Username");
            this.chkb_EsPartnerWeb.UseVisualStyleBackColor = true;
            // 
            // btn_Agregar
            // 
            this.btn_Agregar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Agregar.Image = global::miBIM.Properties.Resources.agregar;
            this.btn_Agregar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Agregar.Location = new System.Drawing.Point(557, 197);
            this.btn_Agregar.Name = "btn_Agregar";
            this.btn_Agregar.Size = new System.Drawing.Size(90, 25);
            this.btn_Agregar.TabIndex = 1;
            this.btn_Agregar.Text = "Agregar";
            this.btn_Agregar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Agregar.UseVisualStyleBackColor = true;
            this.btn_Agregar.Click += new System.EventHandler(this.btn_Agregar_Click);
            // 
            // txtb_MSISDN
            // 
            this.txtb_MSISDN.Location = new System.Drawing.Point(108, 39);
            this.txtb_MSISDN.MaxLength = 11;
            this.txtb_MSISDN.Name = "txtb_MSISDN";
            this.txtb_MSISDN.Size = new System.Drawing.Size(260, 20);
            this.txtb_MSISDN.TabIndex = 0;
            this.txtb_MSISDN.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtb_MSISDN_KeyPress);
            this.txtb_MSISDN.Validated += new System.EventHandler(this.txtb_MSISDN_Validated);
            // 
            // chkb_Produccion
            // 
            this.chkb_Produccion.AutoSize = true;
            this.chkb_Produccion.Location = new System.Drawing.Point(280, 16);
            this.chkb_Produccion.Name = "chkb_Produccion";
            this.chkb_Produccion.Size = new System.Drawing.Size(98, 17);
            this.chkb_Produccion.TabIndex = 0;
            this.chkb_Produccion.Text = "PRODUCCION";
            this.chkb_Produccion.UseVisualStyleBackColor = true;
            this.chkb_Produccion.Visible = false;
            this.chkb_Produccion.Click += new System.EventHandler(this.chkb_Produccion_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "MSISDN *:";
            this.toolTip1.SetToolTip(this.label1, "cod pais + nro. Cel");
            // 
            // chkb_Test
            // 
            this.chkb_Test.AutoSize = true;
            this.chkb_Test.Location = new System.Drawing.Point(108, 16);
            this.chkb_Test.Name = "chkb_Test";
            this.chkb_Test.Size = new System.Drawing.Size(54, 17);
            this.chkb_Test.TabIndex = 18;
            this.chkb_Test.Text = "TEST";
            this.chkb_Test.UseVisualStyleBackColor = true;
            this.chkb_Test.Visible = false;
            this.chkb_Test.Click += new System.EventHandler(this.chkb_Test_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(56, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Idioma *:";
            // 
            // cb_PerfilGrupo
            // 
            this.cb_PerfilGrupo.FormattingEnabled = true;
            this.cb_PerfilGrupo.Location = new System.Drawing.Point(108, 118);
            this.cb_PerfilGrupo.Name = "cb_PerfilGrupo";
            this.cb_PerfilGrupo.Size = new System.Drawing.Size(386, 21);
            this.cb_PerfilGrupo.TabIndex = 4;
            // 
            // txtb_idioma
            // 
            this.txtb_idioma.Location = new System.Drawing.Point(108, 65);
            this.txtb_idioma.Name = "txtb_idioma";
            this.txtb_idioma.ReadOnly = true;
            this.txtb_idioma.Size = new System.Drawing.Size(123, 20);
            this.txtb_idioma.TabIndex = 2;
            this.txtb_idioma.Text = "es";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 121);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Perfil de Grupo *:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(275, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "DNI *:";
            // 
            // cb_OperadorMovil
            // 
            this.cb_OperadorMovil.FormattingEnabled = true;
            this.cb_OperadorMovil.Items.AddRange(new object[] {
            "CLARO",
            "MOVISTAR",
            "ENTEL",
            "TUENTI",
            "BITEL"});
            this.cb_OperadorMovil.Location = new System.Drawing.Point(108, 145);
            this.cb_OperadorMovil.Name = "cb_OperadorMovil";
            this.cb_OperadorMovil.Size = new System.Drawing.Size(386, 21);
            this.cb_OperadorMovil.TabIndex = 5;
            // 
            // txtb_dni
            // 
            this.txtb_dni.Location = new System.Drawing.Point(317, 65);
            this.txtb_dni.MaxLength = 8;
            this.txtb_dni.Name = "txtb_dni";
            this.txtb_dni.Size = new System.Drawing.Size(177, 20);
            this.txtb_dni.TabIndex = 2;
            this.txtb_dni.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtb_dni_KeyPress);
            this.txtb_dni.Validated += new System.EventHandler(this.txtb_dni_Validated);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(17, 148);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Operador Movil *:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(62, 94);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Perfil *:";
            // 
            // txtb_CelPadre
            // 
            this.txtb_CelPadre.Location = new System.Drawing.Point(108, 172);
            this.txtb_CelPadre.Name = "txtb_CelPadre";
            this.txtb_CelPadre.Size = new System.Drawing.Size(386, 20);
            this.txtb_CelPadre.TabIndex = 6;
            this.txtb_CelPadre.Visible = false;
            // 
            // cb_Perfil
            // 
            this.cb_Perfil.FormattingEnabled = true;
            this.cb_Perfil.Location = new System.Drawing.Point(108, 91);
            this.cb_Perfil.Name = "cb_Perfil";
            this.cb_Perfil.Size = new System.Drawing.Size(386, 21);
            this.cb_Perfil.TabIndex = 3;
            this.cb_Perfil.SelectedIndexChanged += new System.EventHandler(this.cb_Perfil_SelectedIndexChanged);
            // 
            // la_celPadre
            // 
            this.la_celPadre.AutoSize = true;
            this.la_celPadre.Location = new System.Drawing.Point(14, 175);
            this.la_celPadre.Name = "la_celPadre";
            this.la_celPadre.Size = new System.Drawing.Size(88, 13);
            this.la_celPadre.TabIndex = 12;
            this.la_celPadre.Text = "Celular de Padre:";
            this.la_celPadre.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgvAgentes);
            this.groupBox1.Location = new System.Drawing.Point(10, 299);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(657, 190);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "AGENTES";
            // 
            // dgvAgentes
            // 
            this.dgvAgentes.AllowUserToAddRows = false;
            this.dgvAgentes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvAgentes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAgentes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Col_Eliminar,
            this.Col_MSIDN,
            this.Col_UsernameG,
            this.Col_Username,
            this.Col_Idioma,
            this.Col_DNI,
            this.Col_ProfileName,
            this.Col_CelPadre,
            this.Col_OpMovil,
            this.Col_PerfilGrupo,
            this.Col_GrupoId});
            this.dgvAgentes.Location = new System.Drawing.Point(9, 16);
            this.dgvAgentes.Margin = new System.Windows.Forms.Padding(0);
            this.dgvAgentes.Name = "dgvAgentes";
            this.dgvAgentes.ReadOnly = true;
            this.dgvAgentes.Size = new System.Drawing.Size(638, 156);
            this.dgvAgentes.TabIndex = 0;
            this.dgvAgentes.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAgentes_CellClick);
            // 
            // Col_Eliminar
            // 
            this.Col_Eliminar.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            this.Col_Eliminar.DefaultCellStyle = dataGridViewCellStyle1;
            this.Col_Eliminar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Col_Eliminar.Frozen = true;
            this.Col_Eliminar.HeaderText = "          ";
            this.Col_Eliminar.Name = "Col_Eliminar";
            this.Col_Eliminar.ReadOnly = true;
            this.Col_Eliminar.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Col_Eliminar.ToolTipText = "Eliminar";
            this.Col_Eliminar.Width = 25;
            // 
            // Col_MSIDN
            // 
            this.Col_MSIDN.HeaderText = "MSIDN";
            this.Col_MSIDN.Name = "Col_MSIDN";
            this.Col_MSIDN.ReadOnly = true;
            this.Col_MSIDN.Width = 67;
            // 
            // Col_UsernameG
            // 
            this.Col_UsernameG.HeaderText = "Username";
            this.Col_UsernameG.Name = "Col_UsernameG";
            this.Col_UsernameG.ReadOnly = true;
            this.Col_UsernameG.Width = 80;
            // 
            // Col_Username
            // 
            this.Col_Username.HeaderText = "Username";
            this.Col_Username.Name = "Col_Username";
            this.Col_Username.ReadOnly = true;
            this.Col_Username.Visible = false;
            this.Col_Username.Width = 80;
            // 
            // Col_Idioma
            // 
            this.Col_Idioma.HeaderText = "Idioma";
            this.Col_Idioma.Name = "Col_Idioma";
            this.Col_Idioma.ReadOnly = true;
            this.Col_Idioma.Width = 63;
            // 
            // Col_DNI
            // 
            this.Col_DNI.HeaderText = "DNI";
            this.Col_DNI.Name = "Col_DNI";
            this.Col_DNI.ReadOnly = true;
            this.Col_DNI.Width = 51;
            // 
            // Col_ProfileName
            // 
            this.Col_ProfileName.HeaderText = "Perfil";
            this.Col_ProfileName.Name = "Col_ProfileName";
            this.Col_ProfileName.ReadOnly = true;
            this.Col_ProfileName.Width = 55;
            // 
            // Col_CelPadre
            // 
            this.Col_CelPadre.HeaderText = "Cel. Padre";
            this.Col_CelPadre.Name = "Col_CelPadre";
            this.Col_CelPadre.ReadOnly = true;
            this.Col_CelPadre.Width = 75;
            // 
            // Col_OpMovil
            // 
            this.Col_OpMovil.HeaderText = "Operador Movil";
            this.Col_OpMovil.Name = "Col_OpMovil";
            this.Col_OpMovil.ReadOnly = true;
            this.Col_OpMovil.Width = 96;
            // 
            // Col_PerfilGrupo
            // 
            this.Col_PerfilGrupo.HeaderText = "Perfil Grupo";
            this.Col_PerfilGrupo.Name = "Col_PerfilGrupo";
            this.Col_PerfilGrupo.ReadOnly = true;
            this.Col_PerfilGrupo.Width = 80;
            // 
            // Col_GrupoId
            // 
            this.Col_GrupoId.HeaderText = "Grupo Id";
            this.Col_GrupoId.Name = "Col_GrupoId";
            this.Col_GrupoId.ReadOnly = true;
            this.Col_GrupoId.Visible = false;
            this.Col_GrupoId.Width = 68;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel5.Controls.Add(this.btnGenerar);
            this.panel5.Controls.Add(this.btnSalir);
            this.panel5.Location = new System.Drawing.Point(10, 495);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(657, 59);
            this.panel5.TabIndex = 37;
            // 
            // btnGenerar
            // 
            this.btnGenerar.Enabled = false;
            this.btnGenerar.Location = new System.Drawing.Point(9, 18);
            this.btnGenerar.Name = "btnGenerar";
            this.btnGenerar.Size = new System.Drawing.Size(79, 29);
            this.btnGenerar.TabIndex = 1;
            this.btnGenerar.Text = "&Generar";
            this.btnGenerar.UseVisualStyleBackColor = true;
            this.btnGenerar.Click += new System.EventHandler(this.btnGenerar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalir.Location = new System.Drawing.Point(557, 16);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(90, 31);
            this.btnSalir.TabIndex = 0;
            this.btnSalir.Text = "&Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // paHeader
            // 
            this.paHeader.BackColor = System.Drawing.SystemColors.ControlLight;
            this.paHeader.Controls.Add(this.laTitulo);
            this.paHeader.Location = new System.Drawing.Point(10, 10);
            this.paHeader.Name = "paHeader";
            this.paHeader.Size = new System.Drawing.Size(657, 49);
            this.paHeader.TabIndex = 36;
            // 
            // laTitulo
            // 
            this.laTitulo.AutoSize = true;
            this.laTitulo.BackColor = System.Drawing.Color.YellowGreen;
            this.laTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laTitulo.ForeColor = System.Drawing.Color.Transparent;
            this.laTitulo.Location = new System.Drawing.Point(227, 15);
            this.laTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laTitulo.Name = "laTitulo";
            this.laTitulo.Size = new System.Drawing.Size(191, 20);
            this.laTitulo.TabIndex = 0;
            this.laTitulo.Text = "REGISTRAR AGENTE";
            // 
            // ErrorP
            // 
            this.ErrorP.ContainerControl = this;
            // 
            // frmCargaBatchAgentes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(677, 554);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.paHeader);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmCargaBatchAgentes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Registrar Agente";
            this.Load += new System.EventHandler(this.frmCargaBatchAgentes_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAgentes)).EndInit();
            this.panel5.ResumeLayout(false);
            this.paHeader.ResumeLayout(false);
            this.paHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorP)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chkb_EsPartnerWeb;
        private System.Windows.Forms.Button btn_Agregar;
        private System.Windows.Forms.TextBox txtb_MSISDN;
        private System.Windows.Forms.CheckBox chkb_Produccion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkb_Test;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cb_PerfilGrupo;
        private System.Windows.Forms.TextBox txtb_idioma;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cb_OperadorMovil;
        private System.Windows.Forms.TextBox txtb_dni;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtb_CelPadre;
        private System.Windows.Forms.ComboBox cb_Perfil;
        private System.Windows.Forms.Label la_celPadre;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgvAgentes;
        private System.Windows.Forms.DataGridViewButtonColumn Col_Eliminar;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_MSIDN;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_UsernameG;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_Username;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_Idioma;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_DNI;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_ProfileName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_CelPadre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_OpMovil;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_PerfilGrupo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_GrupoId;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnGenerar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Panel paHeader;
        private System.Windows.Forms.Label laTitulo;
        private System.Windows.Forms.ErrorProvider ErrorP;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}