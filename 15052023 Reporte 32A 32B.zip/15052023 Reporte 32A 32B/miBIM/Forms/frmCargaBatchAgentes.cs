﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miBIM.Forms
{
    public partial class frmCargaBatchAgentes : Form
    {
        public frmCargaBatchAgentes()
        {
            InitializeComponent();
        }

        private void frmCargaBatchAgentes_Load(object sender, EventArgs e)
        {
            cCargaAgente oCargaAgente = new cCargaAgente();

            DataSet oDatosPerfil = oCargaAgente.Listar(1);
            foreach (DataRow row in oDatosPerfil.Tables[0].Rows)
            {
                cb_Perfil.Items.Add(row["cPerfil"].ToString());
            }
            cb_Perfil.SelectedIndex = 0;
            cb_OperadorMovil.SelectedIndex = 0;

            DataSet oDatosGrupo = oCargaAgente.Listar(2);
            foreach (DataRow row in oDatosGrupo.Tables[0].Rows)
            {
                cb_PerfilGrupo.Items.Add(row["cGroupMember"].ToString());
            }
            cb_PerfilGrupo.SelectedIndex = 0;

            chkb_Produccion.Checked = true;
        }
        public void limpiar()
        {
            txtb_MSISDN.Text = "";
            txtb_dni.Text = "";
            txtb_CelPadre.Text = "";
            cb_Perfil.SelectedIndex = 0;
            cb_PerfilGrupo.SelectedIndex = 0;
            chkb_EsPartnerWeb.Checked = false;
        }

        public void Hab_o_Des_Boton()
        {
            if (dgvAgentes.Rows.Count > 0)
                btnGenerar.Enabled = true; //habilitamos el boton
            else
                btnGenerar.Enabled = false; //deshabilitamos el boton
        }

        private void btnGenerar_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("¿Seguro que desea generar el archivo plano con los Agentes Registrados?", "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            switch (resultado)
            {
                case DialogResult.Yes:
                    cCargaAgente oCargaAgente = new cCargaAgente();
                    DataTable oResultado = new DataTable();
                    string sMSISDN = "";
                    int nUsername = 0;
                    string sIdioma = "";
                    string sID = "";
                    string sCelularPadre = "";
                    string sperfil = "";
                    string sOperadorMovil = "";
                    string sPerfilGrupo = "";
                    int nGrupoID = 0;


                    int[] nNroMovimientos = new int[dgvAgentes.Rows.Count];
                    int nRespuesta;
                    int i = 0;
                    foreach (DataGridViewRow fila in dgvAgentes.Rows)
                    {
                        sMSISDN = fila.Cells["Col_MSIDN"].Value.ToString();
                        nUsername = int.Parse(fila.Cells["Col_Username"].Value.ToString());
                        sIdioma = fila.Cells["Col_Idioma"].Value.ToString();
                        sID = fila.Cells["Col_DNI"].Value.ToString();
                        sCelularPadre = fila.Cells["Col_CelPadre"].Value.ToString();
                        sperfil = fila.Cells["Col_ProfileName"].Value.ToString();
                        sOperadorMovil = fila.Cells["Col_OpMovil"].Value.ToString();
                        sPerfilGrupo = fila.Cells["Col_PerfilGrupo"].Value.ToString();
                        nGrupoID = int.Parse(fila.Cells["Col_GrupoId"].Value.ToString());

                        oResultado = oCargaAgente.Insertar_BatchAgente(sMSISDN, nUsername, sIdioma, sID, sperfil, sCelularPadre, sOperadorMovil, sPerfilGrupo, nGrupoID);
                        nRespuesta = int.Parse(oResultado.Rows[0][0].ToString());

                        if (nRespuesta == 0)
                        {
                            MessageBox.Show("Ocurrio un error al registrar Agente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            nNroMovimientos[i] = nRespuesta;
                        }
                        i++;
                    }
                    EscribirBatchAgente(nNroMovimientos);

                    Hab_o_Des_Boton();
                    break;
                case DialogResult.No:
                    break;
            }
        }

        private void EscribirBatchAgente(int[] nNroMovimientos)
        {
            cCargaAgente oCargaAgente = new cCargaAgente();

            string MSISDN = "";
            string Username = "";
            string Idioma = "";
            string ID = "";
            string CelularPadre = "";
            string BankDomain = "";
            string perfil = "";
            string OperadorMovil = "";
            string PerfilGrupo = "";
            int GrupoID = 0;
            DataSet dsBatchAgentes = new DataSet();

            StreamWriter sw = null;
            DateTime dFecha = DateTime.Now;
            cConstante cConstante = new cConstante();
            String cNombreArchivo;
            cNombreArchivo = "CCUSCO-AGENTES-" + dFecha.ToString("yyyyMMdd") + ".csv";
            string path = cConstante.cpRutaDestinoOutAgentes + cNombreArchivo;
            int nMov;

            sw = File.CreateText(path);
            sw.Flush();
            sw.Close();
            int cont = 1;

            for (int i = 0; i < nNroMovimientos.Length; i++)
            {
                nMov = nNroMovimientos[i];

                dsBatchAgentes = oCargaAgente.Obtener_BatchAgente(nMov, cNombreArchivo);

                if (dsBatchAgentes.Tables[0].Rows.Count == 0)
                {
                    MessageBox.Show("No Se encontro registro de Agentes", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    foreach (DataRow row in dsBatchAgentes.Tables[0].Rows)
                    {
                        MSISDN = row["cMSISDN"].ToString();
                        Username = row["cUsername"].ToString();
                        Idioma = row["cIdioma"].ToString();
                        ID = row["cID"].ToString();
                        perfil = row["cProfilename"].ToString();
                        CelularPadre = row["cCelularPadre"].ToString();
                        BankDomain = row["cBankDomain"].ToString();
                        OperadorMovil = row["cOperadorMovil"].ToString();
                        PerfilGrupo = row["cPerfilGrupo"].ToString();
                        GrupoID = int.Parse(row["nGrupoID"].ToString());

                        sw = File.AppendText(path);
                        if (cont == nNroMovimientos.Length)
                            //sw.WriteLine(MSISDN + "," + Username + "," + Idioma + "," + ID + "," + perfil + "," + CelularPadre + "," + BankDomain + "," + OperadorMovil + "," + PerfilGrupo + "," + GrupoID);
                            sw.Write(MSISDN + "," + Username + "," + Idioma + "," + ID + "," + perfil + "," + CelularPadre + "," + BankDomain + "," + OperadorMovil + "," + PerfilGrupo + "," + GrupoID);
                        else
                            sw.WriteLine(MSISDN + "," + Username + "," + Idioma + "," + ID + "," + perfil + "," + CelularPadre + "," + BankDomain + "," + OperadorMovil + "," + PerfilGrupo + "," + GrupoID);

                        sw.Flush();
                        sw.Close();
                        cont++;
                    }
                }
            }
            //FirmarDocumento  
            //String cMensajeFirma = cConstante.FirmaArchivo(cNombreArchivo);
            //if (cMensajeFirma != "")
            //{
            //    MessageBox.Show(cMensajeFirma.ToString(), "Alerta");
            //    return;
            //}
            limpiar();
            dgvAgentes.Rows.Clear();
            MessageBox.Show("Archivo Generado de forma satisfactoria, " + path);
        }

        private void chkb_Test_Click(object sender, EventArgs e)
        {
            chkb_Produccion.Checked = false;
            chkb_Test.Checked = true;
        }

        private void chkb_Produccion_Click(object sender, EventArgs e)
        {
            chkb_Test.Checked = false;
            chkb_Produccion.Checked = true;
        }

        private Boolean Existe_NumeroCelularEnDgv(String cNroCelular)
        {
            foreach (DataGridViewRow row in dgvAgentes.Rows)
            {
                string Valor = Convert.ToString(row.Cells["Col_MSIDN"].Value);
                if (Valor == cNroCelular)
                    return true;
            }
            return false;
        }


        private Boolean Existe_DNIEnDgv(String cNroCelular)
        {
            foreach (DataGridViewRow row in dgvAgentes.Rows)
            {
                string Valor = Convert.ToString(row.Cells["Col_DNI"].Value);
                if (Valor == cNroCelular)
                {
                    MessageBox.Show("Ya agrego Agente con el mismo DNI", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return true;
                }
            }
            return false;
        }

        private void btn_Agregar_Click(object sender, EventArgs e)
        {
            cCargaAgente oCargaAgente = new cCargaAgente();

            if (txtb_MSISDN.Text.Trim().Length >= 11 && txtb_idioma.Text.Trim() != ""
                            && txtb_dni.Text.Trim().Length == 8 && cb_OperadorMovil.SelectedItem != null
                            && cb_Perfil.SelectedItem != null && cb_PerfilGrupo.SelectedItem != null)
            {
                if (!oCargaAgente.Existe_BatchAgente(txtb_MSISDN.Text.Trim(), txtb_dni.Text.Trim()))
                {
                    if (!Existe_NumeroCelularEnDgv(txtb_MSISDN.Text.Trim()))
                    {
                        if (!Existe_DNIEnDgv(txtb_dni.Text.Trim()))
                        {

                            int GenerarUserPW = 0;
                            string msgGenerarSecuSERpw = "";
                            //GenerarUserPW = 0 : No se genera Username
                            //GenerarUserPW = 1 : Se genera Username para PRODUCION
                            //GenerarUserPW = 2 : Se genera Username para TEST

                            if (txtb_CelPadre.Text.Trim() == txtb_MSISDN.Text.Trim())
                            {
                                MessageBox.Show("El Celular del Padre no puede ser el mismo número de celular que se está registrando.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {

                                dgvAgentes.ColumnHeadersVisible = true;

                                int nGrupoID = 0;

                                if (chkb_Produccion.Checked == true)
                                {
                                    nGrupoID = oCargaAgente.Recuperar_IdGroup("PRODUCCION");

                                    if (chkb_EsPartnerWeb.Checked == true)
                                    {
                                        msgGenerarSecuSERpw = "se generara Username";
                                        GenerarUserPW = 1; //GenerarUserPW = 1 : Se genera Username para PRODUCION
                                    }
                                }
                                else
                                {
                                    nGrupoID = oCargaAgente.Recuperar_IdGroup("TEST");
                                    if (chkb_EsPartnerWeb.Checked == true)
                                    {
                                        msgGenerarSecuSERpw = "se generara Username";
                                        GenerarUserPW = 2;  //GenerarUserPW = 2 : Se genera Username para TEST
                                    }

                                }

                                int nNroFilas = dgvAgentes.Rows.Count;
                                dgvAgentes.Rows.Insert(nNroFilas, "X"
                                     , txtb_MSISDN.Text.Trim()
                                     , msgGenerarSecuSERpw
                                     , GenerarUserPW
                                     , txtb_idioma.Text.Trim()
                                     , txtb_dni.Text.Trim()
                                     , cb_Perfil.SelectedItem.ToString()
                                     , txtb_CelPadre.Text.Trim()
                                     , cb_OperadorMovil.SelectedItem.ToString()
                                     , cb_PerfilGrupo.SelectedItem.ToString()
                                     , nGrupoID
                                    );

                                limpiar();

                            }

                            Hab_o_Des_Boton();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Ya agrego Agente con el mismo MSISDN", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Ya existe Agente con el mismo MSISDN o DNI", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Complete los campos obligatorios * ", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        private void dgvAgentes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0)
                {
                    dgvAgentes.Rows.RemoveAt(e.RowIndex);
                    Hab_o_Des_Boton();
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Seleccion no valida", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void cb_Perfil_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_Perfil.SelectedItem.ToString().ToUpper().Trim() == "CCUSCO AGENTE" || cb_Perfil.SelectedItem.ToString().ToUpper().Trim() == "CCUSCO AGENTECOMERCIO")
            {
                txtb_CelPadre.Visible = true;
                la_celPadre.Visible = true;
            }
            else
            {
                txtb_CelPadre.Visible = false;
                la_celPadre.Visible = false;
            }
        }

        private void txtb_MSISDN_KeyPress(object sender, KeyPressEventArgs e)
        {
            char aux = e.KeyChar;

            if (char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                if (char.IsDigit(e.KeyChar)) //Si es numero
                {
                    e.Handled = false;
                }
                else
                    e.Handled = true;
            }
        }

        private void txtb_dni_KeyPress(object sender, KeyPressEventArgs e)
        {
            char aux = e.KeyChar;

            if (char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                if (char.IsDigit(e.KeyChar)) //Si es numero
                {
                    e.Handled = false;
                }
                else
                    e.Handled = true;
            }
        }

        private void txtb_MSISDN_Validated(object sender, EventArgs e)
        {
            if (txtb_dni.Text.Trim().Length < 8)
            {
                ErrorP.SetError(txtb_dni, "Ingrese un DNI valido.");
            }
            else
            {
                ErrorP.Clear();
            }
        }

        private void txtb_dni_Validated(object sender, EventArgs e)
        {
            if (txtb_MSISDN.Text.Trim().Length < 11)
            {
                ErrorP.SetError(txtb_MSISDN, "El MSISDN debe contener Cod Pais + Nro. Cel");
            }
            else
            {
                ErrorP.Clear();
            }

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        


    }
}
