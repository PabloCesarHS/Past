﻿namespace miBIM.Forms
{
    partial class frmConfiguracion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.laTitulo = new System.Windows.Forms.Label();
            this.laTelefono = new System.Windows.Forms.Label();
            this.tbxRuta = new System.Windows.Forms.TextBox();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lb1 = new System.Windows.Forms.Label();
            this.dgvListaRutas = new System.Windows.Forms.DataGridView();
            this.dvgColumnaEditar = new System.Windows.Forms.DataGridViewImageColumn();
            this.dvgColumnaEliminar = new System.Windows.Forms.DataGridViewImageColumn();
            this.btnBuscarRuta = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbMensaje = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaRutas)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // laTitulo
            // 
            this.laTitulo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.laTitulo.AutoSize = true;
            this.laTitulo.BackColor = System.Drawing.Color.YellowGreen;
            this.laTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.laTitulo.ForeColor = System.Drawing.SystemColors.Control;
            this.laTitulo.Location = new System.Drawing.Point(233, 19);
            this.laTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laTitulo.Name = "laTitulo";
            this.laTitulo.Size = new System.Drawing.Size(139, 20);
            this.laTitulo.TabIndex = 0;
            this.laTitulo.Text = "Configuraciones";
            this.laTitulo.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // laTelefono
            // 
            this.laTelefono.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.laTelefono.AutoSize = true;
            this.laTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.laTelefono.Location = new System.Drawing.Point(12, 262);
            this.laTelefono.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laTelefono.Name = "laTelefono";
            this.laTelefono.Size = new System.Drawing.Size(88, 13);
            this.laTelefono.TabIndex = 1;
            this.laTelefono.Text = "Direccion de ruta";
            // 
            // tbxRuta
            // 
            this.tbxRuta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbxRuta.Location = new System.Drawing.Point(15, 277);
            this.tbxRuta.Margin = new System.Windows.Forms.Padding(2);
            this.tbxRuta.MaxLength = 0;
            this.tbxRuta.Name = "tbxRuta";
            this.tbxRuta.Size = new System.Drawing.Size(370, 20);
            this.tbxRuta.TabIndex = 1;
            // 
            // btnSalir
            // 
            this.btnSalir.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSalir.Location = new System.Drawing.Point(225, 13);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(2);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(166, 30);
            this.btnSalir.TabIndex = 14;
            this.btnSalir.Text = "&Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnModificar.Location = new System.Drawing.Point(448, 272);
            this.btnModificar.Margin = new System.Windows.Forms.Padding(2);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(93, 29);
            this.btnModificar.TabIndex = 16;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = true;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.laTitulo);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(621, 59);
            this.panel2.TabIndex = 16;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.btnSalir);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 418);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(621, 48);
            this.panel1.TabIndex = 20;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.lb1);
            this.groupBox1.Controls.Add(this.btnModificar);
            this.groupBox1.Controls.Add(this.dgvListaRutas);
            this.groupBox1.Controls.Add(this.tbxRuta);
            this.groupBox1.Controls.Add(this.laTelefono);
            this.groupBox1.Controls.Add(this.btnBuscarRuta);
            this.groupBox1.Location = new System.Drawing.Point(12, 20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(597, 308);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Formulairo de modificacion de rutas";
            // 
            // lb1
            // 
            this.lb1.AutoSize = true;
            this.lb1.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lb1.Location = new System.Drawing.Point(202, 250);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(337, 13);
            this.lb1.TabIndex = 23;
            this.lb1.Text = "Para agregar una nueva ruta seleccionar una fila y precionar: (Ctrl + n)";
            // 
            // dgvListaRutas
            // 
            this.dgvListaRutas.AllowUserToAddRows = false;
            this.dgvListaRutas.AllowUserToDeleteRows = false;
            this.dgvListaRutas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvListaRutas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvListaRutas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaRutas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dvgColumnaEditar,
            this.dvgColumnaEliminar});
            this.dgvListaRutas.Location = new System.Drawing.Point(13, 22);
            this.dgvListaRutas.Margin = new System.Windows.Forms.Padding(0);
            this.dgvListaRutas.Name = "dgvListaRutas";
            this.dgvListaRutas.ReadOnly = true;
            this.dgvListaRutas.RowHeadersVisible = false;
            this.dgvListaRutas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListaRutas.Size = new System.Drawing.Size(572, 225);
            this.dgvListaRutas.TabIndex = 15;
            this.dgvListaRutas.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvListaRutas_CellContentClick);
            this.dgvListaRutas.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgvListaRutas_KeyDown);
            // 
            // dvgColumnaEditar
            // 
            this.dvgColumnaEditar.Frozen = true;
            this.dvgColumnaEditar.HeaderText = "Editar";
            this.dvgColumnaEditar.Image = global::miBIM.Properties.Resources.border_color_FILL0_wght400_GRAD0_opsz24;
            this.dvgColumnaEditar.Name = "dvgColumnaEditar";
            this.dvgColumnaEditar.ReadOnly = true;
            this.dvgColumnaEditar.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dvgColumnaEditar.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dvgColumnaEditar.ToolTipText = "Editar";
            this.dvgColumnaEditar.Width = 59;
            // 
            // dvgColumnaEliminar
            // 
            this.dvgColumnaEliminar.Frozen = true;
            this.dvgColumnaEliminar.HeaderText = "Eliminar";
            this.dvgColumnaEliminar.Image = global::miBIM.Properties.Resources.cancel_FILL0_wght400_GRAD0_opsz24;
            this.dvgColumnaEliminar.Name = "dvgColumnaEliminar";
            this.dvgColumnaEliminar.ReadOnly = true;
            this.dvgColumnaEliminar.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dvgColumnaEliminar.ToolTipText = "Eliminar";
            this.dvgColumnaEliminar.Width = 49;
            // 
            // btnBuscarRuta
            // 
            this.btnBuscarRuta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnBuscarRuta.Location = new System.Drawing.Point(393, 275);
            this.btnBuscarRuta.Name = "btnBuscarRuta";
            this.btnBuscarRuta.Size = new System.Drawing.Size(29, 24);
            this.btnBuscarRuta.TabIndex = 18;
            this.btnBuscarRuta.Text = "...";
            this.btnBuscarRuta.UseVisualStyleBackColor = true;
            this.btnBuscarRuta.Click += new System.EventHandler(this.btnBuscarRuta_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lbMensaje);
            this.panel3.Controls.Add(this.groupBox1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 59);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(621, 359);
            this.panel3.TabIndex = 24;
            // 
            // lbMensaje
            // 
            this.lbMensaje.AutoSize = true;
            this.lbMensaje.Location = new System.Drawing.Point(18, 335);
            this.lbMensaje.Name = "lbMensaje";
            this.lbMensaje.Size = new System.Drawing.Size(16, 13);
            this.lbMensaje.TabIndex = 22;
            this.lbMensaje.Text = "...";
            // 
            // frmConfiguracion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(621, 466);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmConfiguracion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Configuraciones";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmConfiguracion_KeyDown);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaRutas)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label laTitulo;
        private System.Windows.Forms.Label laTelefono;
        private System.Windows.Forms.TextBox tbxRuta;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgvListaRutas;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnBuscarRuta;
        private System.Windows.Forms.Label lb1;
        private System.Windows.Forms.DataGridViewImageColumn dvgColumnaEditar;
        private System.Windows.Forms.DataGridViewImageColumn dvgColumnaEliminar;
        private System.Windows.Forms.Label lbMensaje;
    }
}