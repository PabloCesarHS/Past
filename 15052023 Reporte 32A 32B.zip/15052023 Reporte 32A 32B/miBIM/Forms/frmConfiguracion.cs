﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using static CapaNegocio.cConfiguracion;

namespace miBIM.Forms
{
    public partial class frmConfiguracion : Form
    {
        public frmConfiguracion()
        {
            InitializeComponent();
            listarRutas();
        }

        cConfiguracion vgConfiguracion = new cConfiguracion();
        cResultado vgResultado = new cResultado();

        List<cConfiguracionSistema> vgListaConfiguraciones = new List<cConfiguracionSistema>();
        cConfiguracionSistema vgClaseConfiguracion = new cConfiguracionSistema();

        private void listarRutas()
        {
            vgConfiguracion = new cConfiguracion();
            var cResultado = vgConfiguracion.Listar_ConfiguracionSistema();
            vgListaConfiguraciones = cTransformador.ConvertirDataTableAClase<cConfiguracionSistema>(cResultado.Datos);
            dgvListaRutas.DataSource = vgListaConfiguraciones;

            Mostrar_Mensaje(cResultado.Mensaje, 0);
        }

        private void ControlesEdicion()
        {
            tbxRuta.Enabled = true;
            btnModificar.Enabled = true;
            btnBuscarRuta.Enabled = true;
        }

        private void ControlesDefecto()
        {
            tbxRuta.Clear();
            tbxRuta.Enabled = false;
            btnModificar.Enabled = false;
            btnBuscarRuta.Enabled = false;
        }

        private bool ValidarClaseRuta()
        {
            bool Correcto = false;

            //if (vgClaseConfiguracion.nIdConfiguracion != string.Empty)
            //{
            //    Correcto = true;
            //}
            //if (vgClaseRuta.cRuta != string.Empty)
            //{
            //    Correcto = true;
            //}

            return Correcto;
        }

        private void Mostrar_Mensaje(string _Mensaje, int _Tipo)
        {
            switch (_Tipo)
            {
                case 1:
                    lbMensaje.ForeColor = System.Drawing.Color.Blue;
                    lbMensaje.Text = _Mensaje;
                    break;

                case 2:
                    lbMensaje.ForeColor = System.Drawing.Color.OrangeRed;
                    lbMensaje.Text = "ADVERTENCIA:" + _Mensaje;
                    break;

                case 3:
                    lbMensaje.ForeColor = System.Drawing.Color.Red;
                    lbMensaje.Text = "ERROR:" + _Mensaje;
                    break;

                default:
                    lbMensaje.ForeColor = System.Drawing.Color.Green;
                    lbMensaje.Text = _Mensaje;
                    break;
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (ValidarClaseRuta())
            {
                try
                {
                    /* aprobacion de cambio */
                    frmAprobacion oAprobacion = new frmAprobacion();
                    if (oAprobacion.ShowDialog() == DialogResult.OK)
                    {
                        //vgConfiguracion = new cConfiguracion();
                        //vgResultado = new cResultado();

                        //vgResultado = vgConfiguracion.Editar_Ruta(cConverciones.ConvertirAEntero(vgClaseRuta.nid, 0), vgClaseRuta.cRuta);
                        //Mostrar_Mensaje(vgResultado.Mensaje, vgResultado.Estado);
                        //if (vgResultado.Estado > 0)
                        //{
                        //    ControlesDefecto();
                        //}
                    }
                }
                catch (Exception ex)
                {
                    Mostrar_Mensaje(ex.Message, 3);
                }
            }
        }

        private void btnBuscarRuta_Click(object sender, EventArgs e)
        {
            if (ValidarClaseRuta())
            {
                //if (vgClaseRuta.cRuta.EndsWith(@"\"))
                //{
                //    FolderBrowserDialog oFBD = new FolderBrowserDialog();
                //    if (oFBD.ShowDialog() == DialogResult.OK)
                //    {
                //        if (oFBD.SelectedPath != string.Empty)
                //        {
                //            vgClaseRuta.cRuta = oFBD.SelectedPath + @"\";
                //            tbxRuta.Text = oFBD.SelectedPath + @"\";
                //        }
                //    }
                //}
                //else
                //{
                //    OpenFileDialog oFD = new OpenFileDialog();
                //    if (oFD.ShowDialog() == DialogResult.OK)
                //    {
                //        if (oFD.FileName != string.Empty)
                //        {
                //            vgClaseRuta.cRuta = oFD.FileName;
                //            tbxRuta.Text = oFD.FileName;
                //        }
                //    }
                //}
            }
        }

        private void dgvListaRutas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //try
            //{
            //    /* EDITAR */
            //    if (e.ColumnIndex == 0 && e.RowIndex >= 0)
            //    {
            //        if (vgListaRutas[e.RowIndex].cRuta != null || vgListaRutas[e.RowIndex].nid != string.Empty)
            //        {
            //            ControlesEdicion();
            //            tbxRuta.Text = vgListaRutas[e.RowIndex].cRuta;

            //            vgClaseRuta.nid = vgListaRutas[e.RowIndex].nid;
            //            vgClaseRuta.cRuta = vgListaRutas[e.RowIndex].cRuta;
            //            vgClaseRuta.nTipoRuta = vgListaRutas[e.RowIndex].nTipoRuta;
            //        }
            //    }
            //    /* ELIMINAR */
            //    if (e.ColumnIndex == 1 && e.RowIndex >= 0)
            //    {
            //        try
            //        {
            //            if (vgListaRutas[e.RowIndex].cRuta != null || vgListaRutas[e.RowIndex].nid != string.Empty)
            //            {
            //                vgClaseRuta.nid = vgListaRutas[e.RowIndex].nid;
            //                vgClaseRuta.cRuta = vgListaRutas[e.RowIndex].cRuta;
            //                vgClaseRuta.nTipoRuta = vgListaRutas[e.RowIndex].nTipoRuta;
            //            }

            //            if (MessageBox.Show("Eliminar una ruta puede desconfigurar el BIM MANAGER ¿Desea Eliminarla?", "Eliminar Ruta", MessageBoxButtons.YesNo, MessageBoxIcon.Hand) == DialogResult.Yes)
            //            {
            //                /* aprobacion de eliminacion */
            //                frmAprobacion oAprobacion = new frmAprobacion();
            //                if (oAprobacion.ShowDialog() == DialogResult.OK)
            //                {
            //                    vgConfiguracion = new cConfiguracion();
            //                    vgResultado = new cResultado();

            //                    vgResultado = vgConfiguracion.Eliminar_Ruta(cConverciones.ConvertirAEntero(vgClaseRuta.nid, 0));
            //                    Mostrar_Mensaje(vgResultado.Mensaje, vgResultado.Estado);
            //                    if (vgResultado.Estado > 0)
            //                    {
            //                        ControlesDefecto();
            //                    }
            //                }
            //            }
            //        }
            //        catch (Exception ex)
            //        {
            //            Mostrar_Mensaje(ex.Message, 3);
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Mostrar_Mensaje(ex.Message, 2);
            //}
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frm_RegistroRutas()
        {
            frmRuta oRuta = new frmRuta();
            if (oRuta.ShowDialog() == DialogResult.OK)
            {
                ControlesDefecto();
                Mostrar_Mensaje("Se registro la RUTA correctamente", 0);
                listarRutas();
            }
        }

        private void dgvListaRutas_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.N)
            {
                frm_RegistroRutas();
            }
        }

        private void frmConfiguracion_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.N)
            {
                frm_RegistroRutas();
            }
        }
    }
}