﻿namespace miBIM.Forms
{
    partial class frmDetalleCargaArchivos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.laTitulo = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSalir = new System.Windows.Forms.Button();
            this.paFooter = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBoxDetalleCargaArchivos = new System.Windows.Forms.GroupBox();
            this.cBTipoCarga = new System.Windows.Forms.ComboBox();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.dtpFechaCarga = new System.Windows.Forms.DateTimePicker();
            this.dgvListaCarga = new System.Windows.Forms.DataGridView();
            this.lbMensaje = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.paFooter.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBoxDetalleCargaArchivos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaCarga)).BeginInit();
            this.SuspendLayout();
            // 
            // laTitulo
            // 
            this.laTitulo.AutoSize = true;
            this.laTitulo.BackColor = System.Drawing.Color.YellowGreen;
            this.laTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laTitulo.ForeColor = System.Drawing.SystemColors.Control;
            this.laTitulo.Location = new System.Drawing.Point(219, 18);
            this.laTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laTitulo.Name = "laTitulo";
            this.laTitulo.Size = new System.Drawing.Size(378, 26);
            this.laTitulo.TabIndex = 0;
            this.laTitulo.Text = "DETALLE CARGA DE ARCHIVOS";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.laTitulo);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(810, 65);
            this.panel1.TabIndex = 11;
            // 
            // btnSalir
            // 
            this.btnSalir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSalir.Location = new System.Drawing.Point(318, 41);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(180, 32);
            this.btnSalir.TabIndex = 12;
            this.btnSalir.Text = "&Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // paFooter
            // 
            this.paFooter.BackColor = System.Drawing.SystemColors.ControlLight;
            this.paFooter.Controls.Add(this.lbMensaje);
            this.paFooter.Controls.Add(this.btnSalir);
            this.paFooter.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.paFooter.Location = new System.Drawing.Point(0, 522);
            this.paFooter.Name = "paFooter";
            this.paFooter.Size = new System.Drawing.Size(810, 85);
            this.paFooter.TabIndex = 14;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBoxDetalleCargaArchivos);
            this.panel2.Controls.Add(this.dgvListaCarga);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 65);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(810, 457);
            this.panel2.TabIndex = 15;
            // 
            // groupBoxDetalleCargaArchivos
            // 
            this.groupBoxDetalleCargaArchivos.Controls.Add(this.cBTipoCarga);
            this.groupBoxDetalleCargaArchivos.Controls.Add(this.btnBuscar);
            this.groupBoxDetalleCargaArchivos.Controls.Add(this.dtpFechaCarga);
            this.groupBoxDetalleCargaArchivos.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxDetalleCargaArchivos.Location = new System.Drawing.Point(0, 0);
            this.groupBoxDetalleCargaArchivos.Name = "groupBoxDetalleCargaArchivos";
            this.groupBoxDetalleCargaArchivos.Size = new System.Drawing.Size(810, 70);
            this.groupBoxDetalleCargaArchivos.TabIndex = 13;
            this.groupBoxDetalleCargaArchivos.TabStop = false;
            this.groupBoxDetalleCargaArchivos.Text = "Ingresar Datos";
            // 
            // cBTipoCarga
            // 
            this.cBTipoCarga.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBTipoCarga.FormattingEnabled = true;
            this.cBTipoCarga.Items.AddRange(new object[] {
            "Por nombre (Fecha) archivo",
            "Por fecha sistema",
            "Por fecha real"});
            this.cBTipoCarga.Location = new System.Drawing.Point(110, 32);
            this.cBTipoCarga.Name = "cBTipoCarga";
            this.cBTipoCarga.Size = new System.Drawing.Size(261, 23);
            this.cBTipoCarga.TabIndex = 13;
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(576, 29);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(84, 29);
            this.btnBuscar.TabIndex = 12;
            this.btnBuscar.Text = "&Buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // dtpFechaCarga
            // 
            this.dtpFechaCarga.Checked = false;
            this.dtpFechaCarga.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFechaCarga.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaCarga.Location = new System.Drawing.Point(399, 32);
            this.dtpFechaCarga.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.dtpFechaCarga.Name = "dtpFechaCarga";
            this.dtpFechaCarga.Size = new System.Drawing.Size(147, 23);
            this.dtpFechaCarga.TabIndex = 0;
            // 
            // dgvListaCarga
            // 
            this.dgvListaCarga.AllowUserToAddRows = false;
            this.dgvListaCarga.AllowUserToDeleteRows = false;
            this.dgvListaCarga.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvListaCarga.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaCarga.Location = new System.Drawing.Point(16, 76);
            this.dgvListaCarga.Name = "dgvListaCarga";
            this.dgvListaCarga.ReadOnly = true;
            this.dgvListaCarga.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListaCarga.Size = new System.Drawing.Size(782, 360);
            this.dgvListaCarga.TabIndex = 1;
            // 
            // lbMensaje
            // 
            this.lbMensaje.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbMensaje.AutoSize = true;
            this.lbMensaje.ForeColor = System.Drawing.Color.Red;
            this.lbMensaje.Location = new System.Drawing.Point(27, 14);
            this.lbMensaje.Name = "lbMensaje";
            this.lbMensaje.Size = new System.Drawing.Size(16, 15);
            this.lbMensaje.TabIndex = 13;
            this.lbMensaje.Text = "...";
            // 
            // frmDetalleCargaArchivos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(810, 607);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.paFooter);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "frmDetalleCargaArchivos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Detalle Carga de Archivos";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.paFooter.ResumeLayout(false);
            this.paFooter.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBoxDetalleCargaArchivos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaCarga)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label laTitulo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Panel paFooter;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dgvListaCarga;
        private System.Windows.Forms.DateTimePicker dtpFechaCarga;
        private System.Windows.Forms.GroupBox groupBoxDetalleCargaArchivos;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.ComboBox cBTipoCarga;
        private System.Windows.Forms.Label lbMensaje;
    }
}