﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
using System.IO;
using System.Collections; //UQMA 17/10/2017
using static CapaNegocio.cArchivoReporte;
using static CapaNegocio.cConfiguracion;
using System.Net.Mail;
using System.Net;
using System.Text.RegularExpressions;

namespace miBIM.Forms
{
    public partial class frmImportarArchivos : Form
    {
        public String cUser = Environment.UserName.ToString().ToUpper();
        public String cAgencia = "01";
        public DateTime dFechaSistema = DateTime.Now;

        public ArrayList aArchDepComp_FechTransac = new ArrayList();  //UQMA 17/10/2017 Almacena las fechas de INICIO de los archivos Netting

        /* CLASE PARA RECUPERAR RUTAS */
        cConfiguracion vgConfiguracion = new cConfiguracion();
        /* LISTA DE RUTAS Y CONFIGURACIONES DE ARCHIVOS */
        List<cConfiguracionSistema> vgListaRutasConfiguracion = new List<cConfiguracionSistema>();
        /* CLASE DE MANEJO DE EXSISTENCIA DE ARCHIVOS */
        List<cCargaArchivos> vgListaArchivosCarga = new List<cCargaArchivos>();
        /* CLASE DE MANEJO DE ARCHIVOS */
        cArchivoReporte vgArchivoReporte = new cArchivoReporte();        
        /* rutas de carga de archivos */
        cConstante vgConstante = new cConstante();
        /* variable de resultados de operaciones */
        cResultado vgResultado = new cResultado();
        /*  */
        cArchivoReporte vgArchivoReportes = new cArchivoReporte();

        public frmImportarArchivos()
        {
            InitializeComponent();

            CargarYMostrar_Rutas(); /* Inicializa y muestra las rutas de los archivos */
            ListarRutas();

            listarRutasDetalle(); /* CARGAR RUTAS DE PRODUCCION */
            CargaDatosMostrarArchivos(); /* RECUPERAR DATOS DE ARCHIVOS POR CARGAS */
        }

        /* INICIO */
        private void CargarYMostrar_Rutas()
        {
            lblRutaROrigen.Text = vgConstante.cpRutaOrigen;
            lblRutaRDestino.Text = vgConstante.cpRutaDestino;

            lblRutaIOrigen.Text = vgConstante.cpRutaOrigenEricKson;
            lblRutaIDestino.Text = vgConstante.cpRutaDestinoErickson;
        }
        /* FIN */

        /* INICIO */
        private void listarRutasDetalle()
        {
            try
            {                
                vgListaRutasConfiguracion = vgConstante.vgListaRutasConfiguracion;
                dgvListaRutas.DataSource = vgListaRutasConfiguracion;
                if (vgListaRutasConfiguracion.Count > 0)
                {
                    foreach (DataGridViewColumn dgvColumna in dgvListaRutas.Columns)
                    {
                        //if (new int[] { 5, 6, 7 }.Contains(dgvColumna.Index))
                        //{
                        //    dgvColumna.Visible = false;
                        //}
                    }
                }

                Mostrar_Mensaje(vgResultado.Mensaje, vgResultado.Estado);
            }
            catch (Exception ex)
            {
                Mostrar_Mensaje(vgResultado.Mensaje + "-" + ex.Message, vgResultado.Estado);
            }
        }
        /* FIN */

        /* INICIO */
        private void Mostrar_Mensaje(string _Mensaje, int _Tipo)
        {
            switch (_Tipo)
            {
                case 1:
                    lbMensaje.ForeColor = System.Drawing.Color.Blue;
                    lbMensaje.Text = _Mensaje;
                    break;

                case 2:
                    lbMensaje.ForeColor = System.Drawing.Color.OrangeRed;
                    lbMensaje.Text = "ADVERTENCIA:" + _Mensaje;
                    break;

                case 3:
                    lbMensaje.ForeColor = System.Drawing.Color.Red;
                    lbMensaje.Text = "ERROR:" + _Mensaje;
                    break;

                default:
                    lbMensaje.ForeColor = System.Drawing.Color.Green;
                    lbMensaje.Text = _Mensaje;
                    break;
            }
        }
        /*  FIN */

        /* INICIO */
        private void CargarArchivosXRuta(string _Ruta)
        {
            try
            {
                vgListaArchivosCarga = new List<cCargaArchivos>();
                DirectoryInfo vDirectorio = new DirectoryInfo(_Ruta);
                FileInfo[] vArchivos = vDirectorio.GetFiles();

                foreach (FileInfo vArchivo in vArchivos)
                {
                    if (EsArchivoPermitido(vArchivo.Name))
                    {
                        vgListaArchivosCarga.Add(new cCargaArchivos(false, Environment.UserName.ToUpper(), vArchivo.Name, 0, vArchivo.Extension, DateTime.Now, vArchivo.FullName));
                    }
                }
            }
            catch (Exception ex)
            {
                Mostrar_Mensaje(ex.Message, 3);
            }
        }
        /* FIN */

        /* INICIO */
        private void ListarRutas()
        {
            List<cCombo> vgListaRutas = new List<cCombo>();

            foreach (var item in vgConstante.vgListaRutasConfiguracion)
            {
                vgListaRutas.Add(new cCombo(item.cTag, item.cTag));
            }

            cbRutaArchivos.DisplayMember = "Valor";
            cbRutaArchivos.ValueMember = "Codigo";
            cbRutaArchivos.DataSource = vgListaRutas.ToList();
        }

        private void ListarExtencionesDeArchivosxRuta()
        {
            List<cCombo> vgListaExtenciones = new List<cCombo>();
            /* Agupacion de extenciones - LAMBDA */
            //var vListaExtenciones = vgListaArchivosCarga.GroupBy(item => item.ArchivoNuevoExtencion).Select(columna => new { ArchivoNuevoExtenciones = columna.Key });
            /* Agrupacion de Extenciones - LINQ */
            var vListaExtenciones = from Archivo in vgListaArchivosCarga group Archivo by Archivo.ArchivoNuevoExtencion;

            vgListaExtenciones.Add(new cCombo("Defecto", "Lista por Defecto"));
            vgListaExtenciones.Add(new cCombo("Todos", "Listar todos los archivos"));

            foreach (var item in vListaExtenciones)
            {
                vgListaExtenciones.Add(new cCombo(item.Key, item.Key));
            }

            cbExtencionArchivos.DisplayMember = "Valor";
            cbExtencionArchivos.ValueMember = "Codigo";
            cbExtencionArchivos.DataSource = vgListaExtenciones.ToList();
        }
        /* FIN */

        /* INICIO */
        private void ListarArchivosXRuta(string _Filtro)
        {
            try
            {
                switch (_Filtro)
                {
                    case "Defecto":
                        dgvListaCargaArchivos.DataSource = vgListaArchivosCarga.Where(item => !item.ArchivoNuevoExtencion.Contains(".signature")
                                                            && !item.ArchivoNuevoExtencion.Contains(".pdf")).ToList();
                        break;
                    case "Todos":
                        dgvListaCargaArchivos.DataSource = vgListaArchivosCarga.ToList();
                        break;
                    default:
                        dgvListaCargaArchivos.DataSource = vgListaArchivosCarga.Where(item => item.ArchivoNuevoExtencion.Contains(_Filtro)).ToList();
                        return;
                }

                Mostrar_Mensaje(vgListaArchivosCarga.Count().ToString() + " archivos ubicados.", 1);

                int vNroValidacionArchivosCorrectos = 0;
                int vNroValidacionArchivosIncoorrectos = 0;


                foreach (var item in vgListaArchivosCarga)
                {
                    /* NUEVA INSTANACIA A CLASE PARA CONSULTA DE EXITENCIA DE ARCHIVO */
                    vgArchivoReporte = new cArchivoReporte();

                    var vResultado = vgArchivoReporte.Reporte_VerificacionArchivo(item.ArchivoNuevo);

                    if (vResultado.Estado == 0 || vResultado.Estado == 1)
                    {
                        var vDetalle = cTransformador.ConvertirDataTableAClase<cDataArchivosProcesados>(vResultado.Datos);
                        if (vDetalle.First().nIdLogArchivos != "0")
                        {
                            item.Existe = true;
                            item.Usuario = vDetalle.First().cUSer;
                            item.NroCargas = vDetalle.Count;
                            item.FechaCarga = cConverciones.ConvertirAFecha(vDetalle.First().dFechaReal, DateTime.Now);
                            vNroValidacionArchivosCorrectos++;
                        }
                        else
                        {
                            vNroValidacionArchivosIncoorrectos++;
                        }
                    }
                    else
                    {
                        vNroValidacionArchivosIncoorrectos++;
                        Mostrar_Mensaje(vNroValidacionArchivosIncoorrectos.ToString() + "Archivos Observados - " + vResultado.Mensaje, vResultado.Estado);
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                Mostrar_Mensaje(ex.Message, 3);
            }
        }
        /* FIN */

        /* INICIO */
        private void CargaDatosMostrarArchivos()
        {
            try
            {
                if (vgConstante.cpRutaOrigen != "")
                {
                    CargarArchivosXRuta(vgConstante.cpRutaOrigen);

                    ListarExtencionesDeArchivosxRuta();
                }
                else
                {
                    Mostrar_Mensaje("Carpéta sin archivos para cargar", 2);
                }
                Mostrar_Mensaje("(2)" + "Lista cargada", 1);
            }
            catch (Exception ex)
            {
                Mostrar_Mensaje(ex.Message, 3);
            }
        }
        /* FIN */

        /* INICIO */
        private void cbExtencionArchivos_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cbExtencionArchivos.SelectedValue != null)
            {
                ListarArchivosXRuta(cbExtencionArchivos.SelectedValue.ToString());
                CambiarColorArchivosCargados();
            }
        }

        private void cbRutaArchivos_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cbRutaArchivos.SelectedValue != null)
            {
                switch (cbRutaArchivos.SelectedValue.ToString())
                {
                    case "REPORTES":
                        CargarArchivosXRuta(vgConstante.cpRutaOrigen);
                        cbExtencionArchivos_SelectedValueChanged(null, null);
                        break;
                    case "INCOMING":
                        CargarArchivosXRuta(vgConstante.cpRutaOrigenEricKson);
                        cbExtencionArchivos_SelectedValueChanged(null, null);
                        break;
                    default:
                        CargarArchivosXRuta(vgConstante.cpRutaOrigen);
                        cbExtencionArchivos_SelectedValueChanged(null, null);
                        return;
                }                
            }
        }
        /* FIN */

        /* INICIO */
        private void CambiarColorArchivosCargados()
        {
            foreach (DataGridViewRow dgvFila in dgvListaCargaArchivos.Rows)
            {
                foreach (var item in vgListaArchivosCarga)
                {
                    if (dgvFila.Cells[2].Value.ToString() == item.ArchivoNuevo)
                    {
                        if (item.Existe)
                        {
                            dgvFila.DefaultCellStyle.ForeColor = System.Drawing.Color.DarkOrange;
                            //dgvFila.DefaultCellStyle.BackColor = System.Drawing.Color.LightGray;
                        }
                        else
                        {
                            dgvFila.DefaultCellStyle.ForeColor = System.Drawing.Color.DarkGreen;
                            //dgvFila.DefaultCellStyle.BackColor = System.Drawing.Color.LightGray;
                        }
                    }
                }
            }
        }
        /* FIN */

        /* INICIO - HSPC */
        private async Task CargarArchivos()
        {
            // CREAR LISTA DE CARGA DE ARCHIVOS ASINCRONOS
            List<Task<cCargaArchivosInfo>> vProcesosCargaArchivos = new List<Task<cCargaArchivosInfo>>();

            //pbImportar.Maximum = vgListaArchivosCarga.Where(item => !item.ArchivoNuevoExtencion.Contains(".signature")
            //&& !item.ArchivoNuevoExtencion.Contains(".pdf")).ToList().Count();
            pbImportar.Maximum = vgListaArchivosCarga.Count();

            int NroArchivoCargado = 1;

            // SE ITERA EN LA LISTA DE 
            foreach (cCargaArchivos vArchivo in vgListaArchivosCarga)
            {
                pbImportar.Value = NroArchivoCargado;
                if (EsArchivoPermitido(vArchivo.ArchivoRuta))
                {
                    vProcesosCargaArchivos.Add(LeerArchivoAsync(true, vArchivo.ArchivoRuta, vArchivo.ArchivoNuevo));
                }
                else
                {
                    vProcesosCargaArchivos.Add(LeerArchivoAsync(false, vArchivo.ArchivoRuta, vArchivo.ArchivoNuevo));
                }
                NroArchivoCargado++;
            }

            //Esperar a que todas las tareas se completen
            await Task.WhenAll(vProcesosCargaArchivos);

            //Imprimir los datos
            foreach (Task<cCargaArchivosInfo> vProceso in vProcesosCargaArchivos)
            {
                cCargaArchivosInfo vDatosProceso = await vProceso;

                lbImportados.Items.Add($"{cTransformaciones.TransformarBool(vDatosProceso.EstadoCarga, "OK", "Observado")} : {vDatosProceso.NombreArchivo}, Nro Registros: {vDatosProceso.NroRegistros}, Tiempo carga : {(vDatosProceso.Fechainicio - vDatosProceso.FechaFin).TotalSeconds.ToString("0.00") }");
            }

            Mostrar_Mensaje("Reportes importados, el proceso culmino en: " + DateTime.Now.ToString(), 0);
        }

        static bool EsArchivoPermitido(string _Ruta)
        {
            string vExtencionPermitida = Path.GetExtension(_Ruta).ToLower();
            return vExtencionPermitida == ".csv" || vExtencionPermitida == ".txt";
        }

        static void EnviarCorreo(List<cCargaArchivosInfo> datosList)
        {
            string destinatario = "correo@ejemplo.com";  // Reemplaza con la dirección de correo electrónico de destino
            string asunto = "Detalle de la carga de archivos";

            using (MailMessage mensaje = new MailMessage("tucorreo@ejemplo.com", destinatario, asunto, ConstruirCuerpoCorreo(datosList)))
            {
                using (SmtpClient clienteSmtp = new SmtpClient("smtp.tuempresa.com"))
                {
                    clienteSmtp.Credentials = new NetworkCredential("tucorreo@ejemplo.com", "tucontraseña");
                    clienteSmtp.Port = 587;
                    clienteSmtp.EnableSsl = true;

                    try
                    {
                        clienteSmtp.Send(mensaje);
                        Console.WriteLine("Correo electrónico enviado con éxito.");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error al enviar el correo electrónico: {ex.Message}");
                    }
                }
            }
        }

        static string ConstruirCuerpoCorreo(List<cCargaArchivosInfo> datosList)
        {
            // Construir el cuerpo del correo con la información de los datos
            // Puedes personalizar el formato según tus necesidades
            string cuerpoCorreo = "Detalles de la carga de archivos:\n\n";
             
            //foreach (Datos datos in datosList)
            //{
            //    cuerpoCorreo += $"DIA: {datos.Dia}, MES: {datos.Mes}, AÑO: {datos.Anno}, NUMERO DOCUMENTO: {datos.NumeroDocumento}, NUMERO REGISTROS: {datos.NumeroRegistros}, FORMATO: {datos.Formato}, CLAVE: {datos.Clave}\n";
            //}

            return cuerpoCorreo;
        }        

        private async Task<cCargaArchivosInfo> LeerArchivoAsync(bool _Cargar, string _Ruta, string _NombreArchivo)
        {
            cCargaArchivosInfo vListaArchivosCargados = new cCargaArchivosInfo();

            vgArchivoReportes = new cArchivoReporte();
            DateTime vFechaCargaInicio = DateTime.Now;

            if (_Cargar)
            {
                int NroArchivoCargado = 1;
                
                // Leer el archivo y asignar valores a la clase
                using (StreamReader vLector = new StreamReader(_Ruta))
                {
                    string vLinea;

                    while ((vLinea = await vLector.ReadLineAsync()) != null)
                    {
                        switch (IdentificarArchivoReportes(_NombreArchivo))
                        {
                            case "NETTING":
                                vgArchivoReportes.Insertar_Netting(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "LOGUSR":
                                vgArchivoReportes.Insertar_LogUser(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "TR":
                                vgArchivoReportes.Insertar_LogTransacciones(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "USRACCOUNTBALANCE":
                                vgArchivoReportes.Insertar_BalanceCuentas(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "COMISIONES":
                                vgArchivoReportes.Insertar_Comisiones(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "INTEROPE":
                                vgArchivoReportes.Insertar_Interoperabilidad(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "FEEDET":
                                vgArchivoReportes.Insertar_Fee(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "INF-COMERCIAL":
                                vgArchivoReportes.Insertar_InformacionComercial(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "REPORTE32A":
                                //vgArchivoReportes.Insertar_Reporte32A(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "REPORTE32B-I":
                                //vgArchivoReportes.Insertar_Reporte32B_I(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "REPORTE32B-II":
                                //vgArchivoReportes.Insertar_Reporte32B_II(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "REPORTE32B-III":
                                //vgArchivoReportes.Insertar_Reporte32B_III(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "REPORTE32B-IV":
                                //vgArchivoReportes.Insertar_Reporte32B_IV(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "REPORTE32B-V":
                                //vgArchivoReportes.Insertar_Reporte32B_V(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "DEPOSITOS":
                                //vgArchivoReportes.Insertar_Depositos(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "ROANEXO1":
                                //MessageBox.Show(caseSwitch + ": " + vLinea);
                            case "ROANEXO2":
                                //MessageBox.Show(caseSwitch + ": " + vLinea);
                            case "OBSERVADO":
                                vListaArchivosCargados = new cCargaArchivosInfo(false, "Archivo No considerado", Environment.UserName.ToUpper(), _NombreArchivo, vFechaCargaInicio, DateTime.Now, "0");
                                break;
                        }
                        NroArchivoCargado++;                        
                    }
                    vListaArchivosCargados = new cCargaArchivosInfo(true, "Archivo Cargado", Environment.UserName.ToUpper(), _NombreArchivo, vFechaCargaInicio, DateTime.Now, NroArchivoCargado.ToString());
                }
            }
            else
            {
                vListaArchivosCargados = new cCargaArchivosInfo(false, "Archivo No considerado", Environment.UserName.ToUpper(), _NombreArchivo, vFechaCargaInicio, DateTime.Now, "0");
            }

            return vListaArchivosCargados;
        }

        /* Metodo 1 para diferenciar extenciones */
        public string CoincidirExtenciones(string nombreArchivo)
        {
            // Patrón REGEX para la fecha
            string patronFecha = @"^\d{6}(\.\d{3})?-\S*$";

            // Patrón REGEX para la extensión
            string patronExtension = @"(\.\w+)$";

            // Extrae el nombre del archivo
            Match matchFecha = Regex.Match(nombreArchivo, patronFecha);
            if (matchFecha.Success)
            {
                string nombre = matchFecha.Groups[0].Value;

                // Extrae la extensión
                Match matchExtension = Regex.Match(nombre, patronExtension);
                if (matchExtension.Success)
                {
                    nombre = nombre.Substring(0, matchExtension.Index);
                }

                return nombre;
            }
            else
            {
                return nombreArchivo;
            }
        }

        /* Metodo 1 para obetener nombres de  archivos */
        public string QuitarFechasYExtensiones(string nombreArchivo)
        {
            // Encuentra el primer carácter no numérico después de la fecha
            int indiceFecha = nombreArchivo.IndexOfAny(new char[] { '.', '-' });
            if (indiceFecha != -1)
            {
                indiceFecha++; // Avanzamos un carácter para evitar el separador "."
            }

            // Encuentra la siguiente ocurrencia del carácter "."
            int indiceExtension = nombreArchivo.IndexOf(".");

            // Determina el índice de corte
            int indiceCorte = Math.Min(indiceFecha != -1 ? indiceFecha : int.MaxValue,
                                       indiceExtension != -1 ? indiceExtension : int.MaxValue);

            // Devuelve la parte del nombre de archivo antes de la fecha o la extensión
            if (indiceCorte != int.MaxValue)
            {
                return nombreArchivo.Substring(0, indiceCorte);
            }
            else
            {
                // Devuelve el nombre de archivo original si no se encuentra ninguna fecha o extensión
                return nombreArchivo;
            }
        }

        /* Metodo 2 para obetener nombres de  archivos */
        public string QuitarFechasYExtensiones2(string nombreArchivo)
        {
            // Encuentra el primer carácter no válido
            int indiceNoValido = nombreArchivo.IndexOfAny(new char[] { '.', '-' });

            // Si no hay caracteres no válidos, devuelve el nombre de archivo original
            if (indiceNoValido == -1)
            {
                return nombreArchivo;
            }

            // Encuentra la posición de la fecha o extension
            switch (nombreArchivo[indiceNoValido])
            {
                case '.':
                    return nombreArchivo.Substring(0, indiceNoValido);
                case '-':
                    return nombreArchivo.Substring(0, indiceNoValido - 4);
                default:
                    throw new ArgumentException("El nombre de archivo contiene caracteres no válidos.");
            }
        }

        public string IdentificarArchivoReportes(string _NombreArchivo)
        {
            // Primero, comprueba si la longitud del nombre del archivo es suficiente para las posibles coincidencias.
            if (_NombreArchivo.Length >= 8)
            {
                // Crea un diccionario para almacenar las posibles coincidencias y sus nombres correspondientes.
                var posiblesCoincidencias = new Dictionary<string, string>()
                    {
                        {"NETTING", "NETTING"},
                        {"USRACCOUNTBALANCE", "USRACCOUNTBALANCE"},
                        {"LOGUSR", "LOGUSR"},
                        {"TR", "TR"},
                        {"DEPOSITOS", "DEPOSITOS"},
                        {"RETIROS", "RETIROS"},
                        {"COMISIONES", "COMISIONES"},
                        {"INTEROPE", "INTEROPE"},
                        {"FEEDET", "FEEDET"},
                        {"INF-COMERCIAL", "INF-COMERCIAL"},
                        {"PAY", "PAY"},
                        {"REPORTE32A", "REPORTE32A"},
                        {"REPORTE32B-III", "REPORTE32B-III"},
                        {"REPORTE32B-II", "REPORTE32B-II"},
                        {"REPORTE32B-IV", "REPORTE32B-IV"},
                        {"REPORTE32B-I", "REPORTE32B-I"},
                        {"REPORTE32B-V", "REPORTE32B-V"},
                        {"307", "307"}
                    };

                // Intenta encontrar una coincidencia en el diccionario de nombre de archivos.
                string nombreCorrespondiente;
                if (posiblesCoincidencias.TryGetValue(_NombreArchivo.ToUpper().Substring(0, 8), out nombreCorrespondiente))
                {
                    return nombreCorrespondiente.ToUpper();
                }

                /* Validar Reporte de operaciones DINERO ELECTRONICO,APLIACION MOVIL O BANCA POR INTERNET */
                string vReporteOperacionesSBS = QuitarFechasYExtensiones(_NombreArchivo);

                if (vReporteOperacionesSBS.Length <= 10)
                {
                    if (vReporteOperacionesSBS.Substring(0, 2) == "01")
                    {
                        return "ROANEXO1";
                    }
                    if (vReporteOperacionesSBS.Substring(0, 2) == "02")
                    {
                        return "ROANEXO2";
                    }
                }

                // Si no se encuentra ninguna coincidencia en los primeros 8 caracteres, comprueba si hay coincidencias con longitudes específicas.
                    foreach (var coincidencia in posiblesCoincidencias)
                {
                    if (_NombreArchivo.ToUpper().StartsWith(coincidencia.Key))
                    {
                        return coincidencia.Value.ToUpper();
                    }
                }
            }

            // Si no se encuentra ninguna coincidencia, devuelve una cadena vacía.
            return "OBSERVADO";
        }

        public string IdentificarArchivoIntrucciones(string _NombreArchivo)
        {
            // Primero, comprueba si la longitud del nombre del archivo es suficiente para las posibles coincidencias.
            if (_NombreArchivo.Length >= 8)
            {
                // Crea un diccionario para almacenar las posibles coincidencias y sus nombres correspondientes.
                var posiblesCoincidencias = new Dictionary<string, string>()
                    {
                        {"NETTING", "NETTING"},
                        {"USRACCOUNTBALANCE", "USRACCOUNTBALANCE"},
                        {"LOGUSR", "LOGUSR"},
                        {"TR", "TR"},
                        {"DEPOSITOS", "DEPOSITOS"},
                        {"RETIROS", "RETIROS"},
                        {"COMISIONES", "COMISIONES"},
                        {"INTEROPE", "INTEROPE"},
                        {"FEEDET", "FEEDET"},
                        {"INF-COMERCIAL", "INF-COMERCIAL"},
                        {"PAY", "PAY"},
                        {"REPORTE32A", "REPORTE32A"},
                        {"REPORTE32B-III", "REPORTE32B-III"},
                        {"REPORTE32B-II", "REPORTE32B-II"},
                        {"REPORTE32B-IV", "REPORTE32B-IV"},
                        {"REPORTE32B-I", "REPORTE32B-I"},
                        {"REPORTE32B-V", "REPORTE32B-V"},
                        {"307", "307"}
                    };

                // Intenta encontrar una coincidencia en el diccionario de nombre de archivos.
                string nombreCorrespondiente;
                if (posiblesCoincidencias.TryGetValue(_NombreArchivo.ToUpper().Substring(0, 8), out nombreCorrespondiente))
                {
                    return nombreCorrespondiente.ToUpper();
                }

                /* Validar Reporte de operaciones DINERO ELECTRONICO,APLIACION MOVIL O BANCA POR INTERNET */
                string vReporteOperacionesSBS = QuitarFechasYExtensiones(_NombreArchivo);

                if (vReporteOperacionesSBS.Length <= 10)
                {
                    if (vReporteOperacionesSBS.Substring(0, 2) == "01")
                    {
                        return "ROANEXO1";
                    }
                    if (vReporteOperacionesSBS.Substring(0, 2) == "02")
                    {
                        return "ROANEXO2";
                    }
                }

                // Si no se encuentra ninguna coincidencia en los primeros 8 caracteres, comprueba si hay coincidencias con longitudes específicas.
                foreach (var coincidencia in posiblesCoincidencias)
                {
                    if (_NombreArchivo.ToUpper().StartsWith(coincidencia.Key))
                    {
                        return coincidencia.Value.ToUpper();
                    }
                }
            }

            // Si no se encuentra ninguna coincidencia, devuelve una cadena vacía.
            return "OBSERVADO";
        }

        /* FIN - FIN */








        //private void btnImportar_Click(object sender, EventArgs e)
        private async void btnImportar_Click(object sender, EventArgs e)
        {            
            LimpiarControles();

            Mostrar_Mensaje("Validando Archivos (Reportes)...", 1); /*  */

            //MessageBox.Show(IdentificarArchivo("0120230922.307-CCUSCO.txt.signature"));
            //MessageBox.Show(IdentificarArchivo("0220230922.307-CCUSCO.txt.signature"));
            //MessageBox.Show(IdentificarArchivo("REPORTE32B-I-CCUSCO-202307.txt.signature"));
            //MessageBox.Show(IdentificarArchivo("REPORTE32B-II-CCUSCO-202307.txt.signature"));
            //MessageBox.Show(IdentificarArchivo("REPORTE32B-III-CCUSCO-202307.txt.signature"));
            //MessageBox.Show(IdentificarArchivo("REPORTE32B-IV-CCUSCO-202307.txt.signature"));
            //MessageBox.Show(IdentificarArchivo("REPORTE32B-V-CCUSCO-202307.txt.signature"));
            //MessageBox.Show(IdentificarArchivo("TRCCUSCO-20230703031805.csv.signature"));
            //MessageBox.Show(IdentificarArchivo("nettingCCUSCO-20230703001548.csv.signature"));

            //porgresbarReportes();               
            if (VerificarImporteReportes("Reportes")) //LVCH 03/04/2018 Verifica antes de importar que no haya archivos abiertos
                //ImportarReportes();

            await CargarArchivos();
        }







        private void LimpiarControles()
        {
            lbImportados.Items.Clear();
            laMensajeReportes.Text = "";
            lbImportados.Items.Clear();
        }

        private void LimpiarControlesInstrucciones()
        {
            lbInsImportados.Items.Clear();
            laMensajeInstrucciones.Text = "";
            lbInsImportados.Items.Clear();
        }

        private void ImportarInstrucciones()
        {
            cConstante C = new cConstante();
            //cNetting netting = new cNetting();
            //cLogUser loguser = new cLogUser();
            //cLogTransacciones logtran = new cLogTransacciones();
            //cBalanceCuenta saldoBilletera = new cBalanceCuenta();
            cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
            int nExisteArchivos;


            //Obtenmos variables generales
            //String cUser;
            //String cAgencia;
            //DateTime dFechaSistema;

            //cUser = Environment.UserName.ToString().ToUpper();
            //cAgencia = "01";
            //dFechaSistema = DateTime.Now;
            
            int nCantidadArchivos;
            int nLongitudCadena;
            nCantidadArchivos = 0;
            int nContador = 0;
            string line;
            nExisteArchivos = 1;//No existe archivos

            //string fileName = "test.txt";            
            string cRutaOrigen = C.cpRutaOrigenEricKson; //@"D:\PDP\PDPReportes\03-04-05-06-2016\";
            string cRutaDestino = C.cpRutaDestinoErickson;//@"D:\PDP\PDPReportes\03-04-05-06-2016\"+DateTime.Now.ToString("yyyyMMdd");

            string cArchivoDestino;
            string cArchivoOrigen;
            System.IO.StreamReader file;

            try
            {
                DirectoryInfo di = new DirectoryInfo(C.cpDirectoryInfoErickson);            //@"D:\PDP\PDPReportes\03-04-05-06-2016\"
                pbImportarInstrucciones.Minimum = 0;
                pbImportarInstrucciones.Maximum = di.GetFiles().Count();
                pbImportarInstrucciones.Step = 1;

                foreach (var fi in di.GetFiles())
                {
                    pbImportarInstrucciones.PerformStep();
                    nExisteArchivos = 0;// existen archivos
                    nLongitudCadena = fi.Name.Length;
                    //cArchivoOrigen = System.IO.Path.Combine(cRutaOrigen, fi.Name);
                    //cArchivoDestino = System.IO.Path.Combine(cRutaDestino, fi.Name);                                

                    //Determinar tipo de archivo
                    String caseSwitch = ObtenerNombre(fi.Name.ToString());
                    
                    cArchivoOrigen = System.IO.Path.Combine(cRutaOrigen, fi.Name);
                    cArchivoDestino = System.IO.Path.Combine(cRutaDestino, fi.Name);

                    //Procesamos los archivos no firmados
                    if (nLongitudCadena > 10)
                    {
                        if (fi.Name.Substring(fi.Name.Length - 10, 10) != ".signature")
                        {
                            //Leer archivo
                            file = new System.IO.StreamReader(cArchivoOrigen);

                            //file = new System.IO.StreamReader(@"D:\test.csv");
                            while ((line = file.ReadLine()) != null)
                            {
                                switch (caseSwitch)
                                {
                                    case "PAY"://ok                                        
                                        oInstruccion.Insertar_Pago(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);                                                                                                        
                                        break;
                                    default:
                                        MessageBox.Show("archivo no identificado","Alerta"); //UQMA Se cambio a Alerta
                                        return;                                        
                                }
                                nContador++;                                
                            }

                            
                            
                            nContador = 0; //Se limpia contador
                            file.Close();
                            //MessageBox.Show("Nombre Archivo Procesado : " + fi.Name.ToString());
                            lbInsImportados.Items.Add(fi.Name.ToString());
                            nCantidadArchivos = nCantidadArchivos + 1;
                        }
                    }

                    //Trasladamos archivos procesados 
                    if (!System.IO.Directory.Exists(cRutaDestino))
                    {
                        System.IO.Directory.CreateDirectory(cRutaDestino);
                    }
                    System.IO.File.Copy(cArchivoOrigen, cArchivoDestino, true);
                    System.IO.File.Delete(cArchivoOrigen);
                }
                //MessageBox.Show("Archivos Procesados : " + nCantidadArchivos.ToString());
                laMensajeInstrucciones.Text = nCantidadArchivos.ToString() + " Archivos Procesados";
                laMensajeInstrucciones.Visible = true;
                if (nExisteArchivos == 1)
                {
                    MessageBox.Show("No hay archivos para procesar", "Alerta"); //UQMA Se cambio a Alerta
                    pbImportarInstrucciones.Value = 0;                    
                    lbInsImportados.Items.Clear();
                }
                else                    
                    MessageBox.Show("Archivos Procesados correctamente!!", "Informacion");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.ToString());
            }
            
        }



        //private void btnImportarInstrucciones_Click(object sender, EventArgs e)
        private async void btnImportarInstrucciones_Click(object sender, EventArgs e)
        {            
            LimpiarControlesInstrucciones();

            Mostrar_Mensaje("Validando Archivos (Instrucciones)...", 1); /**/

            //porgresbarInstrucciones();    
            //if (VerificarImporteReportes("Archivos")) //04-04/2018 LVCH verifica archivos abiertos
                //ImportarInstrucciones();

            if (VerificarImporteReportes("Archivos"))
            {
                await Task.Run(() => ImportarInstrucciones());
            }
        }









        //UQMA 19/10/2017 para enviar correo
        private void EnviarCorreo()
        {
            try
            {
                cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
                if (aArchDepComp_FechTransac.Count > 0)
                {
                    //UQMA 17/10/2017 Obtiene las fechas de Transaccion de los archivos Netting
                    string fecha_inicial = aArchDepComp_FechTransac[0].ToString();
                    string fecha_final = aArchDepComp_FechTransac[0].ToString();
                    for (int i = 1; i < aArchDepComp_FechTransac.Count; i++)
                    {
                        if (fecha_final.CompareTo(aArchDepComp_FechTransac[i].ToString()) < 0)//>
                        {
                            fecha_final = aArchDepComp_FechTransac[i].ToString();
                        }
                        if (fecha_inicial.CompareTo(aArchDepComp_FechTransac[i].ToString()) > 0)//<
                        {
                            fecha_inicial = aArchDepComp_FechTransac[i].ToString();
                        }
                    }
                    oInstruccion.Buscar_y_EnviarCorreo(Convert.ToDateTime(fecha_inicial), Convert.ToDateTime(fecha_final));
                }
                else
                {
                    oInstruccion.EnviarCorreo("<br> <br> <b> NO HUBO PROCESOS DE ARCHIVOS PARA LA COMPENSACIÓN, COMUNIQUESE CON T.I. </b>");

                }
            }
            catch (Exception error)
            {
                MessageBox.Show("Error: " + error.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool VerificarImporteReportes(string tipo) //LVCH 03/04/2018 - Verifica archivos abiertos
        {
            bool respuesta = true;
            cConstante conecta = new cConstante();           
            if (tipo == "Reportes")
            {
                DirectoryInfo di = new DirectoryInfo(conecta.cpDirectoryInfo);
                foreach (var fi in di.GetFiles())
                {
                    try
                    {
                        FileStream verifica = File.OpenWrite(conecta.cpRutaOrigen + fi.Name);
                        verifica.Close();
                    }
                    catch
                    {
                        MessageBox.Show("El archivo: ''" + fi.Name + "'' Se encuentra abierto, ciérrelo para continuar.", "Importante!!!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        respuesta = false;
                    }
                }
            }
            else
            {
                DirectoryInfo di = new DirectoryInfo(conecta.cpDirectoryInfoErickson);
                foreach (var fi in di.GetFiles())
                {
                    try
                    {
                        FileStream verifica = File.OpenWrite(conecta.cpRutaOrigenEricKson + fi.Name);
                        verifica.Close();
                    }
                    catch
                    {
                        MessageBox.Show("El archivo: ''" + fi.Name + "'' Se encuentra abierto, ciérrelo para continuar.", "Importante!!!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        respuesta = false;
                    }
                }
            }           
            return respuesta;
        }

        private void ImportarReportes()
        {
            aArchDepComp_FechTransac = new ArrayList();  //UQMA 17/10/2017

            cConstante C = new cConstante();
            //cNetting netting = new cNetting();
            //cLogUser loguser = new cLogUser();
            //cLogTransacciones logtran = new cLogTransacciones();
            //cBalanceCuenta saldoBilletera = new cBalanceCuenta();
            cArchivoReporte oReportes = new cArchivoReporte();
            int nExisteArchivos;


            //Obtenmos variables generales
            cArchivoInstruccion oInstrucciones = new cArchivoInstruccion();
            String cUser;
            String cAgencia;
            DateTime dFechaSistema;

            dFechaSistema = oInstrucciones.Obtiene_FechaSistema();
                        
            cUser = Environment.UserName.ToString().ToUpper();
            cAgencia = "01";
            //dFechaSistema = DateTime.Now;
            

            int nCantidadArchivos;
            //int nLongitudCadena; //19/04/2018 LVCH variable que no se usa
            nCantidadArchivos = 0;
            int nContador = 0;
            string line;
            nExisteArchivos=1;//No existe archivos

            //string fileName = "test.txt";
            string cRutaOrigen = C.cpRutaOrigen; //@"D:\PDP\PDPReportes\03-04-05-06-2016\";
            string cRutaDestino = C.cpRutaDestino;//@"D:\PDP\PDPReportes\03-04-05-06-2016\"+DateTime.Now.ToString("yyyyMMdd");
            

            string cArchivoDestino;
            string cArchivoOrigen;
            System.IO.StreamReader file;

            try  // se descomenta para probar catch
            {
                DirectoryInfo di = new DirectoryInfo(C.cpDirectoryInfo);            //@"D:\PDP\PDPReportes\03-04-05-06-2016\"                

                pbImportar.Minimum = 0;
                pbImportar.Maximum = di.GetFiles().Count();
                pbImportar.Step = 1;
            
                foreach (var fi in di.GetFiles())
                {                    
                    pbImportar.PerformStep();
                    nExisteArchivos = 0;// existen archivos
                    //nLongitudCadena = fi.Name.Length; //19/04/2018 LVCH variable que no se usa
                    //cArchivoOrigen = System.IO.Path.Combine(cRutaOrigen, fi.Name);
                    //cArchivoDestino = System.IO.Path.Combine(cRutaDestino, fi.Name);                                

                    //Determinar tipo de archivo
                    String caseSwitch = ObtenerNombre(fi.Name.ToString());
                   
                    cArchivoOrigen = System.IO.Path.Combine(cRutaOrigen, fi.Name);
                    cArchivoDestino = System.IO.Path.Combine(cRutaDestino, fi.Name);
                   

                    //Procesamos los archivos no firmados
                    //if (nLongitudCadena > 7)
                    if (caseSwitch !="")
                    {
                        if(fi.Name.Substring(fi.Name.Length - 4, 4) != ".xls")
                        {
                            if (fi.Name.Substring(fi.Name.Length - 4, 4) != ".pdf")
                            {
                                if (fi.Name.Substring(fi.Name.Length - 10, 10) != ".signature")
                                {
                                    //if (fi.Name.Substring(fi.Name.Length - 4, 4) != ".txt")
                                    //{

                                    //Leer archivo
                        
                                    file = new System.IO.StreamReader(cArchivoOrigen);
                                               
                                    //file = new System.IO.StreamReader(@"D:\test.csv");
                                    while ((line = file.ReadLine()) != null)
                                    {
                                        switch (caseSwitch)
                                        {
                                            //Recomendacion, realizar validacion previa
                                            case "NETTING"://ok                                        
                                                oReportes.Insertar_Netting(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);

                                                //UQMA 17/10/2017 Almacenamos las fechas de transaccion
                                                if (nContador == 1)
                                                {
                                                    String[] cCampos = line.Split(new Char[] { ',' });
                                                    aArchDepComp_FechTransac.Add(cCampos[1].ToString());
                                                }

                                                break;
                                            case "LOGUSR"://ok                                        
                                                oReportes.Insertar_LogUser(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);
                                                break;
                                            case "TR"://ok                                        
                                                oReportes.Insertar_LogTransacciones(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);                                    
                                                break;
                                            case "USRACCOUNTBALANCE"://ok                                        
                                                oReportes.Insertar_BalanceCuentas(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);
                                                break;                                
                                            case "COMISIONES":
                                                oReportes.Insertar_Comisiones(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);
                                                break;
                                            case "INTEROPE"://ok
                                                oReportes.Insertar_Interoperabilidad(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);
                                                break;
                                            case "FEEDET"://ok
                                                oReportes.Insertar_Fee(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);
                                                break;                                
                                            case "INF-COMERCIAL"://ok
                                                oReportes.Insertar_InformacionComercial(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);
                                                break;
                                            //case "REPORTE32A"://ok
                                            //    oReportes.Insertar_Reporte32A(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);
                                            //    break;    
                                            //15/08/2017 UQMA Inicio Para procesar Reporte 32 A y B
                                            case "REPORTE32A":
                                                oReportes.Insertar_Reporte32A(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);
                                                break;
                                            case "REPORTE32B-I":
                                                oReportes.Insertar_Reporte32B_I(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);
                                                break;
                                            case "REPORTE32B-II":
                                                oReportes.Insertar_Reporte32B_II(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);
                                                break;
                                            case "REPORTE32B-III":
                                                oReportes.Insertar_Reporte32B_III(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);
                                                break;
                                            case "REPORTE32B-IV":
                                                oReportes.Insertar_Reporte32B_IV(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);
                                                break;
                                            case "REPORTE32B-V":
                                                oReportes.Insertar_Reporte32B_IV(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);
                                                break;
                                            //15/08/2017 UQMA Fin Para procesar Reporte 32 A y B
                                            case "DEPOSITOS"://Formato Excel
                                                oReportes.Insertar_Depositos(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);
                                                //MessageBox.Show(caseSwitch + ": " + line);
                                                break;
                                            case "RETIROS"://Formato Excel
                                                MessageBox.Show(caseSwitch + ": " + line);
                                                break;                            
                                        }
                                        nContador++;
                                    }
                                    nContador = 0; //Se limpia contador
                                    file.Close();
                                    //MessageBox.Show("Nombre Archivo Procesado : " + fi.Name.ToString());
                                    lbImportados.Items.Add(fi.Name.ToString());
                                    nCantidadArchivos = nCantidadArchivos + 1;
                                //}
                                }
                            }
                        }
                        else //UQMA 03/10/2017 para la importacion de DEPOSITOS Y RETIROS en formato excel
                        {
                            if (fi.Name.Substring(fi.Name.Length - 4, 4) == ".xls")
                            {
                                switch (caseSwitch)
                                {
                                    case "DEPOSITOS"://Formato Excel
                                    case "RETIROS"://Formato Excel
                                        Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
                                        excel.Application.Workbooks.Open(cArchivoOrigen);

                                        int EsDeposito;
                                        if (caseSwitch == "DEPOSITOS")
                                        {
                                            EsDeposito = 1;
                                        }
                                        else //RETIROS
                                        {
                                            EsDeposito = 0;
                                        }

                                        oReportes.Insertar_Compensacion(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), 0, "line", "", DateTime.Now, "", "", "", "", "", "", "", "", 0, EsDeposito);

                                        bool continuar_lectura = true;
                                        int fila = 2;
                                        while (continuar_lectura)
                                        {
                                            if (excel.Range["A" + fila + ":A" + fila].get_Value() != null)
                                            {
                                                if (excel.Range["A" + fila + ":A" + fila].get_Value() != "")
                                                {

                                                    oReportes.Insertar_Compensacion(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), 1, "line"
                                                   , excel.Range["A" + fila + ":A" + fila].get_Value()
                                                   , Convert.ToDateTime(excel.Range["B" + fila + ":B" + fila].get_Value())
                                                   , excel.Range["C" + fila + ":C" + fila].get_Value()
                                                   , excel.Range["D" + fila + ":D" + fila].get_Value()
                                                   , excel.Range["E" + fila + ":E" + fila].get_Value()
                                                   , excel.Range["F" + fila + ":F" + fila].get_Value()
                                                   , excel.Range["G" + fila + ":G" + fila].get_Value()
                                                   , excel.Range["H" + fila + ":H" + fila].get_Value()
                                                   , excel.Range["I" + fila + ":I" + fila].get_Value()
                                                   , excel.Range["J" + fila + ":J" + fila].get_Value()
                                                   , Double.Parse(excel.Range["K" + fila + ":K" + fila].get_Value())
                                                   , EsDeposito);
                                                    fila++;
                                                }
                                                else
                                                    continuar_lectura = false;
                                            }
                                            else
                                                continuar_lectura = false;

                                        }
                                        //GC.Collect(); //UQMA 20-10-2017
                                        //GC.WaitForPendingFinalizers(); //UQMA 20-10-2017
                                        //Marshal.ReleaseComObject(excel); //UQMA 20-10-2017
                                        excel.Application.Workbooks.Close();
                                        //excel.Quit();
                                        break;
                                }
                            }
                            nContador = 0; //Se limpia contador
                            lbImportados.Items.Add(fi.Name.ToString());
                            nCantidadArchivos = nCantidadArchivos + 1;
                        }
                    }

                    //Trasladamos archivos procesados 
                    if (!System.IO.Directory.Exists(cRutaDestino))
                    {
                        System.IO.Directory.CreateDirectory(cRutaDestino);
                    }
                    System.IO.File.Copy(cArchivoOrigen, cArchivoDestino, true);
                    System.IO.File.Delete(cArchivoOrigen);
                }
                ////MessageBox.Show("Archivos Procesados : " + nCantidadArchivos.ToString());
                laMensajeReportes.Text = nCantidadArchivos.ToString() + " Archivos Procesados";
                laMensajeReportes.Visible = true;
                if (nExisteArchivos == 1)
                {
                    MessageBox.Show("No hay archivos para procesar", "Alerta"); //UQMA Se cambio a Alerta
                    pbImportar.Value = 0;
                    lbImportados.Items.Clear();
                }
                else
                    MessageBox.Show("Archivos Procesados correctamente!!", "Informacion");
                

                //UQMA 19/10/2017 ENVIAMOS CORREO DE DEPOSITO POR COMPENSACION
                EnviarCorreo();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.ToString());
            }
        }



        //private void ImportarPago()
        //{
        //    cConstante C = new cConstante();            
        //    cArchivoReporte oReportes = new cArchivoReporte();
        //    int nExisteArchivos;
            
        //    //Obtenmos variables generales
        //    String cUser;
        //    String cAgencia;
        //    DateTime dFechaSistema;

        //    cUser = Environment.UserName.ToString().ToUpper();
        //    cAgencia = "01";
        //    dFechaSistema = DateTime.Now;


        //    int nCantidadArchivos;
        //    int nLongitudCadena;
        //    nCantidadArchivos = 0;
        //    int nContador = 0;
        //    string line;
        //    nExisteArchivos = 1;//No existe archivos
            
        //    string cRutaOrigen = C.cpRutaOrigenEricson; //@"D:\PDP\PDPReportes\03-04-05-06-2016\";
        //    string cRutaDestino = C.cpRutaDestinoErickson;//@"D:\PDP\PDPReportes\03-04-05-06-2016\"+DateTime.Now.ToString("yyyyMMdd");

        //    string cArchivoDestino;
        //    string cArchivoOrigen;
        //    System.IO.StreamReader file;

        //    DirectoryInfo di = new DirectoryInfo(C.cpDirectoryInfo);            //@"D:\PDP\PDPReportes\03-04-05-06-2016\"

        //    foreach (var fi in di.GetFiles())
        //    {
        //        nExisteArchivos = 0;// existen archivos
        //        nLongitudCadena = fi.Name.Length;
        //        cArchivoOrigen = System.IO.Path.Combine(cRutaOrigen, fi.Name);
        //        cArchivoDestino = System.IO.Path.Combine(cRutaDestino, fi.Name);

        //        //Procesamos los archivos no firmados
        //        if (nLongitudCadena > 10)
        //        {
        //            if (fi.Name.Substring(fi.Name.Length - 10, 10) != ".signature")
        //            {
        //                //Determinar tipo de archivo
        //                String caseSwitch = ObtenerNombre(fi.Name.ToString());

        //                //Leer archivo
        //                file = new System.IO.StreamReader(cArchivoOrigen);
        //                //file = new System.IO.StreamReader(@"D:\test.csv");
        //                while ((line = file.ReadLine()) != null)
        //                {       
        //                    oReportes.Insertar_Pago(cUser, cAgencia, dFechaSistema, fi.Name.ToString(), nContador, line);                            
        //                    nContador++;
        //                }

        //                nContador = 0; //Se limpia contador
        //                file.Close();                        
        //                lbImportados.Items.Add(fi.Name.ToString());
        //                nCantidadArchivos = nCantidadArchivos + 1;
        //            }
        //        }

        //        //Trasladamos archivos procesados 
        //        if (!System.IO.Directory.Exists(cRutaDestino))
        //        {
        //            System.IO.Directory.CreateDirectory(cRutaDestino);
        //        }
        //        System.IO.File.Copy(cArchivoOrigen, cArchivoDestino, true);
        //        System.IO.File.Delete(cArchivoOrigen);
        //    }
        //    //MessageBox.Show("Archivos Procesados : " + nCantidadArchivos.ToString());
        //    laMensajeInstrucciones.Text = nCantidadArchivos.ToString() + " Archivos Procesados";
        //    laMensajeInstrucciones.Visible = true;
        //    if (nExisteArchivos == 1)
        //    {
        //        MessageBox.Show("No hay Pagos para importar");
        //        pbImportar.Value = 0;
        //    }
        //}


        public String ObtenerNombre(String cNombreArchivo)
        {
            String caseSwitch = "";

            int nLongitudCadena = cNombreArchivo.Length;

            if (nLongitudCadena > 8)
            {
                if (cNombreArchivo.Substring(0, 7) == "netting")//Determinar si es netting            
                    caseSwitch = cNombreArchivo.Substring(0, 7);
                else
                {
                    if (cNombreArchivo.Substring(0, 17) == "USRACCOUNTBALANCE")//Determinar si es USRACCOUNTBALANCE                
                        caseSwitch = cNombreArchivo.Substring(0, 17);
                    else
                    {
                        if (cNombreArchivo.Substring(0, 6) == "LOGUSR")//Determinar si es USRACCOUNTBALANCE            
                            caseSwitch = cNombreArchivo.Substring(0, 6);
                        else
                        {
                            if (cNombreArchivo.Substring(0, 2) == "TR")//Determinar si es TR
                                caseSwitch = cNombreArchivo.Substring(0, 2);
                            else
                            {
                                if (cNombreArchivo.Substring(0, 9) == "DEPOSITOS")//Determinar si es DEPOSITOS            
                                    caseSwitch = cNombreArchivo.Substring(0, 9);
                                else
                                {
                                    if (cNombreArchivo.Substring(0, 7) == "RETIROS")//Determinar si es RETIROS            
                                        caseSwitch = cNombreArchivo.Substring(0, 7);
                                    else
                                    {
                                        if (cNombreArchivo.Substring(0, 10) == "COMISIONES")//Determinar si es COMISIONES            
                                            caseSwitch = cNombreArchivo.Substring(0, 10);
                                        else
                                        {
                                            if (cNombreArchivo.Substring(0, 8) == "INTEROPE")//Determinar si es COMISIONES            
                                                caseSwitch = cNombreArchivo.Substring(0, 8);
                                            else
                                            {
                                                if (cNombreArchivo.Substring(0, 6) == "FEEDET")//Determinar si es COMISIONES            
                                                    caseSwitch = cNombreArchivo.Substring(0, 6);
                                                else
                                                {
                                                    if (cNombreArchivo.Substring(0, 13) == "INF-COMERCIAL")//Determinar si es COMISIONES            
                                                        caseSwitch = cNombreArchivo.Substring(0, 13);
                                                    else
                                                    {
                                                        if (cNombreArchivo.Substring(7, 3) == "PAY")//Determinar si es COMISIONES            
                                                            caseSwitch = cNombreArchivo.Substring(7, 3);
                                                        else
                                                        {
                                                            //15/08/2017 UQNA INICIO Se comento 
                                                            //if (cNombreArchivo.Substring(0, 10) == "REPORTE32A")//Determinar si es COMISIONES            
                                                            //    caseSwitch = cNombreArchivo.Substring(0, 10);
                                                            //else
                                                            //    caseSwitch = "";
                                                            //15/08/2017 UQNA FIN Se comento 

                                                            //15/08/2017 UQNA Inicio para procesar Reporte 32 A y B 
                                                            if (cNombreArchivo.Substring(0, 10) == "REPORTE32A")//Determinar si es REPORTE32A         
                                                                caseSwitch = cNombreArchivo.Substring(0, 10);
                                                            else
                                                            {
                                                                if (cNombreArchivo.Substring(0, 14) == "REPORTE32B-III")//Determinar si es REPORTE32B-III          
                                                                    caseSwitch = cNombreArchivo.Substring(0, 14);
                                                                else
                                                                {
                                                                    if (cNombreArchivo.Substring(0, 13) == "REPORTE32B-II")//Determinar si es REPORTE32B-II           
                                                                        caseSwitch = cNombreArchivo.Substring(0, 13);
                                                                    else
                                                                    {
                                                                        if (cNombreArchivo.Substring(0, 13) == "REPORTE32B-IV")//Determinar si es REPORTE32B-IV           
                                                                            caseSwitch = cNombreArchivo.Substring(0, 13);
                                                                        else
                                                                        {
                                                                            if (cNombreArchivo.Substring(0, 12) == "REPORTE32B-I")//Determinar si es REPORTE32B-I            
                                                                                caseSwitch = cNombreArchivo.Substring(0, 12);
                                                                            else
                                                                                caseSwitch = "";
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            //15/08/2017 UQNA Fin para procesar Reporte 32 A y B 
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return caseSwitch.ToUpper();            
        }

        private void porgresbarReportes()
        {
            pbImportar.Minimum = 0;
            // Sets the progress bar's maximum value to a number representing
            // all operations complete -- in this case, all five files read.
            pbImportar.Maximum = 5;
            // Sets the Step property to amount to increase with each iteration.
            // In this case, it will increase by one with every file read.
            pbImportar.Step = 1;

            // Uses a for loop to iterate through the operations to be
            // completed. In this case, five files are to be copied into memory,
            // so the loop will execute 5 times.
            for (int i = 0; i <= 4; i++)
            {
                // Inserts code to copy a file
                pbImportar.PerformStep();
                // Updates the label to show that a file was read.
                //label1.Text = "# of Files Read = " + pbImportar.Value.ToString();
            }
        }

        private void porgresbarInstrucciones()
        {
            pbImportarInstrucciones.Minimum = 0;
            pbImportarInstrucciones.Maximum = 5;
            pbImportarInstrucciones.Step = 1;
            
            for (int i = 0; i <= 4; i++)
            {
                pbImportarInstrucciones.PerformStep();             
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            lbImportados.Items.Clear();
            laMensajeReportes.Text = "";
            lbImportados.Items.Clear();
            lbInsImportados.Items.Clear();
            laMensajeInstrucciones.Text = "";
            lbInsImportados.Items.Clear();
            pbImportarInstrucciones.Value = 0;
            pbImportar.Value = 0;
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnValidarCarga_Click(object sender, EventArgs e)
        {
            CambiarColorArchivosCargados();
        }
    }
}
