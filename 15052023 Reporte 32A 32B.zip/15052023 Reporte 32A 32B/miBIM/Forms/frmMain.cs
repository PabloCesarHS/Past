﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.DirectoryServices;
using CapaNegocio;
using System.Net.NetworkInformation;
using System.Net;

namespace miBIM.Forms
{
    public partial class frmMain : Form
    {   
        cRegistro oRegistro = new cRegistro();
        public string lcPass;

        public frmMain()
        {
            InitializeComponent();
        }

        public frmMain(String cPass)
        {            
            lcPass = cPass;            
            InitializeComponent();
            Cargar_Datos_Usuario();
        }

        /**/
        private void Cargar_Datos_Usuario()
        {
            try
            {
                tssUsuarioPrincipal.Text = " Usuario: " + Environment.UserName.ToUpper();
                tssOrdenador.Text = " Ordenador: " + Environment.MachineName.ToString();

                tssModoPrincipal.Text = " [ " + cSistema.ServidorBD.ToUpper() + " ] ";

                tssVersionPrincipal.Text = " Version: " + cSistema.Version.ToUpper();

                NetworkInterface networkInterface = NetworkInterface.GetAllNetworkInterfaces().First(n => n.NetworkInterfaceType == NetworkInterfaceType.Ethernet && n.OperationalStatus == OperationalStatus.Up);
                IPAddress ipAddress = networkInterface.GetIPProperties().UnicastAddresses[0].Address;

                tssIPPrincipal.Text = " Direccion IP: " + ipAddress.ToString();
                
                Mostrar_Mensaje("Datos cargados", 0);
            }
            catch (Exception ex)
            {
                Mostrar_Mensaje(ex.Message, 3);
            }
        }

        public void Mostrar_Mensaje(string _Mensaje, int _Tipo)
        {
            switch (_Tipo)
            {
                case 1:
                    tssMensajePrinciapl.ForeColor = System.Drawing.Color.Blue;
                    tssMensajePrinciapl.Text = _Mensaje;
                    break;

                case 2:
                    tssMensajePrinciapl.ForeColor = System.Drawing.Color.OrangeRed;
                    tssMensajePrinciapl.Text = "ADVERTENCIA:" + _Mensaje;
                    break;

                case 3:
                    tssMensajePrinciapl.ForeColor = System.Drawing.Color.Red;
                    tssMensajePrinciapl.Text = "ERROR:" + _Mensaje;
                    break;

                default:
                    tssMensajePrinciapl.ForeColor = System.Drawing.Color.Green;
                    tssMensajePrinciapl.Text = _Mensaje;
                    break;
            }
        }


        private void frmMain_Load(object sender, EventArgs e)
        {
            String cUsuario = Environment.UserName.ToString().ToUpper();
            int nNivel = 0;
            int nPerfil = 0;

            //INICIO UQMA 04/12/2017 COMENTO
                ////if (!verificarPermisosLocal(cUsuario, lcPass, ref nNivel, ref nPerfil))
                ////{
                ////    MessageBox.Show("Usuario No Tiene Permisos");
                ////    this.Close();
                ////}  // 15/08/2017 UQNA COMENTO


                ////15/08/2017 UQMA INICIO 
                //if (!verificarPermisos(cUsuario, lcPass, ref nNivel, ref nPerfil))
                //{
                //    MessageBox.Show("Usuario No Tiene Permisos");
                //    this.Close();
                //}
                ////15/08/2017 UQMA FIN 
            //FIN UQMA 04/12/2017 COMENTO


            //UQMA 04/12/2017
            if (!verificarPermisosLocal(cUsuario, lcPass, ref nNivel, ref nPerfil))
            {
                //if (!verificarPermisos(cUsuario, lcPass, ref nNivel, ref nPerfil))
                //{
                //    MessageBox.Show("Usuario No Tiene Permisos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //    this.Close();
                //}
            }  

                      
        }

        public bool verificarPermisosLocal(string usuario, string psTxtPass, ref int nNivel, ref int nPerfil)
        {
            try
            {                
                bool esGrupoPermitido = false;
                ObtenerPermisosLocal(usuario, ref esGrupoPermitido, ref nNivel, ref nPerfil);

                return esGrupoPermitido;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool verificarPermisos(string usuario, string psTxtPass, ref int nNivel, ref int nPerfil)
        {
            try
            {
            //Anterior
            //DirectoryEntry entry = new DirectoryEntry("LDAP://CMACCUSCO");

            DirectoryEntry entry = new DirectoryEntry("LDAP://" + "CMACCUSCO" + "", usuario, psTxtPass, System.DirectoryServices.AuthenticationTypes.Secure);
            DirectorySearcher searcher = new DirectorySearcher(entry);

            searcher.Filter = "(SAMAccountName=" + usuario + ")";
            searcher.PropertiesToLoad.Add("MemberOf");
            SearchResult result = searcher.FindOne();

            int n = result.Properties["MemberOf"].Count - 1;

            string item = string.Empty;

            string[] grupos_usuario = new string[n + 1];

            while (n >= 0)
            {
                item = result.Properties["MemberOf"][n] + "";
                item = item.Substring(0, item.IndexOf(",", 0));
                item = item.Replace("CN=", "");
                item = item.Trim();
                grupos_usuario[n] = item;
                n--;
            }

            bool esGrupoPermitido = false;
            ObtenerPermisos(grupos_usuario, ref esGrupoPermitido, ref nNivel, ref nPerfil);
            

            return esGrupoPermitido;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public void ObtenerPermisos(string[] grupos_usuario, ref bool esGrupoPermitido, ref int nNivel, ref int nPerfil)
        {
            DataTable dtGruposUsu = new DataTable();
            int nEstado=-1;
            dtGruposUsu = oRegistro.ObtenerPermisos(ref nEstado);
            
            if(nEstado==0)
            {
                esGrupoPermitido = false;
                nNivel = -1;
                nPerfil = -1;

                for (int i = 0; i < grupos_usuario.Length; i++)
                {
                    for (int j = 0; j < dtGruposUsu.Rows.Count; j++)
                    {
                        if (grupos_usuario[i].Equals(dtGruposUsu.Rows[j][0].ToString()))
                        {
                            // mayor nivel
                            if (Convert.ToInt32(dtGruposUsu.Rows[j][1].ToString()) > nNivel)
                            {
                                nPerfil = Convert.ToInt32(dtGruposUsu.Rows[j][1].ToString());
                                AsignarAcceso(nPerfil);
                            }                            
                            esGrupoPermitido = true;
                        }
                    }
                }
            }
            else
	        {
                MessageBox.Show("Error Acceso");
	        }
        }
        public void ObtenerPermisosLocal(string cUsuario, ref bool esGrupoPermitido, ref int nNivel, ref int nPerfil)
        {
            DataTable dtGruposUsu = new DataTable();
            int nEstado = -1;
            dtGruposUsu = oRegistro.ObtenerPermisosUsuario(ref nEstado, cUsuario);
            //MessageBox.Show("Usuario: " + cUsuario + ", nEstado: " + nEstado);
            

            if (nEstado == 0)
            {
                esGrupoPermitido = false;
                nNivel = -1;
                nPerfil = -1;
                
                for (int j = 0; j < dtGruposUsu.Rows.Count; j++)
                {                    
                    nPerfil = Convert.ToInt32(dtGruposUsu.Rows[j][1].ToString());
                    AsignarAcceso(nPerfil);                        
                    esGrupoPermitido = true;                    
                }
                
            }
            //else
            //{
            //    MessageBox.Show("Error Acceso");
            //}
        }

        public void AsignarAcceso(int nMenu)
        {
            mStrMenu.Items[nMenu].Visible = true;

            mStrMenu.Items[0].Visible = true;
            mStrMenu.Items[1].Visible = true;
            mStrMenu.Items[2].Visible = true;
            mStrMenu.Items[3].Visible = true;
        }

        private void importarReportesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmImportarArchivos oImportar = new frmImportarArchivos();

            oImportar.ShowDialog(Owner);
        }

        private void generarPagoPARToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.frmRespuestaPago oRespuestaPago = new frmRespuestaPago();
            oRespuestaPago.ShowDialog(Owner);

        }

        private void generarDepositoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.frmGenerarDeposito oGenerarDeposito = new frmGenerarDeposito();
            oGenerarDeposito.ShowDialog(Owner);
        }

        private void modificarDepositoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.frmModificarDeposito oGenerarDeposito = new frmModificarDeposito();
            oGenerarDeposito.ShowDialog(Owner);
        }

      

        private void reporte32ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //15/08/2017 UQMA Inicio para modificar Reporte 32
            FrmModificarReporte32 o = new FrmModificarReporte32();
            o.ShowDialog();
            //15/08/2017 UQMA Fin  para modificar Reporte 32
        }

        private void depósitoPorCompensaciónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //03/10/2017 UQMA Deposito por Compensacion
            FrmDepositoCompensacion oDepComp = new FrmDepositoCompensacion();
            oDepComp.ShowDialog();
        }

        private void generarReporteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //04/10/2017 UQMA Para generar reportes
            frmReportes oRep = new frmReportes();
            oRep.ShowDialog();
        }

        private void registrarAgentesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //05/10/2017 UQMA
            frmCargaBatchAgentes o = new frmCargaBatchAgentes();
            o.ShowDialog();
        }

        private void revertirDepositoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.frmRevertirDeposito oRevertirDeposito = new frmRevertirDeposito();
            oRevertirDeposito.ShowDialog(Owner);
        }

        /* INICIO 04072023 HSPC - Se agrega nuevo formulario para visualizar las cargas de archivos */
        private void detalleCargaArchivosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.frmDetalleCargaArchivos oDetalecargaArchivos = new frmDetalleCargaArchivos();
            oDetalecargaArchivos.ShowDialog(Owner);
        }
        /* INICIO 04072023 HSPC - Se agrega nuevo formulario para visualizar las cargas de archivos */

        /* INICIO 04072023 HSPC - Se agrega nuevo formulario de mantenimiento de rutas */
        private void rutasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.frmConfiguracion oConfiguraciones = new frmConfiguracion();
            oConfiguraciones.ShowDialog(Owner);
        }

        private void reporteOperacionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.FrmModificarReporteOperaciones oReporteOperaciones = new FrmModificarReporteOperaciones();
            oReporteOperaciones.ShowDialog(Owner);
        }

        private void accesosUsuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.frmAccesos oGruposUsuarios = new frmAccesos();
            oGruposUsuarios.ShowDialog(Owner);
        }
        /* FIN 04072023 HSPC - Se agrega nuevo formulario de mantenimiento de rutas */
    }
}
