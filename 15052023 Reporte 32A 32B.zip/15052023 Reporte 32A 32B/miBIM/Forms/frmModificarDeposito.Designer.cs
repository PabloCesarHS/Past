﻿namespace miBIM.Forms
{
    partial class frmModificarDeposito
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.laTitulo = new System.Windows.Forms.Label();
            this.chkDepositoCompensacion = new System.Windows.Forms.CheckBox();
            this.chkReversaDeposito = new System.Windows.Forms.CheckBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.paTitulo = new System.Windows.Forms.Panel();
            this.paReversaDeposito = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSalir_Rev = new System.Windows.Forms.Button();
            this.btn_Confirmar_Rev = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btnBuscaRevDep = new System.Windows.Forms.Button();
            this.dgvDeposito = new System.Windows.Forms.DataGridView();
            this.SelRev = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.laFechaFin = new System.Windows.Forms.Label();
            this.laFechaInicio = new System.Windows.Forms.Label();
            this.dtpFechaFinal_Rev = new System.Windows.Forms.DateTimePicker();
            this.dtpFechaInicial_Rev = new System.Windows.Forms.DateTimePicker();
            this.paConfirmarDeposito = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnConfirmar = new System.Windows.Forms.Button();
            this.dgvDepositoSinconfirmar = new System.Windows.Forms.DataGridView();
            this.Sel = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.label3 = new System.Windows.Forms.Label();
            this.btnBuscarDepositos = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpFechaFin_Buscar = new System.Windows.Forms.DateTimePicker();
            this.dtpFechaInicio_Buscar = new System.Windows.Forms.DateTimePicker();
            this.paCompensacion = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnSalir_Comp = new System.Windows.Forms.Button();
            this.btnGenerar_comp = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btnBuscar_Comp = new System.Windows.Forms.Button();
            this.dgvCompensacion = new System.Windows.Forms.DataGridView();
            this.SelComp = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.nReferencia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dtpFechaFin_Comp = new System.Windows.Forms.DateTimePicker();
            this.dtpFechaIni_Comp = new System.Windows.Forms.DateTimePicker();
            this.panel3.SuspendLayout();
            this.paTitulo.SuspendLayout();
            this.paReversaDeposito.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeposito)).BeginInit();
            this.paConfirmarDeposito.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepositoSinconfirmar)).BeginInit();
            this.paCompensacion.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCompensacion)).BeginInit();
            this.SuspendLayout();
            // 
            // laTitulo
            // 
            this.laTitulo.AutoSize = true;
            this.laTitulo.BackColor = System.Drawing.Color.YellowGreen;
            this.laTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laTitulo.ForeColor = System.Drawing.SystemColors.Control;
            this.laTitulo.Location = new System.Drawing.Point(278, 18);
            this.laTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laTitulo.Name = "laTitulo";
            this.laTitulo.Size = new System.Drawing.Size(272, 26);
            this.laTitulo.TabIndex = 18;
            this.laTitulo.Text = "MODIFICAR DEPOSITO";
            this.laTitulo.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // chkDepositoCompensacion
            // 
            this.chkDepositoCompensacion.AutoSize = true;
            this.chkDepositoCompensacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDepositoCompensacion.Location = new System.Drawing.Point(524, 7);
            this.chkDepositoCompensacion.Margin = new System.Windows.Forms.Padding(2);
            this.chkDepositoCompensacion.Name = "chkDepositoCompensacion";
            this.chkDepositoCompensacion.Size = new System.Drawing.Size(182, 19);
            this.chkDepositoCompensacion.TabIndex = 9;
            this.chkDepositoCompensacion.Text = "Deposito por Compensacion";
            this.chkDepositoCompensacion.UseVisualStyleBackColor = true;
            this.chkDepositoCompensacion.CheckedChanged += new System.EventHandler(this.chkDepositoCompensacion_CheckedChanged);
            // 
            // chkReversaDeposito
            // 
            this.chkReversaDeposito.AutoSize = true;
            this.chkReversaDeposito.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkReversaDeposito.Location = new System.Drawing.Point(220, 7);
            this.chkReversaDeposito.Margin = new System.Windows.Forms.Padding(2);
            this.chkReversaDeposito.Name = "chkReversaDeposito";
            this.chkReversaDeposito.Size = new System.Drawing.Size(120, 19);
            this.chkReversaDeposito.TabIndex = 10;
            this.chkReversaDeposito.Text = "Revertir Deposito";
            this.chkReversaDeposito.UseVisualStyleBackColor = true;
            this.chkReversaDeposito.CheckedChanged += new System.EventHandler(this.chkReversaDeposito_CheckedChanged);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.chkDepositoCompensacion);
            this.panel3.Controls.Add(this.chkReversaDeposito);
            this.panel3.Location = new System.Drawing.Point(100, 86);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(830, 40);
            this.panel3.TabIndex = 19;
            // 
            // paTitulo
            // 
            this.paTitulo.BackColor = System.Drawing.SystemColors.ControlLight;
            this.paTitulo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.paTitulo.Controls.Add(this.laTitulo);
            this.paTitulo.Location = new System.Drawing.Point(103, 12);
            this.paTitulo.Name = "paTitulo";
            this.paTitulo.Size = new System.Drawing.Size(830, 68);
            this.paTitulo.TabIndex = 20;
            // 
            // paReversaDeposito
            // 
            this.paReversaDeposito.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.paReversaDeposito.Controls.Add(this.panel2);
            this.paReversaDeposito.Controls.Add(this.label4);
            this.paReversaDeposito.Controls.Add(this.btnBuscaRevDep);
            this.paReversaDeposito.Controls.Add(this.dgvDeposito);
            this.paReversaDeposito.Controls.Add(this.laFechaFin);
            this.paReversaDeposito.Controls.Add(this.laFechaInicio);
            this.paReversaDeposito.Controls.Add(this.dtpFechaFinal_Rev);
            this.paReversaDeposito.Controls.Add(this.dtpFechaInicial_Rev);
            this.paReversaDeposito.Location = new System.Drawing.Point(100, 150);
            this.paReversaDeposito.Name = "paReversaDeposito";
            this.paReversaDeposito.Size = new System.Drawing.Size(830, 360);
            this.paReversaDeposito.TabIndex = 22;
            this.paReversaDeposito.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.btnSalir_Rev);
            this.panel2.Controls.Add(this.btn_Confirmar_Rev);
            this.panel2.Location = new System.Drawing.Point(20, 305);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(790, 50);
            this.panel2.TabIndex = 18;
            // 
            // btnSalir_Rev
            // 
            this.btnSalir_Rev.Location = new System.Drawing.Point(680, 3);
            this.btnSalir_Rev.Name = "btnSalir_Rev";
            this.btnSalir_Rev.Size = new System.Drawing.Size(90, 35);
            this.btnSalir_Rev.TabIndex = 17;
            this.btnSalir_Rev.Text = "&Salir";
            this.btnSalir_Rev.UseVisualStyleBackColor = true;
            this.btnSalir_Rev.Click += new System.EventHandler(this.btnSalir_Rev_Click);
            // 
            // btn_Confirmar_Rev
            // 
            this.btn_Confirmar_Rev.Location = new System.Drawing.Point(1, 3);
            this.btn_Confirmar_Rev.Name = "btn_Confirmar_Rev";
            this.btn_Confirmar_Rev.Size = new System.Drawing.Size(90, 35);
            this.btn_Confirmar_Rev.TabIndex = 16;
            this.btn_Confirmar_Rev.Text = "&Generar";
            this.btn_Confirmar_Rev.UseVisualStyleBackColor = true;
            this.btn_Confirmar_Rev.Click += new System.EventHandler(this.btn_Confirmar_Rev_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(300, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(195, 20);
            this.label4.TabIndex = 13;
            this.label4.Text = "REVERTIR DEPOSITO";
            // 
            // btnBuscaRevDep
            // 
            this.btnBuscaRevDep.Location = new System.Drawing.Point(329, 45);
            this.btnBuscaRevDep.Name = "btnBuscaRevDep";
            this.btnBuscaRevDep.Size = new System.Drawing.Size(75, 23);
            this.btnBuscaRevDep.TabIndex = 6;
            this.btnBuscaRevDep.Text = "&Buscar";
            this.btnBuscaRevDep.UseVisualStyleBackColor = true;
            this.btnBuscaRevDep.Click += new System.EventHandler(this.btnBuscaRevDep_Click);
            // 
            // dgvDeposito
            // 
            this.dgvDeposito.AllowUserToAddRows = false;
            this.dgvDeposito.AllowUserToDeleteRows = false;
            this.dgvDeposito.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDeposito.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDeposito.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SelRev});
            this.dgvDeposito.Location = new System.Drawing.Point(20, 80);
            this.dgvDeposito.Name = "dgvDeposito";
            this.dgvDeposito.Size = new System.Drawing.Size(790, 220);
            this.dgvDeposito.TabIndex = 5;
            // 
            // SelRev
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.NullValue = false;
            this.SelRev.DefaultCellStyle = dataGridViewCellStyle1;
            this.SelRev.Frozen = true;
            this.SelRev.HeaderText = "Sel";
            this.SelRev.Name = "SelRev";
            this.SelRev.Width = 28;
            // 
            // laFechaFin
            // 
            this.laFechaFin.AutoSize = true;
            this.laFechaFin.Location = new System.Drawing.Point(178, 45);
            this.laFechaFin.Name = "laFechaFin";
            this.laFechaFin.Size = new System.Drawing.Size(33, 13);
            this.laFechaFin.TabIndex = 4;
            this.laFechaFin.Text = "F. Fin";
            // 
            // laFechaInicio
            // 
            this.laFechaInicio.AutoSize = true;
            this.laFechaInicio.Location = new System.Drawing.Point(20, 45);
            this.laFechaInicio.Name = "laFechaInicio";
            this.laFechaInicio.Size = new System.Drawing.Size(44, 13);
            this.laFechaInicio.TabIndex = 3;
            this.laFechaInicio.Text = "F. Inicio";
            // 
            // dtpFechaFinal_Rev
            // 
            this.dtpFechaFinal_Rev.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaFinal_Rev.Location = new System.Drawing.Point(224, 45);
            this.dtpFechaFinal_Rev.Name = "dtpFechaFinal_Rev";
            this.dtpFechaFinal_Rev.Size = new System.Drawing.Size(87, 20);
            this.dtpFechaFinal_Rev.TabIndex = 1;
            // 
            // dtpFechaInicial_Rev
            // 
            this.dtpFechaInicial_Rev.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaInicial_Rev.Location = new System.Drawing.Point(72, 45);
            this.dtpFechaInicial_Rev.Name = "dtpFechaInicial_Rev";
            this.dtpFechaInicial_Rev.Size = new System.Drawing.Size(87, 20);
            this.dtpFechaInicial_Rev.TabIndex = 0;
            // 
            // paConfirmarDeposito
            // 
            this.paConfirmarDeposito.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.paConfirmarDeposito.Controls.Add(this.panel1);
            this.paConfirmarDeposito.Controls.Add(this.dgvDepositoSinconfirmar);
            this.paConfirmarDeposito.Controls.Add(this.label3);
            this.paConfirmarDeposito.Controls.Add(this.btnBuscarDepositos);
            this.paConfirmarDeposito.Controls.Add(this.label1);
            this.paConfirmarDeposito.Controls.Add(this.label2);
            this.paConfirmarDeposito.Controls.Add(this.dtpFechaFin_Buscar);
            this.paConfirmarDeposito.Controls.Add(this.dtpFechaInicio_Buscar);
            this.paConfirmarDeposito.Location = new System.Drawing.Point(100, 150);
            this.paConfirmarDeposito.Name = "paConfirmarDeposito";
            this.paConfirmarDeposito.Size = new System.Drawing.Size(830, 360);
            this.paConfirmarDeposito.TabIndex = 23;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btnSalir);
            this.panel1.Controls.Add(this.btnConfirmar);
            this.panel1.Location = new System.Drawing.Point(20, 305);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(790, 50);
            this.panel1.TabIndex = 16;
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(680, 3);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(90, 35);
            this.btnSalir.TabIndex = 15;
            this.btnSalir.Text = "&Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnConfirmar
            // 
            this.btnConfirmar.Location = new System.Drawing.Point(1, 3);
            this.btnConfirmar.Name = "btnConfirmar";
            this.btnConfirmar.Size = new System.Drawing.Size(90, 35);
            this.btnConfirmar.TabIndex = 14;
            this.btnConfirmar.Text = "&Confirmar";
            this.btnConfirmar.UseVisualStyleBackColor = true;
            this.btnConfirmar.Click += new System.EventHandler(this.btnConfirmar_Click);
            // 
            // dgvDepositoSinconfirmar
            // 
            this.dgvDepositoSinconfirmar.AllowUserToAddRows = false;
            this.dgvDepositoSinconfirmar.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDepositoSinconfirmar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDepositoSinconfirmar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Sel});
            this.dgvDepositoSinconfirmar.Location = new System.Drawing.Point(20, 80);
            this.dgvDepositoSinconfirmar.Name = "dgvDepositoSinconfirmar";
            this.dgvDepositoSinconfirmar.Size = new System.Drawing.Size(790, 220);
            this.dgvDepositoSinconfirmar.TabIndex = 13;
            // 
            // Sel
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.NullValue = false;
            this.Sel.DefaultCellStyle = dataGridViewCellStyle2;
            this.Sel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Sel.Frozen = true;
            this.Sel.HeaderText = "Sel";
            this.Sel.Name = "Sel";
            this.Sel.Width = 28;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(300, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(210, 20);
            this.label3.TabIndex = 12;
            this.label3.Text = "CONFIRMAR DEPOSITO";
            // 
            // btnBuscarDepositos
            // 
            this.btnBuscarDepositos.Location = new System.Drawing.Point(329, 45);
            this.btnBuscarDepositos.Name = "btnBuscarDepositos";
            this.btnBuscarDepositos.Size = new System.Drawing.Size(75, 23);
            this.btnBuscarDepositos.TabIndex = 11;
            this.btnBuscarDepositos.Text = "&Buscar";
            this.btnBuscarDepositos.UseVisualStyleBackColor = true;
            this.btnBuscarDepositos.Click += new System.EventHandler(this.btnBuscarDepositos_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(178, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "F. Fin";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "F. Inicio";
            // 
            // dtpFechaFin_Buscar
            // 
            this.dtpFechaFin_Buscar.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaFin_Buscar.Location = new System.Drawing.Point(224, 45);
            this.dtpFechaFin_Buscar.Name = "dtpFechaFin_Buscar";
            this.dtpFechaFin_Buscar.Size = new System.Drawing.Size(87, 20);
            this.dtpFechaFin_Buscar.TabIndex = 8;
            // 
            // dtpFechaInicio_Buscar
            // 
            this.dtpFechaInicio_Buscar.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaInicio_Buscar.Location = new System.Drawing.Point(72, 45);
            this.dtpFechaInicio_Buscar.Name = "dtpFechaInicio_Buscar";
            this.dtpFechaInicio_Buscar.Size = new System.Drawing.Size(87, 20);
            this.dtpFechaInicio_Buscar.TabIndex = 7;
            // 
            // paCompensacion
            // 
            this.paCompensacion.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.paCompensacion.Controls.Add(this.panel5);
            this.paCompensacion.Controls.Add(this.label5);
            this.paCompensacion.Controls.Add(this.btnBuscar_Comp);
            this.paCompensacion.Controls.Add(this.dgvCompensacion);
            this.paCompensacion.Controls.Add(this.label6);
            this.paCompensacion.Controls.Add(this.label7);
            this.paCompensacion.Controls.Add(this.dtpFechaFin_Comp);
            this.paCompensacion.Controls.Add(this.dtpFechaIni_Comp);
            this.paCompensacion.Location = new System.Drawing.Point(100, 150);
            this.paCompensacion.Name = "paCompensacion";
            this.paCompensacion.Size = new System.Drawing.Size(830, 360);
            this.paCompensacion.TabIndex = 24;
            this.paCompensacion.Visible = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.btnSalir_Comp);
            this.panel5.Controls.Add(this.btnGenerar_comp);
            this.panel5.Location = new System.Drawing.Point(20, 305);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(790, 50);
            this.panel5.TabIndex = 26;
            // 
            // btnSalir_Comp
            // 
            this.btnSalir_Comp.Location = new System.Drawing.Point(680, 3);
            this.btnSalir_Comp.Name = "btnSalir_Comp";
            this.btnSalir_Comp.Size = new System.Drawing.Size(90, 35);
            this.btnSalir_Comp.TabIndex = 17;
            this.btnSalir_Comp.Text = "&Salir";
            this.btnSalir_Comp.UseVisualStyleBackColor = true;
            this.btnSalir_Comp.Click += new System.EventHandler(this.btnSalir_Comp_Click);
            // 
            // btnGenerar_comp
            // 
            this.btnGenerar_comp.Location = new System.Drawing.Point(1, 3);
            this.btnGenerar_comp.Name = "btnGenerar_comp";
            this.btnGenerar_comp.Size = new System.Drawing.Size(90, 35);
            this.btnGenerar_comp.TabIndex = 16;
            this.btnGenerar_comp.Text = "&Generar";
            this.btnGenerar_comp.UseVisualStyleBackColor = true;
            this.btnGenerar_comp.Click += new System.EventHandler(this.btnGenerar_comp_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(300, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(287, 20);
            this.label5.TabIndex = 25;
            this.label5.Text = "DEPOSITO POR COMPENSACION";
            // 
            // btnBuscar_Comp
            // 
            this.btnBuscar_Comp.Location = new System.Drawing.Point(329, 45);
            this.btnBuscar_Comp.Name = "btnBuscar_Comp";
            this.btnBuscar_Comp.Size = new System.Drawing.Size(75, 23);
            this.btnBuscar_Comp.TabIndex = 24;
            this.btnBuscar_Comp.Text = "&Buscar";
            this.btnBuscar_Comp.UseVisualStyleBackColor = true;
            this.btnBuscar_Comp.Click += new System.EventHandler(this.btnBuscar_Comp_Click);
            // 
            // dgvCompensacion
            // 
            this.dgvCompensacion.AllowUserToAddRows = false;
            this.dgvCompensacion.AllowUserToDeleteRows = false;
            this.dgvCompensacion.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvCompensacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCompensacion.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SelComp,
            this.nReferencia});
            this.dgvCompensacion.Location = new System.Drawing.Point(20, 80);
            this.dgvCompensacion.Name = "dgvCompensacion";
            this.dgvCompensacion.Size = new System.Drawing.Size(790, 220);
            this.dgvCompensacion.TabIndex = 23;
            // 
            // SelComp
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.NullValue = false;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            this.SelComp.DefaultCellStyle = dataGridViewCellStyle3;
            this.SelComp.Frozen = true;
            this.SelComp.HeaderText = "Sel";
            this.SelComp.Name = "SelComp";
            this.SelComp.Width = 28;
            // 
            // nReferencia
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            this.nReferencia.DefaultCellStyle = dataGridViewCellStyle4;
            this.nReferencia.Frozen = true;
            this.nReferencia.HeaderText = "NroReferencia";
            this.nReferencia.Name = "nReferencia";
            this.nReferencia.Width = 101;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(178, 45);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 13);
            this.label6.TabIndex = 22;
            this.label6.Text = "F. Fin";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(20, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "F. Inicio";
            // 
            // dtpFechaFin_Comp
            // 
            this.dtpFechaFin_Comp.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaFin_Comp.Location = new System.Drawing.Point(224, 45);
            this.dtpFechaFin_Comp.Name = "dtpFechaFin_Comp";
            this.dtpFechaFin_Comp.Size = new System.Drawing.Size(87, 20);
            this.dtpFechaFin_Comp.TabIndex = 20;
            // 
            // dtpFechaIni_Comp
            // 
            this.dtpFechaIni_Comp.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaIni_Comp.Location = new System.Drawing.Point(72, 45);
            this.dtpFechaIni_Comp.Name = "dtpFechaIni_Comp";
            this.dtpFechaIni_Comp.Size = new System.Drawing.Size(87, 20);
            this.dtpFechaIni_Comp.TabIndex = 19;
            // 
            // frmModificarDeposito
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(997, 548);
            this.Controls.Add(this.paTitulo);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.paCompensacion);
            this.Controls.Add(this.paReversaDeposito);
            this.Controls.Add(this.paConfirmarDeposito);
            this.MaximizeBox = false;
            this.Name = "frmModificarDeposito";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmModificarDeposito";
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.paTitulo.ResumeLayout(false);
            this.paTitulo.PerformLayout();
            this.paReversaDeposito.ResumeLayout(false);
            this.paReversaDeposito.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeposito)).EndInit();
            this.paConfirmarDeposito.ResumeLayout(false);
            this.paConfirmarDeposito.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepositoSinconfirmar)).EndInit();
            this.paCompensacion.ResumeLayout(false);
            this.paCompensacion.PerformLayout();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCompensacion)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label laTitulo;
        private System.Windows.Forms.CheckBox chkDepositoCompensacion;
        private System.Windows.Forms.CheckBox chkReversaDeposito;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel paTitulo;
        private System.Windows.Forms.Panel paReversaDeposito;
        private System.Windows.Forms.Button btnBuscaRevDep;
        private System.Windows.Forms.DataGridView dgvDeposito;
        private System.Windows.Forms.Label laFechaFin;
        private System.Windows.Forms.Label laFechaInicio;
        private System.Windows.Forms.DateTimePicker dtpFechaFinal_Rev;
        private System.Windows.Forms.DateTimePicker dtpFechaInicial_Rev;
        private System.Windows.Forms.Panel paConfirmarDeposito;
        private System.Windows.Forms.DataGridView dgvDepositoSinconfirmar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnBuscarDepositos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpFechaFin_Buscar;
        private System.Windows.Forms.DateTimePicker dtpFechaInicio_Buscar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnConfirmar;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Sel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnSalir_Rev;
        private System.Windows.Forms.Button btn_Confirmar_Rev;
        private System.Windows.Forms.DataGridViewCheckBoxColumn SelRev;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel paCompensacion;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnSalir_Comp;
        private System.Windows.Forms.Button btnGenerar_comp;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnBuscar_Comp;
        private System.Windows.Forms.DataGridView dgvCompensacion;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtpFechaFin_Comp;
        private System.Windows.Forms.DateTimePicker dtpFechaIni_Comp;
        private System.Windows.Forms.DataGridViewCheckBoxColumn SelComp;
        private System.Windows.Forms.DataGridViewTextBoxColumn nReferencia;
    }
}