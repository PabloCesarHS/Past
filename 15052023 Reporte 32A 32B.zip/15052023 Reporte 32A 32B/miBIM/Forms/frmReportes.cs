﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miBIM.Forms
{
    public partial class frmReportes : Form //UQMA Para realizar consultas de las operaciones realizadas
    {
        public frmReportes()
        {
            InitializeComponent();
        }

        private void frmReportes_Load(object sender, EventArgs e)
        {
            //para cargar los tipos de reporte:
            cb_TipoRep.Items.Add("Respuesta de Pago (PAR)");
            cb_TipoRep.Items.Add("Generación de Depósito");
            cb_TipoRep.Items.Add("Revertir Depósito");
            cb_TipoRep.Items.Add("Generación de Depósito por Compensación");
            cb_TipoRep.Items.Add("Agentes");

            cb_TipoRep.SelectedIndex = 0;

            cGenerarReportes oGReportes = new cGenerarReportes();
            dgvReporte.DataSource = oGReportes.Consultar_RptaPagoPAR(dtpFechaIni.Value, dtpFechaFin.Value);
            //Para dar formato a la celda Monto
            dgvReporte.Columns["Monto"].DefaultCellStyle.Format = "N2";
            dgvReporte.Columns["MontoRespuesta"].DefaultCellStyle.Format = "N2";

        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            dgvReporte.DataSource = null;

            cGenerarReportes oGReportes = new cGenerarReportes();

            if (cb_TipoRep.SelectedItem != null)
            {
                switch (cb_TipoRep.SelectedItem.ToString())
                {
                    case "Respuesta de Pago (PAR)":
                        dgvReporte.DataSource = oGReportes.Consultar_RptaPagoPAR(dtpFechaIni.Value, dtpFechaFin.Value);
                        //Para dar formato a la celda Monto
                        dgvReporte.Columns["Monto"].DefaultCellStyle.Format = "N2";
                        dgvReporte.Columns["MontoRespuesta"].DefaultCellStyle.Format = "N2";
                        break;
                    case "Generación de Depósito":
                        dgvReporte.DataSource = oGReportes.Consultar_DepGenerados(dtpFechaIni.Value, dtpFechaFin.Value);
                        //Para dar formato a la celda Monto
                        dgvReporte.Columns["Monto"].DefaultCellStyle.Format = "N2";
                        break;
                    case "Revertir Depósito":
                        dgvReporte.DataSource = oGReportes.Consultar_RevDepositos(dtpFechaIni.Value, dtpFechaFin.Value);
                        //Para dar formato a la celda Monto
                        dgvReporte.Columns["Monto"].DefaultCellStyle.Format = "N2";
                        break;
                    case "Generación de Depósito por Compensación":
                        dgvReporte.DataSource = oGReportes.Consultar_DepCompensados(dtpFechaIni.Value, dtpFechaFin.Value);
                        //Para dar formato a la celda Monto
                        dgvReporte.Columns["Monto"].DefaultCellStyle.Format = "N2";
                        break;
                    case "Agentes":
                        dgvReporte.DataSource = oGReportes.Consultar_BatchAgentes(dtpFechaIni.Value, dtpFechaFin.Value);
                        break;
                    default:
                        dgvReporte.Refresh();
                        break;
                }
            }
            else
            {
                MessageBox.Show("Seleccione un tipo de reporte", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
