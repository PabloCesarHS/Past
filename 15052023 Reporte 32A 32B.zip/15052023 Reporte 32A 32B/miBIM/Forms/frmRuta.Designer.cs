﻿namespace miBIM.Forms
{
    partial class frmRuta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.laTitulo = new System.Windows.Forms.Label();
            this.laTelefono = new System.Windows.Forms.Label();
            this.tbxRuta = new System.Windows.Forms.TextBox();
            this.btnSalir = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnRutaArchivo = new System.Windows.Forms.Button();
            this.btnRutaCarpeta = new System.Windows.Forms.Button();
            this.lbMensaje = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // laTitulo
            // 
            this.laTitulo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.laTitulo.AutoSize = true;
            this.laTitulo.BackColor = System.Drawing.Color.YellowGreen;
            this.laTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.laTitulo.ForeColor = System.Drawing.SystemColors.Control;
            this.laTitulo.Location = new System.Drawing.Point(268, 20);
            this.laTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laTitulo.Name = "laTitulo";
            this.laTitulo.Size = new System.Drawing.Size(57, 20);
            this.laTitulo.TabIndex = 0;
            this.laTitulo.Text = "Rutas";
            this.laTitulo.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // laTelefono
            // 
            this.laTelefono.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.laTelefono.AutoSize = true;
            this.laTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.laTelefono.Location = new System.Drawing.Point(29, 28);
            this.laTelefono.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laTelefono.Name = "laTelefono";
            this.laTelefono.Size = new System.Drawing.Size(63, 13);
            this.laTelefono.TabIndex = 1;
            this.laTelefono.Text = "Nueva ruta:";
            // 
            // tbxRuta
            // 
            this.tbxRuta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbxRuta.Location = new System.Drawing.Point(32, 43);
            this.tbxRuta.Margin = new System.Windows.Forms.Padding(2);
            this.tbxRuta.MaxLength = 0;
            this.tbxRuta.Name = "tbxRuta";
            this.tbxRuta.ReadOnly = true;
            this.tbxRuta.Size = new System.Drawing.Size(337, 20);
            this.tbxRuta.TabIndex = 1;
            // 
            // btnSalir
            // 
            this.btnSalir.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSalir.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnSalir.Location = new System.Drawing.Point(315, 16);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(2);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(166, 30);
            this.btnSalir.TabIndex = 14;
            this.btnSalir.Text = "&Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.laTitulo);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(615, 59);
            this.panel2.TabIndex = 16;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.btnGuardar);
            this.panel1.Controls.Add(this.btnSalir);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 166);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(615, 48);
            this.panel1.TabIndex = 20;
            // 
            // btnGuardar
            // 
            this.btnGuardar.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnGuardar.Location = new System.Drawing.Point(118, 16);
            this.btnGuardar.Margin = new System.Windows.Forms.Padding(2);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(166, 30);
            this.btnGuardar.TabIndex = 14;
            this.btnGuardar.Text = "&Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lbMensaje);
            this.panel3.Controls.Add(this.btnRutaArchivo);
            this.panel3.Controls.Add(this.btnRutaCarpeta);
            this.panel3.Controls.Add(this.tbxRuta);
            this.panel3.Controls.Add(this.laTelefono);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 59);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(615, 107);
            this.panel3.TabIndex = 24;
            // 
            // btnRutaArchivo
            // 
            this.btnRutaArchivo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnRutaArchivo.Location = new System.Drawing.Point(499, 41);
            this.btnRutaArchivo.Name = "btnRutaArchivo";
            this.btnRutaArchivo.Size = new System.Drawing.Size(104, 24);
            this.btnRutaArchivo.TabIndex = 20;
            this.btnRutaArchivo.Text = "Elegir archivo";
            this.btnRutaArchivo.UseVisualStyleBackColor = true;
            this.btnRutaArchivo.Click += new System.EventHandler(this.btnRutaArchivo_Click);
            // 
            // btnRutaCarpeta
            // 
            this.btnRutaCarpeta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnRutaCarpeta.Location = new System.Drawing.Point(386, 41);
            this.btnRutaCarpeta.Name = "btnRutaCarpeta";
            this.btnRutaCarpeta.Size = new System.Drawing.Size(95, 24);
            this.btnRutaCarpeta.TabIndex = 19;
            this.btnRutaCarpeta.Text = "Elegir carpeta";
            this.btnRutaCarpeta.UseVisualStyleBackColor = true;
            this.btnRutaCarpeta.Click += new System.EventHandler(this.btnRutaCarpeta_Click);
            // 
            // lbMensaje
            // 
            this.lbMensaje.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbMensaje.AutoSize = true;
            this.lbMensaje.ForeColor = System.Drawing.Color.Red;
            this.lbMensaje.Location = new System.Drawing.Point(29, 81);
            this.lbMensaje.Name = "lbMensaje";
            this.lbMensaje.Size = new System.Drawing.Size(16, 13);
            this.lbMensaje.TabIndex = 21;
            this.lbMensaje.Text = "...";
            // 
            // frmRuta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(615, 214);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmRuta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Rutas";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label laTitulo;
        private System.Windows.Forms.Label laTelefono;
        private System.Windows.Forms.TextBox tbxRuta;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnRutaArchivo;
        private System.Windows.Forms.Button btnRutaCarpeta;
        private System.Windows.Forms.Label lbMensaje;
    }
}