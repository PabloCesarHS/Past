﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Authentication;
using System.DirectoryServices;
using System.Configuration;
using System.Security.Principal;
using System.Runtime.InteropServices;
using CapaNegocio;

namespace miBIM
{
    public partial class Login : Form
    {
        int contador = 0;
        DateTime inicioSession;
        public String cDominio;

        [System.Runtime.InteropServices.DllImport("advapi32.dll")]
        public static extern bool LogonUser(string userName, string domainName, string password, int LogonType, int LogonProvider, ref IntPtr phToken);
        public Login()
        {
            InitializeComponent();
            Cargar_Datos_Usuario();
        }        

        public static bool ValidarClave(string adUsuario, string adClave)
        {
            ////Autenticacion con el Directorio Activo
            ////DirectoryEntry de = new DirectoryEntry(null, "DC=CMACDESA" + "\\" + adUsuario, adClave);
            //DirectoryEntry de = new DirectoryEntry("LDAP://CMACCUSCO", adUsuario, adClave, AuthenticationTypes.None);//RTYP 20160705 Se modifica Autenticacion  LVCH SE COMENTA PARA PRUEBA DE LOGGIN A SERVIDOR
            /*LVCH INICIO*/           
            try
            {
            DirectoryEntry entry = new DirectoryEntry("LDAP://CMACCUSCO", adUsuario, adClave, AuthenticationTypes.Secure);
            //DirectoryEntryConfiguration entryconfig = entry.Options;
            //MessageBox.Show("Server: " + entryconfig.GetCurrentServerName());
            //MessageBox.Show("Security Masks: " + entryconfig.SecurityMasks.ToString());
            //MessageBox.Show("Is Mutually autenticated: " + entryconfig.IsMutuallyAuthenticated().ToString());
            //MessageBox.Show("Page Size: " + entryconfig.PageSize.ToString());
            //MessageBox.Show("Passwords encoding: " + entryconfig.PasswordEncoding.ToString());
            //MessageBox.Show("Password Port: " + entryconfig.PasswordPort.ToString());
            //MessageBox.Show("Referral: " + entryconfig.Referral.ToString());            
            /*LVCH FIN*/            
                object o = entry.NativeObject;
                DirectorySearcher ds = new DirectorySearcher(entry);
                //ds.Filter = "samaccountname=" + adUsuario;
                ds.Filter = "(SAMAccountName=" + adUsuario + ")";
                ds.PropertiesToLoad.Add("cn");
                SearchResult sr = ds.FindOne();
                if (sr == null) throw new Exception();
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void Cargar_Datos_Usuario()
        {
            string vInformacion = "Carga Info";
            try
            {
                vInformacion = string.Concat(
                " Usuario: " + Environment.UserName.ToUpper(),
                " Ordenador: " + Environment.MachineName.ToString(),
                " [ " + cSistema.Modo.ToUpper() + " ] ",
                " Version: " + cSistema.Version.ToUpper());
            }
            catch
            {
                vInformacion = "Error en Carga Info";
            }
            lblInformacion.Text = vInformacion;
        }

        private Boolean ValidarClaveLocal(string adUsuario, string adClave, string adDominio)
        {
            bool issuccess = false;
            string username = GetloggedinUserName();

            if (username.ToLowerInvariant().Contains(adUsuario.Trim().ToLowerInvariant()) && username.ToLowerInvariant().Contains(adDominio.Trim().ToLowerInvariant()))
            {
                //issuccess = IsValidateCredentials(adUsuario.Trim(), adClave.Trim(), adDominio.Trim());
                issuccess = IsValidateCredentials(adUsuario.Trim(), adClave.Trim(), adDominio.Trim());
            }
            
            issuccess = true; /*    habiltar en desarollo para logeos sin validacion   */

            return issuccess;

            //if (issuccess)
            //    MessageBox.Show("Successfuly Login !!!");
            //else
            //    MessageBox.Show("User Name / Password / Domain is invalid !!!");
        }

        private string GetloggedinUserName()
        {
            System.Security.Principal.WindowsIdentity currentUser = System.Security.Principal.WindowsIdentity.GetCurrent();
            return currentUser.Name;
        }

        private bool IsValidateCredentials(string userName, string password, string domain)
        {
            IntPtr tokenHandler = IntPtr.Zero;
            bool isValid = LogonUser(userName, domain, password, 2, 0, ref tokenHandler);
            return isValid;
        }

        private void bSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bIngresar_Click(object sender, EventArgs e)
        {
            //ValidarClaveLocal(txtUsuario.Text, txtClave.Text, cDominio);
            //String cNombre="CMACCUSCO\\RTYP";
            String cUsuario=txtUsuario.Text;

            int nro = txtUsuario.Text.Trim().IndexOf("\\", 0);
            if (nro != -1)
                cUsuario = txtUsuario.Text.Substring(nro + 1, 4);                        

            //if (ValidarClaveLocal(txtUsuario.Text.Trim(), txtClave.Text, cDominio.Trim()))
             
            if (ValidarClaveLocal(cUsuario, txtClave.Text, cDominio.Trim()))
            {
                inicioSession = DateTime.Now;
                //Codigo = -1;
                Forms.frmMain oMain = new Forms.frmMain(txtClave.Text);
                txtClave.Clear();
                this.Hide();
                //oMain.Show();
                oMain.ShowDialog(Owner);
                //this.Dispose();
                this.Close();

            }
            else 
            {
                // 15/08/2017 UQMA INICIO Para loguear 
                if (ValidarClave(txtUsuario.Text, txtClave.Text) == true)
                {
                    inicioSession = DateTime.Now;
                    //Codigo = -1;                
                    Forms.frmMain oMain = new Forms.frmMain(txtClave.Text);
                    txtClave.Clear();
                    this.Hide();
                    oMain.ShowDialog(Owner);
                    this.Close();
                }
                else  // 15/08/2017 UQMA FIN  Para loguear 
                {
                    contador++;
                    if (contador == 4)
                        this.Close();
                    else
                    {
                        txtClave.Clear();
                        MessageBox.Show("Ingrese su usuario y contraseña de dominio correctos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txtClave.Focus();
                    }
                }

              
            }
        }

        

        private void Login_Load(object sender, EventArgs e)
        {
            //txtUsuario.Enabled = false;
            txtUsuario.Text = Environment.UserName.ToString().ToUpper();
            cDominio = Environment.UserDomainName.ToUpper();            
            txtClave.Focus();
        }

        private void bIngresar_KeyPress(object sender, KeyPressEventArgs e)
        {
            bIngresar_Click(sender, e);
        }

        private void txtClave_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                bIngresar_Click(sender, e);
            }
        }

        

       
    }
}
