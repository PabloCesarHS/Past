USE DBCMAC
GO

/* *********************************************************************************************************                       
NOMBRE             : spu_icor_PagaresColocaciones  
PROPOSITO          : LISTA LOS CREDITOS VIGENTES DE UNA PERSONA ASI COMO EL MONTO TOTAL DE LA CUOTA A PAGAR  
CREACION           :   
MODIFICADO     : 07/07/2011 VDCC MODIFICACION PARA MOSTRAR EL MONTO DE LA CUOTA REDONDEADA    
MODIFICADO			: 25/01/2019 MBCR Adecuaciones para no considerar el monto por concepto de inter�s moratorio
MODIFICADO			: 18/02/2019 MBCR Eliminar tabla temporal antes de volver a utilizarla / Crear tabla temporal sin usar INTO
MODIFICADO			: 01/08/2020 MBCR Se restringe cr�dito con bit de bloqueo en 1
					: 13/02/2024 IBPD Se quita el redondeo del monto de la cuota en pantalla inicial de POS
EJECUTAR EN     : DBCMAC  
MODO DE EJECUCION  : spu_icor_PagaresColocaciones '1061800027260'  
***********************************************************************************************************/  

ALTER PROC dbo.spu_icor_PagaresColocaciones @cPersCod      varchar(13)     
as    
BEGIN    
      --DECLARE @cPersCod     varchar(13)       SET @cPersCod = '1060100989657'    
      --DECLARE @cPersCod     varchar(13)       SET @cPersCod = '1060100656660'    
      --DECLARE @cPersCod     varchar(13)       SET @cPersCod = '1060100863156'    
      --DECLARE @cPersCod     varchar(13)       SET @cPersCod = '1060401071327'    
	SET NOCOUNT ON     
    
	--MBCR 20190125 - Adecuaciones para no considerar el monto por concepto de inter�s moratorio
	DECLARE @dFecha DATETIME, @dVenc DATETIME, @nDescuentaIntMor MONEY, @nDescuentaIntMorDebe MONEY, @nDiasAtraso INT, @cCtaCod VARCHAR(18)
	DECLARE @loop_counter INT, @item_category_counter INT

	SELECT @dFecha = cast( substring(nConsSisValor,7,4)+'-'              
		+ substring(nConsSisValor,4,2)+'-'              
		+ substring(nConsSisValor,1,2)+              
		+ ' ' + cast( datepart(hour,getdate()) as varchar(4))+':'              
		+ cast( datepart(minute,getdate())as varchar(4))+':'              
		+ cast( datepart(second,getdate())as varchar(4)) as datetime)              
	FROM ConstSistema WITH (NOLOCK)     
	WHERE nConsSisCod = 16

	DECLARE @tDatosCred TABLE (nId INT IDENTITY, cCtaCod VARCHAR(18), nPrestamo MONEY, cMoneda VARCHAR(10), cTipoCredito VARCHAR(10),
                               cCodMoneda VARCHAR(3), nPrdEstado INT, nSaldo MONEY, nNroProxCuota INT, nNroCalen INT)
	--MBCR 20190125 Fin - Adecuaciones para no considerar el monto por concepto de inter�s moratorio

	INSERT INTO @tDatosCred
	SELECT P.cCtaCod as cNroPagare, C.nMontoCol as nMontoDes,     
			cMoneda=Case When Substring(P.cCtaCod,9,1)='1' Then 'SOLES' Else'DOLARES' End,
			cTipoCredito= CASE cte.cConsDescripcion     
										WHEN 'CREDITO CORPORATIVO'THEN 'CORP'    
										WHEN 'CREDITO GRAN EMPRESA'THEN 'GRAN'    
										WHEN 'CREDITO DE MEDIANA EMPRESA'THEN 'MEDN'    
										WHEN 'CREDITO MEDIANA EMPRESA'THEN 'MEDN'    
										WHEN 'CREDITO DE PEQUE�A EMPRESA'THEN 'PEQU'    
										WHEN 'CREDITO PEQUE�A EMPRESA'THEN 'PEQU'    
										WHEN 'CREDITO DE MICRO EMPRESA'THEN 'MICR'    
										WHEN 'CREDITO MICRO EMPRESA'THEN 'MICR'    
										WHEN 'CREDITO CONSUMO REVOLVENTE'THEN 'REVO'    
										WHEN 'CREDITO CONSUMO NO REVOLVENTE'THEN 'NOREV'    
										WHEN 'CREDITO HIPOTECARIO DE VIVIENDA'THEN 'HIPO' ELSE '' END ,    
			cCodMon=Case When Substring(P.cCtaCod,9,1)='1' Then 'S/.' Else '$' End,    
			P.nPrdEstado, P.nSaldo, CC.nNroProxCuota, CC.nNroCalen    
	From Colocaciones C (NoLock)     
		Inner Join Producto P (NoLock) on P.cCtaCod=C.cCtaCod     
		Inner Join ProductoPersona PP (NoLock) on PP.cCtaCod=P.cCtaCod and PP.nPrdPersRelac=20     
		INNER JOIN ColocacCred CC (NoLock) on CC.cCtaCod=C.cCtaCod     
		INNER JOIN Constante cte (NoLock) on cc.nTipoCreditoBasilea = cte.nConsValor AND cte.nconscod = 9980
	Where PP.cPersCod=@cPersCod     
		and P.nPrdEstado in (2020,2021,2022,2030,2031,2032)
		and ISNULL(CC.bBloqueo,0) = 0 --MBCR 20200801: Se restringe cr�dito con bit de bloqueo en 1

	DECLARE @cPrevLang Varchar(10)
    SET @cPrevLang = @@LANGUAGE
    SET LANGUAGE 'Espa�ol'
	
	--MBCR 20190125 - Adecuaciones para no considerar el monto por concepto de inter�s moratorio

	SET @loop_counter = ISNULL((SELECT COUNT(nId) FROM @tDatosCred), 0)
	SET @item_category_counter = 1

	--MBCR 20190218 Eliminar tabla temporal antes de volver a utilizarla
	IF OBJECT_ID('tempdb.dbo.#tRespuesta') IS NOT NULL
		DROP TABLE #tRespuesta
	--MBCR 20190218 Crear tabla temporal antes de iniciar bucle
	CREATE TABLE dbo.#tRespuesta (
		cCtaCod			VARCHAR(18),
		nPrestamo		MONEY,
		cMoneda			VARCHAR(10),
		cTipoCredito	VARCHAR(10),
		Agencia			VARCHAR(40),
		cMetLiquidacion	VARCHAR(4),
		nPrdEstado		INT,
		cCodMoneda		VARCHAR(3),
		nSaldo			MONEY,
		Cuotas			INT,
		nCuota			INT,
		nDiasAtraso		INT,
		nMontoCuota		MONEY,
		nMontoDebe		MONEY,
		dVenc			DATETIME,
		cVenc			VARCHAR(6),
		nDiasAtrasoAcum	INT
	)
	WHILE @loop_counter > 0 AND @item_category_counter <= @loop_counter
	BEGIN
		SELECT	@cCtaCod = cCtaCod
		FROM	@tDatosCred
		WHERE	nId = @item_category_counter
		
		select @dVenc=ccal.dVenc              
		from ColocCalendario ccal WITH (NOLOCK)  
			inner join ColocacCred cc WITH (NOLOCK) on ccal.cCtaCod = cc.cCtaCod and ccal.nNroCalen = cc.nNroCalen and ccal.nCuota = cc.nNroProxCuota and ccal.nColocCalendApl = 1
		WHERE ccal.cCtaCod = @cCtaCod

		IF DATEDIFF(dd, @dVenc, @dFecha) = (SELECT COUNT(F.dFeriado)
										FROM Feriado F with(nolock) 
											INNER JOIN FeriadoAge FA with(nolock) ON F.dFeriado = FA.dFeriado
										WHERE F.dFeriado >= @dVenc
											--AND F.dFeriado < @dFecha
											AND F.dFeriado < CAST(@dFecha AS DATE) --MBCR 20200324 Solo se debe considerar fecha (no hora) para no incluir a la fecha de pago como feriado
											AND FA.cCodAge = SUBSTRING(@cCtaCod, 4, 2))
		BEGIN
			select @nDescuentaIntMor = nMonto, @nDescuentaIntMorDebe = nMonto - nMontoPagado, @nDiasAtraso = nDiasAtraso
			from ColocCalendDet cdet WITH (NOLOCK)  
				inner join ColocacCred cc WITH (NOLOCK) on cdet.cCtaCod = cc.cCtaCod and cdet.nNroCalen = cc.nNroCalen and cdet.nCuota = cc.nNroProxCuota and cdet.nColocCalendApl = 1
			WHERE cdet.cCtaCod = @cCtaCod and nPrdConceptoCod IN(1101,1108)
		END
		ELSE
		BEGIN
			SET @nDescuentaIntMor = 0
			SET @nDescuentaIntMorDebe = 0
			SET @nDiasAtraso = 0
		END
		
		--MBCR 20190218 Cambia Forma de insertar datos en tabla temporal
		INSERT INTO #tRespuesta
		SELECT   
		cCtaCod,nPrestamo, cMoneda, cTipoCredito, Agencia, cMetLiquidacion, nPrdEstado, cCodMoneda, nSaldo, Cuotas, nCuota, nDiasAtraso, 
		-- ======================= 20110707 VDCC CAMBIO POR REDONDEO =====================  
		-- 13/02/2024 IBPD - INICIO Se comenta redondeo de monto de cuota
		--(CASE WHEN (SELECT dbo.fn_icor_esUltimaCuota(cCtaCod))=0 /* no es ultima cuota */THEN   
		--	CASE WHEN ((nMontoCuota/0.05)%1>0) THEN           
		--	nMontoCuota + (((1-(nMontoCuota/0.05)%1)*0.1)/2)           
		--	ELSE nMontoCuota  
		--	END  
		--ELSE /* ES ULTIMA CUOTA */  
		--CASE WHEN ((nMontoCuota/0.05)%1>0) THEN             
		--	nMontoCuota - ((((nMontoCuota/0.05)%1)*0.1)/2)           
		--	ELSE nMontoCuota  
		--END    
		--END) - @nDescuentaIntMor AS nMontoCuota,
		-- 13/02/2024 IBPD - FIN Se comenta redondeo de monto de cuota
		nMontoCuota, --13/02/2024 IBPD - Se quita redondeo a variable nMontoCuota
		-- ======================= END 20110707 VDCC CAMBIO POR REDONDEO =====================  
		(nMontoDebe - @nDescuentaIntMorDebe) nMontoDebe, dVenc, cVenc, nDiasAtrasoAcum
		--INTO #tRespuesta
		FROM   
		(  
		SELECT cCtaCod, nPrestamo, cMoneda, cTipoCredito, Agencia, cMetLiquidacion, nPrdEstado, cCodMoneda, nSaldo, Cuotas, nCuota, nDiasAtraso,           
			[nMontoCuota] =  SUM(nMontoC), [nMontoDebe] = SUM(nMontoD), dVenc, cVenc, nDiasAtrasoAcum    
		FROM (    
		select distinct t0.cCtaCod, t0.nPrestamo, t0.cMoneda, t0.cTipoCredito,     
			[Agencia] = ag.cAgeDesCorta, CC.cMetLiquidacion,     
			t0.nPrdEstado, t0.cCodMoneda, --t0.nNroCalen,    
			t0.nSaldo, [Cuotas] = Max(CDet.nCuota), [nCuota] = t0.nNroProxCuota, CC.nDiasAtraso,    
			[nMontoC] =  CDet1.nMonto, [nMontoD] = CDet1.nMonto-CDet1.nMontoPagado,    
			[dVenc] = MIN(CCal.dVenc), [cVenc] = CONVERT(VARCHAR(6), MIN(CCal.dVenc), 107 ),    
			CC. nDiasAtrasoAcum    
		from producto prd    
			left join Colocaciones Col     With (Nolock) on Prd.cCtaCod = Col.cCtaCod     
			left join ColocacCred CC       With (Nolock) on Prd.cCtaCod = CC.cCtaCod     
			left join ColocCalendDet CDet1   With (Nolock) on Prd.cCtaCod = CDet1.cCtaCod and CC.nNroCalen = CDet1.nNroCalen and CDet1.nColocCalendApl = 1    
							AND CDet1.nCuota = CC.nNroProxCuota--and CDet.nPrdConceptoCod = 1000 and CDet.nMontoPagado <> 0      --     
			left join ColocCalendario CCal With (Nolock) on Prd.cCtaCod = CCal.cCtaCod and CC.nNroCalen = CCal.nNroCalen and CCal.nColocCalendApl = 1 AND CCal.nColocCalendEstado = 0 -- AND CCal.nCuota>= CC.nNroProxCuota    
			left join ColocCalendDet CDet   With (Nolock) on Prd.cCtaCod = CDet.cCtaCod and CC.nNroCalen = CDet.nNroCalen and CDet.nColocCalendApl = CCal.nColocCalendApl     
							AND CCal.nCuota = CDet.nCuota--and CDet.nPrdConceptoCod = 1000 and CDet.nMontoPagado <> 0   --     
			left join Agencias ag             With (Nolock) on SUBSTRING(prd.cCtaCod, 4,2) = ag.cAgeCod    
			INNER JOIN @tDatosCred t0 ON t0.cCtaCod = prd.cctacod AND t0.nId = @item_category_counter
		----where prd.cctacod = (SELECT cCtaCod FROM @tDatosCred)     
		group by Prd.nPrdEstado , CC.nDiasAtraso, CC. nDiasAtrasoAcum , CC.cMetLiquidacion ,     
			ag.cAgeDesCorta , t0.cCtaCod, t0.cCtaCod, t0.nPrestamo, t0.cMoneda, t0.cTipoCredito,     
			t0.cCodMoneda, t0.nPrdEstado, t0.nSaldo, t0.nNroProxCuota, t0.nNroCalen    
			, CDet1.nNroCalen, CDet1.nCuota, CDet1.nMonto, CDet1.nMontoPagado    
		--ORDER BY CC.nDiasAtraso desc    
		) tbl    
		GROUP BY cCtaCod, nPrestamo, cMoneda, cTipoCredito, Agencia, cMetLiquidacion, nPrdEstado, cCodMoneda,     
			nSaldo, Cuotas, nCuota, nDiasAtraso, dVenc, cVenc, nDiasAtrasoAcum    
		) ztb  
			ORDER BY nDiasAtraso desc

		SET @item_category_counter = @item_category_counter + 1
	END
	
	SELECT * FROM #tRespuesta
	--DROP TABLE #tRespuesta	  --MBCR 20190218 Se eliminar� el principio

	--MBCR 20190125 Fin - Adecuaciones para no considerar el monto por concepto de inter�s moratorio

 --  SELECT   
 -- cCtaCod,nPrestamo, cMoneda, cTipoCredito, Agencia, cMetLiquidacion, nPrdEstado, cCodMoneda, nSaldo, Cuotas, nCuota, nDiasAtraso, 
 -- -- ======================= 20110707 VDCC CAMBIO POR REDONDEO =====================  
 -- CASE WHEN (SELECT dbo.fn_icor_esUltimaCuota(cCtaCod))=0 /* no es ultima cuota */THEN   
 --     CASE WHEN ((nMontoCuota/0.05)%1>0) THEN             
 --       nMontoCuota + (((1-(nMontoCuota/0.05)%1)*0.1)/2)           
 --     ELSE nMontoCuota  
 --     END  
 --   ELSE /* ES ULTIMA CUOTA */  
 --   CASE WHEN ((nMontoCuota/0.05)%1>0) THEN             
 --       nMontoCuota - ((((nMontoCuota/0.05)%1)*0.1)/2)           
 --     ELSE nMontoCuota  
 --   END    
 -- END AS nMontoCuota,  
 -- -- ======================= END 20110707 VDCC CAMBIO POR REDONDEO =====================  
 -- nMontoDebe, dVenc, cVenc, nDiasAtrasoAcum   
 --  FROM   
 --  (  
 --   SELECT cCtaCod, nPrestamo, cMoneda, cTipoCredito, Agencia, cMetLiquidacion, nPrdEstado, cCodMoneda, nSaldo, Cuotas, nCuota, nDiasAtraso,           
 --    [nMontoCuota] =  SUM(nMontoC), [nMontoDebe] = SUM(nMontoD), dVenc, cVenc, nDiasAtrasoAcum    
 --   FROM (    
 --   select distinct t0.cCtaCod, t0.nPrestamo, t0.cMoneda, t0.cTipoCredito,     
 --      [Agencia] = ag.cAgeDesCorta, CC.cMetLiquidacion,     
 --      t0.nPrdEstado, t0.cCodMoneda, --t0.nNroCalen,    
 --      t0.nSaldo, [Cuotas] = Max(CDet.nCuota), [nCuota] = t0.nNroProxCuota, CC.nDiasAtraso,    
 --      [nMontoC] =  CDet1.nMonto, [nMontoD] = CDet1.nMonto-CDet1.nMontoPagado,    
 --      [dVenc] = MIN(CCal.dVenc), [cVenc] = CONVERT(VARCHAR(6), MIN(CCal.dVenc), 107 ),    
 --      CC. nDiasAtrasoAcum    
 --   from producto prd    
 --       left join Colocaciones Col     With (Nolock) on Prd.cCtaCod = Col.cCtaCod     
--    left join ColocacCred CC       With (Nolock) on Prd.cCtaCod = CC.cCtaCod     
 --       left join ColocCalendDet CDet1   With (Nolock) on Prd.cCtaCod = CDet1.cCtaCod and CC.nNroCalen = CDet1.nNroCalen and CDet1.nColocCalendApl = 1    
 --                      AND CDet1.nCuota = CC.nNroProxCuota--and CDet.nPrdConceptoCod = 1000 and CDet.nMontoPagado <> 0      --     
 --       left join ColocCalendario CCal With (Nolock) on Prd.cCtaCod = CCal.cCtaCod and CC.nNroCalen = CCal.nNroCalen and CCal.nColocCalendApl = 1 AND CCal.nColocCalendEstado = 0 -- AND CCal.nCuota>= CC.nNroProxCuota    
 --       left join ColocCalendDet CDet   With (Nolock) on Prd.cCtaCod = CDet.cCtaCod and CC.nNroCalen = CDet.nNroCalen and CDet.nColocCalendApl = CCal.nColocCalendApl     
 --                      AND CCal.nCuota = CDet.nCuota--and CDet.nPrdConceptoCod = 1000 and CDet.nMontoPagado <> 0   --     
 --       left join Agencias ag             With (Nolock) on SUBSTRING(prd.cCtaCod, 4,2) = ag.cAgeCod    
 --       INNER JOIN @tDatosCred t0 ON t0.cCtaCod = prd.cctacod    
 --   ----where prd.cctacod = (SELECT cCtaCod FROM @tDatosCred)     
 --   group by Prd.nPrdEstado , CC.nDiasAtraso, CC. nDiasAtrasoAcum , CC.cMetLiquidacion ,     
 --       ag.cAgeDesCorta , t0.cCtaCod, t0.cCtaCod, t0.nPrestamo, t0.cMoneda, t0.cTipoCredito,     
 --      t0.cCodMoneda, t0.nPrdEstado, t0.nSaldo, t0.nNroProxCuota, t0.nNroCalen    
 --      , CDet1.nNroCalen, CDet1.nCuota, CDet1.nMonto, CDet1.nMontoPagado    
 --   --ORDER BY CC.nDiasAtraso desc    
 --   ) tbl    
 --   GROUP BY cCtaCod, nPrestamo, cMoneda, cTipoCredito, Agencia, cMetLiquidacion, nPrdEstado, cCodMoneda,     
 --       nSaldo, Cuotas, nCuota, nDiasAtraso, dVenc, cVenc, nDiasAtrasoAcum    
 --  ) ztb  
 --     ORDER BY nDiasAtraso desc     
    
      SET LANGUAGE @cPrevLang    
      SET NOCOUNT OFF     
END 

GO