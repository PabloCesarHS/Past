USE DBCMAC
GO

/* ***************************************************************************************************************************    
Nombre      : spu_icor_ProcPagoCuotaFij
Proposito   :  
Creacion    :   
-------------------------------------------------------------------------------------------------------------------------------
Modificado  : 01/12/2010 VDCC MODIFICACION DE LAS VALIDACIONES EN LOS TOPES MAXIMO Y MINIMO DE LA CTA DEL ESTABLECIMIENTO
        : VRCA 20110401 se modific� el tipo de dato para el ITF soportando 5 decimales         
        : VRCA 20110408 Control Maximo de movimientos recurrentes        
        : VRCA 20110509 Se aplica la funci�n de tratamiento de ITF a 2 decimales con redondeo de 0.05 centimos      
        : 08/07/2011 VDCC SE REALIZA REDONDEO PARA EL MONTO DE RETIRO DEL ESTABLECIMIENTO       
        : 07/12/2011 VDCC MODIFICACION EN CONTROL DE LIMITES SE MODIFICO LIMITE INFERIOR DE PAGO DE CREDITOS A >= LIMITE INFERIOR DE PAGO DE CREDITOS  
        : 20/06/2012 VRCA - MOHE - Control de Monto de bloqueo parcial en cuenta del establecimiento  
        : 22/01/2013 VDCC CONTROL QUE NO SALTE CUOTAS EN PAGO DE CUOTAS  
        : 28/01/2013 VDCC SE Fuerza la aplicacion a enviar un error al aplicativo java de Cajero Corresponsal
        : 03/06/2013 VRCA Evitar error "Cannot roll back TCF0. No transaction or savepoint of that name was found."
		: 21/07/2023 IBPD Se agrega control de cuenta de Agente Corresponsal bloqueada (1100, 1200)
		: 13/02/2024 IBPD Se uniformiza monto voucher con monto POS y Estado de Cuenta Agente
*************************************************************************************************************************** */  
ALTER PROCEDURE [dbo].[spu_icor_ProcPagoCuotaFij] 
      @psCtaCod VARCHAR(18),    
      @nNroCuota INT,  -- Nro. de cuota  
      @nCapital MONEY, -- Monto Pagado por capital  
      @nInteres MONEY, -- Intereses compensatorio  
      @nInteresGracia MONEY, -- Nuevo Interes de Gracia *  
      @nIntReprog MONEY,  -- Interes reprogramado *  
      @nIntSuspenso MONEY,   -- interes en Suspenso *  
      @nMora MONEY, -- Mora  
      @nNroDiasMora INT, -- Nro. de d�as de mora  
      @nGastos MONEY, -- Gastos varios *  
      @nITF DECIMAL(18,5), --Money, -- ITF por la transacci�n    --VRCA 20110401 se modific� el tipo de dato para el ITF soportando 5 decimales         
      @nCalPago MONEY, -- Monto total cuota *    
      @dFechaProceso DATETIME,    
      @cAgencia CHAR(2),    
      @cUsuarioHiper CHAR(4),    
      @cTxTxnNumber VARCHAR(15),    
      @nRpta INT OUTPUT,  
      @nzEsUltimaCuota INT OUTPUT   -- 20110715 VDCC INDICADOR SI LA CUOTA ACTUAL ES LA ULTIMA CUOTA         
AS    
BEGIN     
       --DECLARE @cUsuarioHiper char(4) SET @cUsuarioHiper = '0017'      
       --DECLARE @psCtaCod VARCHAR(18), @nNroCuota INT, @nCapital MONEY, @nInteres MONEY, @nInteresGracia MONEY, @nIntReprog MONEY, @nIntSuspenso MONEY, @nMora     MONEY, @nNroDiasMora INT, @nGastos MONEY, @nITF DECIMAL, @nCalPago MONEY, @dFechaProceso DATETIME, @cAgencia CHAR(2), @cUsuarioHiper CHAR(4), @cTxTxnNumber VARCHAR(15), @nRpta INT, @nzEsUltimaCuota       INT
       ----SET @psCtaCod = '106011011010114262' SET @nNroCuota = 4 SET @nCapital = 916.97 SET @nInteres = 948.03 SET @nInteresGracia = 0 SET @nIntReprog = 0 SET @nIntSuspenso = 0 SET @nMora = 0 SET @nNroDiasMora = -22 SET @nGastos = 36.3 SET @nITF = 0.05 SET @nCalPago = 1901.35 SET @dFechaProceso = '2013-06-03 15:43:48.0' SET @cAgencia = '01' SET @cUsuarioHiper = '0001' SET @cTxTxnNumber = '002991'
       --SET @psCtaCod = '106154011001540149' SET @nNroCuota = 36 SET @nCapital = 221.55 SET @nInteres = 20.18 SET @nInteresGracia = -116 SET @nIntReprog = 0 SET @nIntSuspenso = 0 SET @nMora = 0 SET @nNroDiasMora = 0 SET @nGastos = 22 SET @nITF = 0 SET @nCalPago = 263.7 SET @dFechaProceso = '2013-06-03 17:48:08.0' SET @cAgencia = '01' SET @cUsuarioHiper = '0001' SET @cTxTxnNumber = '003203'
       SET NOCOUNT ON    
       DECLARE @nEnTransaccion INT             SET @nEnTransaccion = 0           --VRCA 20130603 - Evitar error "Cannot roll back TCF0. No transaction or savepoint of that name was found."
       --BEGIN TRAN TCF0   

       ----------------------------------------------------      
       -- 0. Declaraciones de Variables de TOPES      
       ----------------------------------------------------      
       DECLARE @nTopeCantOpeDia INT, @nTopeMax_CtaEst MONEY, @nTopeMin_CtaEst MONEY, @nTopeMaxOpe MONEY, @nTopeMinOpe MONEY, @nTopeMaxDiario MONEY

       -- ========= BEGIN 20110715 VDCC DECLARACION DE VARIABLE PARA VERIFICAR SI ES LA ULTIMA CUOTA ==============        
       SELECT @nzEsUltimaCuota=dbo.fn_icor_esUltimaCuota(@psCtaCod)      
       -- ========= END 20110715 VDCC DECLARACION DE VARIABLE PARA VERIFICAR SI ES LA ULTIMA CUOTA ==============       

       -- Obtener el Usuario de RRHH correspondiente al usuario del Hiper    
       DECLARE @cUsuario VARCHAR(8)    
       SELECT @cUsuario = cUserRRHH FROM dbo.UsuariosPOS WHERE cUserHiper = @cUsuarioHiper    
       --PRINT @cUsuario       

       SELECT @nTopeCantOpeDia = nCantPagoCredDia, @nTopeMinOpe = nMontoMinPagoCredOpe, @nTopeMaxOpe = nMontoMaxPagoCredOpe,       
                @nTopeMaxDiario = nMontoMaxPagoCredDia, @nTopeMin_CtaEst = nMontoMinEstablecimiento, @nTopeMax_CtaEst = nMontoMaxEstablecimiento      
       FROM posinfoestablecimiento       
       WHERE cUser = @cUsuario --'C' + SUBSTRING(@cUsuarioHiper,2,3)      

       ----------------------------------------------------      
       -- 1. Declaracion Variables de Contexto      
       ----------------------------------------------------         

       DECLARE @MiPagoCuota TABLE (dFecMov VARCHAR(12), dHorMov VARCHAR(12), cTipoCredito VARCHAR(50), cPersNombre VARCHAR(250), 
                                                 cMoneda VARCHAR(10), nMontoDes MONEY, nSaldo MONEY, dProximaFecha DATETIME, nCapital MONEY, 
                                                 nIntComp MONEY, nIntCompVenc MONEY, nIntMor MONEY, nGastos MONEY, nIntGracia MONEY, nIntSusRep MONEY, 
                                                 nITF DECIMAL(18,5)) --MONEY)


       DECLARE @cFecha VARCHAR(12),       @cHora VARCHAR(12),  @cPersona VARCHAR(250)--,@dProxFecPago DATETIME --,     @pnMontoITF money    
       , @nCantMovsPOS INT         -- VRCA 20110408 Control Maximo de movimientos recurrentes      

       DECLARE    
       @pnMonto MONEY,                         @cMetLiq VARCHAR(4),       @pnMontoITF DECIMAL(18,5), --money,        
       @cOpeCod VARCHAR(6),       @cOpeCodITF VARCHAR(6),           @cMovDesc VARCHAR(550)    

       DECLARE    
       @cMovNro VARCHAR(25),             @nMovNro INT,                     @dFechaHora DATETIME,    
       @nAgenciaCerrada INT,             @nEstado INT,                     @DeudaTotal MONEY,    
       @cProducto VARCHAR(3),            @dProxFecPago DATETIME,  

       @ErrorCode INT,                         @RowCount INT,                           @InTrans INT,    
       @nCantDisp MONEY   -- VRCA 20100913 Control de Tope M�ximo de Operaciones en Cuenta del Establecimiento    

       IF OBJECT_ID('tempdb..#credpend') IS NOT NULL DROP TABLE #credpend    
       CREATE TABLE #credpend (    
          id INT IDENTITY(1,1) NOT NULL
          , cCtaCod VARCHAR(18)
          , nNroCalen INT
          , nCuota INT
          , nPrdConceptoCod INT
          , nMonto MONEY 
          , nMontoPagado MONEY
          , nOrden INT
          , dVenc DATETIME
          , cMetLiquidacion CHAR(4)
          , lId SMALLINT
          )    

       DECLARE @cCtaCod VARCHAR(18), @nMonedaEst SMALLINT, @nMontoCalc MONEY, @ErrorDesc VARCHAR(50), @nResp INT     

       ----------------------------------------------------      
       -- 2. Recuperacion Variables de Contexto      
       ----------------------------------------------------    

       --SET dateformat dmy    
       --SET @dFechaHora = dbo.icor_FechaHoraSis(@dFechaProceso)    

       -- sacar fecha con que se inicio el sistema    
       SELECT @dFechaProceso  =  CAST(SUBSTRING(nConsSisValor,7,4)+'-'    
                                               + SUBSTRING(nConsSisValor,4,2)+'-'    
                                               + SUBSTRING(nConsSisValor,1,2)+    
                                               + ' ' + CAST( DATEPART(HOUR,@dFechaProceso) AS VARCHAR(4) )+':'    
                                               + CAST(DATEPART(MINUTE,@dFechaProceso)AS VARCHAR(4))+':'    
                                               + CAST(DATEPART(SECOND,@dFechaProceso)AS VARCHAR(4)) AS DATETIME)
       FROM ConstSistema WITH(NOLOCK) 
       WHERE nConsSisCod = 16       

       SET @cProducto = SUBSTRING(@psCtaCod,6,3)

       --VRCA 20110401 se modific� el tipo de dato para el ITF soportando 5 decimales        
       ----SELECT @pnMontoITF = ROUND((@nCalPago * CAST(nConsSisvalor AS MONEY))/(CAST(nConsSisvalor AS MONEY) + 1), 2, 2)    
       ----FROM ConstSistema     
       ----WHERE nConsSisCod = 156    
       --SELECT @pnMontoITF = ROUND((@nCalPago * CAST(nConsSisvalor AS DECIMAL(18,5)))/(CAST(nConsSisvalor AS DECIMAL(18,5)) + 1), 2, 2)    
       SELECT @pnMontoITF = @nCalPago * CAST(nConsSisvalor AS DECIMAL(18,5))      
       FROM ConstSistema WITH(NOLOCK) 
       WHERE nConsSisCod = 156        

       SELECT @nITF = dbo.spu_icor_ITF_5Centimos(@nITF)                          --VRCA 20110509 - Se aplica la funci�n de tratamiento de ITF a 2 decimales con redondeo de 0.05 centimos      
       SELECT @pnMontoITF = dbo.spu_icor_ITF_5Centimos(@pnMontoITF) --VRCA 20110509 - Se aplica la funci�n de tratamiento de ITF a 2 decimales con redondeo de 0.05 centimos      

       --FIN VRCA 20110401 se modific� el tipo de dato para el ITF soportando 5 decimales        

       SET @pnMonto = @nCalPago - @pnMontoITF    
       --SELECT @nAgenciaCerrada = count(*) FROM MovDiario WHERE cMovNro LIKE convert(varchar(8), @dFechaHora,112)+'%' AND cOpeCod = '902001' AND nMovFlag = 0 AND Substring(cMovNro, 18,2) = @cAgencia    
       SELECT @nAgenciaCerrada = COUNT(*) FROM MovDiario WITH (NOLOCK) WHERE cMovNro LIKE CONVERT(VARCHAR(8), @dFechaProceso,112)+'%' AND cOpeCod = '902001' AND nMovFlag = 0 AND SUBSTRING(cMovNro, 18,2) = @cAgencia
       SELECT @nEstado = nPrdEstado        
       FROM Producto WITH (NOLOCK) WHERE cCtaCod = @psCtaCod    
       SELECT @cMetLiq = cMetLiquidacion FROM colocacCred WITH (NOLOCK) WHERE cCtaCod = @psCtaCod    

       -- VRCA 20100913 - Control de Tope M�ximo de Operaciones en Cuenta del Cliente    
       SELECT @nCantDisp = nSaldoDisp     
       FROM Captaciones c WITH(NOLOCK)    
       INNER JOIN POSInfoEstablecimiento e WITH(NOLOCK) ON c.cCtaCod = e.cCtaCod    
       WHERE e.cCtaCod = @psCtaCod    

       -- VRCA 20100917 - Control de Movimientos mayores a los existentes en las cuentas    
       DECLARE @cCtaCodEst VARCHAR(18), @nSaldoCredUsu MONEY, @nSaldoCtaEst MONEY,   
       @nBloqueoParcialEst   MONEY --VRCA - MOHE 20120620 - Control de Monto de bloqueo parcial en cuenta del establecimiento
	   ,@nPrdEstadoEst INT --21/07/2023 IBPD Se agrega variable para control de cuenta de Agente Corresponsal bloqueada (1100, 1200, 1300, 1400)
       SELECT @cCtaCodEst = cCtaCod FROM POSInfoEstablecimiento WITH(NOLOCK) WHERE cUser = @cUsuario AND nMoneda = 1    
       SELECT @nSaldoCtaEst = nSaldoDisp,  
                @nBloqueoParcialEst = ISNULL(nBloqueoParcial, 0) --VRCA - MOHE 20120620 - Control de Monto de bloqueo parcial en cuenta del establecimiento  
       FROM Captaciones WITH(NOLOCK) WHERE cCtaCod = @cCtaCodEst
	   SELECT @nPrdEstadoEst = nPrdEstado FROM DBCMAC..Producto WITH(NOLOCK) WHERE cCtaCod = @cCtaCodEst --21/07/2023 IBPD Se obtiene estado de cuenta de establecimiento

       SELECT @nSaldoCredUsu = SUM(cdet.nMonto - cdet.nMontoPagado)    
       FROM Colocaciones col WITH(NOLOCK)
             INNER JOIN ColocacCred cc WITH(NOLOCK) ON col.cCtaCod = cc.cCtaCod    
              INNER JOIN ColocCalendario ccal WITH(NOLOCK) ON ccal.cCtaCod = col.cCtaCod AND ccal.nNroCalen = cc.nNroCalen AND ccal.nColocCalendApl = 1 AND ccal.nColocCalendEstado = 0    
              INNER JOIN ColocCalendDet cdet WITH(NOLOCK) ON cdet.cCtaCod = col.cCtaCod AND cdet.nNroCalen = cc.nNroCalen AND cdet.nColocCalendApl = ccal.nColocCalendApl AND ccal.nCuota = cdet.nCuota
       WHERE col.cCtaCod = @psCtaCod     

       INSERT INTO #credpend    
       EXEC dbo.icor_RecuperaCalendarioConceptosPendientes @psCtaCod, @cMetLiq    

       SELECT @DeudaTotal = (SUM(nMonto) - SUM(nMontoPagado)) FROM #credpend     

       SELECT     
             @nRpta = 0 --,   
             --@nCapital = 0,    
             --@nInteres = 0,     
             --@nInteresVenc = 0,     
             --@nMora = 0,     
             --@nGastos = 0,     
             --@nInteresGracia = 0,     
             --@nIntSuspenso = 0  

       --PRINT @cCtaCodEst    
       ----------------------------------------------------    
       -- 2. Control de Moneda    
       ----------------------------------------------------      

       SET @nMonedaEst = CAST(SUBSTRING(@psCtaCod, 9, 1) AS INT)    

       --Validar Ambas Cuentas    
       SELECT @cCtaCod = cCtaCod --, @nMonedaEst = nMoneda    
       FROM dbo.POSInfoEstablecimiento WITH(NOLOCK) WHERE cUser = @cUsuario AND cAgeCod = @cAgencia AND nMoneda = @nMonedaEst    

       --Control de Montos por c/cuenta    
       DECLARE @nMonedaProc SMALLINT    
       SET @nMonedaProc = CAST(SUBSTRING(@psCtaCod,9,1) AS INT )    

       IF (@nMonedaProc<>@nMonedaEst)    
       BEGIN   
             DECLARE @TpCambio MONEY, @cHoy VARCHAR(10)    
             SELECT @cHoy = nConsSisValor FROM ConstSistema WITH(NOLOCK)WHERE nConsSisCod = 15    
             SELECT @TpCambio = nValFijo FROM TipoCambio WITH(NOLOCK) WHERE dFecCamb = RIGHT(@cHoy,4) + SUBSTRING(@cHoy,4,2) + LEFT(@cHoy,2)    

             IF (@nMonedaProc=1 AND @nMonedaEst=2)    
                    SET @nMontoCalc = ROUND(@nCalPago / @TpCambio,2)    
             IF (@nMonedaProc=2 AND @nMonedaEst=1)    
                    SET @nMontoCalc = ROUND(@nCalPago * @TpCambio,2)    
       END     
       ELSE    
       BEGIN     
             SET @nMontoCalc = @nCalPago    
       END     

       ----------------------------------------------------    
       -- 3. Validacion (Negocio)    
       ----------------------------------------------------         

       --VRCA 20110408 Control Maximo de movimientos recurrentes        
       SELECT @nCantMovsPOS = SUM(ISNULL(bPagoCuota,0)) FROM dbo.POSMovimientos WITH(NOLOCK)
       WHERE cUser = @cUsuario AND cCtaCod = @psCtaCod AND CONVERT(VARCHAR(8), cFecha, 112) = CONVERT(VARCHAR(8), @dFechaProceso, 112) --AND bRetiro = 1  -- AND cCtaCod = @cCuenta

       SELECT @nCantMovsPOS = ISNULL(@nCantMovsPOS,0)      
       IF ( @nCantMovsPOS >= @nTopeCantOpeDia)  --5)         
       BEGIN      
             SET @nRpta = 12 -- SE SOBREPASO EL M�XIMO DE OPERACIONES PERMITIDAS (5)      
             SET @ErrorDesc = 'SE SOBREPASO EL M�XIMO DE OPERACIONES PERMITIDAS (5)'      
       END      
       --FIN VRCA 20110408 Control Maximo de movimientos recurrentes        
 
       IF @nAgenciaCerrada <> 0 --Agencia Cerrada    
       BEGIN     
        SET @nRpta = 2 -- AGENCIA YA HIZO CIERRE    
        SET @ErrorDesc = 'AGENCIA YA HIZO CIERRE'    
        --GOTO ProcExit    
       END    
 
       IF @nCalPago > @nTopeMaxOpe --1500 -- Monto menor al minimo.    
       BEGIN     
        SET @nRpta = 10 -- MONTO MAYOR AL PERMITIDO    
        SET @ErrorDesc = 'MONTO MAYOR AL PERMITIDO'    
        --RETURN @nRpta     
        --GOTO ProcExit    
       END    
 
       -- VRCA 20100913 - Bloqueo de Operaciones en D�lares    
       IF (SUBSTRING(@psCtaCod, 9, 1) = '2')    
       BEGIN     
        SET @nRpta = 90 -- BLOQUEO DE OPERACI�N EN D�LARES    
        SET @ErrorDesc = 'BLOQUEO DE OPERACI�N EN D�LARES'   
        --RETURN @nRpta     
        --GOTO ProcExit    
       END     

       --SELECT @nRpta, @ErrorDesc, @cUsuario, @nCalPago, (@nSaldoCtaEst - 5 ), @nSaldoCtaEst  
       IF @nRpta = 0    
       BEGIN     
        -- IF @pnMonto <= @nTopeMinOpe --5 -- Monto menor al minimo.      07/12/2011 VDCC  COMENTADO    
        IF @pnMonto < @nTopeMinOpe --5 -- Monto menor al minimo.      07/12/2011 VDCC  CAMBIO PARA INTEGRAR AL LIMITE INFERIOR DENTRO DE LA CONDICION   
        BEGIN     
                    SET @nRpta = 9 -- MONTO MENOR AL MINIMO    
                    SET @ErrorDesc = 'MONTO MENOR AL MINIMO'    
                    --RETURN @nRpta     
                    --GOTO ProcExit    
        END    
 
        -- VRCA 20100913 - Control de Tope M�ximo de Operaciones en Cuenta del Establecimiento    
        IF ( @nSaldoCtaEst >= @nTopeMax_CtaEst ) --30000 ) -- VDCC 20101201 actualizacion en monto maximo permitido en la cta del establecimiento   
        BEGIN     
                    SET @nRpta = 13 -- SE LLEG� AL M�XIMO DEL MONTO PERMITIDO EN LA CUENTA DEL ESTABLECIMIENTO    
                    SET @ErrorDesc = 'SE LLEG� AL M�XIMO DEL MONTO PERMITIDO EN LA CUENTA DEL ESTABLECIMIENTO'     
                    --RETURN @nRpta     
                    --GOTO ProcExit    
        END     
 
        -- VRCA 20100920 - Control de Tope Minimo de Operaciones en Cuenta del Establecimiento    
        --IF  ( @nSaldoCtaEst <= @nTopeMin_CtaEst ) --20)       --VRCA - MOHE 20120620 - Control de Monto de bloqueo parcial en cuenta del establecimiento -- VDCC 20101201 actualizacion en monto minimo permitido en la cta del establecimiento    
        IF ( (@nSaldoCtaEst - @nBloqueoParcialEst - @pnMonto) < @nTopeMin_CtaEst) --VRCA - MOHE 20120620 - Control de Monto de bloqueo parcial en cuenta del establecimiento  
        BEGIN     
                    SET @nRpta = 14 -- SE LLEG� AL MINIMO DEL MONTO PERMITIDO EN LA CUENTA DEL ESTABLECIMIENTO    
                    SET @ErrorDesc = 'SE LLEG� AL MINIMO DEL MONTO PERMITIDO EN LA CUENTA DEL ESTABLECIMIENTO'     
        END

        IF @nCalPago > (@nSaldoCtaEst - @nTopeMin_CtaEst ) -- - 20 ) -- VDCC 20101201 actualizacion en monto maximo permitido en la cta del establecimiento   
        BEGIN     
                    SET @nRpta = 19 -- MONTO MAYOR AL SALDO ESTABLECIMIENTO    
                    SET @ErrorDesc = 'MONTO MAYOR AL SALDO ESTABLECIMIENTO'    
                    --RETURN @nRpta
        END

		-- 21/07/2023 IBPD Inicio Se agrega control de cuenta de Agente Corresponsal bloqueada (1100, 1200, 1300, 1400)
		IF (@nPrdEstadoEst is null or @nPrdEstadoEst in (1100, 1200, 1300, 1400)) -- 907 CUENTA ESTABLECIMIENTO INACTIVA 
		BEGIN  
			SET @nRpta = 7   
			SET @ErrorDesc = 'LA CTA. DEL ESTABLECIMIENTO SE ENCUENTRA INACTIVA'
		END
		-- 21/07/2023 IBPD Fin Se agrega control de cuenta de Agente Corresponsal bloqueada (1100, 1200, 1300, 1400)
 
        IF @cProducto IN ('305', '121', '221', '321', '421') --Creditos: Pignoraticio, Carta Fianza    
        BEGIN     
                    SET @nRpta = 20 -- PRODUCTO NO HABILITADO    
                    SET @ErrorDesc = 'PRODUCTO NO HABILITADO'    
        END     
 
        IF @nEstado NOT IN (2020,2021,2022,2030,2031,2032) --Pagare Inactivo   
        BEGIN     
                    SET @nRpta = 21 -- PAGARE INACTIVO    
                    SET @ErrorDesc = 'PAGARE INACTIVO'    
                    --RETURN @nRpta     
                    --GOTO ProcExit    
        END    
 
        ----IF @pnMonto > @DeudaTotal -- Monto Mayor al Saldo en Cuenta del Cliente    
        IF @pnMonto > (@nSaldoCredUsu) -- Control del MINIMO EN CUENTA: S/. 5.00 -- Monto Mayor al Saldo    
        BEGIN     
                    SET @nRpta = 22 -- MONTO MAYOR AL SALDO    
                    SET @ErrorDesc = 'MONTO MAYOR AL SALDO'    
                    --RETURN @nRpta     
                    --GOTO ProcExit    
        END    
 
        ---- VRCA 20100920 - Control de Tope Minimo en Cuenta del Cliente    
        --IF @nCantDisp <= @nTopeMinOpe  -- 5      
        --BEGIN     
        --  SET @nRpta = 25 -- MONTO MENOR AL SALDO    
        --  SET @ErrorDesc = 'MONTO MENOR AL SALDO'    
        --  --RETURN @nRpta     
        --END  
        
        -- VDCC 22/01/2013 CONTROL QUE NO SALTE CUOTAS EN PAGO DE CUOTAS  
         DECLARE @vnMinCuotaDebeCalendario INT  
         SELECT @vnMinCuotaDebeCalendario=MIN(nCuota)   
         FROM ColocCalendario WITH(NOLOCK)  
         WHERE cCtaCod = @psCtaCod AND nNroCalen= (SELECT nNroCalen FROM ColocacCred WITH(NOLOCK) WHERE cCtaCod=@psCtaCod)   
                AND nColocCalendApl=1 AND nColocCalendEstado=0  
   
         IF @vnMinCuotaDebeCalendario <> @nNroCuota  
         BEGIN  
                     SET @nRpta = 13 -- las cuotas minimas a pagar no conhinciden  
                     SET @ErrorDesc ='LAS CUOTA DE CALENDARIO A PAGAR ES DIFERENTE DE LA PROGRAMADA'  
                     --GOTO ProcExit        
         END         
         -- END VDCC 22/01/2013 CONTROL QUE NO SALTE CUOTAS EN PAGO DE CUOTAS  
       END
       ELSE
        GOTO TranExit -- 28/01/2013 VDCC SE AGREGA CONTROL DE CONSISTENCIA  
  
--      
--SELECT @nRpta, @ErrorDesc, @cUsuario, @nCalPago, (@nSaldoCtaEst - 5 ), @nSaldoCtaEst 
  
       ----------------------------------------------------    
       -- 4. Realizar el Registro    
       ----------------------------------------------------      
       DECLARE @nMovNroTrx INT, @nMovNroEst INT     
       IF (@nRpta = 0)    
       BEGIN
        SET @nEnTransaccion = 1                --VRCA 20130603 - Evitar error "Cannot roll back TCF0. No transaction or savepoint of that name was found."
        BEGIN TRAN TCF0
        -- Pago del Credito    
        EXEC dbo.SP_CCPagoCuota @psCtaCod, @nNroCuota, @nCapital, @nInteres, @nInteresGracia, @nIntReprog, @nIntSuspenso,    
                                                   @nMora, @nNroDiasMora, @nGastos, @nITF, @nCalPago, @dFechaProceso, @cAgencia, 
                                                   @cUsuario, @nRpta OUT, @nMovNroTrx OUT, @dProxFecPago out
        --PRINT @@ERROR  
        --PRINT @psCtaCod    
        --PRINT @nMovNroTrx      
        --PRINT @nRpta    
        IF @@ERROR <> 0  
        BEGIN  
                    SET @nRpta = 1  
                    GOTO TranExit  
        END   
  
        IF (@nRpta = 0)  
        BEGIN   
                    --Almacenar en MovDoc el Pago del Credito  
                    INSERT INTO MovDoc (nMovNro, nDocTpo, cDocNro, dDocFecha)    
                    VALUES (@nMovNroTrx, 40, @cTxTxnNumber, @dFechaProceso )    
                    --VALUES (@nMovNroTrx, 40, @cTxTxnNumber, GETDATE() ) 
                    -- 28/01/2013 VDCC Se controla el error para la insercion
                    IF @@ERROR <> 0  
                    BEGIN  
                            SET @nRpta = 1  
                            GOTO TranExit  
                    END   
                    -- END 28/01/2013 VDCC Se controla el error para la insercion
                  
              
                    -- Retiro en la cuenta del establecimiento    
                    -- ===== 08/07/2011 VDCC SE REALIZA REDONDEO PARA EL MONTO DE RETIRO DE LA CTA DEL ESTABLECIMIENTO =====      
                    SET @nMontoCalc=       
                           CASE WHEN (SELECT dbo.fn_icor_esUltimaCuota(@psCtaCod))=0 /* no es ultima cuota */
                           THEN       
                                  CASE WHEN ((@nMontoCalc/0.05)%1>0) 
     THEN @nMontoCalc + (((1-(@nMontoCalc/0.05)%1)*0.1)/2)     
                                        ELSE @nMontoCalc      
                                  END      
                           ELSE /* ES ULTIMA CUOTA */      
                                  CASE WHEN ((@nMontoCalc/0.05)%1>0) 
                                        THEN @nMontoCalc - ((((@nMontoCalc/0.05)%1)*0.1)/2)     
                                        ELSE @nMontoCalc      
                                  END        
                           END         
                    -- ===== END 08/07/2011 VDCC SE REALIZA REDONDEO PARA EL MONTO DE RETIRO DE LA CTA DEL ESTABLECIMIENTO =====      
                 
                    EXEC dbo.spu_icor_Retiro null, @cCtaCodEst, @dFechaProceso, @cAgencia, @cUsuario, @nMontoCalc, 1, @nMovNroEst out, @nResp OUT    
                    --PRINT @cCtaCod    
                    --PRINT @@ERROR  
                    --PRINT @cCtaCodEst   
                    --PRINT @nMovNroEst      
                    --PRINT @nResp    
              
                    IF @@ERROR <> 0  
                    BEGIN  
                           SET @nRpta = 1  
                           GOTO TranExit  
                    END   
              
                    --Registrando cambios en tabla de referencia    
                    INSERT INTO MovPOS (nMovNro, nMovNroEst, dFechaReal, cNumTarjeta, cCtaCod, cCtaCodEst, nMonto, cProceso, cTxTxnNumber)
                    VALUES(@nMovNroTrx, @nMovNroEst, GETDATE(), null, @psCtaCod, @cCtaCod, @nCalPago, 'C', @cTxTxnNumber)    
                    -- 28/01/2013 VDCC Se controla el error para la insercion
                    IF @@ERROR <> 0  
                    BEGIN  
                           SET @nRpta = 1  
                           GOTO TranExit  
                    END   
                    -- END 28/01/2013 VDCC Se controla el error para la insercion
             
                    INSERT INTO MovDoc (nMovNro, nDocTpo, cDocNro, dDocFecha)    
                    VALUES(@nMovNroEst, 40, @cTxTxnNumber, @dFechaProceso )    
                    --VALUES(@nMovNroEst, 40, @cTxTxnNumber, GETDATE() )         
                    -- 28/01/2013 VDCC Se controla el error para la insercion
                    IF @@ERROR <> 0  
                    BEGIN  
                            SET @nRpta = 1  
                            GOTO TranExit  
                    END   
                    -- END 28/01/2013 VDCC Se controla el error para la insercion     
              
                    -- COMMIT TRAN TCF0 28/01/2013 VDCC Se COMENTA 
        END
        ELSE
                    GOTO TranExit   -- 28/01/2013 VDCC SE AGREGA CONTROL DE CONSISTENCIA 
        
        -- 28/01/2013 VDCC Se Realiza commit fuera del IF y se establece 0 para el parametro de salida
        COMMIT TRAN TCF0 
        SET @nRpta=0
        -- END 28/01/2013 VDCC Se ERaliza commit fuera del IF y se establece 0 para el parametro de salida
        DECLARE @sProxFecPago VARCHAR(12)    
        SET @sProxFecPago = CASE WHEN @dProxFecPago IS NULL THEN '' ELSE convert(VARCHAR(12), @dProxFecPago, 103) END     
        SET @cFecha = ISNULL(@cFecha, CONVERT(VARCHAR(12), GETDATE(),103))    
        SET @cHora = ISNULL(@cHora, CONVERT(VARCHAR(12), GETDATE(),108))    
        SET @cHora = CASE WHEN @cHora = '00:00:00' THEN CONVERT(VARCHAR(12), GETDATE(),108) ELSE @cHora END     
        SET @nCapital = ISNULL(@nCapital,0);    
        SET @nInteres = ISNULL(@nInteres,0);    
        SET @nMora = ISNULL(@nMora,0);     
        SET @nGastos = ISNULL(@nGastos,0);     
        SET @nInteresGracia = ISNULL(@nInteresGracia,0);    
        SET @nIntSuspenso = ISNULL(@nIntSuspenso,0);    
        SET @pnMontoITF = ISNULL(@pnMontoITF,0);    
 
        IF (@cPersona='' OR @cPersona IS NULL)
        BEGIN
                    SELECT @cPersona = ISNULL(p.cPersNombre, '')
                    FROM ProductoPersona pp WITH (NOLOCK)
                    INNER JOIN Persona p WITH (NOLOCK) ON pp.cPersCod = p.cPersCod AND pp.nPrdPersRelac = 20
                    WHERE pp.cCtaCod = @psCtaCod
             END
        
             --SELECT * FROM @MiPagoCuota    
             --SELECT [cPersona] = @cPersona, [Fecha] = @cFecha, [Hora] = @cHora, [dProxFecPago] = convert(VARCHAR(12), @dProxFecPago, 103),     
             SELECT [dProxFecPago] = @sProxFecPago, [Fecha] = @cFecha, [Hora] = @cHora, [cPersona] = @cPersona,     
                           --[nPagoCuota] = @nCapital+@nInteres+0+@nMora+@nGastos+@nInteresGracia+@nIntSuspenso, --13/02/2024 IBPD Se comenta
						   [nPagoCuota] = @nMontoCalc, --13/02/2024 IBPD Se uniformiza monto voucher
                           [nCapital] = @nCapital, [nIntComp] = @nInteres, [nIntCompVenc] = 0, [nIntMor] = @nMora,     
                           [nGastos] = @nGastos, [nIntGracia] = @nInteresGracia, [nIntSusRep] = @nIntSuspenso, [pnMontoITF] = @pnMontoITF, [nNro] = 1   
             UNION     
             SELECT [dProxFecPago] = @sProxFecPago, [Fecha] = @cFecha, [Hora] = @cHora, [cPersona] = @cPersona,     
                           --[nPagoCuota] = @nCapital+@nInteres+0+@nMora+@nGastos+@nInteresGracia+@nIntSuspenso, --13/02/2024 IBPD Se comenta
						   [nPagoCuota] = @nMontoCalc, --13/02/2024 IBPD Se uniformiza monto voucher
                           [nCapital] = @nCapital, [nIntComp] = @nInteres, [nIntCompVenc] = 0, [nIntMor] = @nMora,     
                           [nGastos] = @nGastos, [nIntGracia] = @nInteresGracia, [nIntSusRep] = @nIntSuspenso, [pnMontoITF] = @pnMontoITF, [nNro] = 2
       END 
       ELSE
        GOTO TranExit    
      
       SET NOCOUNT OFF
RETURN
TranExit:  
      --IF @nRpta<2 -->1  28/01/2013  VDCC COMENTADO        
      IF @nRpta<>0 -->1 28/01/2013 VDCC SE ENTRA AL ROLLBACK PARA CUALQUIER VALOR DIFERENTE DE 0
      BEGIN   
             --ROLLBACK TRAN TCF0
             IF @nEnTransaccion = 1            --VRCA 20130603 - Evitar error "Cannot roll back TCF0. No transaction or savepoint of that name was found."
             BEGIN                                    --VRCA 20130603 - Evitar error "Cannot roll back TCF0. No transaction or savepoint of that name was found."
                    ROLLBACK TRAN TCF0
             END                                      --VRCA 20130603 - Evitar error "Cannot roll back TCF0. No transaction or savepoint of that name was found."
             SET NOCOUNT OFF --28/01/2013 VDCC SE PONE SET NOCOUNT OFF EN CASO ENTRE AL ROLLBACK
             --SET @nRpta = 1  --VRCA 20130603 - Evitar error "Cannot roll back TCF0. No transaction or savepoint of that name was found."
      END     
END

GO