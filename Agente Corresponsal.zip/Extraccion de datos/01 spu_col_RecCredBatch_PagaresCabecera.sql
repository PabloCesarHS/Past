USE DBCMAC
GO

/*==============================================================    
Nombre Procedimiento : dbo.spu_col_RecCredBatch_PagaresCabecera
Funcionalidad        : 
USADO POR            : 
Usuario              : HSPC
Fecha creaci�n       : 00/03/2024
Modificaci�n         : 
Modo de ejecuci�n    : EXEC dbo.spu_col_RecCredBatch_PagaresCabecera '20240301'
==============================================================*/
ALTER PROC dbo.spu_col_RecCredBatch_PagaresCabecera
(
    @dFechaProceso DATETIME = NULL
)
AS
BEGIN
	SET NOCOUNT ON

	/*===================================================
				DECLARACION DE VARIABLES
	=====================================================*/
	/* VERIFICACION DE PARAMETRO */
	IF (@dFechaProceso IS NULL)
	BEGIN
		SET @dFechaProceso = GETDATE()
	END

	DECLARE @tDatosCabecera TABLE (
		nTipoRegistro INT,
		nC�digoGrupo INT,
		nC�digoRubro INT,
		nC�digoEmpresa INT,
		nC�digoServicio INT,
		nC�digoSolicitud INT,
		cDescripci�nSolicitud VARCHAR(100),
		nOrigenSolicitud INT,
		nC�digoRequerimiento INT,
		nCanalEnv�o INT,
		cTipoInformaci�n VARCHAR(100),
		nN�meroRegistros INT,
		nC�digoUnico VARCHAR(100),
		nFechaProceso DATETIME,
		nFechaInicioCargos DATETIME,
		nMoneda VARCHAR(2),
		nImporteTotal1 MONEY,
		nImporteTotal2 MONEY,
		cTipoGlosa VARCHAR(100),
		cGlosaGeneral VARCHAR(100),
		cLibre VARCHAR(100),
		nTipoFormato INT,
		nC�digoFijo INT
		)

	INSERT INTO @tDatosCabecera
	SELECT 11 AS nTipoRegistro,
		  21 AS nC�digoGrupo,
		  03 AS nC�digoRubro,
		  001 AS nC�digoEmpresa,
		  01 AS nC�digoServicio,
		  01 AS nC�digoSolicitud,
		  'CUOTA MARZO' AS cDescripci�nSolicitud,
		  1 AS nOrigenSolicitud,
		  002 AS nC�digoRequerimiento,
		  1 AS nCanalEnv�o,
		  'M' AS cTipoInformaci�n,
		  5 AS nN�meroRegistros,
		  '0123456789' AS nC�digoUnico,
		  GETDATE() AS nFechaProceso,
		  GETDATE() AS nFechaInicioCargos,
		  '01' AS nMoneda,
		  1000.11 AS nImporteTotal1,
		  2000.22 AS nImporteTotal2,
		  'P' AS cTipoGlosa,
		  '0' AS cGlosaGeneral,
		  '' AS cLibre,
		  01 AS nTipoFormato,
		  0000 AS nC�digoFijo

	SELECT * FROM @tDatosCabecera

	DECLARE @tDatosCred TABLE (
		cCtaCod VARCHAR(18),
		nPrestamo MONEY,
		cMoneda VARCHAR(10),
		cTipoCredito VARCHAR(10),
		cCodMoneda VARCHAR(3),
		nPrdEstado INT,
		nSaldo MONEY,
		nNroProxCuota INT,
		nNroCalen INT
		)

	INSERT INTO @tDatosCred
	SELECT P.cCtaCod AS cNroPagare,
		C.nMontoCol AS nMontoDes,
		cMoneda = CASE 
			WHEN Substring(P.cCtaCod, 9, 1) = '1'
				THEN 'SOLES'
			WHEN Substring(P.cCtaCod, 9, 1) = '2'
				THEN 'DOLARES'
			ELSE 'OTROS-REVISAR'
			END,  
		cte.cConsDescripcion,
		cCodMon = CASE 
			WHEN Substring(P.cCtaCod, 9, 1) = '1'
				THEN '01'
			WHEN Substring(P.cCtaCod, 9, 1) = '1'
				THEN '02'
			ELSE '00'
			END,
		P.nPrdEstado,
		P.nSaldo,
		CC.nNroProxCuota,
		CC.nNroCalen
	FROM DBCMAC..Colocaciones C
	INNER JOIN DBCMAC..Producto P ON P.cCtaCod = C.cCtaCod
	INNER JOIN DBCMAC..ProductoPersona PP ON PP.cCtaCod = P.cCtaCod
		AND PP.nPrdPersRelac = 20
	INNER JOIN ColocacCred CC ON CC.cCtaCod = C.cCtaCod
	INNER JOIN Constante cte ON cc.nTipoCreditoBasilea = cte.nConsValor
		AND cte.nconscod = 9980   
	WHERE P.nPrdEstado IN (2020, 2021, 2022, 2030, 2031, 2032)   
		AND ISNULL(CC.bBloqueo, 0) = 0

	DECLARE @dFecha DATETIME,
		@dVenc AS DATETIME,
		@nDescuentaIntMor MONEY,
		@nDescuentaIntMorDebe MONEY,
		@nDiasAtraso INT

	SELECT @dFecha = cast(substring(nConsSisValor, 7, 4) + '-' + substring(nConsSisValor, 4, 2) + '-' + substring(nConsSisValor, 1, 2) + + ' ' + cast(datepart(hour, getdate()) AS VARCHAR(4)) + ':' + cast(datepart(minute, getdate()) AS VARCHAR(4)) + ':' + cast(datepart(second, getdate()) AS VARCHAR(4)) AS DATETIME)
	FROM DBCMAC..ConstSistema WITH (NOLOCK)
	WHERE nConsSisCod = 16

	DECLARE @cPrevLang VARCHAR(10)  

	SELECT @dVenc = ccal.dVenc
	FROM ColocCalendario ccal WITH (NOLOCK)
	INNER JOIN ColocacCred cc WITH (NOLOCK) ON ccal.cCtaCod = cc.cCtaCod
		AND ccal.nNroCalen = cc.nNroCalen
		AND ccal.nCuota = cc.nNroProxCuota
		AND ccal.nColocCalendApl = 1
	WHERE ccal.cCtaCod = '106842011000030031'

	--SELECT * FROM Feriado F WITH (NOLOCK) INNER JOIN FeriadoAge FA WITH (NOLOCK) ON F.dFeriado = FA.dFeriado
	--				   WHERE F.dFeriado >= '20240207' AND F.dFeriado < '20240228'

	IF DATEDIFF(dd, @dVenc, @dFecha) = (SELECT COUNT(F.dFeriado) FROM Feriado F WITH (NOLOCK) INNER JOIN FeriadoAge FA WITH (NOLOCK) ON F.dFeriado = FA.dFeriado WHERE F.dFeriado >= @dVenc AND F.dFeriado < @dFecha)
	BEGIN
		SELECT @nDescuentaIntMor = nMonto,
			@nDescuentaIntMorDebe = nMonto - nMontoPagado,
			@nDiasAtraso = nDiasAtraso
		FROM ColocCalendDet cdet WITH (NOLOCK)
		INNER JOIN ColocacCred cc WITH (NOLOCK) ON cdet.cCtaCod = cc.cCtaCod
			AND cdet.nNroCalen = cc.nNroCalen
			AND cdet.nCuota = cc.nNroProxCuota
			AND cdet.nColocCalendApl = 1
		WHERE nPrdConceptoCod IN (1101, 1108)
	END
	ELSE
	BEGIN
		SET @nDescuentaIntMor = 0
		SET @nDescuentaIntMorDebe = 0
		SET @nDiasAtraso = 0
	END

	SELECT cCtaCod,
		nPrestamo,
		cMoneda,
		cTipoCredito,
		Agencia,
		cMetLiquidacion,
		nPrdEstado,
		cCodMoneda,
		nSaldo,
		Cuotas,
		nCuota,
		(nDiasAtraso - @nDiasAtraso) nDiasAtraso,
		nMontoCuota,
		(nMontoDebe - @nDescuentaIntMorDebe) nMontoDebe,
		dVenc,
		cVenc,
		nDiasAtrasoAcum
	FROM (
		SELECT cCtaCod,
			nPrestamo,
			cMoneda,
			cTipoCredito,
			Agencia,
			cMetLiquidacion,
			nPrdEstado,
			cCodMoneda,
			nSaldo,
			Cuotas,
			nCuota,
			nDiasAtraso,
			[nMontoCuota] = SUM(nMontoC),
			[nMontoDebe] = SUM(nMontoD),
			dVenc,
			cVenc,
			nDiasAtrasoAcum
		FROM (
			SELECT DISTINCT t0.cCtaCod,
				t0.nPrestamo,
				t0.cMoneda,
				t0.cTipoCredito,
				[Agencia] = ag.cAgeDesCorta,
				CC.cMetLiquidacion,
				t0.nPrdEstado,
				t0.cCodMoneda, --t0.nNroCalen,    
				t0.nSaldo,
				[Cuotas] = Max(CDet.nCuota),
				[nCuota] = t0.nNroProxCuota,
				CC.nDiasAtraso,
				[nMontoC] = CDet1.nMonto,
				[nMontoD] = CDet1.nMonto - CDet1.nMontoPagado,
				[dVenc] = MIN(CCal.dVenc),
				[cVenc] = CONVERT(VARCHAR(6), MIN(CCal.dVenc), 107),
				CC.nDiasAtrasoAcum
			FROM producto prd
			LEFT JOIN Colocaciones Col WITH (NOLOCK) ON Prd.cCtaCod = Col.cCtaCod
			LEFT JOIN ColocacCred CC WITH (NOLOCK) ON Prd.cCtaCod = CC.cCtaCod
			LEFT JOIN ColocCalendDet CDet1 WITH (NOLOCK) ON Prd.cCtaCod = CDet1.cCtaCod
				AND CC.nNroCalen = CDet1.nNroCalen
				AND CDet1.nColocCalendApl = 1
				AND CDet1.nCuota = CC.nNroProxCuota --and CDet.nPrdConceptoCod = 1000 and CDet.nMontoPagado <> 0      --     
			LEFT JOIN ColocCalendario CCal WITH (NOLOCK) ON Prd.cCtaCod = CCal.cCtaCod
				AND CC.nNroCalen = CCal.nNroCalen
				AND CCal.nColocCalendApl = 1
				AND CCal.nColocCalendEstado = 0 -- AND CCal.nCuota>= CC.nNroProxCuota    
			LEFT JOIN ColocCalendDet CDet WITH (NOLOCK) ON Prd.cCtaCod = CDet.cCtaCod
				AND CC.nNroCalen = CDet.nNroCalen
				AND CDet.nColocCalendApl = CCal.nColocCalendApl
				AND CCal.nCuota = CDet.nCuota
			LEFT JOIN Agencias ag WITH (NOLOCK) ON SUBSTRING(prd.cCtaCod, 4, 2) = ag.cAgeCod
			INNER JOIN @tDatosCred t0 ON t0.cCtaCod = prd.cctacod
			GROUP BY Prd.nPrdEstado,
				CC.nDiasAtraso,
				CC.nDiasAtrasoAcum,
				CC.cMetLiquidacion,
				ag.cAgeDesCorta,
				t0.cCtaCod,
				t0.cCtaCod,
				t0.nPrestamo,
				t0.cMoneda,
				t0.cTipoCredito,
				t0.cCodMoneda,
				t0.nPrdEstado,
				t0.nSaldo,
				t0.nNroProxCuota,
				t0.nNroCalen,
				CDet1.nNroCalen,
				CDet1.nCuota,
				CDet1.nMonto,
				CDet1.nMontoPagado 
			) tbl
		GROUP BY cCtaCod,
			nPrestamo,
			cMoneda,
			cTipoCredito,
			Agencia,
			cMetLiquidacion,
			nPrdEstado,
			cCodMoneda,
			nSaldo,
			Cuotas,
			nCuota,
			nDiasAtraso,
			dVenc,
			cVenc,
			nDiasAtrasoAcum
		) ztb1
	ORDER BY nDiasAtraso DESC

	SET NOCOUNT OFF
END
GO