USE DBCMAC
GO

/*==============================================================    
Nombre Procedimiento : dbo.spu_col_RecCredBatch_PagaresCuotas
Funcionalidad        : 
USADO POR            : 
Usuario              : HSPC
Fecha creaci�n       : 00/03/2024
Modificaci�n         : 
Modo de ejecuci�n    : EXEC dbo.spu_col_RecCredBatch_PagaresCuotas '20240301'
==============================================================*/
ALTER PROC dbo.spu_col_RecCredBatch_PagaresCuotas
(
    @dFechaProceso DATETIME = NULL
)
AS
BEGIN
	SET NOCOUNT ON

	/*===================================================
				DECLARACION DE VARIABLES
	=====================================================*/
	/* VERIFICACION DE PARAMETRO */
	IF (@dFechaProceso IS NULL)
	BEGIN
		SET @dFechaProceso = GETDATE()
	END

	DECLARE @tDatosCuotas TABLE (
		nTipoRegistro INT,
		cC�digoCuota VARCHAR(100),
		nN�meroConceptos INT,
		cDescripci�nConcepto1 VARCHAR(100),
		cDescripci�nConcepto2 VARCHAR(100),
		cDescripci�nConcepto3 VARCHAR(100),
		cDescripci�nConcepto4 VARCHAR(100),
		cDescripci�nConcepto5 VARCHAR(100),
		cDescripci�nConcepto6 VARCHAR(100),
		cDescripci�nConcepto7 VARCHAR(100),
		cLibre VARCHAR(100),
		nTipoFormato INT,
		nC�digoFijo INT
		)

	INSERT INTO @tDatosCuotas
	SELECT 
		12 AS nTipoRegistro,
		'00000000' AS cC�digoCuota,
		1 AS nN�meroConceptos,
		'CUOTA MES' AS cDescripci�nConcepto1,
		'' AS cDescripci�nConcepto2,
		'' AS cDescripci�nConcepto3,
		'' AS cDescripci�nConcepto4,
		'' AS cDescripci�nConcepto5,
		'' AS cDescripci�nConcepto6,
		'' AS cDescripci�nConcepto7,
		'' AS cLibre,
		2 AS nTipoFormato,
		0 AS nC�digoFijo

	select* from @tDatosCuotas

	SET NOCOUNT OFF
END
GO