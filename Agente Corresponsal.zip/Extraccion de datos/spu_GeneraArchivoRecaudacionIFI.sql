USE DBTARJETA
GO

/*=============================================== 
Nombre      : spu_GenaraArchivoRecaudacionIFI  
proposito   : Generacion de archivo plano para recaudacion de IFI
Creacion    : 20240227 - TQWI  
Ejecuci�n   : Exec spu_GenaraArchivoRecaudacionIFI '20230622','20230622'  
===============================================*/
ALTER PROCEDURE spu_GenaraArchivoRecaudacionIFI
	@FechaIni DATETIME, --PARAMETROS DE ENTRADA A MODIFICACION DE CREDITOS
	@FechaFin DATETIME --PARAMETROS DE ENTRADA A MODIFICACION DE CREDITOS
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @tDatosCabecera TABLE (
		nTipoRegistro VARCHAR(100),
		nC�digoGrupo VARCHAR(100),
		nC�digoRubro VARCHAR(100),
		nC�digoEmpresa VARCHAR(100),
		nC�digoServicio VARCHAR(100),
		nC�digoSolicitud VARCHAR(100),
		cDescripci�nSolicitud VARCHAR(100),
		nOrigenSolicitud VARCHAR(100),
		nC�digoRequerimiento VARCHAR(100),
		nCanalEnv�o VARCHAR(100),
		cTipoInformaci�n VARCHAR(100),
		nN�meroRegistros VARCHAR(100),
		nC�digoUnico VARCHAR(100),
		nFechaProceso VARCHAR(100),
		nFechaInicioCargos VARCHAR(100),
		nMoneda VARCHAR(2),
		nImporteTotal1 VARCHAR(100),
		nImporteTotal2 VARCHAR(100),
		cTipoGlosa VARCHAR(100),
		cGlosaGeneral VARCHAR(100),
		cLibre VARCHAR(100),
		nTipoFormato VARCHAR(100),
		nC�digoFijo VARCHAR(100)
		)
	DECLARE @tDatosCuotas TABLE (
		nTipoRegistro VARCHAR(100),
		cC�digoCuota VARCHAR(100),
		nN�meroConceptos VARCHAR(100),
		cDescripci�nConcepto1 VARCHAR(100),
		cDescripci�nConcepto2 VARCHAR(100),
		cDescripci�nConcepto3 VARCHAR(100),
		cDescripci�nConcepto4 VARCHAR(100),
		cDescripci�nConcepto5 VARCHAR(100),
		cDescripci�nConcepto6 VARCHAR(100),
		cDescripci�nConcepto7 VARCHAR(100),
		cLibre VARCHAR(100),
		nTipoFormato VARCHAR(100),
		nC�digoFijo VARCHAR(100)
		)
	DECLARE @tDatosDetalle TABLE (
		nTipoRegistro VARCHAR(100),
		cC�digoDeudor VARCHAR(100),
		cNombredelDeudor VARCHAR(100),
		cReferencia1 VARCHAR(100),
		cReferencia2 VARCHAR(100),
		cTipoOperaci�n VARCHAR(100),
		cC�digoCuota VARCHAR(100),
		nFechaEmisi�n VARCHAR(100),
		nFechaVencimiento VARCHAR(100),
		cN�meroDocumento VARCHAR(100),
		nMonedaDeuda VARCHAR(2),
		nImporteConcepto1 VARCHAR(100),
		nImporteConcepto2 VARCHAR(100),
		nImporteConcepto3 VARCHAR(100),
		nImporteConcepto4 VARCHAR(100),
		nImporteConcepto5 VARCHAR(100),
		nImporteConcepto6 VARCHAR(100),
		nImporteConcepto7 VARCHAR(100),
		cTipoCuentaPrincipal VARCHAR(100),
		cProductoCuentaprincipal VARCHAR(100),
		cMonedaCuentaPrincipal NVARCHAR(100),
		cNumeroCuentaPrincipal VARCHAR(100),
		nImporteAbonarCuenta1 VARCHAR(100),
		cTipoCuentaSecundaria VARCHAR(100),
		cProductoCuentaSecundaria VARCHAR(100),
		cMonedaCuentaSecundaria VARCHAR(100),
		cNumeroCuentaSecundaria VARCHAR(100),
		nImporteAbonarCuenta2 VARCHAR(100),
		cGlosaParticular VARCHAR(100),
		cLibre VARCHAR(100),
		nTipoFormato VARCHAR(100),
		nC�digoFijo VARCHAR(100)
		)

	/*  ASIGNACION DE VALORES */
	/* DETALLE */
	INSERT INTO @tDatosDetalle
	SELECT '13' AS nTipoRegistro,
		'00000001' AS cC�digoDeudor,
		'******************************' AS cNombredelDeudor,
		'' AS cReferencia1,
		'' AS cReferencia2,
		'A' AS cTipoOperaci�n,
		'00000000' AS cC�digoCuota,
		'20240228' AS nFechaEmisi�n,
		'20240228' AS nFechaVencimiento,
		'********' AS cN�meroDocumento,
		'01' AS nMonedaDeuda,
		'00' AS nImporteConcepto1,
		'00' AS nImporteConcepto2,
		'00' AS nImporteConcepto3,
		'00' AS nImporteConcepto4,
		'00' AS nImporteConcepto5,
		'00' AS nImporteConcepto6,
		'00' AS nImporteConcepto7,
		'D' AS cTipoCuentaPrincipal,
		'002' AS cProductoCuentaprincipal,
		'01' AS cMonedaCuentaPrincipal,
		'10030000000144' AS cNumeroCuentaPrincipal,
		'100011' AS nImporteAbonarCuenta1,
		'D' AS cTipoCuentaSecundaria,
		'001' AS cProductoCuentaSecundaria,
		'10' AS cMonedaCuentaSecundaria,
		'1003000054444' AS cNumeroCuentaSecundaria,
		'200022' AS nImporteAbonarCuenta2,
		'TRAS.DINERO S/.' AS cGlosaParticular,
		'' AS cLibre,
		'03' AS nTipoFormato,
		'0000' AS nC�digoFijo

	/* CUOTAS */
	INSERT INTO @tDatosCuotas
	SELECT '12' AS nTipoRegistro,
		'00000000' AS cC�digoCuota,
		'1' AS nN�meroConceptos,
		'CUOTA MES' AS cDescripci�nConcepto1,
		'' AS cDescripci�nConcepto2,
		'' AS cDescripci�nConcepto3,
		'' AS cDescripci�nConcepto4,
		'' AS cDescripci�nConcepto5,
		'' AS cDescripci�nConcepto6,
		'' AS cDescripci�nConcepto7,
		'' AS cLibre,
		'2' AS nTipoFormato,
		'0' AS nC�digoFijo

	/* CABECERA */
	INSERT INTO @tDatosCabecera
	SELECT '11' AS nTipoRegistro,
		'21' AS nC�digoGrupo,
		'03' AS nC�digoRubro,
		'001' AS nC�digoEmpresa,
		'01' AS nC�digoServicio,
		'01' AS nC�digoSolicitud,
		'CUOTA MARZO' AS cDescripci�nSolicitud,
		'1' AS nOrigenSolicitud,
		'002' AS nC�digoRequerimiento,
		'1' AS nCanalEnv�o,
		'M' AS cTipoInformaci�n,
		'5' AS nN�meroRegistros,
		'0123456789' AS nC�digoUnico,
		'2024 02 28' AS nFechaProceso,
		'2024 02 28' AS nFechaInicioCargos,
		'01' AS nMoneda,
		'100011' AS nImporteTotal1,
		'200022' AS nImporteTotal2,
		'P' AS cTipoGlosa,
		'0' AS cGlosaGeneral,
		'' AS cLibre,
		'01' AS nTipoFormato,
		'0000' AS nC�digoFijo

	/* VARIABLES CABECERA*/
	SELECT /* '11' --AS TipoRegistro (01: Data Parcial; 11: Data Completa; 01: Pago Autom�tico)
		+ '21' --AS CodGrupo (21: Data Parcial; 21: Data Completa; 00: Pago Autom�tico)
		+ '03' --AS CodRubro
		+ '001' --AS CodEmpresa
		+ '01' --AS CodServicio
		+ '01' --AS CodSolicitud
		+ space(30) --AS DescripSolicitud
		+ '1' --AS (OrigenSolicitud  1: Linea Activa; 2: Diskette; 3: Listados)
		+ '001' --AS CodRequerimiento
		+ '1' --AS CanalEnvio
		+ 'M' --AS TipoInformacion
		+ '000000000000070' --AS NumeroRegistros
		+ '0123456789' --AS CodUnico
		+ '20010302' --AS FechaProceso
		+ '00000000' --AS FechaInicioCargos
		+ '01' --AS Moneda
		+ '000000002345000' --AS ImporteTotal1
		+ '000000000000000' --AS ImporteTotal2
		+ 'P' --AS TipoGlosa
		+ space(50) --AS GlosaGeneral
		+ space(221) --AS Libre
		+ '01' --AS TipoFormato
		+ '0000' --AS CodigoFijo
		-- INCLUIR LOGICA */
		CONCAT (
			nTipoRegistro,
			nC�digoGrupo,
			nC�digoRubro,
			nC�digoEmpresa,
			nC�digoServicio,
			nC�digoSolicitud,
			cDescripci�nSolicitud,
			nOrigenSolicitud,
			nC�digoRequerimiento,
			nCanalEnv�o,
			cTipoInformaci�n,
			nN�meroRegistros,
			nC�digoUnico,
			nFechaProceso,
			nFechaInicioCargos,
			nMoneda,
			nImporteTotal1,
			nImporteTotal2,
			cTipoGlosa,
			cGlosaGeneral,
			cLibre,
			nTipoFormato,
			nC�digoFijo
			)
	FROM @tDatosCabecera
	
	UNION
	
	/* VARIBLES DE REGISTRO DE CUOTAS*/
	SELECT /* '12' --AS TiporRegistro
		+ '00000000' --AS CodigoCuota
		+ '1' --AS NumeroConceptos
		+ 'CUOTA MES' --AS DescripConcepto1
		+ space(10) --AS DescripConcepto2
		+ space(10) --AS DescripConcepto3
		+ space(10) --AS DescripConcepto4
		+ space(10) --AS DescripConcepto5
		+ space(10) --AS DescripConcepto6
		+ space(10) --AS DescripConcepto7
		+ space(313) --AS Libre
		+ '02' --AS TipoFormato
		+ '0000' --AS CodFijo
		-- INCLUIR LOGICA */
		CONCAT (
			nTipoRegistro,
			cC�digoCuota,
			nN�meroConceptos,
			cDescripci�nConcepto1,
			cDescripci�nConcepto2,
			cDescripci�nConcepto3,
			cDescripci�nConcepto4,
			cDescripci�nConcepto5,
			cDescripci�nConcepto6,
			cDescripci�nConcepto7,
			cLibre,
			nTipoFormato,
			nC�digoFijo
			)
	FROM @tDatosCuotas
	
	UNION
	
	/* VARIABLES DE REGISTRO DE DETALLES*/
	SELECT
		/* '13' --AS TipoRegistro
		+ '00000001' --AS CodDeudor
		+ CONCAT (
			'SANCHEZ FARRO',
			REPLICATE(' ', 30 - LEN('SANCHEZ FARRO'))
			) --AS NombreDeudor
		+ SPACE(10) --AS Referencia1
		+ SPACE(10) --AS Referencia2
		+ 'A' --AS TipoOperaci�n
		+ '00000000' --AS CodCuota
		+ '20010220' --AS FechaEmisi�n
		+ '20010305' --AS FechaVencimiento
		+ '67899999' --AS NumeroDocumento
		+ '01' --AS MonedaDeuda
		+ '000125000' --AS ImporteConcepto1
		+ '000000000' --AS ImporteConcepto2
		+ '000000000' --AS ImporteConcepto3
		+ '000000000' --AS ImporteConcepto4
		+ '000000000' --AS ImporteConcepto5
		+ '000000000' --AS ImporteConcepto6
		+ '000000000' --AS ImporteConcepto7
		+ 'D' --AS TipoCuentaPrincipal
		+ '002' --AS ProductoCuentaPrincipal
		+ '01' --AS MonedaCuentaPrincipal
		+ '10030000000144' --AS NumeroCuentaPrincipal
		+ '000000000150000' --AS ImporteAbonarCuenta1
		+ 'D' --AS TipoCuentaSecundaria
		+ '001' --AS ProductoCuentaSecundaria
		+ '10' --AS MonedaCuentaSecundaria
		+ '1003000054444' --AS NumeroCuentaSecundaria
		+ '000000000000000' --AS ImporteAbonarCuenta2
		+ 'TRAS.DINERO S/.' --AS GlosaParticular
		+ SPACE(68) --AS Libre
		+ '03' --AS TipoFormato
		+ '0000' --AS CodFijo
		-- INCLUIR LOGICA */
		CONCAT (
			nTipoRegistro,
			cC�digoDeudor,
			cNombredelDeudor,
			cReferencia1,
			cReferencia2,
			cTipoOperaci�n,
			cC�digoCuota,
			nFechaEmisi�n,
			nFechaVencimiento,
			cN�meroDocumento,
			nMonedaDeuda,
			nImporteConcepto1,
			nImporteConcepto2,
			nImporteConcepto3,
			nImporteConcepto4,
			nImporteConcepto5,
			nImporteConcepto6,
			nImporteConcepto7,
			cTipoCuentaPrincipal,
			cProductoCuentaprincipal,
			cMonedaCuentaPrincipal,
			cNumeroCuentaPrincipal,
			nImporteAbonarCuenta1,
			cTipoCuentaSecundaria,
			cProductoCuentaSecundaria,
			cMonedaCuentaSecundaria,
			cNumeroCuentaSecundaria,
			nImporteAbonarCuenta2,
			cGlosaParticular,
			cLibre,
			nTipoFormato,
			nC�digoFijo
			)
	FROM @tDatosDetalle

	SET NOCOUNT ON
END