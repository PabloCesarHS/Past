﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class cArchivo
    {
        private String NombreArchivo
        {
            get { return NombreArchivo; }
            set {  NombreArchivo=value; }
        }
        private Boolean TieneCabecera
        {
            get { return TieneCabecera;}
            set { TieneCabecera = value; }
        }
        private String Tipo 
        {
            get { return Tipo; }
            set { Tipo = value;}
        }
        private int LineaActual
        {
            get { return LineaActual; }
            set { LineaActual = value; }
        }
    }
}
