﻿using System;

namespace CapaNegocio
{
    /* INICIO 04072023 HSPC - Se crea nueva clase para el formato de datos */
    public static class cFormato
    {
        #region Cadena

        public static string FormatoCaracterDerecha(int _NroCeros, char _Caracter, Object _Valor, string _ValorDefecto)
        {
            try
            {
                if (Convert.ToString(_Valor) != string.Empty)
                    return Convert.ToString(_Valor).PadRight(_NroCeros, _Caracter).Substring(0, _NroCeros);
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        public static string FormatoCaracterIzquierda(int _NroCeros, char _Caracter, Object _Valor, string _ValorDefecto)
        {
            try
            {
                if (Convert.ToString(_Valor) != string.Empty)
                    return Convert.ToString(_Valor).PadLeft(_NroCeros, _Caracter);
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        public static string AgregarCerosDerecha(int _NroCeros, Object _Valor, string _ValorDefecto)
        {
            try
            {
                if (Convert.ToString(_Valor) != string.Empty)
                    return Convert.ToString(_Valor).PadRight(_NroCeros, '0');
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        public static string AgregarCerosIzquierda(int _NroCeros, Object _Valor, string _ValorDefecto)
        {
            try
            {
                if (Convert.ToString(_Valor) != string.Empty)
                    return Convert.ToString(_Valor).PadLeft(_NroCeros, '0');
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        public static string CortarCadena(int _Inicio, int _Longitud, Object _Valor, string _ValorDefecto)
        {
            try
            {
                if (Convert.ToString(_Valor) != string.Empty)
                    return Convert.ToString(_Valor).Substring(_Inicio, _Longitud);
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        public static string QuitarCaracterCadena(Object _Valor, string _ValorDefecto, string _AnteriorCaracter, string _NuevoCaracter = "")
        {
            try
            {
                if (Convert.ToString(_Valor) != string.Empty)
                {
                    return Convert.ToString(_Valor).Replace(_AnteriorCaracter, _NuevoCaracter);
                }
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        #endregion Cadena
    }
    /* FIN 04072023 HSPC - Se crea nueva clase para el formato de datos */
}