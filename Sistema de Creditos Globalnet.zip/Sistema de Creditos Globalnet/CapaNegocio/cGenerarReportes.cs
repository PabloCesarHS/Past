﻿using CapaDatos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class cGenerarReportes //UQMA para realizar consultas 
    {
        cDatos oDatos = new cDatosSQL();

        public DataTable Consultar_RptaPagoPAR(DateTime dFechaIni, DateTime dFechaFin)
        {
            return oDatos.TraerDataTable("spu_Bim_ConsultarRespuestaPago", dFechaIni, dFechaFin);
        }

        public DataTable Consultar_DepGenerados(DateTime dFechaIni, DateTime dFechaFin)
        {
            return oDatos.TraerDataTable("spu_Bim_ConsultarDepGenerados", dFechaIni, dFechaFin);
        }

        public DataTable Consultar_RevDepositos(DateTime dFechaIni, DateTime dFechaFin)
        {
            return oDatos.TraerDataTable("spu_Bim_ConsultarRevDeposito", dFechaIni, dFechaFin);
        }

        public DataTable Consultar_DepCompensados(DateTime dFechaIni, DateTime dFechaFin)
        {
            return oDatos.TraerDataTable("spu_Bim_ConsultarDepComp", dFechaIni, dFechaFin);
        }
        public DataTable Consultar_BatchAgentes(DateTime dFechaIni, DateTime dFechaFin)
        {
            return oDatos.TraerDataTable("spu_Bim_ConsultarBatchAgente", dFechaIni, dFechaFin);
        }
    }
}
