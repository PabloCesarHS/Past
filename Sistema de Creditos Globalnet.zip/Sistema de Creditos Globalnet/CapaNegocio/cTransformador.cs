﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;

namespace CapaNegocio
{
    public static class cTransformador
    {
        /* INICIO 04072023 HSPC - Se agrega nuevo metodo para convertir DATATABLE a List<Class> */
        public static List<T> ConvertirDataTableAClase<T>(DataTable _TablaDatos)
        {
            List<T> vListaClase = new List<T>(); /* 04072023 HSPC - Se crea una instancia de lista de clases */
            foreach (DataRow vFilaDatos in _TablaDatos.Rows) /* 04072023 HSPC - Se recorre la el DATATABLE fila a fila */
            {
                T vClase = ObtenerClase<T>(vFilaDatos); /* 04072023 HSPC - Se extrae la clase enviando la fila al metodo */
                vListaClase.Add(vClase); /* 04072023 HSPC - Se añade la clase a la lista */
            }
            return vListaClase;
        }
        /* FIN 04072023 HSPC - Se agrega nuevo metodo para convertir DATATABLE a List<Class> */

        /* INICIO 04072023 HSPC - Se agrega nuevo metodo para convertir la FILA a Clase */
        public static T ObtenerClase<T>(DataRow _FilaDatos)
        {
            Type vClaseTemporal = typeof(T); /* 04072023 HSPC - Se crea una instancia de clase generica o copia de la clase parametro */
            T vObjectoClase = Activator.CreateInstance<T>(); /* 04072023 HSPC - Se crea una instancia de objeto a retornar */

            foreach (DataColumn vColumnaDatos in _FilaDatos.Table.Columns)  /* 04072023 HSPC - Se recorre las columnas de la fila */
            {
                foreach (PropertyInfo vPropiedades in vClaseTemporal.GetProperties())  /* 04072023 HSPC - Se identifica las propiedades de la clase parametro */
                {
                    if (vPropiedades.Name == vColumnaDatos.ColumnName) /* 04072023 HSPC - Se recorre las columnas comparando los valores */
                    {
                        //vPropiedades.SetValue(vObjectoClase, _FilaDatos[vColumnaDatos.ColumnName], null); /* 04072023 HSPC - Se identifica las propiedades de la columna asignando el valor a la propiedad de la clase */
                        vPropiedades.SetValue(vObjectoClase, _FilaDatos[vColumnaDatos.ColumnName].ToString(), null); /* 04072023 HSPC - Se identifica las propiedades de la columna (STRING) asignando el valor a la propiedad de la clase  */
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            return vObjectoClase;
        }
        /* FIN 04072023 HSPC - Se agrega nuevo metodo para convertir la FILA a Clase */
    }
}
