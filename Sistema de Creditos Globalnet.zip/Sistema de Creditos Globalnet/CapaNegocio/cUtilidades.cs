﻿using System;

namespace CapaNegocio
{
    /* INICIO 04072023 HSPC - Se crea nueva clase para la validacion de datos o variables */
    public static class cConverciones
    {
        public static string ValidarVacioONulo(Object _Valor)
        {
            return _Valor?.ToString() ?? string.Empty;
        }

        #region ConvertirCadena

        public static string ConvertirACadena(Object _Valor, string _ValorDefecto)
        {
            try
            {
                if (_Valor != null)
                    return Convert.ToString(_Valor);
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        public static int ConvertirAEntero(Object _Valor, int _ValorDefecto)
        {
            try
            {
                if (_Valor != null)
                    return Convert.ToInt32(_Valor.ToString());
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        public static bool ConvertirABooleano(Object _Valor, bool _ValorDefecto)
        {
            try
            {
                if (_Valor != null)
                    return Convert.ToBoolean(_Valor.ToString());
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        public static decimal ConvertirADecimal(Object _Valor, decimal _ValorDefecto)
        {
            try
            {
                if (_Valor != null)
                    return Convert.ToDecimal(_Valor.ToString());
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        public static double ConvertirADouble(Object _Valor, double _ValorDefecto)
        {
            try
            {
                if (_Valor != null)
                    return Convert.ToDouble(_Valor.ToString());
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        public static DateTime ConvertirAFecha(Object _Valor, DateTime _ValorDefecto)
        {
            try
            {
                if (_Valor != null)
                    return Convert.ToDateTime(_Valor.ToString());
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        #endregion ConvertirCadena
    }
    /* FIN 04072023 HSPC - Se crea nueva clase para la validacion de datos o variables */

    public static class cTransformaciones
    {
        public static string TransformarBool(bool _Valor, string _Verdadero, string _Falso)
        {
            if (_Valor)
                return _Verdadero;
            else
                return _Falso;
        }

        //public static string Transforma(Object _Valor, string _ValorDefecto)
        //{
        //    try
        //    {
        //        if (_Valor != null)
        //            return Convert.ToString(_Valor);
        //        else
        //            return _ValorDefecto;
        //    }
        //    catch
        //    {
        //        return _ValorDefecto;
        //    }
        //}
    }
}