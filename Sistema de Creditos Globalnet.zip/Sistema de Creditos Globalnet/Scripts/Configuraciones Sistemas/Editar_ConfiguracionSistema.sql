USE DBTarjeta
GO

/* ===================================
NOMBRE             : Editar_ConfiguracionSistema              
PROPOSITO          : 
CREACION           : 
MODIFICACION       : 07/04/2023 HSPC - Se agregan nuevos parametros en la modificacion de registros
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  : Editar_arConfiguracionSistema          
=================================== */
CREATE PROCEDURE dbo.Editar_ConfiguracionSistema
(
	@nIdConfiguracion INT,
	@CProyecto VARCHAR(15),
	@cTipo VARCHAR(10) NULL,
	@cTag VARCHAR(20),
	@cRuta VARCHAR(150) NULL,
	@cBaseDatos VARCHAR(30) NULL,
	@cDireccionIP VARCHAR(24) NULL,
	@cParametros VARCHAR(150) NULL,
	@bEstado INT NULL
)
AS
BEGIN
	SET NOCOUNT ON

	/*
	RESULTADO = 0 : CORRECTO
	RESULTADO = 1 : NO EXISTE
	RESULTADO = 2 : REGISTRO MODIFICADO
	RESULTADO = 3 : REGISTRO ELIMINADO
	*/

	IF EXISTS (SELECT nIdConfiguracion FROM DBTarjeta..Configuraciones_Sistemas WHERE nIdConfiguracion = @nIdConfiguracion)
	BEGIN
		UPDATE DBTarjeta..Configuraciones_Sistemas
		SET CProyecto = @CProyecto,
			cTipo = @cTipo,
			cTag = @cTag,
			cRuta = @cRuta,
			cBaseDatos = @cBaseDatos,
			cDireccionIP = @cDireccionIP,
			cParametros = @cParametros,
			bEstado = @bEstado
		WHERE nIdConfiguracion = @nIdConfiguracion

		SELECT '2' AS RESULTADO
	END
	ELSE
	BEGIN
		SELECT '1' AS RESULTADO
	END

	SET NOCOUNT OFF
END
GO