USE DBTarjeta
GO

/**********************************************************************
NOMBRE             : BimReporte32AEditar_spu              
PROPOSITO          : Actualizar el valor nFideicometido del Reporte 32A
CREACION           : 
MODIFICACION       : 07/04/2023 HSPC - Se agregan nuevos parametros en la modificacion de registros
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  :                     
				 EXEC BimReporte32AEditar_spu 1,1000,100,100
***********************************************************************/
ALTER PROCEDURE dbo.BimReporte32AEditar_spu
	   @IdReporte32A INT,
	   @nFideicometido MONEY,
	   @nValorDisposicionInmediata MONEY = NULL,
	   @nValorGarantia MONEY = NULL
AS
BEGIN
	SET NOCOUNT ON

	/* VERIFICACION DE PARAMETROS EN NULO */
	IF (@nFideicometido IS NULL)
	BEGIN
		SET @nFideicometido = 0
	END

	IF (@nValorDisposicionInmediata IS NULL)
	BEGIN
		SET @nValorDisposicionInmediata = 0
	END

	IF (@nValorGarantia IS NULL)
	BEGIN
		SET @nValorDisposicionInmediata = 0
	END

	/* MODIFICACION DEL REGISTRO */
	UPDATE [DBTarjeta].[dbo].[BimReporte32A]
	SET nFideicometido = @nFideicometido,
		nValorDisposicionInmediata = @nValorDisposicionInmediata,
		nValorGarantia = @nValorGarantia
	WHERE nIdRepA = @IdReporte32A

	SELECT '0' AS RESULTADO

	SET NOCOUNT OFF
END
GO