USE DBTarjeta
GO

/********************************************************************************
NOMBRE             : BimReporte32BIIEditar_spu                
PROPOSITO          : Actualizar el valor nTipoCambio del Reporte 32BI
EJECUTAR EN        : DBTarjeta
CREACION           : 
MODIFICACION       : 07/04/2023 HSPC - Se agregan nuevos parametros en la modificacion de registros
MODO DE EJECUCION  : 
				EXEC BimReporte32BIIEditar_spu 
*********************************************************************************/
ALTER PROCEDURE dbo.BimReporte32BIIEditar_spu
	   @nIdRepBIi INT,
	   @nTipoCambio MONEY,
	   @nMonedaNacional MONEY = NULL,
	   @nMonedaExtranjera MONEY = NULL,
	   @nTotal MONEY = NULL
AS
BEGIN
	SET NOCOUNT ON

	/* VERIFICACION DE PARAMETROS EN NULO */
	IF (@nMonedaNacional IS NULL)
	BEGIN
		SET @nMonedaNacional = 0
	END

	IF (@nMonedaExtranjera IS NULL)
	BEGIN
		SET @nMonedaExtranjera = 0
	END

	IF (@nTotal IS NULL)
	BEGIN
		SET @nTotal = @nMonedaNacional + @nMonedaExtranjera
	END

	/* MODIFICACION DEL REGISTRO */
	UPDATE [DBTarjeta].[dbo].[BimReporte32B_II]
	SET nMonedaNacional = @nMonedaNacional,
		nMonedaExtranjera = @nMonedaExtranjera,
		nTotal = @nTotal
	WHERE nIdRepBII = @nIdRepBIi

	SELECT '0' AS RESULTADO

	SET NOCOUNT OFF
END
GO