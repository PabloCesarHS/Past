USE DBTarjeta
GO

/***********************************************************************************************************************************                        
NOMBRE             : BimReporte32AEditar_spu              
PROPOSITO          : Actualizar el valor nFideicometido del Reporte 32A
CREACION           : 11/08/2017 UQMA 
MODIFICACION       : 16/08/2017 UQMA         
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  :                     
                 
***********************************************************************************************************************************/
CREATE PROCEDURE dbo.BimReporte32AEditar_spu
     @IdReporte32A INT,
	@nFideicometido MONEY
AS
BEGIN
	--Para actualizar el valor nFideicometido   
	UPDATE BimReporte32A
	SET nFideicometido = @nFideicometido
	WHERE nIdRepA = @IdReporte32A
END
GO