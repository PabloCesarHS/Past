USE DBTarjeta
GO

/***********************************************************************************************************************************                          
NOMBRE             : BimReporte32BIEditar_spu                
PROPOSITO          : Actualizar el valor nTipoCambio del Reporte 32BI
CREACION           : 06/06/2018 LVCH           
EJECUTAR EN        : DBTarjeta               
MODO DE EJECUCION  : 

***********************************************************************************************************************************/
CREATE PROCEDURE dbo.BimReporte32BIEditar_spu
     @nIdRepBI INT,
	@nTipoCambio MONEY
AS
BEGIN
	SET NOCOUNT ON

	--Para actualizar el valor nTipoCambio
	UPDATE [DBTarjeta].[dbo].[BimReporte32B_I]
	SET nTipoCambio = @nTipoCambio
	WHERE nIdRepBI = @nIdRepBI

	SET NOCOUNT OFF
END
GO