USE DBTarjeta
GO

/*********************************************************                      
NOMBRE             : spu_Bim_Insertar_Reporte32B_V              
PROPOSITO          : Inserta las filas del ReportePDP BV
CREACION           : HSPC         
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  :                     
				EXEC spu_Bim_Insertar_Reporte32B_V
**********************************************************/
ALTER PROCEDURE dbo.spu_Bim_Insertar_Reporte32B_V 
	   @pcNombreArchivo VARCHAR(250),
	   @pnNroLinea INT,
	   @cCodFila INT,
	   @nTel�fono INT,
	   @nTarjetaPrepago INT,
	   @nOtro INT
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @inIdCabezera INT

	--para recuperar el id de cabecera
	SELECT TOP 1 @inIdCabezera = nIdCabezera
	FROM [DBTarjeta].[dbo].[BimLogArchivosProcesados] bla WITH (NOLOCK)
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK) ON bla.nIdLogArchivos = brc.nIdLogArchivos
	WHERE bla.cNombreArchivo = @pcNombreArchivo

	IF (@pnNroLinea = 1)
	BEGIN
		--Verificamos si ha sido leido el archivo con esa cabecera
		UPDATE brb
		SET bEstado = 1 --Actualizamos el estado a inactivo
		FROM [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK)
		INNER JOIN [DBTarjeta].[dbo].[BimReporte32B_IV] brb WITH (NOLOCK) ON brc.nIdCabezera = brb.nIdCabecera
		WHERE brc.nIdCabezera = @inIdCabezera
	END

	INSERT INTO [DBTarjeta].[dbo].[BimReporte32B_V] (
		[nIdCabecera],
		[cCodFila],
		[nTel�fono],
		[nTarjetaPrepago],
		[nOtro],
		[bEstado]
		)
	VALUES (
		@inIdCabezera,
		@cCodFila,
		@nTel�fono,
		@nTarjetaPrepago,
		@nOtro,
		0
		)

     SELECT '0' AS RESULTADO

	SET NOCOUNT OFF
END
GO