USE DBTarjeta
GO

/***********************************************************************************************************************************                          
NOMBRE             : BimReporte32BIIRecuperar_spu                
PROPOSITO          : Recuperar el Reporte32BII segun la fecha
EJECUTAR EN        : DBTarjeta
CREACION           : 
MODIFICACION       : 30/05/2023 HSPC - Modificacion de seleccion de columnas para el cambio de Reporte 32A            
MODO DE EJECUCION  : exec BimReporte32BIIRecuperar_spu '20230210'
				 exec BimReporte32BIIRecuperar_spu '20231212'
                   
***********************************************************************************************************************************/
CREATE PROCEDURE dbo.BimReporte32BIIRecuperar_spu 
    @dFecha DATETIME
AS
BEGIN
	SET NOCOUNT ON

	--Para recuperar el Reporte32BII segun la fecha

	SELECT bla.cNombreArchivo,
		bla.cFecha,
		br.nIdRepBII,
		br.cCodFila,
		br.nMonedaNacional,
		br.nMonedaExtranjera,
		br.nTotal,
		brc.nIdCabezera,
		brc.cCodigoFormato,
		brc.cAnexo,
		brc.cEntidad,
		brc.dFecha,
		brc.cExpMontos,
		brc.nDatosControl,
		t.nValVent Venta,
		t.nValComp Compra,
		t.nValPondVenta
	FROM [DBTarjeta].[dbo].[BimLogArchivosProcesados] bla WITH (NOLOCK)
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK) ON bla.nIdLogArchivos = brc.nIdLogArchivos
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32B_II] br WITH (NOLOCK) ON brc.nIdCabezera = br.nIdCabecera
	LEFT JOIN DBCMAC..TipoCambio t WITH (NOLOCK) ON YEAR(brc.dFecha) = YEAR(t.dFecCamb)
	WHERE br.bEstado = 0
		AND brc.dFecha = @dFecha
		AND @dFecha = (
			SELECT TOP 1 t.dFecCamb
			FROM DBCMAC..TipoCambio WITH (NOLOCK)
			WHERE YEAR(dFecCamb) = YEAR(@dFecha)
				AND MONTH(dFecCamb) = MONTH(@dFecha)
			ORDER BY 1 DESC
			)
	SET NOCOUNT OFF
END
GO