USE DBTarjeta
GO

/***********************************************************************************************************************************                          
NOMBRE             : BimReporte32BIIIRecuperar_spu                
PROPOSITO          : Recuperar el Reporte32BIII segun la fecha
EJECUTAR EN        : DBTarjeta
CREACION           : 
MODIFICACION       : 30/05/2023 HSPC - Modificacion de seleccion de columnas para el cambio de Reporte 32A
            
MODO DE EJECUCION  : exec BimReporte32BIIIRecuperar_spu '20220210'
				 exec BimReporte32BIIIRecuperar_spu '20221212'                    
                   
***********************************************************************************************************************************/
CREATE PROCEDURE dbo.BimReporte32BIIIRecuperar_spu 
    @dFecha DATETIME
AS
BEGIN
	SET NOCOUNT ON

	--Para recuperar el Reporte32BIII segun la fecha

	SELECT bla.cNombreArchivo,
		bla.cFecha,
		br.nIdRepBIII,
		br.cCodFila,
		br.nCtaSimNroDeCuentas,
		br.nCtaSimNroDeTitu,
		br.nCtaGnrlNroDeCuentas,
		br.nCtaGnrlNroDeTitu,
		brc.nIdCabezera,
		brc.cCodigoFormato,
		brc.cAnexo,
		brc.cEntidad,
		brc.dFecha,
		brc.cExpMontos,
		brc.nDatosControl
	FROM [DBTarjeta].[dbo].[BimLogArchivosProcesados] bla WITH (NOLOCK)
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32_Cabezera] brc WITH (NOLOCK) ON bla.nIdLogArchivos = brc.nIdLogArchivos
	INNER JOIN [DBTarjeta].[dbo].[BimReporte32B_III] br WITH (NOLOCK) ON brc.nIdCabezera = br.nIdCabecera
	WHERE br.bEstado = 0
		AND brc.dFecha = @dFecha
	SET NOCOUNT OFF
END
GO