USE DBTarjeta
GO

/* ===================================
NOMBRE             : spu_Bim_EliminarRutas              
PROPOSITO          : 
CREACION           : 
MODIFICACION       : 07/04/2023 HSPC
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  : EXEC spu_Bim_EliminarRutas 8            
=================================== */
CREATE PROCEDURE dbo.spu_Bim_EliminarRutas
	   @nid INT,
	   @cRuta VARCHAR(80) = NULL,
	   @nTipoRuta INT = NULL
AS
BEGIN
    SET NOCOUNT ON

	/* VERIFICACION DE PARAMETROS EN NULO */

	/* MODIFICACION DEL REGISTRO */
	DELETE DBTarjeta..BIMRutas
	WHERE nid = @nid

	SELECT '0' AS RESULTADO

	SET NOCOUNT OFF
END
GO