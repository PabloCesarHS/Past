USE DBTarjeta
GO

/* ===================================
NOMBRE             : spu_Bim_InsertarRutas              
PROPOSITO          : Registra las rutas  
CREACION           :       
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  :                     
				EXEC spu_Bim_InsertarRutas 'C:\\Users\\hspc\\Documents\\Certificado_Tramo_I-_Protejo_mi_Integridad.pdf',0
=================================== */
CREATE PROCEDURE dbo.spu_Bim_InsertarRutas
     @pcRuraArchivo VARCHAR(250),
	@pnTipo INT = 0
AS
BEGIN
	SET NOCOUNT ON

	IF (@pnTipo = 0)
	BEGIN
		SET @pnTipo = (SELECT MAX(nTipoRuta) + 1 FROM DBTarjeta..BimRutas)
	END

	IF EXISTS (SELECT * FROM DBTarjeta..BimRutas WITH (NOLOCK)WHERE cRuta = @pcRuraArchivo)
	BEGIN
		UPDATE DBTarjeta..BimRutas
		SET nTipoRuta = @pnTipo
		WHERE cRuta = @pcRuraArchivo

		SELECT '2' AS RESULTADO
	END
	ELSE
	BEGIN
		INSERT INTO [DBTarjeta].[dbo].[BimRutas] (
			[cRuta],
			[nTipoRuta]
			)
		VALUES (
			@pcRuraArchivo,
			@pnTipo
			)
	END

	SELECT '0' AS RESULTADO

	SET NOCOUNT OFF
END
GO