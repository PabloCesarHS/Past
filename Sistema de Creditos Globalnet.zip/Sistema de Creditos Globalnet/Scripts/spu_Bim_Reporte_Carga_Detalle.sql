USE DBTarjeta
GO

/* ===================================
NOMBRE             : spu_Bim_Reporte_Carga_Detalle              
PROPOSITO          : Muestra la lista de archivos cargados entre fechas
CREACION           : 29/05/2022 HSPC         
EJECUTAR EN        : DBTarjeta             
MODO DE EJECUCION  :                     
				EXEC spu_Bim_Reporte_Carga_Detalle 'PorNombre','20221212'
				EXEC spu_Bim_Reporte_Carga_Detalle 'PorFechaSistema','20221212'
				EXEC spu_Bim_Reporte_Carga_Detalle 'PorFechasReal','20221212'
=================================== */
CREATE PROCEDURE dbo.spu_Bim_Reporte_Carga_Detalle
    @ndTipo VARCHAR(15) = 'PorNombre',
    @pdFechainicio VARCHAR(8) = NULL
AS
BEGIN
    SET NOCOUNT ON

    IF(@pdFechainicio IS NULL OR @pdFechainicio = '')
	   SET @pdFechainicio = CONVERT(DATETIME, GETDATE(), 112)

    DECLARE @dFechaFin DATETIME
    SET @dFechaFin = DATEADD(DAY, 1,  CONVERT(VARCHAR, @pdFechainicio, 103))

    IF(@ndTipo = 'PorNombre')
	   BEGIN
		  SELECT nIdLogArchivos,cNombreArchivo,dFechaSistema,dFechaReal,cFecha,cUSer,cAgencia,bEstadoInactivo 
		  FROM BimLogArchivosProcesados WITH (NOLOCK) WHERE cNombreArchivo LIKE '%' + REPLACE(CONVERT(VARCHAR, @pdFechainicio, 111),'/','') + '%'
		  ORDER BY nIdLogArchivos
	   END
    IF(@ndTipo = 'PorFechaSistema')
	   BEGIN
		  SELECT nIdLogArchivos,cNombreArchivo,dFechaSistema,dFechaReal,cFecha,cUSer,cAgencia,bEstadoInactivo 
		  FROM BimLogArchivosProcesados WITH (NOLOCK) WHERE CONVERT(DATETIME, dFechaSistema, 112) BETWEEN @pdFechainicio AND @dFechaFin
		  ORDER BY nIdLogArchivos
	   END
    IF(@ndTipo = 'PorFechasReal')
	   BEGIN	   
		  SELECT nIdLogArchivos,cNombreArchivo,dFechaSistema,dFechaReal,cFecha,cUSer,cAgencia,bEstadoInactivo 
		  FROM BimLogArchivosProcesados WITH (NOLOCK) WHERE CONVERT(DATETIME, dFechaReal, 112) BETWEEN @pdFechainicio AND @dFechaFin
		  ORDER BY nIdLogArchivos
	   END

	   PRINT @ndTipo
	   PRINT @pdFechainicio
	   PRINT @dFechaFin

    SET NOCOUNT OFF
END
GO