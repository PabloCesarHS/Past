﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using static CapaNegocio.cConfiguracion;

namespace miBIM.Forms
{
    public partial class frmAccesos : Form
    {
        public frmAccesos()
        {
            InitializeComponent();
            listarGrupos();
            listarUsuarios();
        }

        cConfiguracion vgConfiguracion = new cConfiguracion();
        
        List<cGrupos> vgListaGrupos = new List<cGrupos>();
        List<cUsuarios> vgListaUsuarios = new List<cUsuarios>();

        private void listarGrupos()
        {
            vgConfiguracion = new cConfiguracion();
            var cResultado = vgConfiguracion.Listar_Grupos();
            vgListaGrupos = cTransformador.ConvertirDataTableAClase<cGrupos>(cResultado.Datos);
            dgvListaGrupos.DataSource = vgListaGrupos;

            Mostrar_Mensaje(cResultado.Mensaje, cResultado.Estado);
        }

        private void listarUsuarios()
        {
            vgConfiguracion = new cConfiguracion();
            var cResultado = vgConfiguracion.Listar_Usuarios();
            vgListaUsuarios = cTransformador.ConvertirDataTableAClase<cUsuarios>(cResultado.Datos);
            dgvListaUsuarios.DataSource = vgListaUsuarios;

            Mostrar_Mensaje(cResultado.Mensaje, cResultado.Estado);
        }

        private void ControlesEdicion()
        {
            
        }

        private void ControlesDefecto()
        {
            
        }

        private bool ValidarClaseRuta()
        {
            bool Correcto = false;
                        

            return Correcto;
        }

        private void Mostrar_Mensaje(string _Mensaje, int _Tipo)
        {
            switch (_Tipo)
            {
                case 1:
                    lbMensaje.ForeColor = System.Drawing.Color.Blue;
                    lbMensaje.Text = _Mensaje;
                    break;

                case 2:
                    lbMensaje.ForeColor = System.Drawing.Color.OrangeRed;
                    lbMensaje.Text = "ADVERTENCIA:" + _Mensaje;
                    break;

                case 3:
                    lbMensaje.ForeColor = System.Drawing.Color.Red;
                    lbMensaje.Text = "ERROR:" + _Mensaje;
                    break;

                default:
                    lbMensaje.ForeColor = System.Drawing.Color.Green;
                    lbMensaje.Text = _Mensaje;
                    break;
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}