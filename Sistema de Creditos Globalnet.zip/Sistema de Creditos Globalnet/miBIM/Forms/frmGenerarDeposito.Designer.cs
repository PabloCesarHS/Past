﻿namespace miBIM.Forms
{
    partial class frmGenerarDeposito
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGenerarDeposito));
            this.laTitulo = new System.Windows.Forms.Label();
            this.laTelefono = new System.Windows.Forms.Label();
            this.laMonto = new System.Windows.Forms.Label();
            this.laMensaje = new System.Windows.Forms.Label();
            this.tbCelular = new System.Windows.Forms.TextBox();
            this.tbMonto = new System.Windows.Forms.TextBox();
            this.laNumeroReferencia = new System.Windows.Forms.Label();
            this.tbNumeroReferencia = new System.Windows.Forms.TextBox();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.laApellidos = new System.Windows.Forms.Label();
            this.laNombre = new System.Windows.Forms.Label();
            this.btnBuscarTelefono = new System.Windows.Forms.Button();
            this.tbMensaje = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.dgvDepositos = new System.Windows.Forms.DataGridView();
            this.edit = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btnGenerar = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepositos)).BeginInit();
            this.SuspendLayout();
            // 
            // laTitulo
            // 
            this.laTitulo.AutoSize = true;
            this.laTitulo.BackColor = System.Drawing.Color.YellowGreen;
            this.laTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.laTitulo.ForeColor = System.Drawing.SystemColors.Control;
            this.laTitulo.Location = new System.Drawing.Point(178, 18);
            this.laTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laTitulo.Name = "laTitulo";
            this.laTitulo.Size = new System.Drawing.Size(192, 20);
            this.laTitulo.TabIndex = 0;
            this.laTitulo.Text = "GENERAR DEPÓSITO";
            this.laTitulo.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // laTelefono
            // 
            this.laTelefono.AutoSize = true;
            this.laTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.laTelefono.Location = new System.Drawing.Point(26, 27);
            this.laTelefono.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laTelefono.Name = "laTelefono";
            this.laTelefono.Size = new System.Drawing.Size(86, 13);
            this.laTelefono.TabIndex = 1;
            this.laTelefono.Text = "Numero Celular *";
            // 
            // laMonto
            // 
            this.laMonto.AutoSize = true;
            this.laMonto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.laMonto.Location = new System.Drawing.Point(337, 27);
            this.laMonto.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laMonto.Name = "laMonto";
            this.laMonto.Size = new System.Drawing.Size(44, 13);
            this.laMonto.TabIndex = 2;
            this.laMonto.Text = "Monto *";
            // 
            // laMensaje
            // 
            this.laMensaje.AutoSize = true;
            this.laMensaje.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.laMensaje.Location = new System.Drawing.Point(60, 69);
            this.laMensaje.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laMensaje.Name = "laMensaje";
            this.laMensaje.Size = new System.Drawing.Size(47, 13);
            this.laMensaje.TabIndex = 3;
            this.laMensaje.Text = "Mensaje";
            // 
            // tbCelular
            // 
            this.tbCelular.Location = new System.Drawing.Point(120, 24);
            this.tbCelular.Margin = new System.Windows.Forms.Padding(2);
            this.tbCelular.MaxLength = 9;
            this.tbCelular.Name = "tbCelular";
            this.tbCelular.Size = new System.Drawing.Size(153, 20);
            this.tbCelular.TabIndex = 4;
            this.tbCelular.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCelular_KeyPress);
            // 
            // tbMonto
            // 
            this.tbMonto.Location = new System.Drawing.Point(390, 27);
            this.tbMonto.Margin = new System.Windows.Forms.Padding(2);
            this.tbMonto.Name = "tbMonto";
            this.tbMonto.Size = new System.Drawing.Size(153, 20);
            this.tbMonto.TabIndex = 5;
            this.tbMonto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbMonto_KeyPress);
            this.tbMonto.Leave += new System.EventHandler(this.tbMonto_Leave);
            // 
            // laNumeroReferencia
            // 
            this.laNumeroReferencia.AutoSize = true;
            this.laNumeroReferencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.laNumeroReferencia.Location = new System.Drawing.Point(282, 66);
            this.laNumeroReferencia.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laNumeroReferencia.Name = "laNumeroReferencia";
            this.laNumeroReferencia.Size = new System.Drawing.Size(99, 13);
            this.laNumeroReferencia.TabIndex = 7;
            this.laNumeroReferencia.Text = "Numero Referencia";
            this.laNumeroReferencia.Visible = false;
            // 
            // tbNumeroReferencia
            // 
            this.tbNumeroReferencia.Location = new System.Drawing.Point(390, 59);
            this.tbNumeroReferencia.Margin = new System.Windows.Forms.Padding(2);
            this.tbNumeroReferencia.Name = "tbNumeroReferencia";
            this.tbNumeroReferencia.Size = new System.Drawing.Size(153, 20);
            this.tbNumeroReferencia.TabIndex = 8;
            this.tbNumeroReferencia.Visible = false;
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(468, 11);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(2);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(76, 30);
            this.btnSalir.TabIndex = 14;
            this.btnSalir.Text = "&Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(371, 93);
            this.btnLimpiar.Margin = new System.Windows.Forms.Padding(2);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(75, 25);
            this.btnLimpiar.TabIndex = 16;
            this.btnLimpiar.Text = "&Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // laApellidos
            // 
            this.laApellidos.AutoSize = true;
            this.laApellidos.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.laApellidos.Location = new System.Drawing.Point(222, 46);
            this.laApellidos.Name = "laApellidos";
            this.laApellidos.Size = new System.Drawing.Size(27, 13);
            this.laApellidos.TabIndex = 20;
            this.laApellidos.Text = "N/A";
            this.laApellidos.Visible = false;
            // 
            // laNombre
            // 
            this.laNombre.AutoSize = true;
            this.laNombre.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.laNombre.Location = new System.Drawing.Point(120, 46);
            this.laNombre.Name = "laNombre";
            this.laNombre.Size = new System.Drawing.Size(27, 13);
            this.laNombre.TabIndex = 19;
            this.laNombre.Text = "N/A";
            this.laNombre.Visible = false;
            // 
            // btnBuscarTelefono
            // 
            this.btnBuscarTelefono.Location = new System.Drawing.Point(280, 23);
            this.btnBuscarTelefono.Name = "btnBuscarTelefono";
            this.btnBuscarTelefono.Size = new System.Drawing.Size(29, 24);
            this.btnBuscarTelefono.TabIndex = 18;
            this.btnBuscarTelefono.Text = "...";
            this.btnBuscarTelefono.UseVisualStyleBackColor = true;
            this.btnBuscarTelefono.Visible = false;
            // 
            // tbMensaje
            // 
            this.tbMensaje.Location = new System.Drawing.Point(123, 62);
            this.tbMensaje.Name = "tbMensaje";
            this.tbMensaje.Size = new System.Drawing.Size(153, 20);
            this.tbMensaje.TabIndex = 17;
            this.tbMensaje.Leave += new System.EventHandler(this.tbMensaje_Leave);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.laTitulo);
            this.panel2.Location = new System.Drawing.Point(6, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(553, 59);
            this.panel2.TabIndex = 16;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.btnSalir);
            this.panel1.Location = new System.Drawing.Point(6, 470);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(554, 48);
            this.panel1.TabIndex = 20;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnLimpiar);
            this.groupBox1.Controls.Add(this.tbCelular);
            this.groupBox1.Controls.Add(this.laApellidos);
            this.groupBox1.Controls.Add(this.btnAgregar);
            this.groupBox1.Controls.Add(this.laTelefono);
            this.groupBox1.Controls.Add(this.laNombre);
            this.groupBox1.Controls.Add(this.laMonto);
            this.groupBox1.Controls.Add(this.btnBuscarTelefono);
            this.groupBox1.Controls.Add(this.laMensaje);
            this.groupBox1.Controls.Add(this.tbMensaje);
            this.groupBox1.Controls.Add(this.tbMonto);
            this.groupBox1.Controls.Add(this.tbNumeroReferencia);
            this.groupBox1.Controls.Add(this.laNumeroReferencia);
            this.groupBox1.Location = new System.Drawing.Point(6, 67);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(553, 125);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DATOS DEPÓSITO";
            // 
            // btnAgregar
            // 
            this.btnAgregar.Image = global::miBIM.Properties.Resources.agregar;
            this.btnAgregar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAgregar.Location = new System.Drawing.Point(468, 95);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(75, 23);
            this.btnAgregar.TabIndex = 22;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_Cancelar);
            this.groupBox2.Controls.Add(this.dgvDepositos);
            this.groupBox2.Controls.Add(this.btnGenerar);
            this.groupBox2.Location = new System.Drawing.Point(6, 198);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(553, 266);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DEPÓSITOS A GENERAR";
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.Location = new System.Drawing.Point(390, 226);
            this.btn_Cancelar.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(75, 28);
            this.btn_Cancelar.TabIndex = 13;
            this.btn_Cancelar.Text = "&Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // dgvDepositos
            // 
            this.dgvDepositos.AllowUserToAddRows = false;
            this.dgvDepositos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDepositos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDepositos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.edit});
            this.dgvDepositos.Location = new System.Drawing.Point(14, 16);
            this.dgvDepositos.Margin = new System.Windows.Forms.Padding(0);
            this.dgvDepositos.Name = "dgvDepositos";
            this.dgvDepositos.ReadOnly = true;
            this.dgvDepositos.Size = new System.Drawing.Size(529, 208);
            this.dgvDepositos.TabIndex = 15;
            this.dgvDepositos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDepositos_CellClick);
            // 
            // edit
            // 
            this.edit.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            this.edit.DefaultCellStyle = dataGridViewCellStyle1;
            this.edit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.edit.Frozen = true;
            this.edit.HeaderText = "Edit";
            this.edit.Name = "edit";
            this.edit.ReadOnly = true;
            this.edit.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.edit.ToolTipText = "Eliminar";
            this.edit.Width = 31;
            // 
            // btnGenerar
            // 
            this.btnGenerar.Location = new System.Drawing.Point(468, 226);
            this.btnGenerar.Margin = new System.Windows.Forms.Padding(2);
            this.btnGenerar.Name = "btnGenerar";
            this.btnGenerar.Size = new System.Drawing.Size(75, 28);
            this.btnGenerar.TabIndex = 12;
            this.btnGenerar.Text = "&Generar";
            this.btnGenerar.UseVisualStyleBackColor = true;
            this.btnGenerar.Click += new System.EventHandler(this.btnGenerar_Click);
            // 
            // frmGenerarDeposito
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(566, 523);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmGenerarDeposito";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Generar Depósito";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepositos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label laTitulo;
        private System.Windows.Forms.Label laTelefono;
        private System.Windows.Forms.Label laMonto;
        private System.Windows.Forms.Label laMensaje;
        private System.Windows.Forms.TextBox tbCelular;
        private System.Windows.Forms.TextBox tbMonto;
        private System.Windows.Forms.Label laNumeroReferencia;
        private System.Windows.Forms.TextBox tbNumeroReferencia;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.TextBox tbMensaje;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnBuscarTelefono;
        private System.Windows.Forms.Label laNombre;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label laApellidos;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.DataGridView dgvDepositos;
        private System.Windows.Forms.DataGridViewButtonColumn edit;
        private System.Windows.Forms.Button btnGenerar;

    }
}