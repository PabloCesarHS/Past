﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miBIM.Forms
{
    public partial class frmGenerarDeposito : Form
    {

        public String cUser = Environment.UserName.ToString().ToUpper();
        public String cAgencia = "01";

        public frmGenerarDeposito()
        {
            InitializeComponent();
        }

        //UQMA Comento
        //private void Habilitar_Deposito()
        //{
        //    paBuscarPersona.Visible = false;
        //    paDatosDeposito.Visible = true;

        //    paDepositos.Enabled = true;
        //    btnAgregar.Enabled = true;
        //}

        //UQMA Comento
        //private void btnBuscar_Salir_Click(object sender, EventArgs e)
        //{
        //    Habilitar_Deposito();
        //}

        //UQMA Comento
        //private void btnBuscarTelefono_Click(object sender, EventArgs e)
        //{
        //    paBuscarPersona.Visible = true;
        //    paDatosDeposito.Visible = false;

        //    paDepositos.Enabled = false;
        //    btnAgregar.Enabled = false;

        //    tbBuscar.Focus();
        //}

        //UQMA Comento
        //private void btnBuscarPersona_Click(object sender, EventArgs e)
        //{
        //    DataSet dsPersonas = new DataSet();
        //    CapaNegocio.cArchivoInstruccion oInstrunccion = new CapaNegocio.cArchivoInstruccion();

        //    dsPersonas = oInstrunccion.BuscarPersona(tbBuscar.Text);

        //    dgvUsuariosBim.DataSource =  dsPersonas.Tables[0];
            
        //}

        //UQMA Comento
        //private void dgvUsuariosBim_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        //{
        //    laNombre.Visible=true;
        //    laApellidos.Visible=true;
            
        //    try
        //    {
        //        String cNombre = dgvUsuariosBim["Nombre", e.RowIndex].Value.ToString();
        //        String cApellido = dgvUsuariosBim["Apellido", e.RowIndex].Value.ToString();
        //        String cNroCelular = dgvUsuariosBim["NroCelular", e.RowIndex].Value.ToString();
        //        laNombre.Text = cNombre;
        //        laApellidos.Text = cApellido;
        //        tbCelular.Text = cNroCelular;

        //        dgvUsuariosBim.DataSource = null;
        //        paDatosDeposito.Visible = true;
        //        paBuscarPersona.Visible = false;

        //        Habilitar_Deposito();
        //    }
        //    catch (Exception)
        //    {
        //        MessageBox.Show("Seleccione opcion valida");                
        //    }
            
        //}

        private void tbMonto_Leave(object sender, EventArgs e)
        {
            decimal nValor = 0;

            if (tbMonto.Text != "")
            {
                if (Decimal.TryParse(tbMonto.Text.ToString(), out nValor))
                {
                    decimal value = decimal.Parse(tbMonto.Text);
                    string result = String.Format("{0,12:0.00}", value);
                    tbMonto.Text = result.Trim();

                }
                else
                    MessageBox.Show("Ingrese parametro valido", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); //UQMA Se agrego icono de alerta

                
            }
        }


        private Boolean Existe_NumeroCElular(String cNroCelular)
        {
            Boolean bExiste = false; 
            foreach (DataGridViewRow row in dgvDepositos.Rows)
            {
                string Valor = Convert.ToString(row.Cells["NroCelular"].Value);
                if (Valor == cNroCelular)
                    bExiste = true; 
                else
                    bExiste = false; 
            }
            return bExiste;
 
        }

        private void Limpiar_DatosDeposito()
        {
            tbCelular.Clear();
            laNombre.ResetText();
            laApellidos.ResetText();
            tbMonto.Clear();
            tbMensaje.Clear();
            tbNumeroReferencia.Clear();
        }

        private void tbMensaje_Leave(object sender, EventArgs e)
        {
            tbMensaje.Text = tbMensaje.Text.ToUpper();
        }

        private void dgvDepositos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0)
                    dgvDepositos.Rows.RemoveAt(e.RowIndex);            

            }
            catch (Exception)
            {
                MessageBox.Show("Seleccion no valida", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); //UQMA Se agrego icono de alerta
            }
            
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            dgvDepositos.Rows.Clear();
            dgvDepositos.Refresh();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGenerar_Click(object sender, EventArgs e)
        {            
            String cNroCelular;
            String cNombre;
            String cApellido;
            Double nMoney;
            String cMensaje;
            int nRespuesta;            
            int[] nNroMovimientos;
            int i = 0;
            int nEscompensacion = 0;


            cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
            DataTable oResultado = new DataTable();
            DateTime dFechaSistema = oInstruccion.Obtiene_FechaSistema();
            nNroMovimientos = new int[dgvDepositos.Rows.Count];

            foreach (DataGridViewRow fila in dgvDepositos.Rows)
            {
                cNroCelular = fila.Cells["NroCelular"].Value.ToString();
                cNombre = fila.Cells["Nombre"].Value.ToString();
                cApellido = fila.Cells["Apellido"].Value.ToString();
                nMoney = Double.Parse(fila.Cells["Monto"].Value.ToString());
                cMensaje = fila.Cells["Mensaje"].Value.ToString();

                oResultado = oInstruccion.Insertar_Deposito(cUser, cAgencia, dFechaSistema, cNroCelular, cNombre, cApellido, nMoney, cMensaje, nEscompensacion, 0,0, true);    //UQMA 29/09/2017 Se agrego parametros  0,0 true     
                nRespuesta = int.Parse(oResultado.Rows[0][0].ToString());
                if (nRespuesta == -1)
                {
                    MessageBox.Show("Error al registrar deposito", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); //UQMA Se agrego icono de alerta
                }
                else
                {
                    nNroMovimientos[i] = nRespuesta;
                }
                i++;
            }
            i = 0;

            EscribirDeposito(nNroMovimientos);
            
        }

        //RTYP 20160711 Escribir archico de conciliacion
        private void EscribirDeposito(int[] nNroMovimientos)
        {
            DataSet dsCompensacion = new DataSet();
            cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
            String cTipoOperacion;
            //String cTipo;
            DateTime dFehaHoraTransaccion;
            DateTime dFehaHoraRecepcion;
            Double nMonto;
            String cMSISDN;
            int nMovBIM;
            String cNombre;
            String cApellido;
            //String IdIntruccionPago;
            //int IdTransaccion;
            String cRemitenteCodigo;
            String cRemitenteCuenta;
            String cMensaje; 
            int nMov;

            StreamWriter sw = null;
            DateTime dFecha = DateTime.Now;
            cConstante cConstante = new cConstante();
            String cNombreArchivo;
            cNombreArchivo = "CCUSCO-DEP-" + dFecha.ToString("yyyyMMddHHmmss") + ".csv";
            //string path = @"C:\Modelo Peru\Outgoing\" + cNombreArchivo;
            string path = cConstante.cpRutaOrigenOutgoing + cNombreArchivo;
            DataSet oCabecera;
            int nPrimera = 0;
                       
            
            if (nPrimera == 0)
            {
                nPrimera = nPrimera + 1;
                //Obtener cabecera 
                oCabecera = oInstruccion.ObtenerCabecera();
                sw = File.CreateText(path);

                foreach (DataRow row in oCabecera.Tables[0].Rows)
                {
                    sw.WriteLine(row["cCabecera"].ToString());
                }
                sw.Flush();
                sw.Close();
            }
            else
            {
                File.Delete(path);
                sw = File.CreateText(path);
                sw.Flush();
                sw.Close();
            }

            for (int i = 0; i < nNroMovimientos.Length; i++)
            {
                nMov = nNroMovimientos[i];

                dsCompensacion = oInstruccion.Obtener_Deposito(cNombreArchivo, nMov);

                if (dsCompensacion.Tables[0].Rows.Count == 0)
                {
                    MessageBox.Show("No existen operaciones registradas en la fecha ");
                }
                else
                {
                    foreach (DataRow row in dsCompensacion.Tables[0].Rows)
                    {
                        //cTipoOperacion, dFehaHoraTransaccion,dFehaHoraRecepcion,nMonto, cMSISDN, nMovBIM,cNombre, cApellido,cRemitenteCodigo,cRemitenteCuenta
                        cTipoOperacion = row["cTipoOperacion"].ToString();
                        dFehaHoraTransaccion = DateTime.Parse(row["dFechaHoraTransaccion"].ToString());
                        dFehaHoraRecepcion = DateTime.Parse(row["dFechaHoraRecepcion"].ToString());
                        nMonto = Double.Parse(row["nMonto"].ToString());
                        cMSISDN = row["cMSISDN"].ToString();
                        nMovBIM = int.Parse(row["nMovBIM"].ToString());
                        cNombre = row["cNombre"].ToString();
                        cApellido = row["cApellido"].ToString();
                        cRemitenteCodigo = row["cRemitenteCodigo"].ToString();
                        cRemitenteCuenta = row["cRemitenteCuenta"].ToString();
                        cMensaje = row["cMensaje"].ToString();

                        sw = File.AppendText(path);
                        sw.WriteLine(cTipoOperacion + "," + dFehaHoraTransaccion.ToString("yyyy-MM-dd HH:mm:ss") + "," + "" + "," +String.Format("{0,12:0.00}", nMonto).Trim() + "," + cMSISDN + "," + nMovBIM + "," + cNombre + "," + cApellido + "," + cRemitenteCodigo + "," + cRemitenteCuenta + "," + cMensaje);
                        sw.Flush();
                        sw.Close();
                    }
                }
            }
            //FirmarDocumento  
            String cMensajeFirma = cConstante.FirmaArchivo(cNombreArchivo);
            if (cMensajeFirma != "")
            {
                MessageBox.Show(cMensajeFirma.ToString(), "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error); //UQMA Se agrego icono de alerta
                return;
            }
            dgvDepositos.Rows.Clear();
            MessageBox.Show("Archivo Generado de forma satisfactoria, " + path, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information); //UQMA Se agrego icono de alerta
            //return path;
        }
        //private void FirmaArchivo(String cNombreArchivo)
        //{
        //    try
        //    {
        //        cConstante cConstante = new cConstante();
        //        System.Diagnostics.Process process = new System.Diagnostics.Process();
        //        System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
        //        startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Maximized;
        //        startInfo.FileName = "cmd.exe";
        //        //startInfo.Arguments = "/C copy /b Image1.jpg + Archive.rar Image2.jpg";
        //        //startInfo.Arguments = "/C c:>openssl dgst -sha256 -sign C:\\Certificado\\cajacusco_filesigning_privatekey.key -out " + cConstante.cpRutaOrigenOutgoing + cNombreArchivo + ".signature " + cConstante.cpRutaDestinoOutgoing + cNombreArchivo;
        //        startInfo.Arguments = "/C openssl dgst -sha256 -sign C:\\Certificado\\cajacusco_filesigning_privatekey.key -out " + cConstante.cpRutaOrigenOutgoing + cNombreArchivo + ".signature " + cConstante.cpRutaDestinoOutgoing + cNombreArchivo;
        //        process.StartInfo = startInfo;
        //        process.Start();
        //        //c:>openssl dgst -sha256 -sign C:\Certificado\cajacusco_filesigning_privatekey.key -out c:\SFTP\EWP\Outgoing\CCUSCO-REVDEP-20160202172600.csv.signature c:\SFTP\EWP\Outgoing\CCUSCO-REVDEP-20160202172600.csv
        //    }
        //    catch (Exception ex)
        //    {
                
        //        MessageBox.Show("Error: "+ex.ToString());
        //    }           
 
        //}

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar_DatosDeposito();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (tbCelular.Text != "" && tbMonto.Text != "")
            {
                if (!Existe_NumeroCElular(tbCelular.Text))
                {
                    if (tbCelular.Text.Length < 9)
                    {
                        MessageBox.Show("Numero celular Incorrecto", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error); //UQMA Se agrego icono de alerta

                    }
                    else //UQMA
                    {
                        dgvDepositos.ColumnCount = 6;
                        dgvDepositos.ColumnHeadersVisible = true;

                        dgvDepositos.Columns[0].Name = "X";
                        dgvDepositos.Columns[1].Name = "NroCelular";
                        dgvDepositos.Columns[2].Name = "Nombre";
                        dgvDepositos.Columns[3].Name = "Apellido";
                        dgvDepositos.Columns[4].Name = "Monto";
                        dgvDepositos.Columns[5].Name = "Mensaje";

                        DataGridViewRow fila = new DataGridViewRow();

                        int nNroFilas = dgvDepositos.Rows.Count;

                        //dgvDepositos.Rows.Insert(nNroFilas, "X", tbCelular.Text, laNombre.Text, laApellidos.Text, tbMonto.Text, tbMensaje.Text); //UQMA  COMENTO 04/12/2017
                        dgvDepositos.Rows.Insert(nNroFilas, "X", tbCelular.Text, "", "", tbMonto.Text, tbMensaje.Text); //UQMA   04/12/2017

                        Limpiar_DatosDeposito();
                    }
                }
                else
                    MessageBox.Show("Numero Celular ya Agregado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); //UQMA Se agrego icono de alerta
            }
            else
                MessageBox.Show("Faltan datos ", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); //UQMA Se agrego icono de alerta
        }

        private void tbMonto_KeyPress(object sender, KeyPressEventArgs e)  //24042018 LVCH solo numeros con 2 decimales
        {
            char aux = e.KeyChar;

            if (char.IsControl(e.KeyChar)) //
            {
                e.Handled = false;
            }
            else
            {
                if (char.IsDigit(e.KeyChar)) //Si es numero
                {
                    TextBox txt = sender as TextBox;
                    int ubicacion_cursor = txt.SelectionStart;
                    if (ubicacion_cursor < txt.Text.Split('.')[0].Length + 1)
                    {
                        if (txt.Text.Length >= 10) // validar para digitar hasta 10 enteros
                            e.Handled = true;
                        else
                            e.Handled = false; //agregamos numeros al lado izquierdo
                    }
                    else
                    {
                        if (txt.Text.Split('.')[1].Length <= 1)
                            e.Handled = false; //permitimos 2 decimales 
                        else
                            e.Handled = true;
                    }
                }
                else
                {
                    if (e.KeyChar == 46) // si es punto
                    {
                        TextBox txt = sender as TextBox;

                        if (txt.Text != "")
                            e.Handled = txt.Text.Contains("."); //validamos poner solo un punto
                        else
                            e.Handled = true;
                    }
                    else
                        e.Handled = true;
                }
            }
        }

        private void tbCelular_KeyPress(object sender, KeyPressEventArgs e) //24042018 LVCH solo numeros 
        {
            char aux = e.KeyChar;

            if (char.IsControl(e.KeyChar)) //
            {
                e.Handled = false;
            }
            else
            {
                if (char.IsDigit(e.KeyChar)) //Si es numero
                {
                    TextBox txt = sender as TextBox;
                    int ubicacion_cursor = txt.SelectionStart;
                    if (ubicacion_cursor < txt.Text.Split('.')[0].Length + 1)
                    {
                        if (txt.Text.Length >= 9) // validar para digitar hasta 10 enteros
                            e.Handled = true;
                        else
                            e.Handled = false; //agregamos numeros al lado izquierdo
                    }
                }
                else
                {
                    e.Handled = true;
                }
            }
        }        
    }
}
