﻿namespace miBIM.Forms
{
    partial class frmImportarArchivos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.laTitulo = new System.Windows.Forms.Label();
            this.btnImportar = new System.Windows.Forms.Button();
            this.pbImportar = new System.Windows.Forms.ProgressBar();
            this.laMensajeReportes = new System.Windows.Forms.Label();
            this.lbImportados = new System.Windows.Forms.ListBox();
            this.laMensajeInstrucciones = new System.Windows.Forms.Label();
            this.btnImportarInstrucciones = new System.Windows.Forms.Button();
            this.pbImportarInstrucciones = new System.Windows.Forms.ProgressBar();
            this.lbInsImportados = new System.Windows.Forms.ListBox();
            this.paReportes = new System.Windows.Forms.Panel();
            this.lblRutaRDestino = new System.Windows.Forms.Label();
            this.lblRutaROrigen = new System.Windows.Forms.Label();
            this.paInstrucciones = new System.Windows.Forms.Panel();
            this.lblRutaIDestino = new System.Windows.Forms.Label();
            this.lblRutaIOrigen = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.paFooter = new System.Windows.Forms.Panel();
            this.lbMensaje = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnEnvioDetalleCarga = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnValidarCarga = new System.Windows.Forms.Button();
            this.dgvListaCargaArchivos = new System.Windows.Forms.DataGridView();
            this.cbRutaArchivos = new System.Windows.Forms.ComboBox();
            this.cbExtencionArchivos = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvListaRutas = new System.Windows.Forms.DataGridView();
            this.timerVerificacionArchivos = new System.Windows.Forms.Timer(this.components);
            this.paReportes.SuspendLayout();
            this.paInstrucciones.SuspendLayout();
            this.panel1.SuspendLayout();
            this.paFooter.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaCargaArchivos)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaRutas)).BeginInit();
            this.SuspendLayout();
            // 
            // laTitulo
            // 
            this.laTitulo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.laTitulo.AutoSize = true;
            this.laTitulo.BackColor = System.Drawing.Color.YellowGreen;
            this.laTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laTitulo.ForeColor = System.Drawing.SystemColors.Control;
            this.laTitulo.Location = new System.Drawing.Point(472, 18);
            this.laTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laTitulo.Name = "laTitulo";
            this.laTitulo.Size = new System.Drawing.Size(266, 26);
            this.laTitulo.TabIndex = 0;
            this.laTitulo.Text = "IMPORTAR ARCHIVOS";
            // 
            // btnImportar
            // 
            this.btnImportar.Location = new System.Drawing.Point(12, 50);
            this.btnImportar.Margin = new System.Windows.Forms.Padding(2);
            this.btnImportar.Name = "btnImportar";
            this.btnImportar.Size = new System.Drawing.Size(85, 180);
            this.btnImportar.TabIndex = 1;
            this.btnImportar.Text = "Importar &Reportes";
            this.btnImportar.UseVisualStyleBackColor = true;
            this.btnImportar.Click += new System.EventHandler(this.btnImportar_Click);
            // 
            // pbImportar
            // 
            this.pbImportar.Location = new System.Drawing.Point(15, 238);
            this.pbImportar.Margin = new System.Windows.Forms.Padding(2);
            this.pbImportar.Name = "pbImportar";
            this.pbImportar.Size = new System.Drawing.Size(445, 20);
            this.pbImportar.TabIndex = 2;
            // 
            // laMensajeReportes
            // 
            this.laMensajeReportes.AutoSize = true;
            this.laMensajeReportes.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.laMensajeReportes.Location = new System.Drawing.Point(12, 265);
            this.laMensajeReportes.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laMensajeReportes.Name = "laMensajeReportes";
            this.laMensajeReportes.Size = new System.Drawing.Size(85, 13);
            this.laMensajeReportes.TabIndex = 3;
            this.laMensajeReportes.Text = "MensajeReporte";
            this.laMensajeReportes.Visible = false;
            // 
            // lbImportados
            // 
            this.lbImportados.FormattingEnabled = true;
            this.lbImportados.HorizontalScrollbar = true;
            this.lbImportados.Location = new System.Drawing.Point(100, 50);
            this.lbImportados.Margin = new System.Windows.Forms.Padding(2);
            this.lbImportados.Name = "lbImportados";
            this.lbImportados.ScrollAlwaysVisible = true;
            this.lbImportados.Size = new System.Drawing.Size(360, 173);
            this.lbImportados.TabIndex = 4;
            // 
            // laMensajeInstrucciones
            // 
            this.laMensajeInstrucciones.AutoSize = true;
            this.laMensajeInstrucciones.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.laMensajeInstrucciones.Location = new System.Drawing.Point(11, 265);
            this.laMensajeInstrucciones.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laMensajeInstrucciones.Name = "laMensajeInstrucciones";
            this.laMensajeInstrucciones.Size = new System.Drawing.Size(110, 13);
            this.laMensajeInstrucciones.TabIndex = 5;
            this.laMensajeInstrucciones.Text = "MensajeInstrucciones";
            this.laMensajeInstrucciones.Visible = false;
            // 
            // btnImportarInstrucciones
            // 
            this.btnImportarInstrucciones.Location = new System.Drawing.Point(12, 50);
            this.btnImportarInstrucciones.Margin = new System.Windows.Forms.Padding(2);
            this.btnImportarInstrucciones.Name = "btnImportarInstrucciones";
            this.btnImportarInstrucciones.Size = new System.Drawing.Size(85, 180);
            this.btnImportarInstrucciones.TabIndex = 6;
            this.btnImportarInstrucciones.Text = "Importar &Pagos";
            this.btnImportarInstrucciones.UseVisualStyleBackColor = true;
            this.btnImportarInstrucciones.Click += new System.EventHandler(this.btnImportarInstrucciones_Click);
            // 
            // pbImportarInstrucciones
            // 
            this.pbImportarInstrucciones.Location = new System.Drawing.Point(14, 238);
            this.pbImportarInstrucciones.Margin = new System.Windows.Forms.Padding(2);
            this.pbImportarInstrucciones.Name = "pbImportarInstrucciones";
            this.pbImportarInstrucciones.Size = new System.Drawing.Size(446, 20);
            this.pbImportarInstrucciones.TabIndex = 7;
            // 
            // lbInsImportados
            // 
            this.lbInsImportados.FormattingEnabled = true;
            this.lbInsImportados.HorizontalScrollbar = true;
            this.lbInsImportados.Location = new System.Drawing.Point(100, 50);
            this.lbInsImportados.Margin = new System.Windows.Forms.Padding(2);
            this.lbInsImportados.Name = "lbInsImportados";
            this.lbInsImportados.ScrollAlwaysVisible = true;
            this.lbInsImportados.Size = new System.Drawing.Size(360, 173);
            this.lbInsImportados.TabIndex = 8;
            // 
            // paReportes
            // 
            this.paReportes.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.paReportes.Controls.Add(this.lblRutaRDestino);
            this.paReportes.Controls.Add(this.lblRutaROrigen);
            this.paReportes.Controls.Add(this.lbImportados);
            this.paReportes.Controls.Add(this.laMensajeReportes);
            this.paReportes.Controls.Add(this.pbImportar);
            this.paReportes.Controls.Add(this.btnImportar);
            this.paReportes.Location = new System.Drawing.Point(10, 10);
            this.paReportes.Name = "paReportes";
            this.paReportes.Size = new System.Drawing.Size(481, 300);
            this.paReportes.TabIndex = 9;
            // 
            // lblRutaRDestino
            // 
            this.lblRutaRDestino.AutoSize = true;
            this.lblRutaRDestino.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.lblRutaRDestino.Location = new System.Drawing.Point(13, 30);
            this.lblRutaRDestino.Name = "lblRutaRDestino";
            this.lblRutaRDestino.Size = new System.Drawing.Size(70, 13);
            this.lblRutaRDestino.TabIndex = 16;
            this.lblRutaRDestino.Text = "Ruta destino:";
            // 
            // lblRutaROrigen
            // 
            this.lblRutaROrigen.AutoSize = true;
            this.lblRutaROrigen.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.lblRutaROrigen.Location = new System.Drawing.Point(13, 11);
            this.lblRutaROrigen.Name = "lblRutaROrigen";
            this.lblRutaROrigen.Size = new System.Drawing.Size(71, 13);
            this.lblRutaROrigen.TabIndex = 16;
            this.lblRutaROrigen.Text = "Ruta oriogen:";
            // 
            // paInstrucciones
            // 
            this.paInstrucciones.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.paInstrucciones.Controls.Add(this.lblRutaIDestino);
            this.paInstrucciones.Controls.Add(this.lblRutaIOrigen);
            this.paInstrucciones.Controls.Add(this.lbInsImportados);
            this.paInstrucciones.Controls.Add(this.pbImportarInstrucciones);
            this.paInstrucciones.Controls.Add(this.btnImportarInstrucciones);
            this.paInstrucciones.Controls.Add(this.laMensajeInstrucciones);
            this.paInstrucciones.Location = new System.Drawing.Point(497, 10);
            this.paInstrucciones.Name = "paInstrucciones";
            this.paInstrucciones.Size = new System.Drawing.Size(474, 300);
            this.paInstrucciones.TabIndex = 10;
            // 
            // lblRutaIDestino
            // 
            this.lblRutaIDestino.AutoSize = true;
            this.lblRutaIDestino.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.lblRutaIDestino.Location = new System.Drawing.Point(10, 30);
            this.lblRutaIDestino.Name = "lblRutaIDestino";
            this.lblRutaIDestino.Size = new System.Drawing.Size(70, 13);
            this.lblRutaIDestino.TabIndex = 17;
            this.lblRutaIDestino.Text = "Ruta destino:";
            // 
            // lblRutaIOrigen
            // 
            this.lblRutaIOrigen.AutoSize = true;
            this.lblRutaIOrigen.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.lblRutaIOrigen.Location = new System.Drawing.Point(9, 11);
            this.lblRutaIOrigen.Name = "lblRutaIOrigen";
            this.lblRutaIOrigen.Size = new System.Drawing.Size(65, 13);
            this.lblRutaIOrigen.TabIndex = 17;
            this.lblRutaIOrigen.Text = "Ruta origen:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.laTitulo);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1013, 44);
            this.panel1.TabIndex = 11;
            // 
            // btnSalir
            // 
            this.btnSalir.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSalir.Location = new System.Drawing.Point(559, 38);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(111, 37);
            this.btnSalir.TabIndex = 12;
            this.btnSalir.Text = "&Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnLimpiar.Location = new System.Drawing.Point(345, 38);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(109, 35);
            this.btnLimpiar.TabIndex = 13;
            this.btnLimpiar.Text = "&Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // paFooter
            // 
            this.paFooter.BackColor = System.Drawing.SystemColors.ControlLight;
            this.paFooter.Controls.Add(this.lbMensaje);
            this.paFooter.Controls.Add(this.btnLimpiar);
            this.paFooter.Controls.Add(this.btnSalir);
            this.paFooter.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.paFooter.Location = new System.Drawing.Point(0, 445);
            this.paFooter.Name = "paFooter";
            this.paFooter.Size = new System.Drawing.Size(1013, 90);
            this.paFooter.TabIndex = 14;
            // 
            // lbMensaje
            // 
            this.lbMensaje.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbMensaje.AutoSize = true;
            this.lbMensaje.ForeColor = System.Drawing.Color.Red;
            this.lbMensaje.Location = new System.Drawing.Point(40, 10);
            this.lbMensaje.Name = "lbMensaje";
            this.lbMensaje.Size = new System.Drawing.Size(16, 13);
            this.lbMensaje.TabIndex = 11;
            this.lbMensaje.Text = "...";
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 50);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(989, 389);
            this.tabControl1.TabIndex = 15;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnEnvioDetalleCarga);
            this.tabPage1.Controls.Add(this.paReportes);
            this.tabPage1.Controls.Add(this.paInstrucciones);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(981, 363);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Carga de Archivos";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnEnvioDetalleCarga
            // 
            this.btnEnvioDetalleCarga.Location = new System.Drawing.Point(743, 328);
            this.btnEnvioDetalleCarga.Name = "btnEnvioDetalleCarga";
            this.btnEnvioDetalleCarga.Size = new System.Drawing.Size(228, 29);
            this.btnEnvioDetalleCarga.TabIndex = 11;
            this.btnEnvioDetalleCarga.Text = "Enviar detalle carga de archivos";
            this.btnEnvioDetalleCarga.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Controls.Add(this.btnValidarCarga);
            this.tabPage3.Controls.Add(this.dgvListaCargaArchivos);
            this.tabPage3.Controls.Add(this.cbRutaArchivos);
            this.tabPage3.Controls.Add(this.cbExtencionArchivos);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1173, 363);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Validacion de Archivos";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label3.Location = new System.Drawing.Point(320, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Tipo archivo:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label2.Location = new System.Drawing.Point(24, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Lista de rutas:";
            // 
            // btnValidarCarga
            // 
            this.btnValidarCarga.Location = new System.Drawing.Point(586, 18);
            this.btnValidarCarga.Name = "btnValidarCarga";
            this.btnValidarCarga.Size = new System.Drawing.Size(150, 30);
            this.btnValidarCarga.TabIndex = 18;
            this.btnValidarCarga.Text = "Validar Carga";
            this.btnValidarCarga.UseVisualStyleBackColor = true;
            this.btnValidarCarga.Click += new System.EventHandler(this.btnValidarCarga_Click);
            // 
            // dgvListaCargaArchivos
            // 
            this.dgvListaCargaArchivos.AllowUserToAddRows = false;
            this.dgvListaCargaArchivos.AllowUserToDeleteRows = false;
            this.dgvListaCargaArchivos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvListaCargaArchivos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvListaCargaArchivos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaCargaArchivos.Location = new System.Drawing.Point(9, 61);
            this.dgvListaCargaArchivos.Name = "dgvListaCargaArchivos";
            this.dgvListaCargaArchivos.ReadOnly = true;
            this.dgvListaCargaArchivos.RowHeadersVisible = false;
            this.dgvListaCargaArchivos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListaCargaArchivos.Size = new System.Drawing.Size(1149, 285);
            this.dgvListaCargaArchivos.TabIndex = 17;
            // 
            // cbRutaArchivos
            // 
            this.cbRutaArchivos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbRutaArchivos.FormattingEnabled = true;
            this.cbRutaArchivos.Location = new System.Drawing.Point(27, 24);
            this.cbRutaArchivos.Name = "cbRutaArchivos";
            this.cbRutaArchivos.Size = new System.Drawing.Size(239, 21);
            this.cbRutaArchivos.TabIndex = 16;
            this.cbRutaArchivos.SelectedValueChanged += new System.EventHandler(this.cbRutaArchivos_SelectedValueChanged);
            // 
            // cbExtencionArchivos
            // 
            this.cbExtencionArchivos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbExtencionArchivos.FormattingEnabled = true;
            this.cbExtencionArchivos.Location = new System.Drawing.Point(323, 24);
            this.cbExtencionArchivos.Name = "cbExtencionArchivos";
            this.cbExtencionArchivos.Size = new System.Drawing.Size(239, 21);
            this.cbExtencionArchivos.TabIndex = 16;
            this.cbExtencionArchivos.SelectedValueChanged += new System.EventHandler(this.cbExtencionArchivos_SelectedValueChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.dgvListaRutas);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1173, 363);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Lista Rutas";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label1.Location = new System.Drawing.Point(16, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Lista de rutas:";
            // 
            // dgvListaRutas
            // 
            this.dgvListaRutas.AllowUserToAddRows = false;
            this.dgvListaRutas.AllowUserToDeleteRows = false;
            this.dgvListaRutas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvListaRutas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvListaRutas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaRutas.Location = new System.Drawing.Point(19, 44);
            this.dgvListaRutas.Margin = new System.Windows.Forms.Padding(0);
            this.dgvListaRutas.Name = "dgvListaRutas";
            this.dgvListaRutas.ReadOnly = true;
            this.dgvListaRutas.RowHeadersVisible = false;
            this.dgvListaRutas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListaRutas.Size = new System.Drawing.Size(1138, 303);
            this.dgvListaRutas.TabIndex = 16;
            // 
            // frmImportarArchivos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1013, 535);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.paFooter);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmImportarArchivos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Importar Archivos";
            this.paReportes.ResumeLayout(false);
            this.paReportes.PerformLayout();
            this.paInstrucciones.ResumeLayout(false);
            this.paInstrucciones.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.paFooter.ResumeLayout(false);
            this.paFooter.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaCargaArchivos)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaRutas)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label laTitulo;
        private System.Windows.Forms.Button btnImportar;
        private System.Windows.Forms.ProgressBar pbImportar;
        private System.Windows.Forms.Label laMensajeReportes;
        private System.Windows.Forms.ListBox lbImportados;
        private System.Windows.Forms.Label laMensajeInstrucciones;
        private System.Windows.Forms.Button btnImportarInstrucciones;
        private System.Windows.Forms.ProgressBar pbImportarInstrucciones;
        private System.Windows.Forms.ListBox lbInsImportados;
        private System.Windows.Forms.Panel paReportes;
        private System.Windows.Forms.Panel paInstrucciones;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Panel paFooter;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dgvListaRutas;
        private System.Windows.Forms.Label lbMensaje;
        private System.Windows.Forms.Label lblRutaROrigen;
        private System.Windows.Forms.Label lblRutaIOrigen;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbExtencionArchivos;
        private System.Windows.Forms.DataGridView dgvListaCargaArchivos;
        private System.Windows.Forms.Button btnEnvioDetalleCarga;
        private System.Windows.Forms.Timer timerVerificacionArchivos;
        private System.Windows.Forms.Button btnValidarCarga;
        private System.Windows.Forms.Label lblRutaRDestino;
        private System.Windows.Forms.Label lblRutaIDestino;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbRutaArchivos;
    }
}