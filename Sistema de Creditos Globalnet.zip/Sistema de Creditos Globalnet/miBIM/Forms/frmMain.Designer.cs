﻿namespace miBIM.Forms
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.mStrMenu = new System.Windows.Forms.MenuStrip();
            this.operacionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importarReportesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.detalleCargaArchivosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.archivosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generarPagoPARToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generarDepositoDEPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generarDepositoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificarDepositoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revertirDepositoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.depósitoPorCompensaciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agentesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registrarAgentesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operacionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reporte32ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generarReporteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reporteOperacionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuracionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rutasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accesosUsuariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paBody = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.statusStripPrincipal = new System.Windows.Forms.StatusStrip();
            this.tssUsuarioPrincipal = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssOrdenador = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssIPPrincipal = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssModoPrincipal = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssVersionPrincipal = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssBarraPrinciapl = new System.Windows.Forms.ToolStripProgressBar();
            this.tssMensajePrinciapl = new System.Windows.Forms.ToolStripStatusLabel();
            this.mStrMenu.SuspendLayout();
            this.paBody.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.statusStripPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // mStrMenu
            // 
            this.mStrMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.operacionesToolStripMenuItem,
            this.archivosToolStripMenuItem,
            this.agentesToolStripMenuItem,
            this.operacionsToolStripMenuItem,
            this.configuracionToolStripMenuItem});
            this.mStrMenu.Location = new System.Drawing.Point(0, 0);
            this.mStrMenu.Name = "mStrMenu";
            this.mStrMenu.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.mStrMenu.Size = new System.Drawing.Size(1008, 25);
            this.mStrMenu.TabIndex = 0;
            this.mStrMenu.Text = "menuStrip1";
            // 
            // operacionesToolStripMenuItem
            // 
            this.operacionesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importarReportesToolStripMenuItem,
            this.detalleCargaArchivosToolStripMenuItem});
            this.operacionesToolStripMenuItem.Name = "operacionesToolStripMenuItem";
            this.operacionesToolStripMenuItem.Size = new System.Drawing.Size(75, 21);
            this.operacionesToolStripMenuItem.Text = "&Importar ";
            // 
            // importarReportesToolStripMenuItem
            // 
            this.importarReportesToolStripMenuItem.Name = "importarReportesToolStripMenuItem";
            this.importarReportesToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.importarReportesToolStripMenuItem.Text = "Importar Archivos";
            this.importarReportesToolStripMenuItem.Click += new System.EventHandler(this.importarReportesToolStripMenuItem_Click);
            // 
            // detalleCargaArchivosToolStripMenuItem
            // 
            this.detalleCargaArchivosToolStripMenuItem.Name = "detalleCargaArchivosToolStripMenuItem";
            this.detalleCargaArchivosToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.detalleCargaArchivosToolStripMenuItem.Text = "Detalle Carga Archivos";
            this.detalleCargaArchivosToolStripMenuItem.Click += new System.EventHandler(this.detalleCargaArchivosToolStripMenuItem_Click);
            // 
            // archivosToolStripMenuItem
            // 
            this.archivosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.generarPagoPARToolStripMenuItem,
            this.generarDepositoDEPToolStripMenuItem,
            this.depósitoPorCompensaciónToolStripMenuItem});
            this.archivosToolStripMenuItem.Name = "archivosToolStripMenuItem";
            this.archivosToolStripMenuItem.Size = new System.Drawing.Size(120, 21);
            this.archivosToolStripMenuItem.Text = "&Generar Archivos";
            // 
            // generarPagoPARToolStripMenuItem
            // 
            this.generarPagoPARToolStripMenuItem.Name = "generarPagoPARToolStripMenuItem";
            this.generarPagoPARToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.generarPagoPARToolStripMenuItem.Text = "Respuesta de Pago (PAR)";
            this.generarPagoPARToolStripMenuItem.Click += new System.EventHandler(this.generarPagoPARToolStripMenuItem_Click);
            // 
            // generarDepositoDEPToolStripMenuItem
            // 
            this.generarDepositoDEPToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.generarDepositoToolStripMenuItem,
            this.modificarDepositoToolStripMenuItem,
            this.revertirDepositoToolStripMenuItem});
            this.generarDepositoDEPToolStripMenuItem.Name = "generarDepositoDEPToolStripMenuItem";
            this.generarDepositoDEPToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.generarDepositoDEPToolStripMenuItem.Text = "Realizar depósito (DEP)";
            // 
            // generarDepositoToolStripMenuItem
            // 
            this.generarDepositoToolStripMenuItem.Name = "generarDepositoToolStripMenuItem";
            this.generarDepositoToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.generarDepositoToolStripMenuItem.Text = "Generar Depósito";
            this.generarDepositoToolStripMenuItem.Click += new System.EventHandler(this.generarDepositoToolStripMenuItem_Click);
            // 
            // modificarDepositoToolStripMenuItem
            // 
            this.modificarDepositoToolStripMenuItem.Name = "modificarDepositoToolStripMenuItem";
            this.modificarDepositoToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.modificarDepositoToolStripMenuItem.Text = "Modificar Deposito";
            this.modificarDepositoToolStripMenuItem.Visible = false;
            this.modificarDepositoToolStripMenuItem.Click += new System.EventHandler(this.modificarDepositoToolStripMenuItem_Click);
            // 
            // revertirDepositoToolStripMenuItem
            // 
            this.revertirDepositoToolStripMenuItem.Name = "revertirDepositoToolStripMenuItem";
            this.revertirDepositoToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.revertirDepositoToolStripMenuItem.Text = "Revertir Depósito";
            this.revertirDepositoToolStripMenuItem.Click += new System.EventHandler(this.revertirDepositoToolStripMenuItem_Click);
            // 
            // depósitoPorCompensaciónToolStripMenuItem
            // 
            this.depósitoPorCompensaciónToolStripMenuItem.Name = "depósitoPorCompensaciónToolStripMenuItem";
            this.depósitoPorCompensaciónToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.depósitoPorCompensaciónToolStripMenuItem.Text = "Depósito Por Compensación";
            this.depósitoPorCompensaciónToolStripMenuItem.Click += new System.EventHandler(this.depósitoPorCompensaciónToolStripMenuItem_Click);
            // 
            // agentesToolStripMenuItem
            // 
            this.agentesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registrarAgentesToolStripMenuItem});
            this.agentesToolStripMenuItem.Name = "agentesToolStripMenuItem";
            this.agentesToolStripMenuItem.Size = new System.Drawing.Size(67, 21);
            this.agentesToolStripMenuItem.Text = "Agentes";
            // 
            // registrarAgentesToolStripMenuItem
            // 
            this.registrarAgentesToolStripMenuItem.Name = "registrarAgentesToolStripMenuItem";
            this.registrarAgentesToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.registrarAgentesToolStripMenuItem.Text = "Registrar Agentes";
            this.registrarAgentesToolStripMenuItem.Click += new System.EventHandler(this.registrarAgentesToolStripMenuItem_Click);
            // 
            // operacionsToolStripMenuItem
            // 
            this.operacionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reporte32ToolStripMenuItem,
            this.generarReporteToolStripMenuItem,
            this.reporteOperacionesToolStripMenuItem});
            this.operacionsToolStripMenuItem.Name = "operacionsToolStripMenuItem";
            this.operacionsToolStripMenuItem.Size = new System.Drawing.Size(77, 21);
            this.operacionsToolStripMenuItem.Text = "& Reportes";
            // 
            // reporte32ToolStripMenuItem
            // 
            this.reporte32ToolStripMenuItem.Name = "reporte32ToolStripMenuItem";
            this.reporte32ToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.reporte32ToolStripMenuItem.Text = "Modificar Reporte 32";
            this.reporte32ToolStripMenuItem.Click += new System.EventHandler(this.reporte32ToolStripMenuItem_Click);
            // 
            // generarReporteToolStripMenuItem
            // 
            this.generarReporteToolStripMenuItem.Name = "generarReporteToolStripMenuItem";
            this.generarReporteToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.generarReporteToolStripMenuItem.Text = "Generar Reporte";
            this.generarReporteToolStripMenuItem.Click += new System.EventHandler(this.generarReporteToolStripMenuItem_Click);
            // 
            // reporteOperacionesToolStripMenuItem
            // 
            this.reporteOperacionesToolStripMenuItem.Name = "reporteOperacionesToolStripMenuItem";
            this.reporteOperacionesToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.reporteOperacionesToolStripMenuItem.Text = "Reporte Operaciones";
            this.reporteOperacionesToolStripMenuItem.Click += new System.EventHandler(this.reporteOperacionesToolStripMenuItem_Click);
            // 
            // configuracionToolStripMenuItem
            // 
            this.configuracionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rutasToolStripMenuItem,
            this.accesosUsuariosToolStripMenuItem});
            this.configuracionToolStripMenuItem.Name = "configuracionToolStripMenuItem";
            this.configuracionToolStripMenuItem.Size = new System.Drawing.Size(101, 21);
            this.configuracionToolStripMenuItem.Text = "Configuracion";
            // 
            // rutasToolStripMenuItem
            // 
            this.rutasToolStripMenuItem.Name = "rutasToolStripMenuItem";
            this.rutasToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.rutasToolStripMenuItem.Text = "Rutas";
            this.rutasToolStripMenuItem.Click += new System.EventHandler(this.rutasToolStripMenuItem_Click);
            // 
            // accesosUsuariosToolStripMenuItem
            // 
            this.accesosUsuariosToolStripMenuItem.Name = "accesosUsuariosToolStripMenuItem";
            this.accesosUsuariosToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.accesosUsuariosToolStripMenuItem.Text = "Accesos Grupos/Usuarios";
            this.accesosUsuariosToolStripMenuItem.Click += new System.EventHandler(this.accesosUsuariosToolStripMenuItem_Click);
            // 
            // paBody
            // 
            this.paBody.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.paBody.Controls.Add(this.pictureBox1);
            this.paBody.Location = new System.Drawing.Point(0, 26);
            this.paBody.Margin = new System.Windows.Forms.Padding(2);
            this.paBody.Name = "paBody";
            this.paBody.Size = new System.Drawing.Size(1008, 543);
            this.paBody.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = global::miBIM.Properties.Resources.bim_Nuevo;
            this.pictureBox1.Location = new System.Drawing.Point(355, 92);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(382, 382);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // statusStripPrincipal
            // 
            this.statusStripPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tssUsuarioPrincipal,
            this.tssOrdenador,
            this.tssIPPrincipal,
            this.tssModoPrincipal,
            this.tssVersionPrincipal,
            this.tssBarraPrinciapl,
            this.tssMensajePrinciapl});
            this.statusStripPrincipal.Location = new System.Drawing.Point(0, 573);
            this.statusStripPrincipal.Name = "statusStripPrincipal";
            this.statusStripPrincipal.Size = new System.Drawing.Size(1008, 22);
            this.statusStripPrincipal.TabIndex = 3;
            this.statusStripPrincipal.Text = "BIM Manager";
            // 
            // tssUsuarioPrincipal
            // 
            this.tssUsuarioPrincipal.Name = "tssUsuarioPrincipal";
            this.tssUsuarioPrincipal.Size = new System.Drawing.Size(56, 17);
            this.tssUsuarioPrincipal.Text = "Usuario:";
            // 
            // tssOrdenador
            // 
            this.tssOrdenador.Name = "tssOrdenador";
            this.tssOrdenador.Size = new System.Drawing.Size(80, 17);
            this.tssOrdenador.Text = "Ordenador: ";
            // 
            // tssIPPrincipal
            // 
            this.tssIPPrincipal.Name = "tssIPPrincipal";
            this.tssIPPrincipal.Size = new System.Drawing.Size(21, 17);
            this.tssIPPrincipal.Text = "IP:";
            // 
            // tssModoPrincipal
            // 
            this.tssModoPrincipal.Name = "tssModoPrincipal";
            this.tssModoPrincipal.Size = new System.Drawing.Size(47, 17);
            this.tssModoPrincipal.Text = "Modo:";
            // 
            // tssVersionPrincipal
            // 
            this.tssVersionPrincipal.Name = "tssVersionPrincipal";
            this.tssVersionPrincipal.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tssVersionPrincipal.Size = new System.Drawing.Size(54, 17);
            this.tssVersionPrincipal.Text = "Version:";
            // 
            // tssBarraPrinciapl
            // 
            this.tssBarraPrinciapl.Name = "tssBarraPrinciapl";
            this.tssBarraPrinciapl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tssBarraPrinciapl.Size = new System.Drawing.Size(100, 16);
            // 
            // tssMensajePrinciapl
            // 
            this.tssMensajePrinciapl.Name = "tssMensajePrinciapl";
            this.tssMensajePrinciapl.Size = new System.Drawing.Size(17, 17);
            this.tssMensajePrinciapl.Text = "...";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1008, 595);
            this.Controls.Add(this.statusStripPrincipal);
            this.Controls.Add(this.mStrMenu);
            this.Controls.Add(this.paBody);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mStrMenu;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BIM MANAGER";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.mStrMenu.ResumeLayout(false);
            this.mStrMenu.PerformLayout();
            this.paBody.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.statusStripPrincipal.ResumeLayout(false);
            this.statusStripPrincipal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mStrMenu;
        private System.Windows.Forms.ToolStripMenuItem archivosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operacionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generarPagoPARToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generarDepositoDEPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importarReportesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operacionsToolStripMenuItem;
        private System.Windows.Forms.Panel paBody;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem generarDepositoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modificarDepositoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reporte32ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem depósitoPorCompensaciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generarReporteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agentesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registrarAgentesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revertirDepositoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem detalleCargaArchivosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configuracionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rutasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reporteOperacionesToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStripPrincipal;
        private System.Windows.Forms.ToolStripStatusLabel tssUsuarioPrincipal;
        private System.Windows.Forms.ToolStripStatusLabel tssModoPrincipal;
        private System.Windows.Forms.ToolStripProgressBar tssBarraPrinciapl;
        private System.Windows.Forms.ToolStripStatusLabel tssVersionPrincipal;
        private System.Windows.Forms.ToolStripStatusLabel tssOrdenador;
        private System.Windows.Forms.ToolStripStatusLabel tssIPPrincipal;
        private System.Windows.Forms.ToolStripMenuItem accesosUsuariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel tssMensajePrinciapl;
    }
}