﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miBIM.Forms
{
    public partial class frmModificarDeposito : Form
    {
        public String cUser = Environment.UserName.ToString().ToUpper();
        public String cAgencia = "01";

        public frmModificarDeposito()
        {
            InitializeComponent();
        }

        private void btnBuscarDepositos_Click(object sender, EventArgs e)
        {

            cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
            DataTable dtDepSinConfirmar = new DataTable();
            int nEstado = 99;
            dtDepSinConfirmar = oInstruccion.Buscar_Deposito(dtpFechaInicio_Buscar.Value, dtpFechaFin_Buscar.Value, nEstado);
            dgvDepositoSinconfirmar.DataSource = dtDepSinConfirmar;
            
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            Boolean bEsRespuesta;
            int nIdDeposito;
            int nContador=0;
            cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
            DataSet oResultado = new DataSet();

            foreach (DataGridViewRow row in dgvDepositoSinconfirmar.Rows)
            {
                
                if (row.Cells[0].Value == null)
                {
                    row.Cells[0].Value = false;
                }
                bEsRespuesta = (Boolean)row.Cells["Sel"].Value;

                if (bEsRespuesta)
                {
                    nContador++;
                    nIdDeposito = int.Parse(row.Cells["ID"].Value.ToString());
                    oResultado = oInstruccion.Confirmar_Deposito(nIdDeposito);
                }                
            }

            if (nContador > 0)
            {
                MessageBox.Show("Deposito(s) Confirmado");
                nContador = 0;
            }
            dgvDepositoSinconfirmar.DataSource = null;            
        }

        private void chkReversaDeposito_CheckedChanged(object sender, EventArgs e)
        {
            if (chkReversaDeposito.Checked)
            {
                chkDepositoCompensacion.Checked = false;
                paReversaDeposito.Visible = true;
                paCompensacion.Visible = false;
                //btnBuscarDeposito.Visible = true;
            }
            else
                paReversaDeposito.Visible = false;
        }

        private void chkDepositoCompensacion_CheckedChanged(object sender, EventArgs e)
        {
            if (chkDepositoCompensacion.Checked)
            {
                chkReversaDeposito.Checked = false;
                paCompensacion.Visible = true;
                //laNumeroReferencia.Visible = true;
                //tbNumeroReferencia.Visible = true;
            }
            else
            {
                paCompensacion.Visible = false;
                //laNumeroReferencia.Visible = false;
                //tbNumeroReferencia.Visible = false;
            }
        }

        private void btnSalir_Rev_Click(object sender, EventArgs e)
        {
            chkDepositoCompensacion.Checked = false;
            chkReversaDeposito.Checked = false;
            paConfirmarDeposito.Visible = true;
        }

        private void btnBuscaRevDep_Click(object sender, EventArgs e)
        {
            cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
            DataTable dtDepSinConfirmar = new DataTable();
            int nEstado = 0;
            dtDepSinConfirmar = oInstruccion.Buscar_Deposito(dtpFechaInicio_Buscar.Value, dtpFechaFin_Buscar.Value, nEstado);
            dgvDeposito.DataSource = dtDepSinConfirmar;           

        }

        private void btn_Confirmar_Rev_Click(object sender, EventArgs e)
        {
            Boolean bEsRespuesta;
            int nMovDeposito;
            int nContador = 0;
            String cMensaje;
            //int nMovDepRev;

            cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
            DataTable oResultado = new DataTable();

            int[] nDepositosRev= new int[dgvDeposito.Rows.Count]; 
            DateTime dFechaSistema = oInstruccion.Obtiene_FechaSistema();

            foreach (DataGridViewRow row in dgvDeposito.Rows)
            {
                if (row.Cells[0].Value == null)
                {
                    row.Cells[0].Value = false;
                }
                bEsRespuesta = (Boolean)row.Cells["SelRev"].Value;

                if (bEsRespuesta)
                {                    
                    nMovDeposito = int.Parse(row.Cells["ID"].Value.ToString());
                    cMensaje = row.Cells["Mensaje"].Value.ToString();
                    //cUser, cAgencia, dFechaSistema, nMovDeposito,cMensaje
                    oResultado = oInstruccion.Insertar_ReversaDeposito(cUser, cAgencia, dFechaSistema, nMovDeposito, cMensaje);
                    nMovDeposito = int.Parse(oResultado.Rows[0][0].ToString());
                                       
                    nDepositosRev[nContador] = nMovDeposito;
                    
                }
                nContador++;
            }

            Escribir_ReversaDeposito(nDepositosRev);
        }

        private void Escribir_ReversaDeposito(int[] nNroMovimientos)
        {
            DataSet dsCompensacion = new DataSet();
            cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
            cConstante oConstante = new cConstante();
            String cTipoOperacion;
            //String cTipo;
            DateTime dFehaHoraTransaccion;            
            Double nMonto;
            String cMSISDN;
            int nMovBIM;
            int nMovBimRevDep;
           
            
            String cMensaje;
            int nMov;

            StreamWriter sw = null;
            DateTime dFecha = DateTime.Now;
            String cNombreArchivo;
            cNombreArchivo = "CCUSCO-REVDEP-" + dFecha.ToString("yyyyMMddHHmmss") + ".csv";
            string path = oConstante.cpRutaOrigenOutgoing + cNombreArchivo;
            DataSet oCabecera;
            int nPrimera = 0;


            if (nPrimera == 0)
            {
                nPrimera = nPrimera + 1;
                //Obtener cabecera 
                oCabecera = oInstruccion.ObtenerCabecera();
                sw = File.CreateText(path);

                foreach (DataRow row in oCabecera.Tables[0].Rows)
                {
                    sw.WriteLine(row["cCabecera"].ToString());
                }
                sw.Flush();
                sw.Close();
            }
            else
            {
                File.Delete(path);
                sw = File.CreateText(path);
                sw.Flush();
                sw.Close();
            }

            for (int i = 0; i < nNroMovimientos.Length; i++)
            {                
                nMov = nNroMovimientos[i];
                if (nMov != 0)
                {

                    dsCompensacion = oInstruccion.Obtener_ReversaDeposito(cNombreArchivo, nMov);

                    if (dsCompensacion.Tables[0].Rows.Count == 0)
                    {
                        MessageBox.Show("No existen operaciones registradas en la fecha ");
                    }
                    else
                    {
                        foreach (DataRow row in dsCompensacion.Tables[0].Rows)
                        {
                            //cTipoOperacion, dFehaHoraTransaccion,dFehaHoraRecepcion,nMonto, cMSISDN, nMovBIM,cNombre, cApellido,cRemitenteCodigo,cRemitenteCuenta
                            cTipoOperacion = row["cTipoOperacion"].ToString();
                            nMovBIM = int.Parse(row["nMovBIM"].ToString());
                            dFehaHoraTransaccion = DateTime.Parse(row["dFehaHoraTransaccion"].ToString());
                            nMovBimRevDep = int.Parse(row["nMovBimRevDep"].ToString());
                            cMSISDN = row["cMSISDN"].ToString();
                            nMonto = Double.Parse(row["nMonto"].ToString());
                            cMensaje = row["cMensaje"].ToString();

                            sw = File.AppendText(path);
                            sw.WriteLine(cTipoOperacion + "," + nMovBIM + "," + dFehaHoraTransaccion.ToString("yyyy-MM-dd HH:mm:ss") + "," + nMovBimRevDep + "," + cMSISDN + "," + String.Format("{0,12:0.00}", nMonto).Trim() + "," + cMensaje);
                            sw.Flush();
                            sw.Close();
                        }
                    }
                }
            }

            String cMensajeFirma = oConstante.FirmaArchivo(cNombreArchivo);
            if (cMensajeFirma != "")
            {
                MessageBox.Show(cMensajeFirma.ToString(), "Altera");
                return;
            }

            //FirmaArchivo(cNombreArchivo);
            dgvDeposito.DataSource = null;
            MessageBox.Show("Archivo Generado de forma satisfactoria, " + path);
            //return path;
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSalir_Comp_Click(object sender, EventArgs e)
        {
            chkDepositoCompensacion.Checked = false;
            chkReversaDeposito.Checked = false;
            paConfirmarDeposito.Visible = true;         
        }

        private void btnBuscar_Comp_Click(object sender, EventArgs e)
        {
            dgvCompensacion.DataSource = null;
            cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
            DataTable dtDepCompensacion = new DataTable();
            dtDepCompensacion = oInstruccion.Buscar_Compensacion(dtpFechaIni_Comp.Value, dtpFechaFin_Comp.Value);
            dgvCompensacion.DataSource = dtDepCompensacion;           
        }

        private void btnGenerar_comp_Click(object sender, EventArgs e)
        {
        //Inicio UQMA Comento porque ya no se utiliza el formulario
            //String cNroCelular;
            //String cNombre;
            //String cApellido;
            //Double nMonto;
            //String cMensaje;
            //int nRespuesta;
            //int[] nNroMovimientos;
            //int i = 0;
            //int nEscompensacion = 0;
            //Boolean bEsRespuesta;
            
            //cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
            //DataTable oResultado = new DataTable();
            //DateTime dFechaSistema = oInstruccion.Obtiene_FechaSistema();
            //nNroMovimientos = new int[dgvCompensacion.Rows.Count];

            //foreach (DataGridViewRow row in dgvCompensacion.Rows)
            //{
            //    if (row.Cells[0].Value == null)
            //    {
            //        row.Cells[0].Value = false;
            //    }
            //    bEsRespuesta = (Boolean)row.Cells["SelComp"].Value;

            //    if (bEsRespuesta)
            //    {
            //        cNroCelular = "";
            //        cNombre = "";//row.Cells["Nombre"].Value.ToString();
            //        cApellido = "";// row.Cells["Apellido"].Value.ToString();
            //        nMonto = Math.Abs(Double.Parse(row.Cells["nDiferenciaMonto"].Value.ToString()));
            //        try
            //        {
            //            cMensaje = row.Cells[1].Value.ToString().ToUpper().Trim();
            //        }
            //        catch (Exception)
            //        {
            //            MessageBox.Show("Ingrese Numero de Referencia","Alerta");
            //            return;
            //        }
                    
                    
            //        nEscompensacion = 1;

            //        oResultado = oInstruccion.Insertar_Deposito(cUser, cAgencia, dFechaSistema, cNroCelular, cNombre, cApellido, nMonto, cMensaje, nEscompensacion); 
            //        nRespuesta = int.Parse(oResultado.Rows[0][0].ToString());
            //        switch (nRespuesta)
            //        {
            //            case -1:
            //                MessageBox.Show("Error al registrar deposito","Alterta");                            
            //                break;                            
            //            case -2:
            //                MessageBox.Show("El numero de Referencia ya se registro", "Altera");
            //                break;
            //            default:
            //                nNroMovimientos[i] = nRespuesta;
            //                i++;
            //                break;
            //        }
            //        //if (nRespuesta == -1)
            //        //{
            //        //    MessageBox.Show("Error al registrar deposito");
            //        //}
            //        //else
            //        //{
            //        //    nNroMovimientos[i] = nRespuesta;
            //        //}
                    
            //    }
            //}

            //if (i > 0)
            //{
            //    EscribirDeposito(nNroMovimientos);
            //    i = 0;
            //}
            ////else
            ////    MessageBox.Show("No ha seleccionado deposito valido","Alerta");
        //Fin UQMA Comento porque ya no se utiliza el formulario          
        }

        private void EscribirDeposito(int[] nNroMovimientos)
        {
            DataSet dsCompensacion = new DataSet();
            cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
            String cTipoOperacion;
            //String cTipo;
            DateTime dFehaHoraTransaccion;
            DateTime dFehaHoraRecepcion;
            Double nMonto;
            String cMSISDN;
            int nMovBIM;
            String cNombre;
            String cApellido;
            //String IdIntruccionPago;
            //int IdTransaccion;
            String cRemitenteCodigo;
            String cRemitenteCuenta;
            String cMensaje;
            int nMov;

            StreamWriter sw = null;
            DateTime dFecha = DateTime.Now;
            String cNombreArchivo;
            cConstante oConstante = new cConstante();
            cNombreArchivo = "CCUSCO-DEP-" + dFecha.ToString("yyyyMMddHHmmss") + ".csv";
            string path = oConstante.cpRutaOrigenOutgoing + cNombreArchivo;
            DataSet oCabecera;
            int nPrimera = 0;
            
            if (nPrimera == 0)
            {
                nPrimera = nPrimera + 1;
                //Obtener cabecera 
                oCabecera = oInstruccion.ObtenerCabecera();
                sw = File.CreateText(path);

                foreach (DataRow row in oCabecera.Tables[0].Rows)
                {
                    sw.WriteLine(row["cCabecera"].ToString());
                }
                sw.Flush();
                sw.Close();
            }
            else
            {
                File.Delete(path);
                sw = File.CreateText(path);
                sw.Flush();
                sw.Close();
            }

            for (int i = 0; i < nNroMovimientos.Length; i++)
            {
                nMov = nNroMovimientos[i];

                if (nMov != 0)
                {
                    dsCompensacion = oInstruccion.Obtener_Deposito(cNombreArchivo, nMov);

                    if (dsCompensacion.Tables[0].Rows.Count == 0)
                    {
                        MessageBox.Show("No existen operaciones registradas en la fecha ");
                    }
                    else
                    {
                        foreach (DataRow row in dsCompensacion.Tables[0].Rows)
                        {
                            //cTipoOperacion, dFehaHoraTransaccion,dFehaHoraRecepcion,nMonto, cMSISDN, nMovBIM,cNombre, cApellido,cRemitenteCodigo,cRemitenteCuenta
                            cTipoOperacion = row["cTipoOperacion"].ToString();
                            dFehaHoraTransaccion = DateTime.Parse(row["dFehaHoraTransaccion"].ToString());
                            dFehaHoraRecepcion = DateTime.Parse(row["dFehaHoraRecepcion"].ToString());
                            nMonto = Double.Parse(row["nMonto"].ToString());
                            cMSISDN = row["cMSISDN"].ToString();
                            nMovBIM = int.Parse(row["nMovBIM"].ToString());
                            cNombre = row["cNombre"].ToString();
                            cApellido = row["cApellido"].ToString();
                            cRemitenteCodigo = row["cRemitenteCodigo"].ToString();
                            cRemitenteCuenta = row["cRemitenteCuenta"].ToString();
                            cMensaje = row["cMensaje"].ToString().ToUpper();


                            sw = File.AppendText(path);
                            sw.WriteLine(cTipoOperacion + "," + dFehaHoraTransaccion.ToString("yyyy-MM-dd HH:mm:ss") + "," + "" + "," + String.Format("{0,12:0.00}", nMonto).Trim() + "," + cMSISDN + "," + nMovBIM + "," + cNombre + "," + cApellido + "," + cRemitenteCodigo + "," + cRemitenteCuenta + "," + cMensaje);
                            sw.Flush();
                            sw.Close();
                        }
                    }
                }            
            }

            String cMensajeFirma = oConstante.FirmaArchivo(cNombreArchivo);
            if (cMensajeFirma != "")
            {
                MessageBox.Show(cMensajeFirma.ToString(), "Altera");
                return;
            }

            //FirmaArchivo(cNombreArchivo);
            dgvCompensacion.DataSource = null;
            MessageBox.Show("Archivo Generado de forma satisfactoria, " + path);
            //return path;
        }

        //private void FirmaArchivo(String cNombreArchivo)
        //{
        //    try
        //    {
        //        cConstante cConstante = new cConstante();
        //        System.Diagnostics.Process process = new System.Diagnostics.Process();
        //        System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
        //        startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Maximized;
        //        startInfo.FileName = "cmd.exe";
        //        //startInfo.Arguments = "/C copy /b Image1.jpg + Archive.rar Image2.jpg";
        //        //startInfo.Arguments = "/C c:>openssl dgst -sha256 -sign C:\\Certificado\\cajacusco_filesigning_privatekey.key -out " + cConstante.cpRutaOrigenOutgoing + cNombreArchivo + ".signature " + cConstante.cpRutaDestinoOutgoing + cNombreArchivo;
        //        startInfo.Arguments = "/C openssl dgst -sha256 -sign C:\\Certificado\\cajacusco_filesigning_privatekey.key -out " + cConstante.cpRutaOrigenOutgoing + cNombreArchivo + ".signature " + cConstante.cpRutaDestinoOutgoing + cNombreArchivo;
        //        process.StartInfo = startInfo;
        //        process.Start();
        //        //c:>openssl dgst -sha256 -sign C:\Certificado\cajacusco_filesigning_privatekey.key -out c:\SFTP\EWP\Outgoing\CCUSCO-REVDEP-20160202172600.csv.signature c:\SFTP\EWP\Outgoing\CCUSCO-REVDEP-20160202172600.csv
        //    }
        //    catch (Exception ex)
        //    {

        //        MessageBox.Show("Error: " + ex.ToString());
        //    }
        //}

        
    }
}
