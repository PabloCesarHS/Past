﻿namespace miBIM.Forms
{
    partial class frmRespuestaPago
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRespuestaPago));
            this.laTitulo = new System.Windows.Forms.Label();
            this.dgvPAY = new System.Windows.Forms.DataGridView();
            this.Col_EsSuccess = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.btnMostra = new System.Windows.Forms.Button();
            this.btnGenerar = new System.Windows.Forms.Button();
            this.laMensaje = new System.Windows.Forms.Label();
            this.laFecha = new System.Windows.Forms.Label();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.btnSalir = new System.Windows.Forms.Button();
            this.paHeader = new System.Windows.Forms.Panel();
            this.paFooter = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPAY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.paHeader.SuspendLayout();
            this.paFooter.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // laTitulo
            // 
            this.laTitulo.AutoSize = true;
            this.laTitulo.BackColor = System.Drawing.Color.YellowGreen;
            this.laTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.laTitulo.ForeColor = System.Drawing.Color.Transparent;
            this.laTitulo.Location = new System.Drawing.Point(238, 10);
            this.laTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laTitulo.Name = "laTitulo";
            this.laTitulo.Size = new System.Drawing.Size(188, 20);
            this.laTitulo.TabIndex = 0;
            this.laTitulo.Text = "PAGOS PENDIENTES";
            // 
            // dgvPAY
            // 
            this.dgvPAY.AllowUserToAddRows = false;
            this.dgvPAY.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvPAY.ColumnHeadersHeight = 25;
            this.dgvPAY.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Col_EsSuccess});
            this.dgvPAY.Location = new System.Drawing.Point(18, 44);
            this.dgvPAY.Margin = new System.Windows.Forms.Padding(2);
            this.dgvPAY.Name = "dgvPAY";
            this.dgvPAY.RowTemplate.Height = 24;
            this.dgvPAY.Size = new System.Drawing.Size(621, 260);
            this.dgvPAY.TabIndex = 1;
            // 
            // Col_EsSuccess
            // 
            this.Col_EsSuccess.HeaderText = "";
            this.Col_EsSuccess.Items.AddRange(new object[] {
            "-- Seleccione Estado --",
            "SUCCESS",
            "FAILED"});
            this.Col_EsSuccess.Name = "Col_EsSuccess";
            // 
            // btnMostra
            // 
            this.btnMostra.Image = global::miBIM.Properties.Resources.buscar;
            this.btnMostra.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMostra.Location = new System.Drawing.Point(561, 17);
            this.btnMostra.Margin = new System.Windows.Forms.Padding(2);
            this.btnMostra.Name = "btnMostra";
            this.btnMostra.Size = new System.Drawing.Size(77, 23);
            this.btnMostra.TabIndex = 0;
            this.btnMostra.Text = "&Mostrar";
            this.btnMostra.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMostra.UseVisualStyleBackColor = true;
            this.btnMostra.Click += new System.EventHandler(this.btnMostra_Click);
            // 
            // btnGenerar
            // 
            this.btnGenerar.Location = new System.Drawing.Point(18, 18);
            this.btnGenerar.Margin = new System.Windows.Forms.Padding(2);
            this.btnGenerar.Name = "btnGenerar";
            this.btnGenerar.Size = new System.Drawing.Size(118, 28);
            this.btnGenerar.TabIndex = 0;
            this.btnGenerar.Text = "&Generar Respuesta";
            this.btnGenerar.UseVisualStyleBackColor = true;
            this.btnGenerar.Click += new System.EventHandler(this.btnGenerar_Click);
            // 
            // laMensaje
            // 
            this.laMensaje.AutoSize = true;
            this.laMensaje.ForeColor = System.Drawing.SystemColors.Highlight;
            this.laMensaje.Location = new System.Drawing.Point(15, 323);
            this.laMensaje.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laMensaje.Name = "laMensaje";
            this.laMensaje.Size = new System.Drawing.Size(47, 13);
            this.laMensaje.TabIndex = 4;
            this.laMensaje.Text = "Mensaje";
            this.laMensaje.Visible = false;
            // 
            // laFecha
            // 
            this.laFecha.AutoSize = true;
            this.laFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.laFecha.Location = new System.Drawing.Point(405, 22);
            this.laFecha.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laFecha.Name = "laFecha";
            this.laFecha.Size = new System.Drawing.Size(43, 13);
            this.laFecha.TabIndex = 5;
            this.laFecha.Text = "Fecha :";
            // 
            // dtpFecha
            // 
            this.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecha.Location = new System.Drawing.Point(452, 17);
            this.dtpFecha.Margin = new System.Windows.Forms.Padding(2);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.Size = new System.Drawing.Size(105, 20);
            this.dtpFecha.TabIndex = 6;
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(561, 18);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(2);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(78, 28);
            this.btnSalir.TabIndex = 1;
            this.btnSalir.Text = "&Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // paHeader
            // 
            this.paHeader.BackColor = System.Drawing.SystemColors.ControlLight;
            this.paHeader.Controls.Add(this.laTitulo);
            this.paHeader.Location = new System.Drawing.Point(6, 6);
            this.paHeader.Name = "paHeader";
            this.paHeader.Size = new System.Drawing.Size(652, 49);
            this.paHeader.TabIndex = 8;
            // 
            // paFooter
            // 
            this.paFooter.BackColor = System.Drawing.SystemColors.ControlLight;
            this.paFooter.Controls.Add(this.btnGenerar);
            this.paFooter.Controls.Add(this.btnSalir);
            this.paFooter.Location = new System.Drawing.Point(6, 410);
            this.paFooter.Name = "paFooter";
            this.paFooter.Size = new System.Drawing.Size(652, 54);
            this.paFooter.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dtpFecha);
            this.groupBox1.Controls.Add(this.laMensaje);
            this.groupBox1.Controls.Add(this.laFecha);
            this.groupBox1.Controls.Add(this.btnMostra);
            this.groupBox1.Controls.Add(this.dgvPAY);
            this.groupBox1.Location = new System.Drawing.Point(6, 61);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(652, 343);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "PAGOS PENDIENTES";
            // 
            // frmRespuestaPago
            // 
            this.AcceptButton = this.btnMostra;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(664, 469);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.paFooter);
            this.Controls.Add(this.paHeader);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmRespuestaPago";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Respuesta de Pago";
            this.Load += new System.EventHandler(this.frmRespuestaPago_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPAY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.paHeader.ResumeLayout(false);
            this.paHeader.PerformLayout();
            this.paFooter.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label laTitulo;
        private System.Windows.Forms.DataGridView dgvPAY;
        private System.Windows.Forms.Button btnMostra;
        private System.Windows.Forms.Button btnGenerar;
        private System.Windows.Forms.Label laMensaje;
        private System.Windows.Forms.Label laFecha;
        private System.Windows.Forms.DateTimePicker dtpFecha;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Panel paHeader;
        private System.Windows.Forms.Panel paFooter;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridViewComboBoxColumn Col_EsSuccess;
    }
}