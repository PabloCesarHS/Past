﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
using System.IO;


namespace miBIM.Forms
{
    public partial class frmRespuestaPago : Form
    {
        public String cUser = Environment.UserName.ToString().ToUpper();
        public String cAgencia = "01";
        //public DateTime dFechaSistema = DateTime.Now;  //Obtener fecha Sistema
        //public DateTime dFechaSistema = Fecha(

        public frmRespuestaPago()
        {
            InitializeComponent();
        }
        

        //UQMA 04/10/2017 Para habilitar o desabilitar botones
        public void Hab_Des_Botones()
        {
            if (dgvPAY.Rows.Count > 0)
            {
                btnGenerar.Enabled = true;
            }
            else
                btnGenerar.Enabled = false;
        }

        //UQMA 23/10/2017 Para verificar que selecciono un estado
        private bool Selecciono_Estados()
        {
            foreach (DataGridViewRow row in dgvPAY.Rows)
            {
                if (row.Cells["Col_EsSuccess"].Value.ToString() == "-- Seleccione Estado --")
                {
                    MessageBox.Show("Seleccione un estado", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return false;
                }
            }
            return true;
        }

        private void btnMostra_Click(object sender, EventArgs e)
        {
            //Limpiar grid
            dgvPAY.DataSource = null;
            //Obtener Pagos del dia
            DataTable tPagos;
            tPagos = MostrarPagos(dtpFecha.Value);
            dgvPAY.DataSource = tPagos;

            //UQMA 04/10/2017 Para que las columnas sean solo de lectura
            dgvPAY.Columns["CodigoBanco"].ReadOnly = true;
            dgvPAY.Columns["BancoDestino"].ReadOnly = true;
            dgvPAY.Columns["Monto"].ReadOnly = true;
            dgvPAY.Columns["FehaHoraTransaccion"].ReadOnly = true;
            dgvPAY.Columns["Mensaje"].ReadOnly = true;
            dgvPAY.Columns["IDInstruccionPago"].ReadOnly = true;
            dgvPAY.Columns["IDPago"].ReadOnly = true;
            //UQMA 04/10/2017 Para dar formato a las columnas
            dgvPAY.Columns["Monto"].DefaultCellStyle.Format = "N2";

            Hab_Des_Botones();

            //UQMA 04/10/2017 para seleccionar por defecto SUCCESS
            foreach (DataGridViewRow row in dgvPAY.Rows)
            {
                row.Cells["Col_EsSuccess"].Value = "-- Seleccione Estado --";
            }
        }

        private void btnGenerar_Click(object sender, EventArgs e)
        {
            if (Selecciono_Estados())
            {
                DialogResult oResultadoMsg = MessageBox.Show("¿Seguro que desea Generar archivo plano de Respuesta de Pago?", "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Question); //UQMA 17/10/2017

                if (oResultadoMsg == DialogResult.Yes) //UQMA 17/10/2017
                {
                    cArchivoInstruccion oInstruccuion = new cArchivoInstruccion();

                    DataSet dsPAY = new DataSet();
                    String cCodigoBanco;
                    double nMonto;
                    DateTime dFecha;
                    String cMensaje;
                    String cIDInstruccionPago;
                    int nIDPago;
                    String cMensajeRespuesta;

                    //Insertar respuesta de pago
                    cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
                    DateTime dFechaSistema = oInstruccion.Obtiene_FechaSistema();


                    DataTable oResultado = new DataTable();
                    String cRespuesta = "";
                    int nContador = 0;
                    String cError = "0";


                    Boolean bEsSuccess = false;  //UQMA 28/09/2017 Para determinar si es success o failed

                    foreach (DataGridViewRow row in dgvPAY.Rows)
                    {
                        //UQMA 04/10/2017 bEsRespuesta: TRUE: SUCCESS, FALSE: FAILED
                        if (row.Cells["Col_EsSuccess"].Value.ToString() == "SUCCESS")
                        {
                            bEsSuccess = true;
                        }
                        else
                        {
                            bEsSuccess = false;
                        }

                        //if (row.Cells[0].Value == null)
                        //{
                        //    row.Cells[0].Value = false;
                        //}
                        //bEsRespuesta = (Boolean)row.Cells["item"].Value;

                        //if (bEsRespuesta)
                        //{
                        nContador++;
                        cCodigoBanco = row.Cells["CodigoBanco"].Value.ToString();
                        nMonto = double.Parse(row.Cells["Monto"].Value.ToString());
                        dFecha = DateTime.Parse(row.Cells["FehaHoraTransaccion"].Value.ToString());
                        cMensaje = row.Cells["Mensaje"].Value.ToString();
                        cIDInstruccionPago = row.Cells["IDInstruccionPago"].Value.ToString();
                        nIDPago = int.Parse(row.Cells["IDPago"].Value.ToString());
                        oResultado = oInstruccion.Generar_RespuestaPago(cUser, cAgencia, dFechaSistema, cCodigoBanco, nMonto, dFecha, cMensaje, cIDInstruccionPago, nIDPago, bEsSuccess);
                        cRespuesta = oResultado.Rows[0][0].ToString();

                        if (cRespuesta == "")
                        {
                            cError = "1";
                        }

                        //}

                    }

                    if (cError == "1" || nContador < 1)
                        MessageBox.Show("No se ha procesado correctamente Respuesta de Pago. ");
                    else
                    {
                        cMensajeRespuesta = EscribirRespuestaPago(int.Parse(cRespuesta));
                        MessageBox.Show("Respuesta de pago Generada. " + cMensajeRespuesta);
                    }
                    dgvPAY.DataSource = null;

                    Hab_Des_Botones();
                }
            }
        }

        //RTYP 20160711 Escribir archivo de conciliacion
        private String EscribirRespuestaPago(int nIDRespuesta)
        {            
            DataSet dsCompensacion = new DataSet();
            cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
            cConstante oConstante = new cConstante();
            String nIdLogArchivos;
            String cTipo;
            DateTime dFehaHoraTransaccion;
            DateTime dFehaHoraReservaOpeacion;
            Double nMonto;
            String IdIntruccionPago;
            int IdTransaccion;
            String cResultado;
            String cNombreArchivo;

            StreamWriter sw = null;
            DateTime dFecha = DateTime.Now;
            cNombreArchivo = "CCUSCO_PAR_" + dFecha.ToString("yyyyMMddHHmmss") + ".csv";
            //string path = @"D:\PDP\Outgoing-desarrollo\" + "CCUSCO_PAR_" + dFecha.ToString("yyyyMMddHHmmss") + ".csv";
            string path = oConstante.cpRutaOrigenOutgoing + cNombreArchivo;
            DataSet oCabecera;
            int nPrimera = 0;

            dsCompensacion = oInstruccion.Obtener_RespuestaPago(nIDRespuesta);

            
                if (nPrimera==0)
                {
                    nPrimera=nPrimera+1;
                    //Obtener cabecera 
                    oCabecera = oInstruccion.ObtenerCabecera();
                    sw = File.CreateText(path);

                    foreach (DataRow row in oCabecera.Tables[0].Rows)
                    {
                        sw.WriteLine(row["cCabecera"].ToString());
                    }                    
                    sw.Flush();
                    sw.Close();
                }
                else
                {
                    File.Delete(path);
                    sw = File.CreateText(path);
                    sw.Flush();
                    sw.Close();
                }

                if (dsCompensacion.Tables[0].Rows.Count == 0)
                {
                    MessageBox.Show("No existen operaciones registradas en la fecha ");
                }
                else
                {
                    foreach (DataRow row in dsCompensacion.Tables[0].Rows)
                    {
                        nIdLogArchivos = row["nIdLogArchivos"].ToString();
                        cTipo = row["cTipo"].ToString();
                        dFehaHoraTransaccion = DateTime.Parse(row["dFehaHoraTransaccion"].ToString());
                        //dFehaHoraReservaOpeacion = DateTime.Parse(row["dFehaHoraReservaOpeacion"].ToString());
                        dFehaHoraReservaOpeacion = DateTime.Parse(row["dFechaHoraReservaOperacion"].ToString());  //18/04/2018 LVCH se corrige error
                        nMonto = Double.Parse(row["nMonto"].ToString());
                        IdIntruccionPago = row["cIdIntruccionPago"].ToString();
                        IdTransaccion = int.Parse(row["nMovBim"].ToString());
                        cResultado = row["cResultado"].ToString();                        
                        sw = File.AppendText(path);                        
                        sw.WriteLine(cTipo + "," + dFehaHoraTransaccion.ToString("yyyy-MM-dd HH:mm:ss") + "," + dFehaHoraReservaOpeacion.ToString("yyyy-MM-dd HH:mm:ss") + "," +String.Format("{0,12:0.00}", nMonto).Trim() + "," + IdIntruccionPago + "," + IdTransaccion + "," + cResultado);
                        sw.Flush();
                        sw.Close();
                    }
                }
                //FirmarDocumento  
                String cMensajeFirma = oConstante.FirmaArchivo(cNombreArchivo);
                if (cMensajeFirma != "")
                {
                    MessageBox.Show(cMensajeFirma.ToString(), "Altera");                    
                }
            return path;
        }
        //RTYP 20160711 Escribir archivo de conciliacion

        private void frmRespuestaPago_Load(object sender, EventArgs e)
        {            
            //Obtener Pagos del dia
            DataTable dtPagos;
            dtPagos = MostrarPagos(DateTime.Now);
            dgvPAY.DataSource = dtPagos;
        }
        private DataTable MostrarPagos(DateTime dFecha)
        {
            cArchivoInstruccion oInstruccion = new cArchivoInstruccion();
            return oInstruccion.Mostrar_Pagos(dFecha);
            //dgvPAY.Dispose();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
