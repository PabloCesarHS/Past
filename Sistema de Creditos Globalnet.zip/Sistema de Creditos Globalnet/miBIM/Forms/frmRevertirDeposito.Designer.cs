﻿namespace miBIM.Forms
{
    partial class frmRevertirDeposito
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRevertirDeposito));
            this.paHeader = new System.Windows.Forms.Panel();
            this.laTitulo = new System.Windows.Forms.Label();
            this.btnBuscaRevDep = new System.Windows.Forms.Button();
            this.dgvDeposito = new System.Windows.Forms.DataGridView();
            this.SelRev = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.laFechaFin = new System.Windows.Forms.Label();
            this.laFechaInicio = new System.Windows.Forms.Label();
            this.dtpFechaFinal_Rev = new System.Windows.Forms.DateTimePicker();
            this.dtpFechaInicial_Rev = new System.Windows.Forms.DateTimePicker();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSalir_Rev = new System.Windows.Forms.Button();
            this.btn_Confirmar_Rev = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.paHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeposito)).BeginInit();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // paHeader
            // 
            this.paHeader.BackColor = System.Drawing.SystemColors.ControlLight;
            this.paHeader.Controls.Add(this.laTitulo);
            this.paHeader.Location = new System.Drawing.Point(10, 9);
            this.paHeader.Name = "paHeader";
            this.paHeader.Size = new System.Drawing.Size(830, 49);
            this.paHeader.TabIndex = 31;
            // 
            // laTitulo
            // 
            this.laTitulo.AutoSize = true;
            this.laTitulo.BackColor = System.Drawing.Color.YellowGreen;
            this.laTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laTitulo.ForeColor = System.Drawing.Color.Transparent;
            this.laTitulo.Location = new System.Drawing.Point(317, 10);
            this.laTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laTitulo.Name = "laTitulo";
            this.laTitulo.Size = new System.Drawing.Size(195, 20);
            this.laTitulo.TabIndex = 0;
            this.laTitulo.Text = "REVERTIR DEPÓSITO";
            // 
            // btnBuscaRevDep
            // 
            this.btnBuscaRevDep.Image = global::miBIM.Properties.Resources.buscar;
            this.btnBuscaRevDep.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscaRevDep.Location = new System.Drawing.Point(727, 16);
            this.btnBuscaRevDep.Name = "btnBuscaRevDep";
            this.btnBuscaRevDep.Size = new System.Drawing.Size(85, 23);
            this.btnBuscaRevDep.TabIndex = 2;
            this.btnBuscaRevDep.Text = "&Buscar";
            this.btnBuscaRevDep.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscaRevDep.UseVisualStyleBackColor = true;
            this.btnBuscaRevDep.Click += new System.EventHandler(this.btnBuscaRevDep_Click);
            // 
            // dgvDeposito
            // 
            this.dgvDeposito.AllowUserToAddRows = false;
            this.dgvDeposito.AllowUserToDeleteRows = false;
            this.dgvDeposito.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDeposito.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDeposito.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SelRev});
            this.dgvDeposito.Location = new System.Drawing.Point(22, 45);
            this.dgvDeposito.Name = "dgvDeposito";
            this.dgvDeposito.Size = new System.Drawing.Size(790, 292);
            this.dgvDeposito.TabIndex = 3;
            // 
            // SelRev
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.NullValue = false;
            this.SelRev.DefaultCellStyle = dataGridViewCellStyle1;
            this.SelRev.Frozen = true;
            this.SelRev.HeaderText = "Sel";
            this.SelRev.Name = "SelRev";
            this.SelRev.Width = 28;
            // 
            // laFechaFin
            // 
            this.laFechaFin.AutoSize = true;
            this.laFechaFin.Location = new System.Drawing.Point(574, 21);
            this.laFechaFin.Name = "laFechaFin";
            this.laFechaFin.Size = new System.Drawing.Size(54, 13);
            this.laFechaFin.TabIndex = 4;
            this.laFechaFin.Text = "Fecha Fin";
            // 
            // laFechaInicio
            // 
            this.laFechaInicio.AutoSize = true;
            this.laFechaInicio.Location = new System.Drawing.Point(411, 21);
            this.laFechaInicio.Name = "laFechaInicio";
            this.laFechaInicio.Size = new System.Drawing.Size(65, 13);
            this.laFechaInicio.TabIndex = 3;
            this.laFechaInicio.Text = "Fecha Inicio";
            // 
            // dtpFechaFinal_Rev
            // 
            this.dtpFechaFinal_Rev.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaFinal_Rev.Location = new System.Drawing.Point(634, 19);
            this.dtpFechaFinal_Rev.Name = "dtpFechaFinal_Rev";
            this.dtpFechaFinal_Rev.Size = new System.Drawing.Size(87, 20);
            this.dtpFechaFinal_Rev.TabIndex = 1;
            // 
            // dtpFechaInicial_Rev
            // 
            this.dtpFechaInicial_Rev.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaInicial_Rev.Location = new System.Drawing.Point(482, 19);
            this.dtpFechaInicial_Rev.Name = "dtpFechaInicial_Rev";
            this.dtpFechaInicial_Rev.Size = new System.Drawing.Size(86, 20);
            this.dtpFechaInicial_Rev.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.btnSalir_Rev);
            this.panel2.Controls.Add(this.btn_Confirmar_Rev);
            this.panel2.Location = new System.Drawing.Point(10, 430);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(830, 50);
            this.panel2.TabIndex = 30;
            // 
            // btnSalir_Rev
            // 
            this.btnSalir_Rev.Location = new System.Drawing.Point(720, 3);
            this.btnSalir_Rev.Name = "btnSalir_Rev";
            this.btnSalir_Rev.Size = new System.Drawing.Size(90, 35);
            this.btnSalir_Rev.TabIndex = 1;
            this.btnSalir_Rev.Text = "&Salir";
            this.btnSalir_Rev.UseVisualStyleBackColor = true;
            this.btnSalir_Rev.Click += new System.EventHandler(this.btnSalir_Rev_Click);
            // 
            // btn_Confirmar_Rev
            // 
            this.btn_Confirmar_Rev.Enabled = false;
            this.btn_Confirmar_Rev.Location = new System.Drawing.Point(20, 3);
            this.btn_Confirmar_Rev.Name = "btn_Confirmar_Rev";
            this.btn_Confirmar_Rev.Size = new System.Drawing.Size(90, 35);
            this.btn_Confirmar_Rev.TabIndex = 0;
            this.btn_Confirmar_Rev.Text = "&Generar";
            this.btn_Confirmar_Rev.UseVisualStyleBackColor = true;
            this.btn_Confirmar_Rev.Click += new System.EventHandler(this.btn_Confirmar_Rev_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnBuscaRevDep);
            this.groupBox1.Controls.Add(this.dtpFechaInicial_Rev);
            this.groupBox1.Controls.Add(this.dgvDeposito);
            this.groupBox1.Controls.Add(this.dtpFechaFinal_Rev);
            this.groupBox1.Controls.Add(this.laFechaFin);
            this.groupBox1.Controls.Add(this.laFechaInicio);
            this.groupBox1.Location = new System.Drawing.Point(10, 64);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(830, 360);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "REVERTIR DEPÓSITO";
            // 
            // frmRevertirDeposito
            // 
            this.AcceptButton = this.btnBuscaRevDep;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(850, 489);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.paHeader);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmRevertirDeposito";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Revertir Depósito";
            this.Load += new System.EventHandler(this.frmRevertirDeposito_Load);
            this.paHeader.ResumeLayout(false);
            this.paHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeposito)).EndInit();
            this.panel2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel paHeader;
        private System.Windows.Forms.Label laTitulo;
        private System.Windows.Forms.Button btnBuscaRevDep;
        private System.Windows.Forms.DataGridView dgvDeposito;
        private System.Windows.Forms.DataGridViewCheckBoxColumn SelRev;
        private System.Windows.Forms.Label laFechaFin;
        private System.Windows.Forms.Label laFechaInicio;
        private System.Windows.Forms.DateTimePicker dtpFechaFinal_Rev;
        private System.Windows.Forms.DateTimePicker dtpFechaInicial_Rev;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnSalir_Rev;
        private System.Windows.Forms.Button btn_Confirmar_Rev;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}