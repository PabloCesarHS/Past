﻿using CapaNegocio;
using System;
using System.Windows.Forms;

namespace miBIM.Forms
{
    public partial class frmRuta : Form
    {
        cConfiguracion vgConfiguracion = new cConfiguracion();
        cResultado vgResultado = new cResultado();

        public frmRuta()
        {
            InitializeComponent();
        }

        private bool ValidarClaseRuta()
        {
            bool Correcto = false;

            if (tbxRuta.Text != string.Empty)
                Correcto = true;

            return Correcto;
        }

        private void Mostrar_Mensaje(string _Mensaje, int _Tipo)
        {
            switch (_Tipo)
            {
                case 1:
                    lbMensaje.ForeColor = System.Drawing.Color.Blue;
                    lbMensaje.Text = _Mensaje;
                    break;

                case 2:
                    lbMensaje.ForeColor = System.Drawing.Color.OrangeRed;
                    lbMensaje.Text = "ADVERTENCIA:" + _Mensaje;
                    break;

                case 3:
                    lbMensaje.ForeColor = System.Drawing.Color.Red;
                    lbMensaje.Text = "ERROR:" + _Mensaje;
                    break;

                default:
                    lbMensaje.ForeColor = System.Drawing.Color.Green;
                    lbMensaje.Text = _Mensaje;
                    break;
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (ValidarClaseRuta())
            {
                /* aprobacion de cambio */
                frmAprobacion oAprobacion = new frmAprobacion();
                if (oAprobacion.ShowDialog() == DialogResult.OK)
                {
                    //vgConfiguracion = new cConfiguracion();
                    //vgResultado = new cResultado();

                    //vgResultado = vgConfiguracion.Insertar_Ruta(tbxRuta.Text, 0);

                    //if (vgResultado.Estado == 1)
                    //{
                    //    this.DialogResult = DialogResult.OK;
                    //    this.Close();
                    //}
                    //else
                    //{
                    //    Mostrar_Mensaje(vgResultado.Mensaje, vgResultado.Estado);
                    //}
                }
            }
        }

        private void btnRutaCarpeta_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog oFBD = new FolderBrowserDialog();
            if (oFBD.ShowDialog() == DialogResult.OK)
            {
                if (oFBD.SelectedPath != string.Empty)
                {
                    tbxRuta.Text = oFBD.SelectedPath + @"\";
                }
            }
        }

        private void btnRutaArchivo_Click(object sender, EventArgs e)
        {
            OpenFileDialog oFD = new OpenFileDialog();
            if (oFD.ShowDialog() == DialogResult.OK)
            {
                if (oFD.FileName != string.Empty)
                {
                    tbxRuta.Text = oFD.FileName;
                }
            }
        }
    }
}

/*
 using System;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        string filePath = @"C:\path\to\your\file.txt";

        try
        {
            using (StreamReader sr = new StreamReader(filePath))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    // Process the line here
                }
            }
        }
        catch (Exception e)
        {
            Console.WriteLine("An error occurred: " + e.Message);
        }
    }
}
 */