﻿using System;

namespace WFPruebasBus.Clases
{
    public class ClClaBusInt_Autenticacion_Ent
    {
        public ClClaBusInt_Autenticacion_Ent()
        {
        }

        public ClClaBusInt_Autenticacion_Ent(string codigo_Canal, string id_usuario, string id_agencia, string otros)
        {
            Codigo_Canal = codigo_Canal;
            Id_usuario = id_usuario;
            Id_agencia = id_agencia;
            Otros = otros;
        }

        public string Codigo_Canal { get; set; }
        public string Id_usuario { get; set; }
        public string Id_agencia { get; set; }
        public string Otros { get; set; }

    }

    public class ClaBusInt_ConsultaDeuda_Ent
    {
        public ClaBusInt_ConsultaDeuda_Ent()
        {
        }

        public ClaBusInt_ConsultaDeuda_Ent(string token, string usuario, string codigoInstitucion, string canal, string codigoAlumno, string codigoConcepto)
        {
            this.token = token;
            this.usuario = usuario;
            this.codigoInstitucion = codigoInstitucion;
            this.canal = canal;
            this.codigoAlumno = codigoAlumno;
            this.codigoConcepto = codigoConcepto;
        }

        public string token { get; set; }
        public string usuario { get; set; }
        public string codigoInstitucion { get; set; }
        public string canal { get; set; }
        public string codigoAlumno { get; set; }
        public string codigoConcepto { get; set; }
    }

    public class ClaBusInt_ConsultaDeuda_ASMX_Ent
    {
        public ClaBusInt_ConsultaDeuda_ASMX_Ent()
        {
        }

        public ClaBusInt_ConsultaDeuda_ASMX_Ent(string codigo_Canal, string id_Cliente, string id_usuario, string id_agencia, string fecha_Hora)
        {
            Codigo_Canal = codigo_Canal;
            Id_Cliente = id_Cliente;
            Id_usuario = id_usuario;
            Id_agencia = id_agencia;
            Fecha_Hora = fecha_Hora;
        }

        public string Codigo_Canal { get; set; }
        public string Id_Cliente { get; set; }
        public string Id_usuario { get; set; }
        public string Id_agencia { get; set; }
        public string Fecha_Hora { get; set; }
    }

    public class ClaBusInt_ConsultaDeuda_Full_Ent
    {
        public ClaBusInt_ConsultaDeuda_Full_Ent()
        {
        }

        public ClaBusInt_ConsultaDeuda_Full_Ent(string _usuarioAuth, string _usuario, string _codigoInstitucion, string _canal, string _codigoAlumno, string _codigoConcepto)
        {
            this.usuarioAuth = _usuarioAuth;
            this.usuario = _usuario;
            this.codigoInstitucion = _codigoInstitucion;
            this.canal = _canal;
            this.codigoAlumno = _codigoAlumno;
            this.codigoConcepto = _codigoConcepto;
        }

        public string usuarioAuth { get; set; }
        public string usuario { get; set; }
        public string codigoInstitucion { get; set; }
        public string canal { get; set; }
        public string codigoAlumno { get; set; }
        public string codigoConcepto { get; set; }
    }

    public class ClaBusInt_Autenticacion
    {
        public ClaBusInt_Autenticacion()
        {
        }

        public ClaBusInt_Autenticacion(string codigoRespuesta, string mensajeRespuesta, string access_token, string token_type, string refresh_token, string expires_in, string scope, ClaBusInt_DetalleAuth detalle, string jti)
        {
            this.codigoRespuesta = codigoRespuesta;
            this.mensajeRespuesta = mensajeRespuesta;
            this.access_token = access_token;
            this.token_type = token_type;
            this.refresh_token = refresh_token;
            this.expires_in = expires_in;
            this.scope = scope;
            this.detalle = detalle;
            this.jti = jti;
        }

        public ClaBusInt_Autenticacion ByDefault()
        {
            ClaBusInt_Autenticacion oClase = new ClaBusInt_Autenticacion();
            oClase.codigoRespuesta = "03";
            oClase.mensajeRespuesta = "Error:Time Out";
            //oClase.access_token = access_token;
            //oClase.token_type = token_type;
            //oClase.refresh_token = refresh_token;
            //oClase.expires_in = expires_in;
            //oClase.scope = scope;
            oClase.detalle = new ClaBusInt_DetalleAuth();
            //oClase.jti = jti;

            return oClase;
        }

        /*
            * "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MzQyNDEyNDQsInVzZXJfbmFtZSI6IiIsImp0aSI6ImE2N2NjYmIzLTg0MTktNDMwZC04NzNhLWU1OWEwNzIwNzRiYiIsImNsaWVudF9pZCI6ImF1dGVudGlmaWNhY2lvbiIsInNjb3BlIjpbInJlYWQiLCJ3cml0ZSJdLCJkZXRhbGxlIjp7ImNvZGlnb1Jlc3B1ZXN0YSI6IjAwIiwibWVuc2FqZVJlc3B1ZXN0YSI6IkNPUlJFQ1RPIiwidGlwb0NhbWJpb0NvbXByYSI6IjQuMDgzMCIsInRpcG9DYW1iaW9WZW50YSI6IjQuMTg4MCIsImludGVyYWNjaW9uU2VndW5kb3MiOjYwLCJjYW5hbCI6IjAzIiwidXN1YXJpbyI6ImhzcGMiLCJhZ2VuY2lhIjoiMDEiLCJkZXNjcmlwY2lvbkFnZW5jaWEiOiJPZmljaW5hIFByaW5jaXBhbCIsImRlc2NyaXBjaW9uQ2FuYWwiOiJWZW50YW5pbGxhIn19.kOjdbHsbxscmBQcbO6FJIn_y8lHlGjzxCxI5F48gKVoe_c_h_puLgfzMca_yZTgB-uDrop1RECWKK3_jgh8pdOLiIx_m7lrpj0DYncnTSiVWE1NN2KXLoLbVikd3vfa6ioSgLGGTttnysw9z771cq7-KcSAVUzuMMsjZ3_GZWkIR3CqTIYcT73JZBItVFYZRX03iHatcV0KKqt5EZj2yO4AOmTJck4WuBF58oY0lFtXiMd3FzUN7n5tt4L0vUY8p53eB6RFzZNnpWywQbrVtou0UHlBIy6lyuRYiCqB1RNiBh_-ly6E-0bhSwy45Wwtt4DmtHqbKPdoIZgeKuYRUtw",
               "token_type": "bearer",
               "refresh_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX25hbWUiOiIiLCJzY29wZSI6WyJyZWFkIiwid3JpdGUiXSwiYXRpIjoiYTY3Y2NiYjMtODQxOS00MzBkLTg3M2EtZTU5YTA3MjA3NGJiIiwiZXhwIjoxNjM0MjQxMjk0LCJqdGkiOiI4NDZmYTI0NS1jZjJiLTQyYjAtYmYxNy01ZWU0OWY2OWJhYmYiLCJjbGllbnRfaWQiOiJhdXRlbnRpZmljYWNpb24iLCJkZXRhbGxlIjp7ImNvZGlnb1Jlc3B1ZXN0YSI6IjAwIiwibWVuc2FqZVJlc3B1ZXN0YSI6IkNPUlJFQ1RPIiwidGlwb0NhbWJpb0NvbXByYSI6IjQuMDgzMCIsInRpcG9DYW1iaW9WZW50YSI6IjQuMTg4MCIsImludGVyYWNjaW9uU2VndW5kb3MiOjYwLCJjYW5hbCI6IjAzIiwidXN1YXJpbyI6ImhzcGMiLCJhZ2VuY2lhIjoiMDEiLCJkZXNjcmlwY2lvbkFnZW5jaWEiOiJPZmljaW5hIFByaW5jaXBhbCIsImRlc2NyaXBjaW9uQ2FuYWwiOiJWZW50YW5pbGxhIn19.Bc35HdkpDhGh9AxGR_wcGqvwCXemdfXA0RI94ntgwmgNqFLoyN-tgt1B_dCsc1tTH97A8GuA3oqfy0tIY6gwfWHgyan6VtadAXqwOWDkjQ4pNlnaADkQgnPzHycCX4hqUZo50XgrM7Qp4CbFW7zpJXgROXoE2HbhHGorh4YQzcEo9EMA08tNH7_3cZt7NDh7KFsmuU_Y806n-iq0T4EgFRqG5G_cpi9VbfHQHrJscTDF6X84cViDk2dpPmNMNseXkaIyUVllqgXWmFN-B6LqOyJnqu--OJRRo07VhEVk5Dh4zlKeq9wBi8dYgCX-4txfyihc17iVZfaKqtdc84r0Ww",
               "expires_in": 299,
               "scope": "read write",
               "detalle": {
                   "codigoRespuesta": "00",
                   "mensajeRespuesta": "CORRECTO",
                   "tipoCambioCompra": "4.0830",
                   "tipoCambioVenta": "4.1880",
                   "interaccionSegundos": 60,
                   "canal": "03",
                   "usuario": "hspc",
                   "agencia": "01",
                   "descripcionAgencia": "Oficina Principal",
                   "descripcionCanal": "Ventanilla"
               },
               "jti": "a67ccbb3-8419-430d-873a-e59a072074bb"
            */
        public string codigoRespuesta { get; set; }
        public string mensajeRespuesta { get; set; }
        public string access_token { get; set; }
        public string token_type { get; set; }
        public string refresh_token { get; set; }
        public string expires_in { get; set; }
        public string scope { get; set; }
        public ClaBusInt_DetalleAuth detalle { get; set; }
        public string jti { get; set; }

    }

    public class ClaBusInt_DetalleAuth
    {
        public ClaBusInt_DetalleAuth()
        {
        }

        public ClaBusInt_DetalleAuth(string codigoRespuesta, string mensajeRespuesta, string tipoCambioCompra, string tipoCambioVenta, int interaccionSegundos, string canal, string usuario, string agencia, string descripcionAgencia, string descripcionCanal)
        {
            this.codigoRespuesta = codigoRespuesta;
            this.mensajeRespuesta = mensajeRespuesta;
            this.tipoCambioCompra = tipoCambioCompra;
            this.tipoCambioVenta = tipoCambioVenta;
            this.interaccionSegundos = interaccionSegundos;
            this.canal = canal;
            this.usuario = usuario;
            this.agencia = agencia;
            this.descripcionAgencia = descripcionAgencia;
            this.descripcionCanal = descripcionCanal;
        }

        public ClaBusInt_DetalleAuth ByDefault()
        {
            ClaBusInt_DetalleAuth oClase = new ClaBusInt_DetalleAuth();
            oClase.codigoRespuesta = "03";
            oClase.mensajeRespuesta = "Error:Time Out";
            //oClase.tipoCambioCompra = tipoCambioCompra;
            //oClase.tipoCambioVenta = tipoCambioVenta;
            //oClase.interaccionSegundos = interaccionSegundos;
            //oClase.canal = canal;
            //oClase.usuario = usuario;
            //oClase.agencia = agencia;
            //oClase.descripcionAgencia = descripcionAgencia;
            //oClase.descripcionCanal = descripcionCanal;

            return oClase;
        }

        /*
            * "detalle": {
                   "codigoRespuesta": "00",
                   "mensajeRespuesta": "CORRECTO",
                   "tipoCambioCompra": "4.0830",
                   "tipoCambioVenta": "4.1880",
                   "interaccionSegundos": 60,
                   "canal": "03",
                   "usuario": "hspc",
                   "agencia": "01",
                   "descripcionAgencia": "Oficina Principal",
                   "descripcionCanal": "Ventanilla"
               }
            */
        public string codigoRespuesta { get; set; }
        public string mensajeRespuesta { get; set; }
        public string tipoCambioCompra { get; set; }
        public string tipoCambioVenta { get; set; }
        public int interaccionSegundos { get; set; }
        public string canal { get; set; }
        public string usuario { get; set; }
        public string agencia { get; set; }
        public string descripcionAgencia { get; set; }
        public string descripcionCanal { get; set; }
    }

    public class ClaBusInt_ConsultaDeuda
    {
        public ClaBusInt_ConsultaDeuda()
        {
        }

        public ClaBusInt_ConsultaDeuda(string codigoRespuesta, string mensajeRespuesta, string codigoAlumno, string codigoConceptoPago, string codigoPeriodoPago, string codigoServicioPago, string nombreInstitucion, string numeroCuota, string nombrePago, string fechaVencimiento, string fechaPago, string diasMora, string montoPago, string nombreServicio, string nombreConcepto, ClaBusInt_Moneda moneda, string nombreCliente, string descripcionPeriodo, string montoCuota, string montoMora, string montoAdicional, string montoVariable)
        {
            this.codigoRespuesta = codigoRespuesta;
            this.mensajeRespuesta = mensajeRespuesta;
            this.codigoAlumno = codigoAlumno;
            this.codigoConceptoPago = codigoConceptoPago;
            this.codigoPeriodoPago = codigoPeriodoPago;
            this.codigoServicioPago = codigoServicioPago;
            this.nombreInstitucion = nombreInstitucion;
            this.numeroCuota = numeroCuota;
            this.nombrePago = nombrePago;
            this.fechaVencimiento = fechaVencimiento;
            this.fechaPago = fechaPago;
            this.diasMora = diasMora;
            this.montoPago = montoPago;
            this.nombreServicio = nombreServicio;
            this.nombreConcepto = nombreConcepto;
            this.moneda = moneda;
            this.nombreCliente = nombreCliente;
            this.descripcionPeriodo = descripcionPeriodo;
            this.montoCuota = montoCuota;
            this.montoMora = montoMora;
            this.montoAdicional = montoAdicional;
            this.montoVariable = montoVariable;
        }

        public ClaBusInt_ConsultaDeuda ByDefault()
        {
            ClaBusInt_ConsultaDeuda oClase = new ClaBusInt_ConsultaDeuda();
            oClase.codigoRespuesta = "03";
            oClase.mensajeRespuesta = "Error:Time Out";
            //oClase.codigoAlumno = codigoAlumno;
            //oClase.codigoConceptoPago = codigoConceptoPago;
            //oClase.codigoPeriodoPago = codigoPeriodoPago;
            //oClase.codigoServicioPago = codigoServicioPago;
            //oClase.nombreInstitucion = nombreInstitucion;
            //oClase.numeroCuota = numeroCuota;
            //oClase.nombrePago = nombrePago;
            //oClase.fechaVencimiento = fechaVencimiento;
            //oClase.fechaPago = fechaPago;
            //oClase.diasMora = diasMora;
            //oClase.montoPago = montoPago;
            //oClase.nombreServicio = nombreServicio;
            //oClase.nombreConcepto = nombreConcepto;
            oClase.moneda = new ClaBusInt_Moneda();
            //oClase.nombreCliente = nombreCliente;
            //oClase.descripcionPeriodo = descripcionPeriodo;
            //oClase.montoCuota = montoCuota;
            //oClase.montoMora = montoMora;
            //oClase.montoAdicional = montoAdicional;
            //oClase.montoVariable = montoVariable;

            return oClase;
        }

        /*
            * "codigoRespuesta": "00",
               "mensajeRespuesta": "CORRECTO",
               "codigoAlumno": "110000124",
               "codigoConceptoPago": "00",
               "codigoPeriodoPago": "00",
               "codigoServicioPago": "00",
               "nombreInstitucion": "",
               "numeroCuota": 1078,
               "nombrePago": "",
               "fechaVencimiento": "2021-07-19 00:00:00.0",
               "fechaPago": "",
               "diasMora": "0",
               "montoPago": "11.80",
               "nombreServicio": "",
               "nombreConcepto": "",
               "moneda": {
                   "codigo": 1,
                   "descripcion": "S/"
               },
               "nombreCliente": "SOTO ARANDA LUIS PATRICIO",
               "descripcionPeriodo": "",
               "montoCuota": "11.80",
               "montoMora": "0.00",
               "montoAdicional": "0.00",
               "montoVariable": false
            */
        public string codigoRespuesta { get; set; }
        public string mensajeRespuesta { get; set; }
        public string codigoAlumno { get; set; }
        public string codigoConceptoPago { get; set; }
        public string codigoPeriodoPago { get; set; }
        public string codigoServicioPago { get; set; }
        public string nombreInstitucion { get; set; }
        public string numeroCuota { get; set; }
        public string nombrePago { get; set; }
        public string fechaVencimiento { get; set; }
        public string fechaPago { get; set; }
        public string diasMora { get; set; }
        public string montoPago { get; set; }
        public string nombreServicio { get; set; }
        public string nombreConcepto { get; set; }
        public ClaBusInt_Moneda moneda { get; set; }
        public string nombreCliente { get; set; }
        public string descripcionPeriodo { get; set; }
        public string montoCuota { get; set; }
        public string montoMora { get; set; }
        public string montoAdicional { get; set; }
        public string montoVariable { get; set; }
    }

    public class ClaBusInt_Moneda
    {
        public ClaBusInt_Moneda()
        {
        }

        public ClaBusInt_Moneda(string codigo, string descripcion)
        {
            this.codigo = codigo;
            this.descripcion = descripcion;
        }

        public string CoinToStringName(string codigo)
        {
            string Moneda = "VACIO";
            switch (codigo)
            {
                case "1":
                    Moneda = "SOLES";
                    break;
                case "2":
                    Moneda = "DOLARES";
                    break;
                default:
                    Moneda = "VACIO";
                    break;
            }

            return Moneda;
        }

        public string CoinToStringId(string name)
        {
            string Moneda = "0";
            switch (name)
            {
                case "SOLES":
                    Moneda = "1";
                    break;
                case "DOLARES":
                    Moneda = "2";
                    break;
                default:
                    Moneda = "0";
                    break;
            }

            return Moneda;
        }

        /*
            * "moneda": {
                   "codigo": 1,
                   "descripcion": "S/"
               }
            */

        public string codigo { get; set; }
        public string descripcion { get; set; }
    }

    public class ClaBusInt_PagarDeuda
    {
        public ClaBusInt_PagarDeuda()
        {
        }

        public ClaBusInt_PagarDeuda(string codigoRespuesta, string mensajeRespuesta, int codigoAutoriza, int numeroCobro)
        {
            this.codigoRespuesta = codigoRespuesta;
            this.mensajeRespuesta = mensajeRespuesta;
            this.codigoAutoriza = codigoAutoriza;
            this.numeroCobro = numeroCobro;
        }

        /*
            * "codigoRespuesta": "00",
               "mensajeRespuesta": "CORRECTO",
               "codigoAutoriza": 0,
               "numeroCobro": 2362622
            */

        public string codigoRespuesta { get; set; }
        public string mensajeRespuesta { get; set; }
        public int codigoAutoriza { get; set; }
        public int numeroCobro { get; set; }
    }
}