﻿using System;

namespace WFPruebasBus.Clases
{
    public class RetornoConsultarDeuda
    {
        private string pCodigo_Respuesta = "";
        private string pMensaje_Respuesta = "";
        private string pId_Institucion = "";
        private string pId_Cliente = "";
        private string pCodigo_Concepto = "";
        private string pCodigo_Servicio = "";
        private int pNumero_Cuota = 0; //Monto total de la cuota
        private string pCodigo_Periodo = "";
        private string pMoneda = "";
        private DateTime pFecha_Vencimiento;// = DateTime.MinValue; //ddmmaaaa
        private string pNombre_Concepto = "";
        private string pDescripcion_Periodo = "";
        private double pMonto_Cuota;// = 0.00; //Monto de la cuota
        //private double pMonto_Mora;// = 0.00;
        private string pMonto_Mora; //MBCR 20180824 - Cambia a string para mostrar nombre del cliente en pantalla (solo para pagos con ELSE)
        private int pDias_Atraso;// = 0;
        private double pMonto_Adicional;// = 0.00;
        private double pComision;//= 0.00;
        private double pPago_Total;// = 0.00;
        private int pCuota_Pendiente = 0;//UQMA 28/08/2017
        private string pNombre_Institucion = "";  //29/08/2017 UQMA para obtner Nombre corto de Instirución
        private string pNombre_Cliente = "";      //29/08/2017 UQMA para obtner Nombre corto de cliente

        public RetornoConsultarDeuda()
        { }

        public RetornoConsultarDeuda(string pCodigo_Respuesta, string pMensaje_Respuesta, string pId_Institucion, string pId_Cliente, string pCodigo_Concepto, string pCodigo_Servicio, int pNumero_Cuota, string pCodigo_Periodo, string pMoneda, DateTime pFecha_Vencimiento, string pNombre_Concepto, string pDescripcion_Periodo, double pMonto_Cuota, string pMonto_Mora, int pDias_Atraso, double pMonto_Adicional, double pComision, double pPago_Total, int pCuota_Pendiente, string pNombre_Institucion, string pNombre_Cliente)
        {
            Codigo_Respuesta = pCodigo_Respuesta ?? throw new ArgumentNullException(nameof(pCodigo_Respuesta));
            Mensaje_Respuesta = pMensaje_Respuesta ?? throw new ArgumentNullException(nameof(pMensaje_Respuesta));
            Id_Institucion = pId_Institucion ?? throw new ArgumentNullException(nameof(pId_Institucion));
            Id_Cliente = pId_Cliente ?? throw new ArgumentNullException(nameof(pId_Cliente));
            Codigo_Concepto = pCodigo_Concepto ?? throw new ArgumentNullException(nameof(pCodigo_Concepto));
            Codigo_Servicio = pCodigo_Servicio ?? throw new ArgumentNullException(nameof(pCodigo_Servicio));
            Numero_Cuota = pNumero_Cuota;
            Codigo_Periodo = pCodigo_Periodo ?? throw new ArgumentNullException(nameof(pCodigo_Periodo));
            Moneda = pMoneda ?? throw new ArgumentNullException(nameof(pMoneda));
            Fecha_Vencimiento = pFecha_Vencimiento;
            Nombre_Concepto = pNombre_Concepto ?? throw new ArgumentNullException(nameof(pNombre_Concepto));
            Descripcion_Periodo = pDescripcion_Periodo ?? throw new ArgumentNullException(nameof(pDescripcion_Periodo));
            Monto_Cuota = pMonto_Cuota;
            Monto_Mora = pMonto_Mora ?? throw new ArgumentNullException(nameof(pMonto_Mora));
            Dias_Atraso = pDias_Atraso;
            Monto_Adicional = pMonto_Adicional;
            Comision = pComision;
            Pago_Total = pPago_Total;
            Cuota_Pendiente = pCuota_Pendiente;
            Nombre_Institucion = pNombre_Institucion ?? throw new ArgumentNullException(nameof(pNombre_Institucion));
            Nombre_Cliente = pNombre_Cliente ?? throw new ArgumentNullException(nameof(pNombre_Cliente));
        }

        public RetornoConsultarDeuda ClaseXDefecto()
        {
            return new RetornoConsultarDeuda();
        }


        public string Codigo_Respuesta
        {
            get
            {
                return this.pCodigo_Respuesta;
            }
            set
            {
                this.pCodigo_Respuesta = value;
            }
        }

        public string Mensaje_Respuesta
        {
            get
            {
                return this.pMensaje_Respuesta;
            }
            set
            {
                this.pMensaje_Respuesta = value;
            }
        }
        public string Id_Institucion
        {
            get
            {
                return this.pId_Institucion;
            }
            set
            {
                this.pId_Institucion = value;
            }
        }
        public string Nombre_Institucion     //29/08/2017 UQMA para obtner Nombre corto de Instirución
        {
            get
            {
                return this.pNombre_Institucion;
            }
            set
            {
                this.pNombre_Institucion = value;
            }
        }


        public string Id_Cliente
        {
            get
            {
                return this.pId_Cliente;
            }
            set
            {
                this.pId_Cliente = value;
            }
        }
        public string Nombre_Cliente             //29/08/2017 UQMA para obtner Nombre corto de cliente
        {
            get
            {
                return this.pNombre_Cliente;
            }
            set
            {
                this.pNombre_Cliente = value;
            }
        }

        public string Codigo_Concepto
        {
            get
            {
                return this.pCodigo_Concepto;
            }
            set
            {
                this.pCodigo_Concepto = value;
            }
        }
        public string Codigo_Servicio
        {
            get
            {
                return this.pCodigo_Servicio;
            }
            set
            {
                this.pCodigo_Servicio = value;
            }
        }

        public int Numero_Cuota
        {
            get
            {
                return this.pNumero_Cuota;
            }
            set
            {
                this.pNumero_Cuota = value;
            }
        }

        public string Codigo_Periodo
        {
            get
            {
                return this.pCodigo_Periodo;
            }
            set
            {
                this.pCodigo_Periodo = value;
            }
        }

        public string Moneda
        {
            get
            {
                return this.pMoneda;
            }
            set
            {
                this.pMoneda = value;
            }
        }

        public DateTime Fecha_Vencimiento
        {
            get
            {
                return this.pFecha_Vencimiento;
            }
            set
            {
                this.pFecha_Vencimiento = value;
            }
        }

        public string Nombre_Concepto
        {
            get
            {
                return this.pNombre_Concepto;
            }
            set
            {
                this.pNombre_Concepto = value;
            }
        }

        public string Descripcion_Periodo
        {
            get
            {
                return this.pDescripcion_Periodo;
            }
            set
            {
                this.pDescripcion_Periodo = value;
            }
        }

        public double Monto_Cuota
        {
            get
            {
                return this.pMonto_Cuota;
            }
            set
            {
                this.pMonto_Cuota = value;
            }
        }

        //public double Monto_Mora
        //MBCR 20180824 - Cambia a string para mostrar nombre del cliente en pantalla (solo para pagos con ELSE)
        public string Monto_Mora
        {
            get
            {
                return this.pMonto_Mora;
            }
            set
            {
                this.pMonto_Mora = value;
            }
        }

        public int Dias_Atraso
        {
            get
            {
                return this.pDias_Atraso;
            }
            set
            {
                this.pDias_Atraso = value;
            }
        }
        public double Monto_Adicional
        {
            get
            {
                return this.pMonto_Adicional;
            }
            set
            {
                this.pMonto_Adicional = value;
            }
        }

        public double Comision
        {
            get
            {
                return this.pComision;
            }
            set
            {
                this.pComision = value;
            }
        }

        public double Pago_Total
        {
            get
            {
                return this.pPago_Total;
            }
            set
            {
                this.pPago_Total = value;
            }
        }
        //UQMA 28/08/2017
        public int Cuota_Pendiente
        {
            get
            {
                return this.pCuota_Pendiente;
            }
            set
            {
                this.pCuota_Pendiente = value;
            }
        }

    }
}