﻿using System;

namespace WFPruebasBus.Clases
{
    public class cGenerico
    {

    }

    public class cResultado
    {
        public cResultado()
        {
        }

        public cResultado(int nro, DateTime fechaHoraGen, DateTime fechaHoraIni, int duracion, DateTime fechaHoraFin, string concepto, string estado, string respuesta)
        {
            Nro = nro;
            FechaHoraGen = fechaHoraGen;
            FechaHoraIni = fechaHoraIni;
            Duracion = duracion;
            FechaHoraFin = fechaHoraFin;
            Concepto = concepto;
            Estado = estado;
            Respuesta = respuesta;
        }

        public int Nro { get; set; }
        public DateTime FechaHoraGen { get; set; }
        public DateTime FechaHoraIni { get; set; }
        public int Duracion { get; set; }
        public DateTime FechaHoraFin { get; set; }
        public string Concepto { get; set; }
        public string Estado { get; set; }
        public string Respuesta { get; set; }
    }
}