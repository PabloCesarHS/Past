﻿
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using WFPruebasBus.Clases;
//using WFPruebasBus.SRAgenteCorresponsal;

namespace WFPruebasBus
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
            Listar_Clases_Transformacion();
        }

        //Lista de VARIABLES UNIVERSALES
        //string vuEstadoLista = "V0";

        #region TRANSFORMACION Y RECOLECCION DE DATOS

        //copiar lista de memoria
        public DataTable GetListCopyMemory()
        {
            DataTable oTabla = new DataTable();

            //CAPTURRA LISTA DE MEMORIA
            string s = Clipboard.GetText();
            string[] Lista = s.Split(new char[2] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            //VERIFICAR PRIMERA COLUMNA
            bool EsPrimero = true;

            foreach (string Linea in Lista)
            {
                //SEPARARA DATOS DE LINEA
                string[] Celdas = Linea.Split('\t');

                //VERIFICAR PRIMERA FILA
                if (EsPrimero)
                {
                    foreach (string value in Celdas)
                    {
                        oTabla.Columns.Add(value);
                    }
                    // cambiar valor de variable
                    EsPrimero = false;
                }
                else
                {
                    DataRow NuevaFila = oTabla.NewRow();
                    NuevaFila.ItemArray = Celdas;
                    oTabla.Rows.Add(NuevaFila);
                }
            }
            return oTabla;
        }

        //Convertir DATABLE A LIST
        private static List<T> DataTableAList<T>(DataTable _DataTable)
        {
            //Primera parte
            Type TipoClase = typeof(T);
            var Propiedades = TipoClase.GetProperties();

            _DataTable.TableName = typeof(T).FullName;
            Dictionary<string, object> ListaColumnas = new Dictionary<string, object>();
            //Agregar a lista las columnas
            foreach (PropertyInfo info in Propiedades)
            {
                ListaColumnas.Add(info.Name, Nullable.GetUnderlyingType(info.PropertyType) ?? info.PropertyType);
            }
            //Modificar el nombre de las columnas
            foreach (DataColumn Columna in _DataTable.Columns)
            {
                _DataTable.Columns[Columna.Ordinal].ColumnName = ListaColumnas.ElementAt(Columna.Ordinal).Key;
            }
            //segunda parte
            List<T> ListaClases = new List<T>();
            foreach (DataRow Fila in _DataTable.Rows)
            {
                T item = ObtenerFila<T>(Fila);
                ListaClases.Add(item);
            }
            return ListaClases;
        }

        //Convertir fila a Clase
        private static T ObtenerFila<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            foreach (DataColumn Columna in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == Columna.ColumnName)
                        pro.SetValue(obj, dr[Columna.ColumnName], null);
                    else
                        continue;
                }
            }
            return obj;
        }

        public string IsEmptyNull(Object Valor)
        {
            return Valor?.ToString() ?? string.Empty;
        }

        #endregion TRANSFORMACION Y RECOLECCION DE DATOS

        #region LISTAS O VARABLES UNIVERSALES A UTILIZAR
        //LISTAS DE ENTRADA
        List<ClClaBusInt_Autenticacion_Ent> vuListaAutenticacion_Ent = new List<ClClaBusInt_Autenticacion_Ent>();
        List<ClaBusInt_ConsultaDeuda_Ent> vuListaConsultaDeuda_Ent = new List<ClaBusInt_ConsultaDeuda_Ent>();
        List<ClaBusInt_ConsultaDeuda_Full_Ent> vuListaConsultaDeuda_Full_Ent = new List<ClaBusInt_ConsultaDeuda_Full_Ent>();
        List<ClaBusInt_ConsultaDeuda_ASMX_Ent> vuListaConsultaDeuda_ASMX_Ent = new List<ClaBusInt_ConsultaDeuda_ASMX_Ent>();

        //LISTAS DE SALIDA
        List<ClaBusInt_ConsultaDeuda> vuListaConsultaDeuda = new List<ClaBusInt_ConsultaDeuda>();

        //LISA GENERAL DE RESPUESTA
        List<cResultado> vuListaRespuesta = new List<cResultado>();

        //LISTA DE CLASES
        Dictionary<string, string> vuListaClases = new Dictionary<string, string>();

        #endregion LISTAS O VARABLES UNIVERSALES A UTILIZAR

        #region PROCESOS DEL FORMULARIO

        void Listar_Clases_Transformacion()
        {
            //vuListaClases.Add("cClientes", "cClientes");
            vuListaClases.Add("ClaBusInt_Autenticacion", "ClaBusInt_Autenticacion");
            vuListaClases.Add("ClaBusInt_ConsultaDeuda", "ClaBusInt_ConsultaDeuda");
            vuListaClases.Add("ClaBusInt_ConsultaDeuda_Full", "ClaBusInt_ConsultaDeuda_Full");
            vuListaClases.Add("ClaBusInt_ConsultaDeuda_ASMX", "ClaBusInt_ConsultaDeuda_ASMX");

            cbListaClases.DataSource = new BindingSource(vuListaClases, null);
            cbListaClases.DisplayMember = "Key";
            cbListaClases.ValueMember = "Value";
        }

        #endregion PROCESOS DEL FORMULARIO

        private void btnCopiarLista_Click(object sender, EventArgs e)
        {
            var oTabla = GetListCopyMemory();
            try
            {
                if (chbModificarAClase.Checked)
                {
                    switch (cbListaClases.SelectedValue.ToString())
                    {
                        //case "cClientes":
                        //    vuListaClientes = DataTableAList<cClientes>(oTabla);
                        //    dgvListaDatos.DataSource = vuListaClientes.ToList();
                        //    break;
                        case "ClaBusInt_Autenticacion":
                            vuListaAutenticacion_Ent = DataTableAList<ClClaBusInt_Autenticacion_Ent>(oTabla);
                            dgvListaDatos.DataSource = vuListaAutenticacion_Ent.ToList();
                            tbxListaDatos.Text = "Datos Exitosamente convertidos a Clase: AUTENTIFICACION";
                            tbxListaDatos.ForeColor = Color.Green;
                            //vuEstadoLista = "C1";
                            break;
                        case "ClaBusInt_ConsultaDeuda":
                            vuListaConsultaDeuda_Ent = DataTableAList<ClaBusInt_ConsultaDeuda_Ent>(oTabla);
                            dgvListaDatos.DataSource = vuListaConsultaDeuda_Ent.ToList();
                            tbxListaDatos.Text = "Datos Exitosamente convertidos a Clase:CONSULTA DEUDA";
                            tbxListaDatos.ForeColor = Color.Green;
                            //vuEstadoLista = "C1";
                            break;
                        case "ClaBusInt_ConsultaDeuda_Full":
                            vuListaConsultaDeuda_Full_Ent = DataTableAList<ClaBusInt_ConsultaDeuda_Full_Ent>(oTabla);
                            dgvListaDatos.DataSource = vuListaConsultaDeuda_Full_Ent.ToList();
                            tbxListaDatos.Text = "Datos Exitosamente convertidos a Clase:CONSULTA DEUDA FULL";
                            tbxListaDatos.ForeColor = Color.Green;
                            //vuEstadoLista = "C1";
                            break;
                        case "ClaBusInt_ConsultaDeuda_ASMX":
                            vuListaConsultaDeuda_ASMX_Ent = DataTableAList<ClaBusInt_ConsultaDeuda_ASMX_Ent>(oTabla);
                            dgvListaDatos.DataSource = vuListaConsultaDeuda_ASMX_Ent.ToList();
                            tbxListaDatos.Text = "Datos Exitosamente convertidos a Clase:CONSULTA DEUDA ASMX";
                            tbxListaDatos.ForeColor = Color.Green;
                            //vuEstadoLista = "C1";
                            break;
                        default:
                            dgvListaDatos.DataSource = oTabla;
                            tbxListaDatos.Text = "Datos NO convertidos a Clase, SIN ESTADO";
                            tbxListaDatos.ForeColor = Color.Green;
                            //vuEstadoLista = "C2";
                            break;
                    }
                }
                else
                {
                    dgvListaDatos.DataSource = oTabla;
                    tbxListaDatos.Text = "Datos SIN convercion a Clase, Active la modificacion a Clases";
                    tbxListaDatos.ForeColor = Color.Red;
                    //vuEstadoLista = "C2";
                }
            }
            catch (Exception ex)
            {
                dgvListaDatos.DataSource = oTabla;
                //vuEstadoLista = "C3";
                tbxListaDatos.Text = "Error al convertir Datos a List<Class> :" + ex.Message;
                tbxListaDatos.ForeColor = Color.Red;
            }
        }

        static string TransformarADetalle(Object _Objeto)
        {
            //Type TipoClase = typeof(T);
            string Resultado = "Propiedades:";
            var Propiedades = _Objeto.GetType().GetProperties();
            foreach (PropertyInfo info in Propiedades)
            {
                Resultado += " -(" + info.Name + "," + info.PropertyType.Name + ")";
            }
            return Resultado;
        }

        private void cbListaClases_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cbListaClases.SelectedValue.ToString())
            {
                //case "cClientes":
                //    tbxDetalleClaseSeleccion.Text = TransformarADetalle(new cClientes());                    
                //    break;
                case "ClaBusInt_Autenticacion":
                    tbxDetalleClaseSeleccion.Text = TransformarADetalle(new ClaBusInt_Autenticacion());
                    break;
                case "ClaBusInt_ConsultaDeuda":
                    tbxDetalleClaseSeleccion.Text = TransformarADetalle(new ClaBusInt_ConsultaDeuda());
                    break;
                case "ClaBusInt_ConsultaDeuda_Full":
                    tbxDetalleClaseSeleccion.Text = TransformarADetalle(new ClaBusInt_ConsultaDeuda());
                    break;
                case "ClaBusInt_ConsultaDeuda_ASMX":
                    tbxDetalleClaseSeleccion.Text = TransformarADetalle(new ClaBusInt_ConsultaDeuda());
                    break;
                default:
                    tbxDetalleClaseSeleccion.Text = "No se Encontro Clase";
                    break;
            }
        }

        #region METODOS DE CONSULTA
        public async Task<cResultado> Test_ConsultaDeuda_ASMX_WebServices(int _codigo_Canal, string _id_Cliente, string _id_usuario, string _id_agencia, DateTime _fecha_Hora)
        {

            SRAgenteCorresponsal.wsCajeroCorresponsalSoapClient oCliente = new SRAgenteCorresponsal.wsCajeroCorresponsalSoapClient();

            cResultado oRespuesta = new cResultado();

            oRespuesta.FechaHoraIni = DateTime.Now;

            try
            {                
                var oLista = await oCliente.ConsultarDeudaAsync(_codigo_Canal, _id_Cliente, _id_usuario, _id_agencia, _fecha_Hora);

                oRespuesta.Respuesta = JsonConvert.SerializeObject(oLista);

                oRespuesta.Duracion = int.Parse((DateTime.Now.Millisecond - oRespuesta.FechaHoraIni.Millisecond).ToString());
                oRespuesta.Estado = "Completado";
                oRespuesta.FechaHoraFin = DateTime.Now;
            }
            catch (Exception ex)
            {
                oRespuesta.Duracion = int.Parse((DateTime.Now.Millisecond - oRespuesta.FechaHoraIni.Millisecond).ToString());
                oRespuesta.Respuesta = ex.Message;
                oRespuesta.Estado = "Con Errores";
                oRespuesta.FechaHoraFin = DateTime.Now;
            }            

            return oRespuesta;
        }

        public async Task<cResultado> Test_ConsultaDeuda_Full_WebServices(string _usuarioAuth, string _usuario, string _codigoInstitucion, string _canal, string _codigoAlumno, string _codigoConcepto = "00")
        {
            ClaBusInt_Autenticacion oAutenticacion = await Test_Autenticacion_Clase_WebServices(_canal, _usuarioAuth);
            ClaBusInt_ConsultaDeuda oConsultaDeuda = new ClaBusInt_ConsultaDeuda().ByDefault();
            cResultado oRespuesta = new cResultado();

            oRespuesta.FechaHoraIni = DateTime.Now;

            if (IsEmptyNull(oAutenticacion.access_token) != "")
            {
                Dictionary<string, Object> DParametros = new Dictionary<string, object>();
                DParametros.Add("usuario", _usuario);
                DParametros.Add("codigoInstitucion", _codigoInstitucion);
                DParametros.Add("canal", _canal);
                DParametros.Add("codigoAlumno", _codigoAlumno);
                DParametros.Add("codigoConcepto", _codigoConcepto);

                String Parametros = JsonConvert.SerializeObject(DParametros);

                //WebRequest oRequest = WebRequest.Create("http://192.168.116.10/mspagos/pagoservicio/consultarDeuda");

                //oRequest.Headers.Add("Authorization", "Bearer " + oAutenticacion.access_token);
                //oRequest.Method = "POST";
                //oRequest.ContentType = "application/json;charset=UTF-8";

                HttpWebRequest request;
                request = (HttpWebRequest)WebRequest.Create("http://192.168.116.10/mspagos/pagoservicio/consultarDeuda");
                request.Headers.Add("Authorization", "Bearer " + oAutenticacion.access_token);
                request.Method = "POST";
                request.ContentType = "application/json;charset=UTF-8";
                request.Timeout = 300000;

                using (var oSW = new StreamWriter(request.GetRequestStream()))
                {
                    oSW.Write(Parametros);
                    oSW.Flush();
                    oSW.Close();
                }

                try
                {
                    //
                    var response = (HttpWebResponse)(await request.GetResponseAsync());

                    //WebResponse response = await oRequest.GetResponseAsync().Wait();
                    HttpWebResponse httpResponse = (HttpWebResponse)response;

                    using (Stream responseStream = httpResponse.GetResponseStream())
                    {
                        oConsultaDeuda = JsonConvert.DeserializeObject<ClaBusInt_ConsultaDeuda>(new StreamReader(responseStream).ReadToEnd());
                        oRespuesta.Duracion = httpResponse.LastModified.Millisecond;
                        oRespuesta.Estado = "Completado";
                        oRespuesta.Respuesta = JsonConvert.SerializeObject(oConsultaDeuda);
                    }

                    oRespuesta.FechaHoraFin = DateTime.Now;
                    return oRespuesta;
                }
                catch (WebException ex)
                {
                    if (ex.Status.ToString() != "ConnectionClosed")
                    {
                        using (Stream responseStream = ex.Response.GetResponseStream())
                        {
                            oConsultaDeuda = JsonConvert.DeserializeObject<ClaBusInt_ConsultaDeuda>(new StreamReader(responseStream).ReadToEnd());
                            oRespuesta.Duracion = responseStream.ReadTimeout;
                            oRespuesta.Estado = "Incompleto";
                            oRespuesta.Respuesta = JsonConvert.SerializeObject(oConsultaDeuda);
                        }
                    }
                    else
                    {

                        oRespuesta.Duracion = Convert.ToInt32((oRespuesta.FechaHoraIni - DateTime.Now).TotalSeconds);
                        oRespuesta.Respuesta = ex.Message;
                        oRespuesta.Estado = "Con Errores";
                        oRespuesta.FechaHoraFin = DateTime.Now;
                    }
                }
            }
            else
            {
                oConsultaDeuda.mensajeRespuesta = "ConsultaDeuda-" + oAutenticacion.mensajeRespuesta;
                oRespuesta.Duracion = int.Parse((DateTime.Now.Millisecond - oRespuesta.FechaHoraIni.Millisecond).ToString());
                oRespuesta.Respuesta = "AccessToken - " + oAutenticacion.mensajeRespuesta;
                oRespuesta.Estado = "Con Errores";
                oRespuesta.FechaHoraFin = DateTime.Now;
            }
            return oRespuesta;
        }

        public async Task<cResultado> Test_ConsultaDeuda_WebServices(string _token, string _usuario, string _codigoInstitucion, string _canal, string _codigoAlumno, string _codigoConcepto = "00")
        {
            ClaBusInt_ConsultaDeuda oConsultaDeuda = new ClaBusInt_ConsultaDeuda().ByDefault();

            cResultado oRespuesta = new cResultado();

            oRespuesta.FechaHoraIni = DateTime.Now;

            Dictionary<string, Object> DParametros = new Dictionary<string, object>();
            DParametros.Add("usuario", _usuario);
            DParametros.Add("codigoInstitucion", _codigoInstitucion);
            DParametros.Add("canal", _canal);
            DParametros.Add("codigoAlumno", _codigoAlumno);
            DParametros.Add("codigoConcepto", _codigoConcepto);

            String Parametros = JsonConvert.SerializeObject(DParametros);

            String sParams = JsonConvert.SerializeObject(Parametros);

            //HttpWebRequest request = new HttpWebRequest(new Uri(String.Format("{0}api/Account/Register", Constants.BaseAddress)));
            WebRequest request = WebRequest.Create("http://192.168.116.10/mspagos/pagoservicio/consultarDeuda");
            request.Method = "POST";
            request.ContentType = "application/json";
            request.Headers.Add("Authorization", "Bearer " + _token);

            byte[] bytes = Encoding.UTF8.GetBytes(sParams);
            using (Stream stream = await request.GetRequestStreamAsync())
            {
                stream.Write(bytes, 0, bytes.Length);
            }

            try
            {
                WebResponse response = await request.GetResponseAsync();
                HttpWebResponse httpResponse = (HttpWebResponse)response;

                using (Stream responseStream = httpResponse.GetResponseStream())
                {
                    oConsultaDeuda = JsonConvert.DeserializeObject<ClaBusInt_ConsultaDeuda>(new StreamReader(responseStream).ReadToEnd());
                    oRespuesta.Duracion = responseStream.ReadTimeout;
                    oRespuesta.Estado = "Completado";
                }
                oRespuesta.FechaHoraFin = DateTime.Now;
            }
            catch (WebException ex)
            {
                //oRespuesta.Duracion = Convert.ToInt32((oRespuesta.FechaHoraIni - DateTime.Now).TotalSeconds);
                //oRespuesta.Estado = "Con Errores:" + ex.Message;
                //oRespuesta.FechaHoraFin = DateTime.Now;                

                if (ex.Status.ToString() != "ConnectionClosed")
                {
                    using (Stream responseStream = ex.Response.GetResponseStream())
                    {
                        oConsultaDeuda = JsonConvert.DeserializeObject<ClaBusInt_ConsultaDeuda>(new StreamReader(responseStream).ReadToEnd());
                        oRespuesta.Duracion = responseStream.ReadTimeout;
                        oRespuesta.Estado = "Incompleto";
                        oRespuesta.Respuesta = JsonConvert.SerializeObject(oConsultaDeuda);
                    }
                }
                else
                {

                    oRespuesta.Duracion = Convert.ToInt32((oRespuesta.FechaHoraIni - DateTime.Now).TotalSeconds);
                    oRespuesta.Respuesta = ex.Message;
                    oRespuesta.Estado = "Con Errores";
                    oRespuesta.FechaHoraFin = DateTime.Now;
                }
            }
            return oRespuesta;
        }

        public async Task<cResultado> Test_Autenticacion_WebServices(string _Codigo_Canal, string _Id_usuario, string _Id_agencia = "01")
        {
            ClaBusInt_Autenticacion oAutenticacion = new ClaBusInt_Autenticacion().ByDefault();

            cResultado oRespuesta = new cResultado();

            oRespuesta.FechaHoraIni = DateTime.Now;

            String credenciales = Convert.ToBase64String(Encoding.UTF8.GetBytes("autentificacion" + ":" + "nolosabes"));

            String Parametros = "canal=" + _Codigo_Canal + "&usuario=" + _Id_usuario + "&codigoAgencia=" + _Id_agencia + "&grant_type=password";

            Byte[] BParametros = Encoding.UTF8.GetBytes(Parametros);

            WebRequest request = WebRequest.Create("http://192.168.116.10/msautentificacion/oauth/token");

            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization", "Basic " + credenciales);
            request.Method = "POST";
            request.ContentLength = BParametros.Length;

            byte[] bytes = Encoding.UTF8.GetBytes(Parametros);

            using (Stream dataStream = await request.GetRequestStreamAsync())
            {
                dataStream.Write(BParametros, 0, BParametros.Length);
            }

            try
            {
                WebResponse response = await request.GetResponseAsync();
                HttpWebResponse httpResponse = (HttpWebResponse)response;

                using (Stream responseStream = httpResponse.GetResponseStream())
                {
                    oAutenticacion = JsonConvert.DeserializeObject<ClaBusInt_Autenticacion>(new StreamReader(responseStream).ReadToEnd());
                    oRespuesta.Duracion = responseStream.ReadTimeout;
                    oRespuesta.Estado = "Completado";
                }
                oRespuesta.FechaHoraFin = DateTime.Now;
            }
            catch (WebException ex)
            {
                if (ex.Status.ToString() != "ConnectionClosed")
                {
                    using (Stream responseStream = ex.Response.GetResponseStream())
                    {
                        oAutenticacion = JsonConvert.DeserializeObject<ClaBusInt_Autenticacion>(new StreamReader(responseStream).ReadToEnd());
                        oRespuesta.Duracion = responseStream.ReadTimeout;
                        oRespuesta.Estado = "Incompleto";
                        oRespuesta.Respuesta = JsonConvert.SerializeObject(oAutenticacion);
                    }
                }
                else
                {

                    oRespuesta.Duracion = Convert.ToInt32((oRespuesta.FechaHoraIni - DateTime.Now).TotalSeconds);
                    oRespuesta.Respuesta = ex.Message;
                    oRespuesta.Estado = "Con Errores";
                    oRespuesta.FechaHoraFin = DateTime.Now;
                }
            }
            return oRespuesta;
        }

        public async Task<ClaBusInt_Autenticacion> Test_Autenticacion_Clase_WebServices(string _Codigo_Canal, string _Id_usuario, string _Id_agencia = "01")
        {
            ClaBusInt_Autenticacion oAutenticacion = new ClaBusInt_Autenticacion().ByDefault();

            String credenciales = Convert.ToBase64String(Encoding.UTF8.GetBytes("autentificacion" + ":" + "nolosabes"));

            String Parametros = "canal=" + _Codigo_Canal + "&usuario=" + _Id_usuario + "&codigoAgencia=" + _Id_agencia + "&grant_type=password";

            Byte[] BParametros = Encoding.UTF8.GetBytes(Parametros);

            WebRequest request = WebRequest.Create("http://192.168.116.10/msautentificacion/oauth/token");

            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization", "Basic " + credenciales);
            request.Method = "POST";
            request.ContentLength = BParametros.Length;

            byte[] bytes = Encoding.UTF8.GetBytes(Parametros);

            using (Stream dataStream = await request.GetRequestStreamAsync())
            {
                dataStream.Write(BParametros, 0, BParametros.Length);
            }

            try
            {
                WebResponse response = await request.GetResponseAsync();
                HttpWebResponse httpResponse = (HttpWebResponse)response;

                using (Stream responseStream = httpResponse.GetResponseStream())
                {
                    oAutenticacion = JsonConvert.DeserializeObject<ClaBusInt_Autenticacion>(new StreamReader(responseStream).ReadToEnd());
                }
            }
            catch (WebException ex)
            {
                using (Stream responseStream = ex.Response.GetResponseStream())
                {
                    oAutenticacion = JsonConvert.DeserializeObject<ClaBusInt_Autenticacion>(new StreamReader(responseStream).ReadToEnd());
                }
            }
            return oAutenticacion;
        }

        //public async Task<bool> Prueba4()
        //{
        //    List<ClaBusInt_ConsultaDeuda> models = new List<ClaBusInt_ConsultaDeuda>();

        //    Dictionary<string, Object> Parametros = new Dictionary<string, object>();
        //    Parametros.Add("usuario", "Juan");
        //    Parametros.Add("codigoinstitucion", "Carlos");
        //    Parametros.Add("canal", "Robert");
        //    Parametros.Add("codigoalumno", "Lomo");
        //    Parametros.Add("codigoconcepto", "4564651351654168468");

        //    String sParams = JsonConvert.SerializeObject(Parametros);

        //    //HttpWebRequest request = new HttpWebRequest(new Uri(String.Format("{0}api/Account/Register", Constants.BaseAddress)));
        //    WebRequest request = WebRequest.Create("https://jsonplaceholder.typicode.com/posts");
        //    request.Method = "POST";
        //    request.ContentType = "application/json";

        //    byte[] bytes = Encoding.UTF8.GetBytes(sParams);
        //    using (Stream stream = await request.GetRequestStreamAsync())
        //    {
        //        stream.Write(bytes, 0, bytes.Length);
        //    }

        //    try
        //    {
        //        //await request.GetResponseAsync();

        //        WebResponse response = await request.GetResponseAsync();
        //        HttpWebResponse httpResponse = (HttpWebResponse)response;
        //        string result;

        //        using (Stream responseStream = httpResponse.GetResponseStream())
        //        {
        //            result = new StreamReader(responseStream).ReadToEnd();
        //            Console.WriteLine(result);
        //        }

        //        return true;
        //    }
        //    catch (Exception)
        //    {
        //        return false;
        //    }
        //}

        //public async Task RegistroExterno(string username)
        //{
        //string uri = String.Format("{0}/api/Account/RegistroExterno", BaseUri);

        //RegisterExternalBindingModel model = new RegisterExternalBindingModel
        //{
        //    UserName = username
        //};
        //HttpWebRequest request = new HttpWebRequest(new Uri(uri));

        //request.ContentType = "application/json";
        //request.Accept = "application/json";
        //request.Headers.Add("Authorization", String.Format("Bearer {0}", AccessToken));
        //request.Method = "POST";

        //string postJson = JsonConvert.SerializeObject(model);
        //byte[] bytes = Encoding.UTF8.GetBytes(postJson);
        //using (Stream requestStream = await request.GetRequestStreamAsync())
        //{
        //    requestStream.Write(bytes, 0, bytes.Length);
        //}

        //try
        //{
        //    WebResponse response = await request.GetResponseAsync();
        //    HttpWebResponse httpResponse = (HttpWebResponse)response;
        //    string result;

        //    using (Stream responseStream = httpResponse.GetResponseStream())
        //    {
        //        result = new StreamReader(responseStream).ReadToEnd();
        //        Console.WriteLine(result);
        //    }
        //}
        //catch (SecurityException)
        //{
        //    throw;
        //}
        //catch (Exception ex)
        //{
        //    throw new InvalidOperationException("Unable to register user", ex);
        //}
        //}


        #endregion FIN METODOS CONSULTA

        private async void btnCorrerPrueba_Click(object sender, EventArgs e)
        {
            //Listar clase por defecto
            vuListaRespuesta = CrearListasRespuesta(cbListaClases.SelectedValue.ToString());
            dgvListaResultados.DataSource = vuListaRespuesta;
            //editar estados terminados
            await PruebaDeMetodos(cbListaClases.SelectedValue.ToString());
            // editar valores totales
            dgvListaResultados.DataSource = vuListaRespuesta;
            tbxListaResultados.Text = "Proceso completado";
            tbxListaResultados.ForeColor = Color.Green;
        }

        private List<cResultado> CrearListasRespuesta(string Condicion)
        {
            List<cResultado> vuListaRespuesta = new List<cResultado>();

            int NroFila = 0;

            switch (Condicion)
            {
                //case "cClientes":
                //    tbxDetalleClaseSeleccion.Text = TransformarADetalle(new cClientes());                    
                //    break;
                case "ClaBusInt_Autenticacion":
                    foreach (ClClaBusInt_Autenticacion_Ent Fila in vuListaAutenticacion_Ent)
                    {
                        vuListaRespuesta.Add(new cResultado
                        {
                            Nro = NroFila,
                            FechaHoraGen = DateTime.Now,
                            Concepto = Fila.Codigo_Canal + " - " + Fila.Id_agencia + " - " + Fila.Id_usuario + " - " + Fila.Otros
                        });
                        NroFila++;
                    }
                    break;
                case "ClaBusInt_ConsultaDeuda":
                    foreach (ClaBusInt_ConsultaDeuda_Ent Fila in vuListaConsultaDeuda_Ent)
                    {
                        vuListaRespuesta.Add(new cResultado
                        {
                            Nro = NroFila,
                            FechaHoraGen = DateTime.Now,
                            Concepto = Fila.token + " - " + Fila.canal + " - " + Fila.codigoAlumno + " - " + Fila.codigoConcepto + " - " + Fila.codigoInstitucion + " - " + Fila.usuario
                        });
                        NroFila++;
                    }
                    break;
                case "ClaBusInt_ConsultaDeuda_Full":
                    foreach (ClaBusInt_ConsultaDeuda_Full_Ent Fila in vuListaConsultaDeuda_Full_Ent)
                    {
                        vuListaRespuesta.Add(new cResultado
                        {
                            Nro = NroFila,
                            FechaHoraGen = DateTime.Now,
                            Concepto = Fila.usuarioAuth + " - " + Fila.canal + " - " + Fila.codigoAlumno + " - " + Fila.codigoConcepto + " - " + Fila.codigoInstitucion + " - " + Fila.usuario
                        });
                        NroFila++;
                    }
                    break;
                case "ClaBusInt_ConsultaDeuda_ASMX":
                    foreach (ClaBusInt_ConsultaDeuda_ASMX_Ent Fila in vuListaConsultaDeuda_ASMX_Ent)
                    {
                        vuListaRespuesta.Add(new cResultado
                        {
                            Nro = NroFila,
                            FechaHoraGen = DateTime.Now,
                            /* int NroFila, int _codigo_Canal, string _id_Cliente, string _id_usuario, string _id_agencia, DateTime _fecha_Hora */
                            Concepto = Fila.Codigo_Canal + " - " + Fila.Id_Cliente + " - " + Fila.Id_usuario + " - " + Fila.Id_agencia + " - " + Fila.Fecha_Hora
                        });
                        NroFila++;
                    }
                    break;
                default:
                    tbxDetalleClaseSeleccion.Text = "No se Encontro Clase";
                    break;
            }

            return vuListaRespuesta;
        }

        async Task CapturaMetodo_Autentifiacion(int NroFila, string Codigo_Canal, string Id_usuario, string Id_agencia, string Otros)
        {
            var oResultado = await Test_Autenticacion_WebServices(Codigo_Canal, Id_usuario, Id_agencia);

            //vuListaRespuesta.Add(oResultado);
            //List<cResultado> vuListaRespuesta = new List<cResultado>();
            var index = vuListaRespuesta.FindIndex(c => c.Nro == NroFila);
            vuListaRespuesta[NroFila].FechaHoraIni = oResultado.FechaHoraIni;
            vuListaRespuesta[NroFila].FechaHoraFin = oResultado.FechaHoraFin;
            vuListaRespuesta[NroFila].Duracion = oResultado.Duracion;
            vuListaRespuesta[NroFila].Estado = oResultado.Estado;
            vuListaRespuesta[NroFila].Respuesta = oResultado.Respuesta;

            dgvListaResultados.DataSource = vuListaRespuesta;
        }

        async Task CapturaMetodo_ConsultaDeuda(int NroFila, string _token, string _usuario, string _codigoInstitucion, string _canal, string _codigoAlumno, string _codigoConcepto = "00")
        {
            var oResultado = await Test_ConsultaDeuda_WebServices(_token, _usuario, _codigoInstitucion, _canal, _codigoAlumno);

            //vuListaRespuesta.Add(oResultado);
            //List<cResultado> vuListaRespuesta = new List<cResultado>();
            var index = vuListaRespuesta.FindIndex(c => c.Nro == NroFila);
            vuListaRespuesta[NroFila].FechaHoraIni = oResultado.FechaHoraIni;
            vuListaRespuesta[NroFila].FechaHoraFin = oResultado.FechaHoraFin;
            vuListaRespuesta[NroFila].Duracion = oResultado.Duracion;
            vuListaRespuesta[NroFila].Estado = oResultado.Estado;
            vuListaRespuesta[NroFila].Respuesta = oResultado.Respuesta;

            dgvListaResultados.DataSource = vuListaRespuesta;
        }

        async Task CapturaMetodo_ConsultaDeuda_Full(int NroFila, string _usuarioAuth, string _usuario, string _codigoInstitucion, string _canal, string _codigoAlumno, string _codigoConcepto = "00")
        {
            var oResultado = await Test_ConsultaDeuda_Full_WebServices(_usuarioAuth, _usuario, _codigoInstitucion, _canal, _codigoAlumno);

            //vuListaRespuesta.Add(oResultado);
            //List<cResultado> vuListaRespuesta = new List<cResultado>();
            var index = vuListaRespuesta.FindIndex(c => c.Nro == NroFila);
            vuListaRespuesta[NroFila].FechaHoraIni = oResultado.FechaHoraIni;
            vuListaRespuesta[NroFila].FechaHoraFin = oResultado.FechaHoraFin;
            vuListaRespuesta[NroFila].Duracion = oResultado.Duracion;
            vuListaRespuesta[NroFila].Estado = oResultado.Estado;
            vuListaRespuesta[NroFila].Respuesta = oResultado.Respuesta;

            dgvListaResultados.DataSource = vuListaRespuesta;

            //WSAgenteCorresponsalHSPC.RetornoConsultarDeuda wsElectro = new WRELSE.WebService();
        }

        async Task CapturaMetodo_ConsultaDeuda_ASMX(int NroFila, string _codigo_Canal, string _id_Cliente, string _id_usuario, string _id_agencia, string _fecha_Hora)
        {
            var oResultado = await Test_ConsultaDeuda_ASMX_WebServices(int.Parse(_codigo_Canal), _id_Cliente, _id_usuario, _id_agencia, DateTime.Parse(_fecha_Hora));

            //vuListaRespuesta.Add(oResultado);
            //List<cResultado> vuListaRespuesta = new List<cResultado>();
            var index = vuListaRespuesta.FindIndex(c => c.Nro == NroFila);
            vuListaRespuesta[NroFila].FechaHoraIni = oResultado.FechaHoraIni;
            vuListaRespuesta[NroFila].FechaHoraFin = oResultado.FechaHoraFin;
            vuListaRespuesta[NroFila].Duracion = oResultado.Duracion;
            vuListaRespuesta[NroFila].Estado = oResultado.Estado;
            vuListaRespuesta[NroFila].Respuesta = oResultado.Respuesta;

            dgvListaResultados.DataSource = vuListaRespuesta;

            //WSAgenteCorresponsalHSPC.RetornoConsultarDeuda wsElectro = new WRELSE.WebService();
        }

        async Task PruebaDeMetodos(string Condicion)
        {
            int NroFila = 0;

            switch (Condicion)
            {
                //case "cClientes":
                //    tbxDetalleClaseSeleccion.Text = TransformarADetalle(new cClientes());                    
                //    break;
                case "ClaBusInt_Autenticacion":
                    foreach (ClClaBusInt_Autenticacion_Ent Fila in vuListaAutenticacion_Ent)
                    {
                        await CapturaMetodo_Autentifiacion(NroFila, Fila.Codigo_Canal, Fila.Id_usuario, Fila.Id_agencia, Fila.Otros);
                        NroFila++;
                    }
                    break;
                case "ClaBusInt_ConsultaDeuda":
                    foreach (ClaBusInt_ConsultaDeuda_Ent Fila in vuListaConsultaDeuda_Ent)
                    {
                        /*int NroFila, string _token, string _usuario, string _codigoInstitucion, string _canal, string _codigoAlumno, string _codigoConcepto = "00"*/
                        await CapturaMetodo_ConsultaDeuda(NroFila, Fila.token, Fila.usuario, Fila.codigoInstitucion, Fila.canal, Fila.codigoAlumno);
                        NroFila++;
                    }
                    break;
                case "ClaBusInt_ConsultaDeuda_Full":
                    foreach (ClaBusInt_ConsultaDeuda_Full_Ent Fila in vuListaConsultaDeuda_Full_Ent)
                    {
                        /*int NroFila, string _token, string _usuario, string _codigoInstitucion, string _canal, string _codigoAlumno, string _codigoConcepto = "00"*/
                        await CapturaMetodo_ConsultaDeuda_Full(NroFila, Fila.usuarioAuth, Fila.usuario, Fila.codigoInstitucion, Fila.canal, Fila.codigoAlumno);
                        NroFila++;
                    }
                    break;
                case "ClaBusInt_ConsultaDeuda_ASMX":
                    foreach (ClaBusInt_ConsultaDeuda_ASMX_Ent Fila in vuListaConsultaDeuda_ASMX_Ent)
                    {
                        /* int NroFila, int _codigo_Canal, string _id_Cliente, string _id_usuario, string _canal, string _id_agencia, DateTime _fecha_Hora */
                        await CapturaMetodo_ConsultaDeuda_ASMX(NroFila, Fila.Codigo_Canal, Fila.Id_Cliente, Fila.Id_usuario, Fila.Id_agencia, Fila.Fecha_Hora);
                        NroFila++;
                    }
                    break;
                default:
                    tbxDetalleClaseSeleccion.Text = "No se Encontro Clase";
                    break;
            }
        }
    }
}
