﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class cConexionsSQL
    {
        private static readonly Dictionary<string, DbCommand> ColComandos =
            new Dictionary<string, DbCommand>();

        private readonly string Cadena;

        public cConexionsSQL()
        {
            Cadena = DatabaseFactory.CreateDatabase("CadenaConexion").CreateConnection().ConnectionString;
        }

        private void CargarParametros(DbCommand comando, params object[] args)
        {
            if (args != null && args.Length > 0)
            {
                for (int i = 0; i < args.Length; i++)
                {
                    var parametro = new SqlParameter($"@parametro{i}", args[i]);
                    comando.Parameters.Add(parametro);
                }
            }
        }

        public async Task<DataTable> TraerDataTableAsync(string consulta, params object[] args)
        {
            using (var connection = new SqlConnection(Cadena))
            {
                await connection.OpenAsync().ConfigureAwait(false);

                using (var comando = new SqlCommand(consulta, connection))
                {
                    CargarParametros(comando, args);

                    using (var reader = await comando.ExecuteReaderAsync(CommandBehavior.SequentialAccess).ConfigureAwait(false))
                    {
                        var dataTable = new DataTable();
                        dataTable.Load(reader);
                        return dataTable;
                    }
                }
            }
        }

        public async Task<IEnumerable<T>> TraerEnumerableAsync<T>(string consulta, params object[] args)
        {
            using (var connection = new SqlConnection(Cadena))
            {
                await connection.OpenAsync().ConfigureAwait(false);

                using (var comando = new SqlCommand(consulta, connection))
                {
                    CargarParametros(comando, args);

                    using (var reader = await comando.ExecuteReaderAsync(CommandBehavior.SequentialAccess).ConfigureAwait(false))
                    {
                        var lista = new List<T>();

                        while (await reader.ReadAsync().ConfigureAwait(false))
                        {
                            var elemento = Activator.CreateInstance<T>();

                            foreach (var propiedad in typeof(T).GetProperties())
                            {
                                var valor = reader[propiedad.Name];

                                if (valor != DBNull.Value)
                                {
                                    propiedad.SetValue(elemento, valor);
                                }
                            }

                            lista.Add(elemento);
                        }

                        return lista;
                    }
                }
            }
        }

        public async Task EjecutarConsultaAsync(string consulta, params object[] args)
        {
            using (var connection = new SqlConnection(Cadena))
            {
                await connection.OpenAsync().ConfigureAwait(false);

                using (var comando = new SqlCommand(consulta, connection))
                {
                    CargarParametros(comando, args);
                    await comando.ExecuteNonQueryAsync().ConfigureAwait(false);
                }
            }
        }
    }
}