﻿namespace CapaNegocio
{
    public class cDataArchivoPagosRealizados
    {
        public string nTipoRegistro { get; set; }
        public string nCódigoRubro { get; set; }
        public string nCódigoEmpresa { get; set; }
        public string nCódigoServicio { get; set; }
        public string nMoneda { get; set; }
        public string cCódigoDeudor { get; set; }
        public string cCódigoCuota { get; set; }
        public string cNúmeroDocumento { get; set; }
        public string cNombreDeudor { get; set; }
        public string nFechaPago { get; set; }
        public string nHoraPago { get; set; }
        public string nImportePagado { get; set; }
        public string nImporteMora { get; set; }
        public string nImporteDescuento { get; set; }
        public string nFechaEmisión { get; set; }
        public string nFechaVecimiento { get; set; }
        public string nNúmeroOperación { get; set; }
        public string cNúmerocheque { get; set; }
        public string cIndicadorcheque { get; set; }
        public string cBlancos { get; set; }

        /*
         
        */

        public cDataArchivoPagosRealizados()
        {
        }
    }
}