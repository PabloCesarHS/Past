﻿using System;

namespace CapaNegocio
{
    public class cDataArchivoCabecera
    {
        public int nTipoRegistro { get; set; } //11
        public int nCódigoGrupo { get; set; } //21
        public int nCódigoRubro { get; set; } //03
        public int nCódigoEmpresa { get; set; } //001
        public int nCódigoServicio { get; set; } //01
        public int nCódigoSolicitud { get; set; } //01
        public string cDescripciónSolicitud { get; set; } //CUOTA MARZO
        public int nOrigenSolicitud { get; set; } //1
        public int nCódigoRequerimiento { get; set; } //002
        public int nCanalEnvío { get; set; } //1
        public string cTipoInformación { get; set; } //M
        public int nNúmeroRegistros { get; set; } //000000000000070
        public string nCódigoUnico { get; set; } //0123456789
        public DateTime nFechaProceso { get; set; } //20010302
        public DateTime nFechaInicioCargos { get; set; } //00000000
        public string nMoneda { get; set; } //01
        public decimal nImporteTotal1 { get; set; } //000000002345000
        public decimal nImporteTotal2 { get; set; } //000000000000000
        public string cTipoGlosa { get; set; } //P
        public string cGlosaGeneral { get; set; } // 
        public string cLibre { get; set; } // 
        public int nTipoFormato { get; set; } //01
        public int nCódigoFijo { get; set; } //0000

        /*
         nTipoRegistro	nCódigoGrupo	nCódigoRubro	nCódigoEmpresa	nCódigoServicio	nCódigoSolicitud	cDescripciónSolicitud	nOrigenSolicitud	nCódigoRequerimiento	nCanalEnvío	cTipoInformación	nNúmeroRegistros	nCódigoUnico	nFechaProceso	nFechaInicioCargos	nMoneda	nImporteTotal1	nImporteTotal2	cTipoGlosa	cGlosaGeneral	cLibre	nTipoFormato	nCódigoFijo
            11	        21	            3	            1	            1	            1	                CUOTA MARZO	            1	                2	                    1	        M	                70	                123456789	    20010302	    0	                1	    2345000.00	    0.00	        P	        0		        ''      1	            0
        */

        public cDataArchivoCabecera()
        {
        }

        public cDataArchivoCabecera(int nTipoRegistro, int nCódigoGrupo, int nCódigoRubro, int nCódigoEmpresa, int nCódigoServicio, int nCódigoSolicitud, string cDescripciónSolicitud, int nOrigenSolicitud, int nCódigoRequerimiento, int nCanalEnvío, string cTipoInformación, int nNúmeroRegistros, string nCódigoUnico, DateTime nFechaProceso, DateTime nFechaInicioCargos, string nMoneda, decimal nImporteTotal1, decimal nImporteTotal2, string cTipoGlosa, string cGlosaGeneral, string cLibre, int nTipoFormato, int nCódigoFijo)
        {
            this.nTipoRegistro = nTipoRegistro;
            this.nCódigoGrupo = nCódigoGrupo;
            this.nCódigoRubro = nCódigoRubro;
            this.nCódigoEmpresa = nCódigoEmpresa;
            this.nCódigoServicio = nCódigoServicio;
            this.nCódigoSolicitud = nCódigoSolicitud;
            this.cDescripciónSolicitud = cDescripciónSolicitud;
            this.nOrigenSolicitud = nOrigenSolicitud;
            this.nCódigoRequerimiento = nCódigoRequerimiento;
            this.nCanalEnvío = nCanalEnvío;
            this.cTipoInformación = cTipoInformación;
            this.nNúmeroRegistros = nNúmeroRegistros;
            this.nCódigoUnico = nCódigoUnico;
            this.nFechaProceso = nFechaProceso;
            this.nFechaInicioCargos = nFechaInicioCargos;
            this.nMoneda = nMoneda;
            this.nImporteTotal1 = nImporteTotal1;
            this.nImporteTotal2 = nImporteTotal2;
            this.cTipoGlosa = cTipoGlosa;
            this.cGlosaGeneral = cGlosaGeneral;
            this.cLibre = cLibre;
            this.nTipoFormato = nTipoFormato;
            this.nCódigoFijo = nCódigoFijo;
        }

        public cDataArchivoCabecera ClaseXDefecto()
        {
            return new cDataArchivoCabecera(
            this.nTipoRegistro = 11,
            this.nCódigoGrupo = 21,
            this.nCódigoRubro = 03,
            this.nCódigoEmpresa = 001,
            this.nCódigoServicio = 01,
            this.nCódigoSolicitud = 01,
            this.cDescripciónSolicitud = "CUOTA MARZO",
            this.nOrigenSolicitud = 1,
            this.nCódigoRequerimiento = 002,
            this.nCanalEnvío = 1,
            this.cTipoInformación = "M",
            this.nNúmeroRegistros = 000000000000070,
            this.nCódigoUnico = "0123456789",
            this.nFechaProceso = DateTime.Now,
            this.nFechaInicioCargos = DateTime.Now,
            this.nMoneda = "01",
            this.nImporteTotal1 = 000000002345000,
            this.nImporteTotal2 = 000000000000000,
            this.cTipoGlosa = "P",
            this.cGlosaGeneral = "",
            this.cLibre = "",
            this.nTipoFormato = 01,
            this.nCódigoFijo = 0000);
        }
    }

    public class cDataArchivoCuota
    {
        public int nTipoRegistro { get; set; } //12
        public string cCódigoCuota { get; set; } //00000000
        public int nNúmeroConceptos { get; set; } //1
        public string cDescripciónConcepto1 { get; set; } //CUOTA MES
        public string cDescripciónConcepto2 { get; set; } //
        public string cDescripciónConcepto3 { get; set; } //
        public string cDescripciónConcepto4 { get; set; } //
        public string cDescripciónConcepto5 { get; set; } //
        public string cDescripciónConcepto6 { get; set; } //
        public string cDescripciónConcepto7 { get; set; } //
        public string cLibre { get; set; } //
        public int nTipoFormato { get; set; } //02
        public int nCódigoFijo { get; set; } //0000

        /*
        nTipoRegistro	cCódigoCuota	nNúmeroConceptos	cDescripciónConcepto1	cDescripciónConcepto2	cDescripciónConcepto3	cDescripciónConcepto4	cDescripciónConcepto5	cDescripciónConcepto6	cDescripciónConcepto7	cLibre	nTipoFormato	nCódigoFijo
        12	00000000	1	CUOTA MES								2	0
        */

        public cDataArchivoCuota()
        {
        }

        public cDataArchivoCuota(int nTipoRegistro, string cCódigoCuota, int nNúmeroConceptos, string cDescripciónConcepto1, string cDescripciónConcepto2, string cDescripciónConcepto3, string cDescripciónConcepto4, string cDescripciónConcepto5, string cDescripciónConcepto6, string cDescripciónConcepto7, string cLibre, int nTipoFormato, int nCódigoFijo)
        {
            this.nTipoRegistro = nTipoRegistro;
            this.cCódigoCuota = cCódigoCuota;
            this.nNúmeroConceptos = nNúmeroConceptos;
            this.cDescripciónConcepto1 = cDescripciónConcepto1;
            this.cDescripciónConcepto2 = cDescripciónConcepto2;
            this.cDescripciónConcepto3 = cDescripciónConcepto3;
            this.cDescripciónConcepto4 = cDescripciónConcepto4;
            this.cDescripciónConcepto5 = cDescripciónConcepto5;
            this.cDescripciónConcepto6 = cDescripciónConcepto6;
            this.cDescripciónConcepto7 = cDescripciónConcepto7;
            this.cLibre = cLibre;
            this.nTipoFormato = nTipoFormato;
            this.nCódigoFijo = nCódigoFijo;
        }

        public cDataArchivoCuota ClaseXDefecto()
        {
            return new cDataArchivoCuota(
            this.nTipoRegistro = 12,
            this.cCódigoCuota = "00000000",
            this.nNúmeroConceptos = 1,
            this.cDescripciónConcepto1 = "CUOTA MES",
            this.cDescripciónConcepto2 = "",
            this.cDescripciónConcepto3 = "",
            this.cDescripciónConcepto4 = "",
            this.cDescripciónConcepto5 = "",
            this.cDescripciónConcepto6 = "",
            this.cDescripciónConcepto7 = "",
            this.cLibre = "",
            this.nTipoFormato = 2,
            this.nCódigoFijo = 0);
        }
    }

    public class cDataArchivoDetalle
    {
        public int nTipoRegistro { get; set; } //13
        public string cCódigoDeudor { get; set; } //00000001
        public string cNombredelDeudor { get; set; } //SANCHEZ FARRO MARIA
        public string cReferencia1 { get; set; } //
        public string cReferencia2 { get; set; } //
        public string cTipoOperación { get; set; } //A
        public string cCódigoCuota { get; set; } //00000000
        public DateTime nFechaEmisión { get; set; } //20010220
        public DateTime nFechaVencimiento { get; set; } //20010305
        public string cNúmeroDocumento { get; set; } //67899999
        public string nMonedaDeuda { get; set; } //01
        public decimal nImporteConcepto1 { get; set; } //000125000
        public decimal nImporteConcepto2 { get; set; } //000000000
        public decimal nImporteConcepto3 { get; set; } //000000000
        public decimal nImporteConcepto4 { get; set; } //000000000
        public decimal nImporteConcepto5 { get; set; } //000000000
        public decimal nImporteConcepto6 { get; set; } //000000000
        public decimal nImporteConcepto7 { get; set; } //000000000
        public string cTipoCuentaPrincipal { get; set; } //D
        public string cProductoCuentaprincipal { get; set; } //002
        public string cMonedaCuentaPrincipal { get; set; } //01
        public string cNumeroCuentaPrincipal { get; set; } //10030000000144
        public decimal nImporteAbonarCuenta1 { get; set; } //000000000150000
        public string cTipoCuentaSecundaria { get; set; } //D
        public string cProductoCuentaSecundaria { get; set; } //001
        public string cMonedaCuentaSecundaria { get; set; } //10
        public string cNumeroCuentaSecundaria { get; set; } //1003000054444
        public decimal nImporteAbonarCuenta2 { get; set; } //000000000000000
        public string cGlosaParticular { get; set; } //TRAS.DINERO S/.
        public string cLibre { get; set; } //
        public int nTipoFormato { get; set; } //03
        public int nCódigoFijo { get; set; } //0000

        /*
        nTipoRegistro	cCódigoDeudor	cNombredelDeudor	cReferencia1	cReferencia2	cTipoOperación	cCódigoCuota	nFechaEmisión	nFechaVencimiento	cNúmeroDocumento	nMonedaDeuda	nImporteConcepto1	nImporteConcepto2	nImporteConcepto3	nImporteConcepto4	nImporteConcepto5	nImporteConcepto6	nImporteConcepto7	cTipoCuentaPrincipal	cProductoCuentaprincipal	cMonedaCuentaPrincipal	cNumeroCuentaPrincipal	nImporteAbonarCuenta1	cTipoCuentaSecundaria	cProductoCuentaSecundaria	cMonedaCuentaSecundaria	cNumeroCuentaSecundaria	nImporteAbonarCuenta2	cGlosaParticular	cLibre	nTipoFormato	nCódigoFijo
        13	00000001	SANCHEZ FARRO MARIA			A	00000000	20010220	20010305	67899999	1	125000	0	0	0	0	0	0	D	002	01	10030000000144	150000	D	001	10	1003000054444	0	TRAS.DINERO S/.		3	0
        */

        public cDataArchivoDetalle()
        {
        }

        public cDataArchivoDetalle(int nTipoRegistro, string cCódigoDeudor, string cNombredelDeudor, string cReferencia1, string cReferencia2, string cTipoOperación, string cCódigoCuota, DateTime nFechaEmisión, DateTime nFechaVencimiento, string cNúmeroDocumento, string nMonedaDeuda, decimal nImporteConcepto1, decimal nImporteConcepto2, decimal nImporteConcepto3, decimal nImporteConcepto4, decimal nImporteConcepto5, decimal nImporteConcepto6, decimal nImporteConcepto7, string cTipoCuentaPrincipal, string cProductoCuentaprincipal, string cMonedaCuentaPrincipal, string cNumeroCuentaPrincipal, decimal nImporteAbonarCuenta1, string cTipoCuentaSecundaria, string cProductoCuentaSecundaria, string cMonedaCuentaSecundaria, string cNumeroCuentaSecundaria, decimal nImporteAbonarCuenta2, string cGlosaParticular, string cLibre, int nTipoFormato, int nCódigoFijo)
        {
            this.nTipoRegistro = nTipoRegistro;
            this.cCódigoDeudor = cCódigoDeudor;
            this.cNombredelDeudor = cNombredelDeudor;
            this.cReferencia1 = cReferencia1;
            this.cReferencia2 = cReferencia2;
            this.cTipoOperación = cTipoOperación;
            this.cCódigoCuota = cCódigoCuota;
            this.nFechaEmisión = nFechaEmisión;
            this.nFechaVencimiento = nFechaVencimiento;
            this.cNúmeroDocumento = cNúmeroDocumento;
            this.nMonedaDeuda = nMonedaDeuda;
            this.nImporteConcepto1 = nImporteConcepto1;
            this.nImporteConcepto2 = nImporteConcepto2;
            this.nImporteConcepto3 = nImporteConcepto3;
            this.nImporteConcepto4 = nImporteConcepto4;
            this.nImporteConcepto5 = nImporteConcepto5;
            this.nImporteConcepto6 = nImporteConcepto6;
            this.nImporteConcepto7 = nImporteConcepto7;
            this.cTipoCuentaPrincipal = cTipoCuentaPrincipal;
            this.cProductoCuentaprincipal = cProductoCuentaprincipal;
            this.cMonedaCuentaPrincipal = cMonedaCuentaPrincipal;
            this.cNumeroCuentaPrincipal = cNumeroCuentaPrincipal;
            this.nImporteAbonarCuenta1 = nImporteAbonarCuenta1;
            this.cTipoCuentaSecundaria = cTipoCuentaSecundaria;
            this.cProductoCuentaSecundaria = cProductoCuentaSecundaria;
            this.cMonedaCuentaSecundaria = cMonedaCuentaSecundaria;
            this.cNumeroCuentaSecundaria = cNumeroCuentaSecundaria;
            this.nImporteAbonarCuenta2 = nImporteAbonarCuenta2;
            this.cGlosaParticular = cGlosaParticular;
            this.cLibre = cLibre;
            this.nTipoFormato = nTipoFormato;
            this.nCódigoFijo = nCódigoFijo;
        }

        public cDataArchivoDetalle ClaseXDefecto()
        {
            return new cDataArchivoDetalle(
            this.nTipoRegistro = 13,
            this.cCódigoDeudor = "00000001",
            this.cNombredelDeudor = "SANCHEZ FARRO MARIA",
            this.cReferencia1 = "",
            this.cReferencia2 = "",
            this.cTipoOperación = "A",
            this.cCódigoCuota = "00000000",
            this.nFechaEmisión = DateTime.Now,
            this.nFechaVencimiento = DateTime.Now,
            this.cNúmeroDocumento = "67899999",
            this.nMonedaDeuda = "01",
            this.nImporteConcepto1 = 000125000,
            this.nImporteConcepto2 = 000000000,
            this.nImporteConcepto3 = 000000000,
            this.nImporteConcepto4 = 000000000,
            this.nImporteConcepto5 = 000000000,
            this.nImporteConcepto6 = 000000000,
            this.nImporteConcepto7 = 000000000,
            this.cTipoCuentaPrincipal = "D",
            this.cProductoCuentaprincipal = "002",
            this.cMonedaCuentaPrincipal = "01",
            this.cNumeroCuentaPrincipal = "10030000000144",
            this.nImporteAbonarCuenta1 = 000000000150000,
            this.cTipoCuentaSecundaria = "D",
            this.cProductoCuentaSecundaria = "001",
            this.cMonedaCuentaSecundaria = "10",
            this.cNumeroCuentaSecundaria = "1003000054444",
            this.nImporteAbonarCuenta2 = 000000000000000,
            this.cGlosaParticular = "TRAS.DINERO S /.",
            this.cLibre = "",
            this.nTipoFormato = 03,
            this.nCódigoFijo = 0000);
        }
    }
}