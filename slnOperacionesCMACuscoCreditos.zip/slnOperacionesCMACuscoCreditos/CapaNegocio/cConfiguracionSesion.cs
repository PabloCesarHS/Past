﻿using CapaDatos;
using System;
using System.Data;

namespace CapaNegocio
{
    public class cConfiguracionSesion
    {
        //cDatos oDatos = new cConexionsSQL();

        //public DataTable ObtenerPermisos(ref int nError)
        //{
        //    DataTable dt;
        //    try
        //    {
        //        dt = oDatos.TraerDataTable("spu_Bim_Permisos");
        //        if (dt.Rows.Count == 0)
        //            nError = -1;
        //        else
        //            nError = 0;
        //    }
        //    catch (Exception)
        //    {
        //        dt = null;
        //        nError = -1;
        //    }
        //    return dt;
        //}

        //public DataTable ObtenerPermisosUsuario(ref int nError, String cUser)
        //{
        //    DataTable dt;
        //    try
        //    {
        //        dt = oDatos.TraerDataTable("spu_Bim_PermisosUsuario", cUser);
        //        if (dt.Rows.Count == 0)
        //            nError = -1;
        //        else
        //            nError = 0;
        //    }
        //    /* INICIO 04072023 HSPC - Se comenta para mostrar error en control de inicio de sesion */
        //    //catch (Exception)
        //    //{
        //    //    dt = null;
        //    //    nError = -1;
        //    //}
        //    //return dt;
        //    /* FIN 04072023 HSPC - Se comenta para mostrar error en control de inicio de sesion */
        //    catch (Exception ex)
        //    {
        //        string f = ex.Message;
        //        dt = null;
        //        nError = -1;
        //    }
        //    return dt;
        //}
    }
}