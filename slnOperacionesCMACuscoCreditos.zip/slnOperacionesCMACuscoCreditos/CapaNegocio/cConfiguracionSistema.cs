﻿using CapaDatos;
using System;
using System.Configuration;

namespace CapaNegocio
{
    public class cConfiguracionSistema
    {
        //cDatos oDatos = new cConexionsSQL();

        public class cConfiguracionSistemas
        {
            public string nIdConfiguracion { get; set; }
            public string CProyecto { get; set; }
            public string cTipo { get; set; }
            public string cTag { get; set; }
            public string cRuta { get; set; }
            public string cBaseDatos { get; set; }
            public string cDireccionIP { get; set; }
            public string cParametros { get; set; }
            public string bEstado { get; set; }

            /*             
                1	C:\SFTP\PDP\PDPReportes\	0
             */
            public cConfiguracionSistemas()
            {
            }
        }

        //public cResultado Listar_ConfiguracionSistema()
        //{
        //    try
        //    {
        //        return new cResultado(
        //            0,
        //            "Lista obtenida",
        //            oDatos.TraerDataTable("Listar_ConfiguracionSistema", "SISTEMA","RUTA"));
        //    }
        //    catch (Exception ex)
        //    {
        //        return new cResultado(3, ex.Message, null);
        //    }
        //}

        //public cResultado Obtener_ConfiguracionSistema(string _Proyecto, string _Tipo, string _Tag)
        //{
        //    try
        //    {
        //        return new cResultado(
        //            0,
        //            "Lista obtenida",
        //            oDatos.TraerDataTable("Obtener_ConfiguracionSistema", "SISTEMA", _Tipo, _Tag));
        //    }
        //    catch (Exception ex)
        //    {
        //        return new cResultado(3, ex.Message, null);
        //    }
        //}

        //public cResultado Insertar_ConfiguracionSistema(string _Proyecto, string _Tipo, string _Tag, string _Ruta, string _BaseDatos, string _DireccionIP, string _Parametros, bool _Estado)
        //{
        //    try
        //    {
        //        return new cResultado(
        //            cConverciones.ConvertirAEntero(oDatos.TraerValor("Registrar_ConfiguracionSistema", _Proyecto, _Tipo, _Tag, _Ruta, _BaseDatos, _DireccionIP, _Parametros, _Estado), 2),
        //            "Registro Insertado",
        //            null);
        //    }
        //    catch (Exception ex)
        //    {
        //        return new cResultado(3, ex.Message, null);
        //    }
        //}

        //public cResultado Editar_ConfiguracionSistema(int _IdConfiguracion, string _Proyecto, string _Tipo, string _Tag, string _Ruta, string _BaseDatos, string _DireccionIP, string _Parametros, bool _Estado)
        //{
        //    try
        //    {
        //        return new cResultado(
        //            cConverciones.ConvertirAEntero(oDatos.TraerValor("spu_Bim_EditarRutas", _IdConfiguracion, _Proyecto, _Tipo, _Tag, _Ruta, _BaseDatos, _DireccionIP, _Parametros, _Estado), 2),
        //            "Registro modificado",
        //            null);
        //    }
        //    catch (Exception ex)
        //    {
        //        return new cResultado(3, ex.Message, null);
        //    }
        //}

        //public cResultado Eliminar_Ruta(int _IdConfiguracion)
        //{
        //    try
        //    {
        //        return new cResultado(
        //            cConverciones.ConvertirAEntero(oDatos.TraerValor("Eliminar_ConfiguracionSistema", _IdConfiguracion), 2),
        //            "Registro eliminado",
        //            null);
        //    }
        //    catch (Exception ex)
        //    {
        //        return new cResultado(3, ex.Message, null);
        //    }
        //}

        //public class cUsuarios
        //{
        //    public string nid { get; set; }
        //    public string cUsuario { get; set; }
        //    public string nIdMenu { get; set; }

        //    public cUsuarios()
        //    {
        //    }
        //}

        //public cResultado Listar_Usuarios()
        //{
        //    try
        //    {
        //        return new cResultado(
        //            0,
        //            "Lista obtenida",
        //            oDatos.TraerDataTable("spu_Bim_ObtenerUsuarios"));
        //    }
        //    catch (Exception ex)
        //    {
        //        return new cResultado(3, ex.Message, null);
        //    }
        //}

        //public class cGrupos
        //{
        //    public string nidGrupo { get; set; }
        //    public string cGrupoUsuario { get; set; }
        //    public string nIdMenu { get; set; }

        //    public cGrupos()
        //    {
        //    }
        //}

        //public cResultado Listar_Grupos()
        //{
        //    try
        //    {
        //        return new cResultado(
        //            0,
        //            "Lista obtenida",
        //            oDatos.TraerDataTable("spu_Bim_ObtenerGrupoAcceso"));
        //    }
        //    catch (Exception ex)
        //    {
        //        return new cResultado(3, ex.Message, null);
        //    }
        //}
    }

    public static class cSistema
    {
        public static string Modo
        {
            get
            {
                try
                {
                    return ConfigurationManager.AppSettings["AppConfModo"].ToString();
                }
                catch
                {
                    return "Error en archivo de configuracion";
                }
            }
        }
        public static string Version
        {
            get
            {
                try
                {
                    return ConfigurationManager.AppSettings["AppConfVersion"].ToString();
                }
                catch
                {
                    return "Error en archivo de configuracion";
                }
            }
        }

        public static string CadenaConexion
        {
            get
            {
                try
                {
                    return ConfigurationManager.ConnectionStrings["CadenaConexion"].ConnectionString.ToString();
                }
                catch
                {
                    return "Error en archivo de configuracion";
                }
            }
        }

        public static string ServidorBD
        {
            get
            {
                try
                {
                    string vCadenaConexion = ConfigurationManager.ConnectionStrings["CadenaConexion"].ConnectionString.ToString();
                    string[] vPartes = vCadenaConexion.Split(';');
                    return vPartes[0];
                }
                catch
                {
                    return "Error en archivo de configuracion";
                }
            }
        }
    }
}