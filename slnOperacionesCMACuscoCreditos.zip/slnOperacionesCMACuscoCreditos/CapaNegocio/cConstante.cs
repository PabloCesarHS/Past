﻿using CapaDatos;
using System.Collections.Generic;
using System.Data;
namespace CapaNegocio
{
    public class cConstante
    {
        public cConstante()
        {

        }
    }

    public class cRutas
    {
        string RutaSistema { get; set; }
        string RutaCargaArchivos { get; set; }
        string RutaGuardadoArchivos { get; set; }
        string RutaRegistros { get; set; }

        public void ObtenerRutas()
        {
            cConexionsSQL oDatos = new cConexionsSQL();
            cResultado cResultado = new cResultado();
            //cConfiguracion vgConfiguracion = new cConfiguracion();
            //vgListaRutasConfiguracion = new List<cConfiguracionSistema>();

            //cResultado = vgConfiguracion.Listar_ConfiguracionSistema();

            if (cResultado.Estado == 0)
            {
                //vgListaRutasConfiguracion = cTransformador.ConvertirDataTableAClase<cConfiguracionSistema>(cResultado.Datos);

                ///* Inicializacion de variables */
                //string vReportes = "Ruta Inicializada";
                //string vIncoming = "Ruta Inicializada";
                //string vOutgoing = "Ruta Inicializada";
                //string vAgentes = "Ruta Inicializada";
                //string vCertificado = "Ruta Inicializada";

                //vReportes = vgListaRutasConfiguracion.Where(item => item.cTag == "NUEVO").First().cRuta.ToString();
                //vIncoming = vgListaRutasConfiguracion.Where(item => item.cTag == "NUEVO").First().cRuta.ToString();
                //vOutgoing = vgListaRutasConfiguracion.Where(item => item.cTag == "NUEVO").First().cRuta.ToString();
                //vAgentes = vgListaRutasConfiguracion.Where(item => item.cTag == "NUEVO").First().cRuta.ToString();
                //vCertificado = vgListaRutasConfiguracion.Where(item => item.cTag == "NUEVO").First().cRuta.ToString();

            }
            else
            {
                //ClaseXDefecto();
            }
        }
        public cRutas()
        {}

        public cRutas(string rutaCargaArchivos, string rutaGuardadoArchivos, string rutaRegistros)
        {
            RutaCargaArchivos = rutaCargaArchivos;
            RutaGuardadoArchivos = rutaGuardadoArchivos;
            RutaRegistros = rutaRegistros;
        }
        public cRutas RutaXDefecto()
        {
            return new cRutas(
            RutaCargaArchivos = @"D:\21 Tramas-Archivos\Pagos de credito\Entrada",
            RutaGuardadoArchivos = @"D:\21 Tramas-Archivos\Pagos de credito\Salida",
            RutaRegistros = @"D:\21 Tramas-Archivos\Pagos de credito\Log"
            );
        }
    }

    public class cResultado<T>
    {
        private int estado;
        private string mensaje;
        private IEnumerable<T> lista;

        public int Estado { get => estado; set => estado = value; }
        public string Mensaje { get => mensaje; set => mensaje = value; }
        public IEnumerable<T> Lista { get => lista; set => lista = value; }

        public cResultado()
        {
        }

        public cResultado(int estado, string mensaje)
        {
            Estado = estado;
            Mensaje = mensaje;
        }

        public cResultado(int estado, string mensaje, IEnumerable<T> lista)
        {
            Estado = estado;
            Mensaje = mensaje;            
            Lista = lista;
        }
    }

    public class cResultado
    {
        private int estado;
        private string mensaje;
        private DataTable datos;

        public int Estado { get => estado; set => estado = value; }
        public string Mensaje { get => mensaje; set => mensaje = value; }
        public DataTable Datos { get => datos; set => datos = value; }

        public cResultado()
        {
        }

        public cResultado(int estado, string mensaje)
        {
            Estado = estado;
            Mensaje = mensaje;
        }

        public cResultado(int estado, string mensaje, DataTable datos)
        {
            Estado = estado;
            Mensaje = mensaje;
            Datos = datos;
        }
    }

    public class cCombo
    {
        private string codigo;
        private string valor;

        public string Codigo { get => codigo; set => codigo = value; }
        public string Valor { get => valor; set => valor = value; }

        public cCombo()
        {
        }

        public cCombo(string codigo, string valor)
        {
            Codigo = codigo;
            Valor = valor;
        }
    }
}