﻿using System;

namespace CapaNegocio
{    
    public class cCargaArchivos
    {
        public cCargaArchivos()
        {
        }

        public cCargaArchivos(bool existe, string usuario, string archivoNuevo, int nroCargas, string archivoNuevoExtencion, DateTime fechaCarga, string archivoruta)
        {
            Existe = existe;
            Usuario = usuario;
            ArchivoNuevo = archivoNuevo;
            NroCargas = nroCargas;
            ArchivoNuevoExtencion = archivoNuevoExtencion;
            FechaCarga = fechaCarga;
            ArchivoRuta = archivoruta;
        }

        public bool Existe { get; set; }
        public string Usuario { get; set; }
        public string ArchivoNuevo { get; set; }
        public int NroCargas { get; set; }
        public string ArchivoNuevoExtencion { get; set; }
        public DateTime FechaCarga { get; set; }
        public string ArchivoRuta { get; set; }
    }

    public class cCargaArchivosInfo
    {
        public cCargaArchivosInfo()
        {
        }

        public cCargaArchivosInfo(bool estadoCarga, string mensajeCarga, string usuario, string nombreArchivo, DateTime fechainicio, DateTime fechaFin, string nroRegistros)
        {
            EstadoCarga = estadoCarga;
            MensajeCarga = mensajeCarga;
            Usuario = usuario;
            NombreArchivo = nombreArchivo;
            Fechainicio = fechainicio;
            FechaFin = fechaFin;
            NroRegistros = nroRegistros;
        }

        public bool EstadoCarga { get; set; }
        public string MensajeCarga { get; set; }
        public string Usuario { get; set; }
        public string NombreArchivo { get; set; }
        public DateTime Fechainicio { get; set; }
        public DateTime FechaFin { get; set; }
        public string NroRegistros { get; set; }
    }
}