﻿using System;

namespace CapaNegocio
{    
    public static class cFormatoDatos
    {
        #region Cadena

        public static string FormatoCaracterDerecha(int _NroCaracteres, char _Caracter, Object _Valor, string _ValorDefecto)
        {
            try
            {
                if (Convert.ToString(_Valor) != string.Empty)
                    return Convert.ToString(_Valor).PadRight(_NroCaracteres, _Caracter).Substring(0, _NroCaracteres);
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        public static string FormatoCaracterIzquierda(int _NroCaracteres, char _Caracter, Object _Valor, string _ValorDefecto)
        {
            try
            {
                if (Convert.ToString(_Valor) != string.Empty)
                    return Convert.ToString(_Valor).PadLeft(_NroCaracteres, _Caracter);
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        public static string AgregarCerosDerecha(int _NroCeros, Object _Valor, string _ValorDefecto)
        {
            try
            {
                if (Convert.ToString(_Valor) != string.Empty)
                    return Convert.ToString(_Valor).PadRight(_NroCeros, '0');
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        public static string AgregarCerosIzquierda(int _NroCeros, Object _Valor, string _ValorDefecto)
        {
            try
            {
                if (Convert.ToString(_Valor) != string.Empty)
                    return Convert.ToString(_Valor).PadLeft(_NroCeros, '0');
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        public static string CortarCadena(int _Inicio, int _Longitud, Object _Valor, string _ValorDefecto)
        {
            try
            {
                if (Convert.ToString(_Valor) != string.Empty)
                    return Convert.ToString(_Valor).Substring(_Inicio, _Longitud);
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        public static string QuitarCaracterCadena(Object _Valor, string _ValorDefecto, string _AnteriorCaracter, string _NuevoCaracter = "")
        {
            try
            {
                if (Convert.ToString(_Valor) != string.Empty)
                {
                    return Convert.ToString(_Valor).Replace(_AnteriorCaracter, _NuevoCaracter);
                }
                else
                    return _ValorDefecto;
            }
            catch
            {
                return _ValorDefecto;
            }
        }

        #endregion Cadena
    }    
}