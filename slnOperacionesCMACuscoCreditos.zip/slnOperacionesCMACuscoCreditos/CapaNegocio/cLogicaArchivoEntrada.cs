﻿using CapaDatos;
using System;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class cLogicaArchivoEntrada
    {
        cConexionsSQL oConexion = new cConexionsSQL();

        public async Task<cResultado<T>> GenerarCabecera<T>(string pdFechainicio)
        {
            try
            {
                return new cResultado<T>(
                    0,
                    "Cabecera obtenida", 
                    await oConexion.TraerEnumerableAsync<T>(cNombreProcedimientos.usp_select_GenerarCabecera, pdFechainicio)
                    );
            }
            catch (Exception ex)
            {
                return new cResultado<T>(3, ex.Message, null);
            }
        }

        public async Task<cResultado<T>> GenerarCuotas<T>(string pdFechainicio)
        {
            try
            {
                return new cResultado<T>(
                    0,
                    "Cuotas obtenidas",
                    await oConexion.TraerEnumerableAsync<T>(cNombreProcedimientos.usp_select_GenerarCoutas, pdFechainicio)
                    );
            }
            catch (Exception ex)
            {
                return new cResultado<T>(3, ex.Message, null);
            }
        }

        public async Task<cResultado<T>> GenerarDetalle<T>(string pdFechainicio)
        {
            try
            {
                return new cResultado<T>(
                    0,
                    "Detalle Pagares obtenido",
                    await oConexion.TraerEnumerableAsync<T>(cNombreProcedimientos.usp_select_GenerarDetalle, pdFechainicio)
                    );
            }
            catch (Exception ex)
            {
                return new cResultado<T>(3, ex.Message, null);
            }
        }
    }
}