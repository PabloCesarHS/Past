﻿namespace CapaNegocio
{
    public class cNombreProcedimientos
    {
        //Generar Archivos
        public const string usp_select_GenerarCabecera = "spu_col_RecCredBatch_PagaresCabecera";
        public const string usp_select_GenerarCoutas = "spu_col_RecCredBatch_PagaresCuotas";
        public const string usp_select_GenerarDetalle = "spu_col_RecCredBatch_PagaresDetalle";

        //Registrar datos
        public const string usp_insert_RegistrarPagares = "";
    }
}