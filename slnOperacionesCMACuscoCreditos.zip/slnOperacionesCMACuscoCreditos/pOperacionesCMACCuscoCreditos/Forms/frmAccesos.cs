﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using static CapaNegocio.cConfiguracionSistema;

namespace pOperacionesCMACCuscoCreditos.Forms
{
    public partial class frmAccesos : Form
    {
        public frmAccesos()
        {
            InitializeComponent();
            listarGrupos();
            listarUsuarios();
        }

        CapaNegocio.cConfiguracionSistema vgConfiguracion = new CapaNegocio.cConfiguracionSistema();
        
        //List<cGrupos> vgListaGrupos = new List<cGrupos>();
        //List<cUsuarios> vgListaUsuarios = new List<cUsuarios>();

        private void listarGrupos()
        {
            //vgConfiguracion = new CapaNegocio.cConfiguracionSistema();
            //var cResultado = vgConfiguracion.Listar_Grupos();
            //vgListaGrupos = cTransformadorDatos.ConvertirDataTableAClase<cGrupos>(cResultado.Datos);
            //dgvListaGrupos.DataSource = vgListaGrupos;

            //Mostrar_Mensaje(cResultado.Mensaje, cResultado.Estado);
        }

        private void listarUsuarios()
        {
            //vgConfiguracion = new CapaNegocio.cConfiguracionSistema();
            //var cResultado = vgConfiguracion.Listar_Usuarios();
            //vgListaUsuarios = cTransformadorDatos.ConvertirDataTableAClase<cUsuarios>(cResultado.Datos);
            //dgvListaUsuarios.DataSource = vgListaUsuarios;

            //Mostrar_Mensaje(cResultado.Mensaje, cResultado.Estado);
        }

        private void ControlesEdicion()
        {
            
        }

        private void ControlesDefecto()
        {
            
        }

        private bool ValidarClaseRuta()
        {
            bool Correcto = false;
                        

            return Correcto;
        }

        private void Mostrar_Mensaje(string _Mensaje, int _Tipo)
        {
            switch (_Tipo)
            {
                case 1:
                    lbMensaje.ForeColor = System.Drawing.Color.Blue;
                    lbMensaje.Text = _Mensaje;
                    break;

                case 2:
                    lbMensaje.ForeColor = System.Drawing.Color.OrangeRed;
                    lbMensaje.Text = "ADVERTENCIA:" + _Mensaje;
                    break;

                case 3:
                    lbMensaje.ForeColor = System.Drawing.Color.Red;
                    lbMensaje.Text = "ERROR:" + _Mensaje;
                    break;

                default:
                    lbMensaje.ForeColor = System.Drawing.Color.Green;
                    lbMensaje.Text = _Mensaje;
                    break;
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}