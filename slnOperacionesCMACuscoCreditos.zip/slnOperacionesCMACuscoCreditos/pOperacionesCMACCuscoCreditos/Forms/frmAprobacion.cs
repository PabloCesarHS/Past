﻿using System;
using System.Windows.Forms;

namespace pOperacionesCMACCuscoCreditos.Forms
{
    public partial class frmAprobacion : Form
    {
        public frmAprobacion()
        {
            InitializeComponent();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAprobar_Click(object sender, EventArgs e)
        {
            if (tbxRuta.Text != string.Empty)
            {
                /* Se asigna contraseña para controlar el cambio de rutas */
                if (tbxRuta.Text == "BIMAdM!n!$TrAD0r")
                {
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
        }
    }
}