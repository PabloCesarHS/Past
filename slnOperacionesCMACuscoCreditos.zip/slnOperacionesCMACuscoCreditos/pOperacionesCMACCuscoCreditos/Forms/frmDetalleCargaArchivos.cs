﻿using CapaNegocio;
using System;
using System.Windows.Forms;

namespace pOperacionesCMACCuscoCreditos.Forms
{
    public partial class frmDetalleCargaArchivos : Form
    {
        cLogicaArchivoEntrada vgReportes = new cLogicaArchivoEntrada();
        cResultado vgResultado = new cResultado();
        public frmDetalleCargaArchivos()
        {
            InitializeComponent();
            cBTipoCarga.SelectedIndex = 0;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            Listar_Detalle();
        }

        private void Listar_Detalle()
        {
            vgReportes = new cLogicaArchivoEntrada();
            vgResultado = new cResultado();

            string Seleccion = "";

            switch (cBTipoCarga.SelectedItem.ToString())
            {
                case "Por nombre (Fecha) archivo":
                    Seleccion = "PorNombre";
                    break;

                case "Por fecha sistema":
                    Seleccion = "PorFechaSistema";
                    break;

                case "Por fecha real":
                    Seleccion = "PorFechasReal";
                    break;

                default:
                    break;
            }

            try
            {
                //vgResultado = vgReportes.Reporte_CargaListaArchivo(Seleccion, dtpFechaCarga.Value.ToString("yyyyMMdd"));
                //dgvListaCarga.DataSource = vgResultado.Datos;

                //Mostrar_Mensaje(vgResultado.Mensaje, vgResultado.Estado);
            }
            catch (Exception ex)
            {
                Mostrar_Mensaje(vgResultado.Mensaje + "-" + ex.Message, vgResultado.Estado);
            }

        }

        private void Mostrar_Mensaje(string _Mensaje, int _Tipo)
        {
            switch (_Tipo)
            {
                case 1:
                    lbMensaje.ForeColor = System.Drawing.Color.Blue;
                    lbMensaje.Text = _Mensaje;
                    break;

                case 2:
                    lbMensaje.ForeColor = System.Drawing.Color.OrangeRed;
                    lbMensaje.Text = "ADVERTENCIA:" + _Mensaje;
                    break;

                case 3:
                    lbMensaje.ForeColor = System.Drawing.Color.Red;
                    lbMensaje.Text = "ERROR:" + _Mensaje;
                    break;

                default:
                    lbMensaje.ForeColor = System.Drawing.Color.Green;
                    lbMensaje.Text = _Mensaje;
                    break;
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}