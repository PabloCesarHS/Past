﻿namespace pOperacionesCMACCuscoCreditos.Forms
{
    partial class frmGeneracionArchivos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelFiltro = new System.Windows.Forms.Panel();
            this.dtpFechaFiltro = new System.Windows.Forms.DateTimePicker();
            this.bGenerarDatos = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelDetalles = new System.Windows.Forms.Panel();
            this.dgvListaDetalle = new System.Windows.Forms.DataGridView();
            this.panelCuotas = new System.Windows.Forms.Panel();
            this.dgvCuotas = new System.Windows.Forms.DataGridView();
            this.panelInformacion = new System.Windows.Forms.Panel();
            this.dgvInformacion = new System.Windows.Forms.DataGridView();
            this.bGenerarArchivo = new System.Windows.Forms.Button();
            this.panelCabecera = new System.Windows.Forms.Panel();
            this.dgvCabecera = new System.Windows.Forms.DataGridView();
            this.panelPiePagina = new System.Windows.Forms.Panel();
            this.bSalirCerrar = new System.Windows.Forms.Button();
            this.bEnviarInformacion = new System.Windows.Forms.Button();
            this.pbProcesos = new System.Windows.Forms.ProgressBar();
            this.lbMensaje = new System.Windows.Forms.Label();
            this.panelFiltro.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panelDetalles.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaDetalle)).BeginInit();
            this.panelCuotas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCuotas)).BeginInit();
            this.panelInformacion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInformacion)).BeginInit();
            this.panelCabecera.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCabecera)).BeginInit();
            this.panelPiePagina.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelFiltro
            // 
            this.panelFiltro.Controls.Add(this.dtpFechaFiltro);
            this.panelFiltro.Controls.Add(this.bGenerarDatos);
            this.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFiltro.Location = new System.Drawing.Point(0, 0);
            this.panelFiltro.Name = "panelFiltro";
            this.panelFiltro.Size = new System.Drawing.Size(1318, 75);
            this.panelFiltro.TabIndex = 0;
            // 
            // dtpFechaFiltro
            // 
            this.dtpFechaFiltro.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaFiltro.Location = new System.Drawing.Point(264, 27);
            this.dtpFechaFiltro.Name = "dtpFechaFiltro";
            this.dtpFechaFiltro.Size = new System.Drawing.Size(161, 20);
            this.dtpFechaFiltro.TabIndex = 1;
            // 
            // bGenerarDatos
            // 
            this.bGenerarDatos.Location = new System.Drawing.Point(466, 18);
            this.bGenerarDatos.Name = "bGenerarDatos";
            this.bGenerarDatos.Size = new System.Drawing.Size(150, 33);
            this.bGenerarDatos.TabIndex = 0;
            this.bGenerarDatos.Text = "ObtenerDatos";
            this.bGenerarDatos.UseVisualStyleBackColor = true;
            this.bGenerarDatos.Click += new System.EventHandler(this.bGenerarDatos_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panelDetalles);
            this.panel2.Controls.Add(this.panelCuotas);
            this.panel2.Controls.Add(this.panelInformacion);
            this.panel2.Controls.Add(this.panelCabecera);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 75);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1318, 677);
            this.panel2.TabIndex = 0;
            // 
            // panelDetalles
            // 
            this.panelDetalles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelDetalles.Controls.Add(this.dgvListaDetalle);
            this.panelDetalles.Location = new System.Drawing.Point(0, 267);
            this.panelDetalles.Name = "panelDetalles";
            this.panelDetalles.Size = new System.Drawing.Size(991, 399);
            this.panelDetalles.TabIndex = 3;
            // 
            // dgvListaDetalle
            // 
            this.dgvListaDetalle.AllowUserToAddRows = false;
            this.dgvListaDetalle.AllowUserToDeleteRows = false;
            this.dgvListaDetalle.AllowUserToResizeRows = false;
            this.dgvListaDetalle.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvListaDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvListaDetalle.BackgroundColor = System.Drawing.Color.White;
            this.dgvListaDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cascadia Code", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvListaDetalle.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvListaDetalle.Location = new System.Drawing.Point(12, 13);
            this.dgvListaDetalle.Name = "dgvListaDetalle";
            this.dgvListaDetalle.ReadOnly = true;
            this.dgvListaDetalle.RowHeadersVisible = false;
            this.dgvListaDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListaDetalle.Size = new System.Drawing.Size(970, 383);
            this.dgvListaDetalle.TabIndex = 0;
            // 
            // panelCuotas
            // 
            this.panelCuotas.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelCuotas.Controls.Add(this.dgvCuotas);
            this.panelCuotas.Location = new System.Drawing.Point(3, 132);
            this.panelCuotas.Name = "panelCuotas";
            this.panelCuotas.Size = new System.Drawing.Size(988, 126);
            this.panelCuotas.TabIndex = 2;
            // 
            // dgvCuotas
            // 
            this.dgvCuotas.AllowUserToAddRows = false;
            this.dgvCuotas.AllowUserToDeleteRows = false;
            this.dgvCuotas.AllowUserToResizeRows = false;
            this.dgvCuotas.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvCuotas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvCuotas.BackgroundColor = System.Drawing.Color.White;
            this.dgvCuotas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Cascadia Code", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCuotas.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvCuotas.Location = new System.Drawing.Point(9, 5);
            this.dgvCuotas.Name = "dgvCuotas";
            this.dgvCuotas.ReadOnly = true;
            this.dgvCuotas.RowHeadersVisible = false;
            this.dgvCuotas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCuotas.Size = new System.Drawing.Size(970, 111);
            this.dgvCuotas.TabIndex = 0;
            // 
            // panelInformacion
            // 
            this.panelInformacion.Controls.Add(this.dgvInformacion);
            this.panelInformacion.Controls.Add(this.bEnviarInformacion);
            this.panelInformacion.Controls.Add(this.bGenerarArchivo);
            this.panelInformacion.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelInformacion.Location = new System.Drawing.Point(991, 0);
            this.panelInformacion.Name = "panelInformacion";
            this.panelInformacion.Size = new System.Drawing.Size(327, 677);
            this.panelInformacion.TabIndex = 2;
            // 
            // dgvInformacion
            // 
            this.dgvInformacion.AllowUserToAddRows = false;
            this.dgvInformacion.AllowUserToDeleteRows = false;
            this.dgvInformacion.AllowUserToResizeRows = false;
            this.dgvInformacion.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvInformacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInformacion.Location = new System.Drawing.Point(17, 16);
            this.dgvInformacion.Name = "dgvInformacion";
            this.dgvInformacion.ReadOnly = true;
            this.dgvInformacion.Size = new System.Drawing.Size(298, 480);
            this.dgvInformacion.TabIndex = 1;
            // 
            // bGenerarArchivo
            // 
            this.bGenerarArchivo.Location = new System.Drawing.Point(17, 536);
            this.bGenerarArchivo.Name = "bGenerarArchivo";
            this.bGenerarArchivo.Size = new System.Drawing.Size(149, 46);
            this.bGenerarArchivo.TabIndex = 0;
            this.bGenerarArchivo.Text = "Generar Archivo";
            this.bGenerarArchivo.UseVisualStyleBackColor = true;
            this.bGenerarArchivo.Click += new System.EventHandler(this.bGenerarArchivo_Click);
            // 
            // panelCabecera
            // 
            this.panelCabecera.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelCabecera.Controls.Add(this.dgvCabecera);
            this.panelCabecera.Location = new System.Drawing.Point(0, 0);
            this.panelCabecera.Name = "panelCabecera";
            this.panelCabecera.Size = new System.Drawing.Size(992, 126);
            this.panelCabecera.TabIndex = 1;
            // 
            // dgvCabecera
            // 
            this.dgvCabecera.AllowUserToAddRows = false;
            this.dgvCabecera.AllowUserToDeleteRows = false;
            this.dgvCabecera.AllowUserToResizeRows = false;
            this.dgvCabecera.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvCabecera.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvCabecera.BackgroundColor = System.Drawing.Color.White;
            this.dgvCabecera.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Cascadia Code", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCabecera.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvCabecera.Location = new System.Drawing.Point(12, 16);
            this.dgvCabecera.Name = "dgvCabecera";
            this.dgvCabecera.ReadOnly = true;
            this.dgvCabecera.RowHeadersVisible = false;
            this.dgvCabecera.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCabecera.Size = new System.Drawing.Size(970, 96);
            this.dgvCabecera.TabIndex = 0;
            // 
            // panelPiePagina
            // 
            this.panelPiePagina.Controls.Add(this.lbMensaje);
            this.panelPiePagina.Controls.Add(this.pbProcesos);
            this.panelPiePagina.Controls.Add(this.bSalirCerrar);
            this.panelPiePagina.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelPiePagina.Location = new System.Drawing.Point(0, 752);
            this.panelPiePagina.Name = "panelPiePagina";
            this.panelPiePagina.Size = new System.Drawing.Size(1318, 57);
            this.panelPiePagina.TabIndex = 0;
            // 
            // bSalirCerrar
            // 
            this.bSalirCerrar.Location = new System.Drawing.Point(1066, 11);
            this.bSalirCerrar.Name = "bSalirCerrar";
            this.bSalirCerrar.Size = new System.Drawing.Size(105, 34);
            this.bSalirCerrar.TabIndex = 0;
            this.bSalirCerrar.Text = "Salir";
            this.bSalirCerrar.UseVisualStyleBackColor = true;
            // 
            // bEnviarInformacion
            // 
            this.bEnviarInformacion.Location = new System.Drawing.Point(166, 535);
            this.bEnviarInformacion.Name = "bEnviarInformacion";
            this.bEnviarInformacion.Size = new System.Drawing.Size(149, 46);
            this.bEnviarInformacion.TabIndex = 0;
            this.bEnviarInformacion.Text = "Enviar Informacion";
            this.bEnviarInformacion.UseVisualStyleBackColor = true;
            this.bEnviarInformacion.Click += new System.EventHandler(this.bGenerarArchivo_Click);
            // 
            // pbProcesos
            // 
            this.pbProcesos.Location = new System.Drawing.Point(12, 19);
            this.pbProcesos.Name = "pbProcesos";
            this.pbProcesos.Size = new System.Drawing.Size(338, 20);
            this.pbProcesos.TabIndex = 1;
            // 
            // lbMensaje
            // 
            this.lbMensaje.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbMensaje.AutoSize = true;
            this.lbMensaje.ForeColor = System.Drawing.Color.Red;
            this.lbMensaje.Location = new System.Drawing.Point(373, 22);
            this.lbMensaje.Name = "lbMensaje";
            this.lbMensaje.Size = new System.Drawing.Size(16, 13);
            this.lbMensaje.TabIndex = 12;
            this.lbMensaje.Text = "...";
            // 
            // frmGeneracionArchivos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1318, 809);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelPiePagina);
            this.Controls.Add(this.panelFiltro);
            this.Name = "frmGeneracionArchivos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmGeneracionArchivos";
            this.panelFiltro.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panelDetalles.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaDetalle)).EndInit();
            this.panelCuotas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCuotas)).EndInit();
            this.panelInformacion.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInformacion)).EndInit();
            this.panelCabecera.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCabecera)).EndInit();
            this.panelPiePagina.ResumeLayout(false);
            this.panelPiePagina.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelFiltro;
        private System.Windows.Forms.DateTimePicker dtpFechaFiltro;
        private System.Windows.Forms.Button bGenerarDatos;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panelCabecera;
        private System.Windows.Forms.DataGridView dgvCabecera;
        private System.Windows.Forms.DataGridView dgvInformacion;
        private System.Windows.Forms.DataGridView dgvListaDetalle;
        private System.Windows.Forms.Panel panelPiePagina;
        private System.Windows.Forms.Button bSalirCerrar;
        private System.Windows.Forms.Button bGenerarArchivo;
        private System.Windows.Forms.Panel panelDetalles;
        private System.Windows.Forms.Panel panelCuotas;
        private System.Windows.Forms.DataGridView dgvCuotas;
        private System.Windows.Forms.Panel panelInformacion;
        private System.Windows.Forms.Button bEnviarInformacion;
        private System.Windows.Forms.Label lbMensaje;
        private System.Windows.Forms.ProgressBar pbProcesos;
    }
}