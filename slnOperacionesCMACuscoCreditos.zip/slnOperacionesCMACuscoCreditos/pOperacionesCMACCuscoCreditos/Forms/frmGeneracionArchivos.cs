﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace pOperacionesCMACCuscoCreditos.Forms
{
    public partial class frmGeneracionArchivos : Form
    {
        public frmGeneracionArchivos()
        {
            InitializeComponent();
        }

        /* ARCHIVOS DE ENTRADA */
        IEnumerable<cDataArchivoCabecera> vgListaCabecera;
        IEnumerable<cDataArchivoCuota> vgListaCuotas;
        IEnumerable<cDataArchivoDetalle> vgListaDetalle;

        /* ARCHIVOS DE SALIDA */
        IEnumerable<cDataArchivoPagosRealizados> vgListaCreditosPagados;

        /* INSTANCIA LOGICA */
        cLogicaArchivoEntrada vgLogicaArchivoEntrada = new cLogicaArchivoEntrada();

        private async void bGenerarDatos_Click(object sender, EventArgs e)
        {
            CambiarEstadoControles(false);

            var vResultadoCabecera = await vgLogicaArchivoEntrada.GenerarCabecera<cDataArchivoCabecera>("27/02/2024");
            if (vResultadoCabecera.Estado == 0)
            {
                vgListaCabecera = vResultadoCabecera.Lista;
                dgvCabecera.DataSource = vResultadoCabecera.Lista;
            }
            Mostrar_Mensaje(true, vResultadoCabecera.Mensaje, vResultadoCabecera.Estado);
            Proceso(30);


            var vResultadoCuotas = await vgLogicaArchivoEntrada.GenerarCuotas<cDataArchivoCuota>("27/02/2024");
            if (vResultadoCuotas.Estado == 0)
            {
                vgListaCuotas = vResultadoCuotas.Lista;
                dgvCuotas.DataSource = vResultadoCuotas.Lista;
            }
            Mostrar_Mensaje(true, vResultadoCuotas.Mensaje, vResultadoCuotas.Estado);
            Proceso(60);

            var vResultadoDetalle = await vgLogicaArchivoEntrada.GenerarDetalle<cDataArchivoDetalle>("27/02/2024");
            if (vResultadoDetalle.Estado == 0)
            {
                vgListaDetalle = vResultadoDetalle.Lista;
                dgvListaDetalle.DataSource = vResultadoDetalle.Lista;
            }
            Mostrar_Mensaje(true, vResultadoDetalle.Mensaje, vResultadoDetalle.Estado);
            Proceso(100);

            CambiarEstadoControles(true);
            Mostrar_Mensaje(true, "Proceso Terminado", 0);
            Proceso(0);
        }

        public void Mostrar_Mensaje(bool pConcatenar, string pMensaje, int pTipo)
        {
            switch (pTipo)
            {
                case 1:
                    lbMensaje.ForeColor = System.Drawing.Color.Blue;
                    if (pConcatenar)
                    {
                        lbMensaje.Text = lbMensaje.Text + " - " + pMensaje;
                    }
                    else
                    {
                        lbMensaje.Text = pMensaje;
                    }
                    break;

                case 2:
                    lbMensaje.ForeColor = System.Drawing.Color.OrangeRed;
                    if (pConcatenar)
                    {
                        lbMensaje.Text = lbMensaje.Text + " - " + "ADVERTENCIA:" + pMensaje;
                    }
                    else
                    {
                        lbMensaje.Text = "ADVERTENCIA:" + pMensaje;
                    }
                    break;

                case 3:
                    lbMensaje.ForeColor = System.Drawing.Color.Red;
                    if (pConcatenar)
                    {
                        lbMensaje.Text = lbMensaje.Text + " - " + "ERROR:" + pMensaje;
                    }
                    else
                    {
                        lbMensaje.Text = "ERROR:" + pMensaje;
                    }
                    break;

                default:
                    lbMensaje.ForeColor = System.Drawing.Color.Green;
                    if (pConcatenar)
                    {
                        lbMensaje.Text = lbMensaje.Text + " - " + pMensaje;
                    }
                    else
                    {
                        lbMensaje.Text = pMensaje;
                    }
                    break;
            }
        }

        private void CambiarEstadoControles(bool pEstado)
        {
            bGenerarDatos.Enabled = pEstado;
            dgvCabecera.Enabled = pEstado;
            dgvCuotas.Enabled = pEstado;
            dgvListaDetalle.Enabled = pEstado;
        }

        private void Proceso(int pPorcentaje)
        {
            pbProcesos.Value = pPorcentaje;
        }

        private void ExportarReporte(string pCarpetaFecha, string _NombreArchivo, string _ReporteExportar)
        {
            /* OBTENER LISTA DE RUTAS DE DB AL MOMENTO DE REALIZAR LA INSTACIA DE LA CLASE */
            cConstante oConstante = new cConstante();

            //StreamReader lectura; /* COMPLEMENTO DE LECTURA DE ARCHIVO */
            StreamWriter escritura; /* COMPLEMENTO DE ESCRITURA DE ARCHIVOS */

            /* INSTANCIA DE CUADRO DE GUARDADO DE ARCHIVOS PLANOS - PRUEBA DE DESARROLLO */
            SaveFileDialog sFD = new SaveFileDialog();
            sFD.FileName = _NombreArchivo;
            sFD.Filter = "Text Files (*.txt)|*.txt";
            sFD.ShowDialog();

            string RutaArchivoGuardar = sFD.FileName;

            //var d1 = Path.GetExtension(RutaArchivoGuardar); // returns .exe
            //var d2 = Path.GetFileNameWithoutExtension(RutaArchivoGuardar); // returns File
            //var d3 = Path.GetFileName(RutaArchivoGuardar); // returns File.exe
            //var d4 = Path.GetDirectoryName(RutaArchivoGuardar); // returns C:\Program Files\Program

            string sRutaCompleta = Path.GetDirectoryName(RutaArchivoGuardar) + "\\" + pCarpetaFecha + "\\" + Path.GetFileName(RutaArchivoGuardar);
            string sRutaCarpetas = Path.GetDirectoryName(RutaArchivoGuardar) + "\\" + pCarpetaFecha;

            if (!File.Exists(sRutaCompleta))
            {
                Directory.CreateDirectory(sRutaCarpetas);
            }

            /* Eliminacion de archivo existente para crear uno nuevo */
            if (File.Exists(sRutaCompleta))
            {
                File.Delete(sRutaCompleta);
            }
            /* Creacion de archivo dupliacdo para crear nuevo contenido */
            escritura = File.CreateText(sRutaCompleta);

            try
            {

                escritura.WriteLine(String.Concat(
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', cConverciones.ConvertirACadena(vgListaCabecera.First().nTipoRegistro, "11"), "00"),
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', cConverciones.ConvertirACadena(vgListaCabecera.First().nCódigoRubro, "21"), "00"),
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', cConverciones.ConvertirACadena(vgListaCabecera.First().nCódigoEmpresa, "03"), "00"),
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', cConverciones.ConvertirACadena(vgListaCabecera.First().nCódigoServicio, "003"), "000"),
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', cConverciones.ConvertirACadena(vgListaCabecera.First().nCódigoSolicitud, "01"), "00"),
                        cFormatoDatos.FormatoCaracterDerecha(30, ' ', cFormatoDatos.CortarCadena(1, 30, vgListaCabecera.First().cDescripciónSolicitud, ""), "                              "),
                        cConverciones.ConvertirACadena(vgListaCabecera.First().nOrigenSolicitud, "1"),
                        cFormatoDatos.FormatoCaracterIzquierda(3, '0', cConverciones.ConvertirACadena(vgListaCabecera.First().nCódigoRequerimiento, "003"), "003"),
                        cConverciones.ConvertirACadena(vgListaCabecera.First().nCanalEnvío, "01"),
                        cConverciones.ConvertirACadena(vgListaCabecera.First().cTipoInformación, "A"),
                        cFormatoDatos.FormatoCaracterIzquierda(15, '0', cConverciones.ConvertirACadena(vgListaCabecera.First().nNúmeroRegistros, "000000000000000"), "000000000000000"),
                        cFormatoDatos.FormatoCaracterIzquierda(10, '0', cConverciones.ConvertirACadena(vgListaCabecera.First().nCódigoUnico, "0000000000"), "0000000000"),
                        cTransformaciones.TranformarFechaFormato(vgListaCabecera.First().nFechaProceso, "yyyymmdd", DateTime.Now.ToString("yyyymmdd")),
                        cTransformaciones.TranformarFechaFormato(vgListaCabecera.First().nFechaInicioCargos, "yyyymmdd", DateTime.Now.ToString("yyyymmdd")),
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', vgListaCabecera.First().nMoneda, "01"), "00"),
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', cFormatoDatos.QuitarCaracterCadena(cConverciones.ConvertirACadena(vgListaCabecera.First().nImporteTotal1, ""), "00", "."), "00"),
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', cFormatoDatos.QuitarCaracterCadena(cConverciones.ConvertirACadena(vgListaCabecera.First().nImporteTotal2, ""), "00", "."), "00"),
                        cConverciones.ConvertirACadena(vgListaCabecera.First().cTipoGlosa, "P"),
                        cFormatoDatos.FormatoCaracterDerecha(50, ' ', vgListaCabecera.First().cGlosaGeneral, "                                                  "),
                        cFormatoDatos.FormatoCaracterDerecha(221, ' ', vgListaCabecera.First().cLibre, " "),
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', cConverciones.ConvertirACadena(vgListaCabecera.First().nTipoFormato, "01"), "00"),
                        cFormatoDatos.FormatoCaracterIzquierda(4, '0', cConverciones.ConvertirACadena(vgListaCabecera.First().nCódigoFijo, "0000"), "00000")//,"\r\n"
                        );

                escritura.WriteLine(String.Concat(
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', cConverciones.ConvertirACadena(vgListaCuotas.First().nTipoRegistro, "00"), "00"),
                        cFormatoDatos.FormatoCaracterIzquierda(10, '0', cConverciones.ConvertirACadena(vgListaCuotas.First().cCódigoCuota, "0000000000"), "0000000000"),
                        cConverciones.ConvertirACadena(vgListaCuotas.First().nNúmeroConceptos, "1"),
                        cFormatoDatos.FormatoCaracterIzquierda(10, ' ', cConverciones.ConvertirACadena(vgListaCuotas.First().cDescripciónConcepto1, "          "), "          "),
                        cFormatoDatos.FormatoCaracterIzquierda(10, ' ', cConverciones.ConvertirACadena(vgListaCuotas.First().cDescripciónConcepto2, "          "), "          "),
                        cFormatoDatos.FormatoCaracterIzquierda(10, ' ', cConverciones.ConvertirACadena(vgListaCuotas.First().cDescripciónConcepto3, "          "), "          "),
                        cFormatoDatos.FormatoCaracterIzquierda(10, ' ', cConverciones.ConvertirACadena(vgListaCuotas.First().cDescripciónConcepto4, "          "), "          "),
                        cFormatoDatos.FormatoCaracterIzquierda(10, ' ', cConverciones.ConvertirACadena(vgListaCuotas.First().cDescripciónConcepto5, "          "), "          "),
                        cFormatoDatos.FormatoCaracterIzquierda(10, ' ', cConverciones.ConvertirACadena(vgListaCuotas.First().cDescripciónConcepto6, "          "), "          "),
                        cFormatoDatos.FormatoCaracterIzquierda(10, ' ', cConverciones.ConvertirACadena(vgListaCuotas.First().cDescripciónConcepto7, "          "), "          "),
                        cFormatoDatos.FormatoCaracterIzquierda(313, ' ', vgListaCuotas.First().cLibre, " "),
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', cConverciones.ConvertirACadena(vgListaCuotas.First().nTipoFormato, "00"), "00"),
                        cFormatoDatos.FormatoCaracterIzquierda(4, '0', cConverciones.ConvertirACadena(vgListaCuotas.First().nCódigoFijo, "0000"), "0000")//,"\r\n"
                        ));

                /* CUERPO DE ARCHIVO */
                foreach (cDataArchivoDetalle vClase in vgListaDetalle)
                {
                    /* 
                    */
                    escritura.WriteLine(String.Concat(
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', cConverciones.ConvertirACadena(vClase.nTipoRegistro, "00"), "00"),
                        cFormatoDatos.FormatoCaracterIzquierda(20, '0', cConverciones.ConvertirACadena(vClase.cCódigoDeudor, "00000000000000000000"), "00000000000000000000"),
                        cFormatoDatos.FormatoCaracterDerecha(30, ' ', cConverciones.ConvertirACadena(vClase.cNombredelDeudor, "          "), "                              "),
                        cFormatoDatos.FormatoCaracterIzquierda(10, ' ', cConverciones.ConvertirACadena(vClase.cReferencia1, "          "), "          "),
                        cFormatoDatos.FormatoCaracterIzquierda(10, ' ', cConverciones.ConvertirACadena(vClase.cReferencia2, "          "), "          "),
                        cConverciones.ConvertirACadena(vClase.cTipoOperación, "A"),
                        cFormatoDatos.FormatoCaracterIzquierda(8, ' ', cConverciones.ConvertirACadena(vClase.cCódigoCuota, "000000"), "000000"),
                        cTransformaciones.TranformarFechaFormato(vClase.nFechaEmisión, "yyyymmdd", DateTime.Now.ToString("yyyymmdd")),
                        cTransformaciones.TranformarFechaFormato(vClase.nFechaVencimiento, "yyyymmdd", DateTime.Now.ToString("yyyymmdd")),
                        cFormatoDatos.FormatoCaracterIzquierda(15, '0', cConverciones.ConvertirACadena(vClase.cNúmeroDocumento, "000000000000000"), "000000000000000"),
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', cConverciones.ConvertirACadena(vClase.nMonedaDeuda, "00"), "00"),
                        cFormatoDatos.FormatoCaracterIzquierda(7, '0', cFormatoDatos.QuitarCaracterCadena(vClase.nImporteConcepto1, "0000000", "."), "0000000"),
                        cFormatoDatos.FormatoCaracterIzquierda(7, '0', cFormatoDatos.QuitarCaracterCadena(vClase.nImporteConcepto2, "0000000", "."), "0000000"),
                        cFormatoDatos.FormatoCaracterIzquierda(7, '0', cFormatoDatos.QuitarCaracterCadena(vClase.nImporteConcepto3, "0000000", "."), "0000000"),
                        cFormatoDatos.FormatoCaracterIzquierda(7, '0', cFormatoDatos.QuitarCaracterCadena(vClase.nImporteConcepto4, "0000000", "."), "0000000"),
                        cFormatoDatos.FormatoCaracterIzquierda(7, '0', cFormatoDatos.QuitarCaracterCadena(vClase.nImporteConcepto5, "0000000", "."), "0000000"),
                        cFormatoDatos.FormatoCaracterIzquierda(7, '0', cFormatoDatos.QuitarCaracterCadena(vClase.nImporteConcepto6, "0000000", "."), "0000000"),
                        cFormatoDatos.FormatoCaracterIzquierda(7, '0', cFormatoDatos.QuitarCaracterCadena(vClase.nImporteConcepto7, "0000000", "."), "0000000"),
                        cConverciones.ConvertirACadena(vClase.cTipoCuentaPrincipal, "D"),
                        cFormatoDatos.FormatoCaracterIzquierda(3, '0', cConverciones.ConvertirACadena(vClase.cProductoCuentaprincipal, "000"), "000"),
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', cConverciones.ConvertirACadena(vClase.cMonedaCuentaPrincipal, "00"), "00"),
                        cFormatoDatos.FormatoCaracterIzquierda(20, '0', cConverciones.ConvertirACadena(vClase.cNumeroCuentaPrincipal, "00000000000000000000"), "00000000000000000000"),                        
                        cFormatoDatos.FormatoCaracterIzquierda(6, '0', cFormatoDatos.QuitarCaracterCadena(vClase.nImporteAbonarCuenta1, "000000", "."), "000000"),
                        cConverciones.ConvertirACadena(vClase.cTipoCuentaSecundaria, "D"),
                        cFormatoDatos.FormatoCaracterIzquierda(3, '0', cConverciones.ConvertirACadena(vClase.cProductoCuentaSecundaria, "000"), "000"),
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', cConverciones.ConvertirACadena(vClase.cMonedaCuentaSecundaria, "00"), "00"),
                        cFormatoDatos.FormatoCaracterIzquierda(20, '0', cConverciones.ConvertirACadena(vClase.cNumeroCuentaSecundaria, "00000000000000000000"), "00000000000000000000"),                        
                        cFormatoDatos.FormatoCaracterIzquierda(6, '0', cFormatoDatos.QuitarCaracterCadena(vClase.nImporteAbonarCuenta2, "000000", "."), "000000"),                        
                        cFormatoDatos.FormatoCaracterIzquierda(67, ' ', cConverciones.ConvertirACadena(vClase.cGlosaParticular, " "), " "),
                        cFormatoDatos.FormatoCaracterIzquierda(68, ' ', cConverciones.ConvertirACadena(vClase.cLibre, " "), " "),
                        cFormatoDatos.FormatoCaracterIzquierda(2, '0', cConverciones.ConvertirACadena(vClase.nTipoFormato, "00"), "00"),
                        cFormatoDatos.FormatoCaracterIzquierda(4, '0', cConverciones.ConvertirACadena(vClase.nCódigoFijo, "0000"), "0000")//,"\r\n"
                        ));
                }
                escritura.Close();
            }
            catch
            {

            }
        }

        private void bGenerarArchivo_Click(object sender, EventArgs e)
        {
            ExportarReporte("27022024", "Salida", "Detalle");
        }
    }
}