﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pOperacionesCMACCuscoCreditos.Forms
{
    public partial class frmImportarArchivos : Form
    {
        public String cUser = Environment.UserName.ToString().ToUpper();
        public String cAgencia = "01";
        public DateTime dFechaSistema = DateTime.Now;

        /* CLASE PARA RECUPERAR RUTAS */
        CapaNegocio.cConfiguracionSistema vgConfiguracion = new CapaNegocio.cConfiguracionSistema();
        /* LISTA DE RUTAS Y CONFIGURACIONES DE ARCHIVOS */
        List<CapaNegocio.cConfiguracionSistema.cConfiguracionSistemas> vgListaRutasConfiguracion = new List<CapaNegocio.cConfiguracionSistema.cConfiguracionSistemas>();
        /* CLASE DE MANEJO DE EXSISTENCIA DE ARCHIVOS */
        List<cCargaArchivos> vgListaArchivosCarga = new List<cCargaArchivos>();
        /* CLASE DE MANEJO DE ARCHIVOS */
        cLogicaArchivoEntrada vgArchivoReporte = new cLogicaArchivoEntrada();
        /* rutas de carga de archivos */
        cConstante vgConstante = new cConstante();
        /* variable de resultados de operaciones */
        cResultado vgResultado = new cResultado();
        /*  */
        cLogicaArchivoEntrada vgArchivoReportes = new cLogicaArchivoEntrada();

        public frmImportarArchivos()
        {
            InitializeComponent();

            CargarYMostrar_Rutas(); /* Inicializa y muestra las rutas de los archivos */
            ListarRutas();

            listarRutasDetalle(); /* CARGAR RUTAS DE PRODUCCION */
            CargaDatosMostrarArchivos(); /* RECUPERAR DATOS DE ARCHIVOS POR CARGAS */
        }

        private void CargarYMostrar_Rutas()
        {
            //lblRutaROrigen.Text = vgConstante.cpRutaOrigen;
            //lblRutaRDestino.Text = vgConstante.cpRutaDestino;

            //lblRutaIOrigen.Text = vgConstante.cpRutaOrigenEricKson;
            //lblRutaIDestino.Text = vgConstante.cpRutaDestinoErickson;
        }

        private void listarRutasDetalle()
        {
            try
            {
                //vgListaRutasConfiguracion = vgConstante.vgListaRutasConfiguracion;
                //dgvListaRutas.DataSource = vgListaRutasConfiguracion;
                //if (vgListaRutasConfiguracion.Count > 0)
                //{
                //    foreach (DataGridViewColumn dgvColumna in dgvListaRutas.Columns)
                //    {
                //        //if (new int[] { 5, 6, 7 }.Contains(dgvColumna.Index))
                //        //{
                //        //    dgvColumna.Visible = false;
                //        //}
                //    }
                //}

                Mostrar_Mensaje(vgResultado.Mensaje, vgResultado.Estado);
            }
            catch (Exception ex)
            {
                Mostrar_Mensaje(vgResultado.Mensaje + "-" + ex.Message, vgResultado.Estado);
            }
        }

        private void Mostrar_Mensaje(string _Mensaje, int _Tipo)
        {
            switch (_Tipo)
            {
                case 1:
                    lbMensaje.ForeColor = System.Drawing.Color.Blue;
                    lbMensaje.Text = _Mensaje;
                    break;

                case 2:
                    lbMensaje.ForeColor = System.Drawing.Color.OrangeRed;
                    lbMensaje.Text = "ADVERTENCIA:" + _Mensaje;
                    break;

                case 3:
                    lbMensaje.ForeColor = System.Drawing.Color.Red;
                    lbMensaje.Text = "ERROR:" + _Mensaje;
                    break;

                default:
                    lbMensaje.ForeColor = System.Drawing.Color.Green;
                    lbMensaje.Text = _Mensaje;
                    break;
            }
        }

        private void CargarArchivosXRuta(string _Ruta)
        {
            try
            {
                vgListaArchivosCarga = new List<cCargaArchivos>();
                DirectoryInfo vDirectorio = new DirectoryInfo(_Ruta);
                FileInfo[] vArchivos = vDirectorio.GetFiles();

                foreach (FileInfo vArchivo in vArchivos)
                {
                    if (EsArchivoPermitido(vArchivo.Name))
                    {
                        vgListaArchivosCarga.Add(new cCargaArchivos(false, Environment.UserName.ToUpper(), vArchivo.Name, 0, vArchivo.Extension, DateTime.Now, vArchivo.FullName));
                    }
                }
            }
            catch (Exception ex)
            {
                Mostrar_Mensaje(ex.Message, 3);
            }
        }

        private void ListarRutas()
        {
            List<cCombo> vgListaRutas = new List<cCombo>();

            //foreach (var item in vgConstante.vgListaRutasConfiguracion)
            //{
            //    vgListaRutas.Add(new cCombo(item.cTag, item.cTag));
            //}

            //cbRutaArchivos.DisplayMember = "Valor";
            //cbRutaArchivos.ValueMember = "Codigo";
            //cbRutaArchivos.DataSource = vgListaRutas.ToList();
        }

        private void ListarExtencionesDeArchivosxRuta()
        {
            List<cCombo> vgListaExtenciones = new List<cCombo>();
            /* Agupacion de extenciones - LAMBDA */
            //var vListaExtenciones = vgListaArchivosCarga.GroupBy(item => item.ArchivoNuevoExtencion).Select(columna => new { ArchivoNuevoExtenciones = columna.Key });
            /* Agrupacion de Extenciones - LINQ */
            var vListaExtenciones = from Archivo in vgListaArchivosCarga group Archivo by Archivo.ArchivoNuevoExtencion;

            vgListaExtenciones.Add(new cCombo("Defecto", "Lista por Defecto"));
            vgListaExtenciones.Add(new cCombo("Todos", "Listar todos los archivos"));

            foreach (var item in vListaExtenciones)
            {
                vgListaExtenciones.Add(new cCombo(item.Key, item.Key));
            }

            cbExtencionArchivos.DisplayMember = "Valor";
            cbExtencionArchivos.ValueMember = "Codigo";
            cbExtencionArchivos.DataSource = vgListaExtenciones.ToList();
        }
        private void ListarArchivosXRuta(string _Filtro)
        {
            try
            {
                switch (_Filtro)
                {
                    case "Defecto":
                        dgvListaCargaArchivos.DataSource = vgListaArchivosCarga.Where(item => !item.ArchivoNuevoExtencion.Contains(".signature")
                                                            && !item.ArchivoNuevoExtencion.Contains(".pdf")).ToList();
                        break;
                    case "Todos":
                        dgvListaCargaArchivos.DataSource = vgListaArchivosCarga.ToList();
                        break;
                    default:
                        dgvListaCargaArchivos.DataSource = vgListaArchivosCarga.Where(item => item.ArchivoNuevoExtencion.Contains(_Filtro)).ToList();
                        return;
                }

                Mostrar_Mensaje(vgListaArchivosCarga.Count().ToString() + " archivos ubicados.", 1);

                int vNroValidacionArchivosCorrectos = 0;
                int vNroValidacionArchivosIncoorrectos = 0;


                foreach (var item in vgListaArchivosCarga)
                {
                    /* NUEVA INSTANACIA A CLASE PARA CONSULTA DE EXITENCIA DE ARCHIVO */
                    vgArchivoReporte = new cLogicaArchivoEntrada();

                    //var vResultado = vgArchivoReporte.Reporte_VerificacionArchivo(item.ArchivoNuevo);

                    //if (vResultado.Estado == 0 || vResultado.Estado == 1)
                    //{
                    //    var vDetalle = cTransformadorDatos.ConvertirDataTableAClase<cDataArchivosProcesados>(vResultado.Datos);
                    //    if (vDetalle.First().nIdLogArchivos != "0")
                    //    {
                    //        item.Existe = true;
                    //        item.Usuario = vDetalle.First().cUSer;
                    //        item.NroCargas = vDetalle.Count;
                    //        item.FechaCarga = cConverciones.ConvertirAFecha(vDetalle.First().dFechaReal, DateTime.Now);
                    //        vNroValidacionArchivosCorrectos++;
                    //    }
                    //    else
                    //    {
                    //        vNroValidacionArchivosIncoorrectos++;
                    //    }
                    //}
                    //else
                    //{
                    //    vNroValidacionArchivosIncoorrectos++;
                    //    Mostrar_Mensaje(vNroValidacionArchivosIncoorrectos.ToString() + "Archivos Observados - " + vResultado.Mensaje, vResultado.Estado);
                    //    break;
                    //}
                }
            }
            catch (Exception ex)
            {
                Mostrar_Mensaje(ex.Message, 3);
            }
        }
        private void CargaDatosMostrarArchivos()
        {
            try
            {
                //if (vgConstante.cpRutaOrigen != "")
                //{
                //    CargarArchivosXRuta(vgConstante.cpRutaOrigen);

                //    ListarExtencionesDeArchivosxRuta();
                //}
                //else
                //{
                //    Mostrar_Mensaje("Carpéta sin archivos para cargar", 2);
                //}
                //Mostrar_Mensaje("(2)" + "Lista cargada", 1);
            }
            catch (Exception ex)
            {
                Mostrar_Mensaje(ex.Message, 3);
            }
        }
        private void cbExtencionArchivos_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cbExtencionArchivos.SelectedValue != null)
            {
                ListarArchivosXRuta(cbExtencionArchivos.SelectedValue.ToString());
                CambiarColorArchivosCargados();
            }
        }

        private void cbRutaArchivos_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cbRutaArchivos.SelectedValue != null)
            {
                switch (cbRutaArchivos.SelectedValue.ToString())
                {
                    //case "REPORTES":
                    //    CargarArchivosXRuta(vgConstante.cpRutaOrigen);
                    //    cbExtencionArchivos_SelectedValueChanged(null, null);
                    //    break;
                    //case "INCOMING":
                    //    CargarArchivosXRuta(vgConstante.cpRutaOrigenEricKson);
                    //    cbExtencionArchivos_SelectedValueChanged(null, null);
                    //    break;
                    //default:
                    //    CargarArchivosXRuta(vgConstante.cpRutaOrigen);
                    //    cbExtencionArchivos_SelectedValueChanged(null, null);
                    //    return;
                }
            }
        }
        private void CambiarColorArchivosCargados()
        {
            foreach (DataGridViewRow dgvFila in dgvListaCargaArchivos.Rows)
            {
                foreach (var item in vgListaArchivosCarga)
                {
                    if (dgvFila.Cells[2].Value.ToString() == item.ArchivoNuevo)
                    {
                        if (item.Existe)
                        {
                            dgvFila.DefaultCellStyle.ForeColor = System.Drawing.Color.DarkOrange;
                            //dgvFila.DefaultCellStyle.BackColor = System.Drawing.Color.LightGray;
                        }
                        else
                        {
                            dgvFila.DefaultCellStyle.ForeColor = System.Drawing.Color.DarkGreen;
                            //dgvFila.DefaultCellStyle.BackColor = System.Drawing.Color.LightGray;
                        }
                    }
                }
            }
        }
        private async Task CargarArchivos()
        {
            // CREAR LISTA DE CARGA DE ARCHIVOS ASINCRONOS
            List<Task<cCargaArchivosInfo>> vProcesosCargaArchivos = new List<Task<cCargaArchivosInfo>>();

            //pbImportar.Maximum = vgListaArchivosCarga.Where(item => !item.ArchivoNuevoExtencion.Contains(".signature")
            //&& !item.ArchivoNuevoExtencion.Contains(".pdf")).ToList().Count();
            pbImportar.Maximum = vgListaArchivosCarga.Count();

            int NroArchivoCargado = 1;

            // SE ITERA EN LA LISTA DE 
            foreach (cCargaArchivos vArchivo in vgListaArchivosCarga)
            {
                pbImportar.Value = NroArchivoCargado;
                if (EsArchivoPermitido(vArchivo.ArchivoRuta))
                {
                    vProcesosCargaArchivos.Add(LeerArchivoAsync(true, vArchivo.ArchivoRuta, vArchivo.ArchivoNuevo));
                }
                else
                {
                    vProcesosCargaArchivos.Add(LeerArchivoAsync(false, vArchivo.ArchivoRuta, vArchivo.ArchivoNuevo));
                }
                NroArchivoCargado++;
            }

            //Esperar a que todas las tareas se completen
            await Task.WhenAll(vProcesosCargaArchivos);

            //Imprimir los datos
            foreach (Task<cCargaArchivosInfo> vProceso in vProcesosCargaArchivos)
            {
                cCargaArchivosInfo vDatosProceso = await vProceso;

                lbImportados.Items.Add($"{cTransformaciones.TransformarBool(vDatosProceso.EstadoCarga, "OK", "Observado")} : {vDatosProceso.NombreArchivo}, Nro Registros: {vDatosProceso.NroRegistros}, Tiempo carga : {(vDatosProceso.Fechainicio - vDatosProceso.FechaFin).TotalSeconds.ToString("0.00") }");
            }

            Mostrar_Mensaje("Reportes importados, el proceso culmino en: " + DateTime.Now.ToString(), 0);
        }

        static bool EsArchivoPermitido(string _Ruta)
        {
            string vExtencionPermitida = Path.GetExtension(_Ruta).ToLower();
            return vExtencionPermitida == ".csv" || vExtencionPermitida == ".txt";
        }

        static void EnviarCorreo(List<cCargaArchivosInfo> datosList)
        {
            string destinatario = "correo@ejemplo.com";  // Reemplaza con la dirección de correo electrónico de destino
            string asunto = "Detalle de la carga de archivos";

            using (MailMessage mensaje = new MailMessage("tucorreo@ejemplo.com", destinatario, asunto, ConstruirCuerpoCorreo(datosList)))
            {
                using (SmtpClient clienteSmtp = new SmtpClient("smtp.tuempresa.com"))
                {
                    clienteSmtp.Credentials = new NetworkCredential("tucorreo@ejemplo.com", "tucontraseña");
                    clienteSmtp.Port = 587;
                    clienteSmtp.EnableSsl = true;

                    try
                    {
                        clienteSmtp.Send(mensaje);
                        Console.WriteLine("Correo electrónico enviado con éxito.");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error al enviar el correo electrónico: {ex.Message}");
                    }
                }
            }
        }

        static string ConstruirCuerpoCorreo(List<cCargaArchivosInfo> datosList)
        {
            // Construir el cuerpo del correo con la información de los datos
            // Puedes personalizar el formato según tus necesidades
            string cuerpoCorreo = "Detalles de la carga de archivos:\n\n";

            //foreach (Datos datos in datosList)
            //{
            //    cuerpoCorreo += $"DIA: {datos.Dia}, MES: {datos.Mes}, AÑO: {datos.Anno}, NUMERO DOCUMENTO: {datos.NumeroDocumento}, NUMERO REGISTROS: {datos.NumeroRegistros}, FORMATO: {datos.Formato}, CLAVE: {datos.Clave}\n";
            //}

            return cuerpoCorreo;
        }

        private async Task<cCargaArchivosInfo> LeerArchivoAsync(bool _Cargar, string _Ruta, string _NombreArchivo)
        {
            cCargaArchivosInfo vListaArchivosCargados = new cCargaArchivosInfo();

            vgArchivoReportes = new cLogicaArchivoEntrada();
            DateTime vFechaCargaInicio = DateTime.Now;

            if (_Cargar)
            {
                int NroArchivoCargado = 1;

                // Leer el archivo y asignar valores a la clase
                using (StreamReader vLector = new StreamReader(_Ruta))
                {
                    string vLinea;

                    while ((vLinea = await vLector.ReadLineAsync()) != null)
                    {
                        switch (IdentificarArchivo(_NombreArchivo))
                        {
                            case "NETTING":
                                //vgArchivoReportes.Insertar_Netting(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "LOGUSR":
                                //vgArchivoReportes.Insertar_LogUser(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "TR":
                                //vgArchivoReportes.Insertar_LogTransacciones(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "USRACCOUNTBALANCE":
                                //vgArchivoReportes.Insertar_BalanceCuentas(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "COMISIONES":
                                //vgArchivoReportes.Insertar_Comisiones(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "INTEROPE":
                                //vgArchivoReportes.Insertar_Interoperabilidad(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "FEEDET":
                                //vgArchivoReportes.Insertar_Fee(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "INF-COMERCIAL":
                                //vgArchivoReportes.Insertar_InformacionComercial(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "REPORTE32A":
                                //vgArchivoReportes.Insertar_Reporte32A(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "REPORTE32B-I":
                                //vgArchivoReportes.Insertar_Reporte32B_I(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "REPORTE32B-II":
                                //vgArchivoReportes.Insertar_Reporte32B_II(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "REPORTE32B-III":
                                //vgArchivoReportes.Insertar_Reporte32B_III(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "REPORTE32B-IV":
                                //vgArchivoReportes.Insertar_Reporte32B_IV(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "REPORTE32B-V":
                                //vgArchivoReportes.Insertar_Reporte32B_V(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "DEPOSITOS":
                                //vgArchivoReportes.Insertar_Depositos(cUser, cAgencia, dFechaSistema, _NombreArchivo, NroArchivoCargado, vLinea);
                                break;
                            case "ROANEXO1":
                            //MessageBox.Show(caseSwitch + ": " + vLinea);
                            case "ROANEXO2":
                            //MessageBox.Show(caseSwitch + ": " + vLinea);
                            case "OBSERVADO":
                                vListaArchivosCargados = new cCargaArchivosInfo(false, "Archivo No considerado", Environment.UserName.ToUpper(), _NombreArchivo, vFechaCargaInicio, DateTime.Now, "0");
                                break;
                        }
                        NroArchivoCargado++;
                    }
                    vListaArchivosCargados = new cCargaArchivosInfo(true, "Archivo Cargado", Environment.UserName.ToUpper(), _NombreArchivo, vFechaCargaInicio, DateTime.Now, NroArchivoCargado.ToString());
                }
            }
            else
            {
                vListaArchivosCargados = new cCargaArchivosInfo(false, "Archivo No considerado", Environment.UserName.ToUpper(), _NombreArchivo, vFechaCargaInicio, DateTime.Now, "0");
            }

            return vListaArchivosCargados;
        }

        /* Metodo 1 para diferenciar extenciones */
        public string CoincidirExtenciones(string nombreArchivo)
        {
            // Patrón REGEX para la fecha
            string patronFecha = @"^\d{6}(\.\d{3})?-\S*$";

            // Patrón REGEX para la extensión
            string patronExtension = @"(\.\w+)$";

            // Extrae el nombre del archivo
            Match matchFecha = Regex.Match(nombreArchivo, patronFecha);
            if (matchFecha.Success)
            {
                string nombre = matchFecha.Groups[0].Value;

                // Extrae la extensión
                Match matchExtension = Regex.Match(nombre, patronExtension);
                if (matchExtension.Success)
                {
                    nombre = nombre.Substring(0, matchExtension.Index);
                }

                return nombre;
            }
            else
            {
                return nombreArchivo;
            }
        }

        /* Metodo 1 para obtener nombres de  archivos */
        public string QuitarFechasYExtensiones(string nombreArchivo)
        {
            // Encuentra el primer carácter no numérico después de la fecha
            int indiceFecha = nombreArchivo.IndexOfAny(new char[] { '.', '-' });
            if (indiceFecha != -1)
            {
                indiceFecha++; // Avanzamos un carácter para evitar el separador "."
            }

            // Encuentra la siguiente ocurrencia del carácter "."
            int indiceExtension = nombreArchivo.IndexOf(".");

            // Determina el índice de corte
            int indiceCorte = Math.Min(indiceFecha != -1 ? indiceFecha : int.MaxValue,
                                       indiceExtension != -1 ? indiceExtension : int.MaxValue);

            // Devuelve la parte del nombre de archivo antes de la fecha o la extensión
            if (indiceCorte != int.MaxValue)
            {
                return nombreArchivo.Substring(0, indiceCorte);
            }
            else
            {
                // Devuelve el nombre de archivo original si no se encuentra ninguna fecha o extensión
                return nombreArchivo;
            }
        }

        /* Metodo 2 para obetener nombres de  archivos */
        public string QuitarFechasYExtensiones2(string nombreArchivo)
        {
            // Encuentra el primer carácter no válido
            int indiceNoValido = nombreArchivo.IndexOfAny(new char[] { '.', '-' });

            // Si no hay caracteres no válidos, devuelve el nombre de archivo original
            if (indiceNoValido == -1)
            {
                return nombreArchivo;
            }

            // Encuentra la posición de la fecha o extension
            switch (nombreArchivo[indiceNoValido])
            {
                case '.':
                    return nombreArchivo.Substring(0, indiceNoValido);
                case '-':
                    return nombreArchivo.Substring(0, indiceNoValido - 4);
                default:
                    throw new ArgumentException("El nombre de archivo contiene caracteres no válidos.");
            }
        }

        public string IdentificarArchivo(string _NombreArchivo)
        {
            // Primero, comprueba si la longitud del nombre del archivo es suficiente para las posibles coincidencias.
            if (_NombreArchivo.Length >= 8)
            {
                // Crea un diccionario para almacenar las posibles coincidencias y sus nombres correspondientes.
                var posiblesCoincidencias = new Dictionary<string, string>()
                    {
                        {"NETTING", "NETTING"},
                        {"USRACCOUNTBALANCE", "USRACCOUNTBALANCE"},
                        {"LOGUSR", "LOGUSR"},
                        {"TR", "TR"},
                        {"DEPOSITOS", "DEPOSITOS"},
                        {"RETIROS", "RETIROS"},
                        {"COMISIONES", "COMISIONES"},
                        {"INTEROPE", "INTEROPE"},
                        {"FEEDET", "FEEDET"},
                        {"INF-COMERCIAL", "INF-COMERCIAL"},
                        {"PAY", "PAY"},
                        {"REPORTE32A", "REPORTE32A"},
                        {"REPORTE32B-III", "REPORTE32B-III"},
                        {"REPORTE32B-II", "REPORTE32B-II"},
                        {"REPORTE32B-IV", "REPORTE32B-IV"},
                        {"REPORTE32B-I", "REPORTE32B-I"},
                        {"REPORTE32B-V", "REPORTE32B-V"},
                        {"307", "307"}
                    };

                // Intenta encontrar una coincidencia en el diccionario de nombre de archivos.
                string nombreCorrespondiente;
                if (posiblesCoincidencias.TryGetValue(_NombreArchivo.ToUpper().Substring(0, 8), out nombreCorrespondiente))
                {
                    return nombreCorrespondiente.ToUpper();
                }

                /* Validar Reporte de operaciones DINERO ELECTRONICO,APLIACION MOVIL O BANCA POR INTERNET */
                string vReporteOperacionesSBS = QuitarFechasYExtensiones(_NombreArchivo);

                if (vReporteOperacionesSBS.Length <= 10)
                {
                    if (vReporteOperacionesSBS.Substring(0, 2) == "01")
                    {
                        return "ROANEXO1";
                    }
                    if (vReporteOperacionesSBS.Substring(0, 2) == "02")
                    {
                        return "ROANEXO2";
                    }
                }

                // Si no se encuentra ninguna coincidencia en los primeros 8 caracteres, comprueba si hay coincidencias con longitudes específicas.
                foreach (var coincidencia in posiblesCoincidencias)
                {
                    if (_NombreArchivo.ToUpper().StartsWith(coincidencia.Key))
                    {
                        return coincidencia.Value.ToUpper();
                    }
                }
            }
            
            return "OBSERVADO";
        }


        //private void btnImportar_Click(object sender, EventArgs e)
        private async void btnImportar_Click(object sender, EventArgs e)
        {
            LimpiarControles();

            Mostrar_Mensaje("Validando Archivos (Reportes)...", 1); /*  */

            //MessageBox.Show(IdentificarArchivo("0120230922.307-CCUSCO.txt.signature"));
            //MessageBox.Show(IdentificarArchivo("0220230922.307-CCUSCO.txt.signature"));
            //MessageBox.Show(IdentificarArchivo("REPORTE32B-I-CCUSCO-202307.txt.signature"));
            //MessageBox.Show(IdentificarArchivo("REPORTE32B-II-CCUSCO-202307.txt.signature"));
            //MessageBox.Show(IdentificarArchivo("REPORTE32B-III-CCUSCO-202307.txt.signature"));
            //MessageBox.Show(IdentificarArchivo("REPORTE32B-IV-CCUSCO-202307.txt.signature"));
            //MessageBox.Show(IdentificarArchivo("REPORTE32B-V-CCUSCO-202307.txt.signature"));
            //MessageBox.Show(IdentificarArchivo("TRCCUSCO-20230703031805.csv.signature"));
            //MessageBox.Show(IdentificarArchivo("nettingCCUSCO-20230703001548.csv.signature"));

            //porgresbarReportes();               
            //if (VerificarImporteReportes("Reportes")) //LVCH 03/04/2018 Verifica antes de importar que no haya archivos abiertos
            //ImportarReportes();

            await CargarArchivos();
        }
        private void LimpiarControles()
        {
            lbImportados.Items.Clear();
            laMensajeReportes.Text = "";
            lbImportados.Items.Clear();
        }

        private void LimpiarControlesInstrucciones()
        {
            lbInsImportados.Items.Clear();
            laMensajeInstrucciones.Text = "";
            lbInsImportados.Items.Clear();
        }
        
        private async void btnImportarInstrucciones_Click(object sender, EventArgs e)
        {
            LimpiarControlesInstrucciones();

            Mostrar_Mensaje("Validando Archivos (Instrucciones)...", 1); /**/

            //porgresbarInstrucciones();    
            //if (VerificarImporteReportes("Archivos")) //04-04/2018 LVCH verifica archivos abiertos
            //ImportarInstrucciones();
        }

        private void porgresbarInstrucciones()
        {
            pbImportarInstrucciones.Minimum = 0;
            pbImportarInstrucciones.Maximum = 5;
            pbImportarInstrucciones.Step = 1;

            for (int i = 0; i <= 4; i++)
            {
                pbImportarInstrucciones.PerformStep();
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            lbImportados.Items.Clear();
            laMensajeReportes.Text = "";
            lbImportados.Items.Clear();
            lbInsImportados.Items.Clear();
            laMensajeInstrucciones.Text = "";
            lbInsImportados.Items.Clear();
            pbImportarInstrucciones.Value = 0;
            pbImportar.Value = 0;
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnValidarCarga_Click(object sender, EventArgs e)
        {
            CambiarColorArchivosCargados();
        }
    }
}