﻿namespace pOperacionesCMACCuscoCreditos.Forms
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPrincipal));
            this.mStrMenu = new System.Windows.Forms.MenuStrip();
            this.operacionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importarArchivosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generarArchivosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.detalleCargaArchivosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.detalleGeneracionArchivosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ReportesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuracionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rutasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accesosUsuariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paBody = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.statusStripPrincipal = new System.Windows.Forms.StatusStrip();
            this.tssUsuarioPrincipal = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssOrdenador = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssIPPrincipal = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssModoPrincipal = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssVersionPrincipal = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssBarraPrinciapl = new System.Windows.Forms.ToolStripProgressBar();
            this.tssMensajePrinciapl = new System.Windows.Forms.ToolStripStatusLabel();
            this.mStrMenu.SuspendLayout();
            this.paBody.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.statusStripPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // mStrMenu
            // 
            this.mStrMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.operacionesToolStripMenuItem,
            this.ReportesToolStripMenuItem,
            this.configuracionToolStripMenuItem});
            this.mStrMenu.Location = new System.Drawing.Point(0, 0);
            this.mStrMenu.Name = "mStrMenu";
            this.mStrMenu.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.mStrMenu.Size = new System.Drawing.Size(1212, 25);
            this.mStrMenu.TabIndex = 0;
            this.mStrMenu.Text = "menuStrip1";
            // 
            // operacionesToolStripMenuItem
            // 
            this.operacionesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importarArchivosToolStripMenuItem,
            this.generarArchivosToolStripMenuItem,
            this.toolStripSeparator1,
            this.detalleCargaArchivosToolStripMenuItem,
            this.detalleGeneracionArchivosToolStripMenuItem});
            this.operacionesToolStripMenuItem.Name = "operacionesToolStripMenuItem";
            this.operacionesToolStripMenuItem.Size = new System.Drawing.Size(69, 21);
            this.operacionesToolStripMenuItem.Text = "Archivos";
            // 
            // importarArchivosToolStripMenuItem
            // 
            this.importarArchivosToolStripMenuItem.Name = "importarArchivosToolStripMenuItem";
            this.importarArchivosToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.importarArchivosToolStripMenuItem.Text = "Importar Archivos";
            this.importarArchivosToolStripMenuItem.Click += new System.EventHandler(this.importarReportesToolStripMenuItem_Click);
            // 
            // generarArchivosToolStripMenuItem
            // 
            this.generarArchivosToolStripMenuItem.Name = "generarArchivosToolStripMenuItem";
            this.generarArchivosToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.generarArchivosToolStripMenuItem.Text = "Generar Archivos";
            this.generarArchivosToolStripMenuItem.Click += new System.EventHandler(this.generarArchivosToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(240, 6);
            // 
            // detalleCargaArchivosToolStripMenuItem
            // 
            this.detalleCargaArchivosToolStripMenuItem.Name = "detalleCargaArchivosToolStripMenuItem";
            this.detalleCargaArchivosToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.detalleCargaArchivosToolStripMenuItem.Text = "Detalle importacion Archivos";
            this.detalleCargaArchivosToolStripMenuItem.Click += new System.EventHandler(this.detalleCargaArchivosToolStripMenuItem_Click);
            // 
            // detalleGeneracionArchivosToolStripMenuItem
            // 
            this.detalleGeneracionArchivosToolStripMenuItem.Name = "detalleGeneracionArchivosToolStripMenuItem";
            this.detalleGeneracionArchivosToolStripMenuItem.Size = new System.Drawing.Size(243, 22);
            this.detalleGeneracionArchivosToolStripMenuItem.Text = "Detalle Generacion Archivos";
            // 
            // ReportesToolStripMenuItem
            // 
            this.ReportesToolStripMenuItem.Name = "ReportesToolStripMenuItem";
            this.ReportesToolStripMenuItem.Size = new System.Drawing.Size(77, 21);
            this.ReportesToolStripMenuItem.Text = "& Reportes";
            // 
            // configuracionToolStripMenuItem
            // 
            this.configuracionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rutasToolStripMenuItem,
            this.accesosUsuariosToolStripMenuItem});
            this.configuracionToolStripMenuItem.Name = "configuracionToolStripMenuItem";
            this.configuracionToolStripMenuItem.Size = new System.Drawing.Size(101, 21);
            this.configuracionToolStripMenuItem.Text = "Configuracion";
            // 
            // rutasToolStripMenuItem
            // 
            this.rutasToolStripMenuItem.Name = "rutasToolStripMenuItem";
            this.rutasToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.rutasToolStripMenuItem.Text = "Rutas";
            this.rutasToolStripMenuItem.Click += new System.EventHandler(this.rutasToolStripMenuItem_Click);
            // 
            // accesosUsuariosToolStripMenuItem
            // 
            this.accesosUsuariosToolStripMenuItem.Name = "accesosUsuariosToolStripMenuItem";
            this.accesosUsuariosToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.accesosUsuariosToolStripMenuItem.Text = "Accesos Grupos/Usuarios";
            this.accesosUsuariosToolStripMenuItem.Click += new System.EventHandler(this.accesosUsuariosToolStripMenuItem_Click);
            // 
            // paBody
            // 
            this.paBody.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.paBody.Controls.Add(this.pictureBox1);
            this.paBody.Location = new System.Drawing.Point(0, 26);
            this.paBody.Margin = new System.Windows.Forms.Padding(2);
            this.paBody.Name = "paBody";
            this.paBody.Size = new System.Drawing.Size(1212, 632);
            this.paBody.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Location = new System.Drawing.Point(457, 137);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(382, 382);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // statusStripPrincipal
            // 
            this.statusStripPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tssUsuarioPrincipal,
            this.tssOrdenador,
            this.tssIPPrincipal,
            this.tssModoPrincipal,
            this.tssVersionPrincipal,
            this.tssBarraPrinciapl,
            this.tssMensajePrinciapl});
            this.statusStripPrincipal.Location = new System.Drawing.Point(0, 662);
            this.statusStripPrincipal.Name = "statusStripPrincipal";
            this.statusStripPrincipal.Size = new System.Drawing.Size(1212, 22);
            this.statusStripPrincipal.TabIndex = 3;
            this.statusStripPrincipal.Text = "BIM Manager";
            // 
            // tssUsuarioPrincipal
            // 
            this.tssUsuarioPrincipal.Name = "tssUsuarioPrincipal";
            this.tssUsuarioPrincipal.Size = new System.Drawing.Size(56, 17);
            this.tssUsuarioPrincipal.Text = "Usuario:";
            // 
            // tssOrdenador
            // 
            this.tssOrdenador.Name = "tssOrdenador";
            this.tssOrdenador.Size = new System.Drawing.Size(80, 17);
            this.tssOrdenador.Text = "Ordenador: ";
            // 
            // tssIPPrincipal
            // 
            this.tssIPPrincipal.Name = "tssIPPrincipal";
            this.tssIPPrincipal.Size = new System.Drawing.Size(21, 17);
            this.tssIPPrincipal.Text = "IP:";
            // 
            // tssModoPrincipal
            // 
            this.tssModoPrincipal.Name = "tssModoPrincipal";
            this.tssModoPrincipal.Size = new System.Drawing.Size(47, 17);
            this.tssModoPrincipal.Text = "Modo:";
            // 
            // tssVersionPrincipal
            // 
            this.tssVersionPrincipal.Name = "tssVersionPrincipal";
            this.tssVersionPrincipal.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tssVersionPrincipal.Size = new System.Drawing.Size(54, 17);
            this.tssVersionPrincipal.Text = "Version:";
            // 
            // tssBarraPrinciapl
            // 
            this.tssBarraPrinciapl.Name = "tssBarraPrinciapl";
            this.tssBarraPrinciapl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tssBarraPrinciapl.Size = new System.Drawing.Size(100, 16);
            // 
            // tssMensajePrinciapl
            // 
            this.tssMensajePrinciapl.Name = "tssMensajePrinciapl";
            this.tssMensajePrinciapl.Size = new System.Drawing.Size(17, 17);
            this.tssMensajePrinciapl.Text = "...";
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1212, 684);
            this.Controls.Add(this.statusStripPrincipal);
            this.Controls.Add(this.mStrMenu);
            this.Controls.Add(this.paBody);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mStrMenu;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "frmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Operaciones Pagos de Credito - CMAC CUSCO";
            this.mStrMenu.ResumeLayout(false);
            this.mStrMenu.PerformLayout();
            this.paBody.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.statusStripPrincipal.ResumeLayout(false);
            this.statusStripPrincipal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mStrMenu;
        private System.Windows.Forms.ToolStripMenuItem operacionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importarArchivosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ReportesToolStripMenuItem;
        private System.Windows.Forms.Panel paBody;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem detalleCargaArchivosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configuracionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rutasToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStripPrincipal;
        private System.Windows.Forms.ToolStripStatusLabel tssUsuarioPrincipal;
        private System.Windows.Forms.ToolStripStatusLabel tssModoPrincipal;
        private System.Windows.Forms.ToolStripProgressBar tssBarraPrinciapl;
        private System.Windows.Forms.ToolStripStatusLabel tssVersionPrincipal;
        private System.Windows.Forms.ToolStripStatusLabel tssOrdenador;
        private System.Windows.Forms.ToolStripStatusLabel tssIPPrincipal;
        private System.Windows.Forms.ToolStripMenuItem accesosUsuariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel tssMensajePrinciapl;
        private System.Windows.Forms.ToolStripMenuItem generarArchivosToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem detalleGeneracionArchivosToolStripMenuItem;
    }
}