﻿using CapaNegocio;
using System;
using System.Data;
using System.DirectoryServices;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Windows.Forms;

namespace pOperacionesCMACCuscoCreditos.Forms
{
    public partial class frmPrincipal : Form
    {
        cConfiguracionSesion oRegistro = new cConfiguracionSesion();
        public string lcPass;

        public frmPrincipal()
        {
            InitializeComponent();
        }

        public frmPrincipal(String cPass)
        {
            lcPass = cPass;
            InitializeComponent();
            Cargar_Datos_Usuario();
        }

        private void Cargar_Datos_Usuario()
        {
            try
            {
                tssUsuarioPrincipal.Text = " Usuario: " + Environment.UserName.ToUpper();
                tssOrdenador.Text = " Ordenador: " + Environment.MachineName.ToString();

                tssModoPrincipal.Text = " [ " + cSistema.ServidorBD.ToUpper() + " ] ";

                tssVersionPrincipal.Text = " Version: " + cSistema.Version.ToUpper();

                NetworkInterface networkInterface = NetworkInterface.GetAllNetworkInterfaces().First(n => n.NetworkInterfaceType == NetworkInterfaceType.Ethernet && n.OperationalStatus == OperationalStatus.Up);
                
                IPAddress ipAddress = networkInterface.GetIPProperties().UnicastAddresses[0].Address;

                tssIPPrincipal.Text = " Direccion IP: " + ipAddress.ToString();

                Mostrar_Mensaje("Datos cargados", 0);
            }
            catch (Exception ex)
            {
                Mostrar_Mensaje(ex.Message, 3);
            }
        }

        public void Mostrar_Mensaje(string _Mensaje, int _Tipo)
        {
            switch (_Tipo)
            {
                case 1:
                    tssMensajePrinciapl.ForeColor = System.Drawing.Color.Blue;
                    tssMensajePrinciapl.Text = _Mensaje;
                    break;

                case 2:
                    tssMensajePrinciapl.ForeColor = System.Drawing.Color.OrangeRed;
                    tssMensajePrinciapl.Text = "ADVERTENCIA:" + _Mensaje;
                    break;

                case 3:
                    tssMensajePrinciapl.ForeColor = System.Drawing.Color.Red;
                    tssMensajePrinciapl.Text = "ERROR:" + _Mensaje;
                    break;

                default:
                    tssMensajePrinciapl.ForeColor = System.Drawing.Color.Green;
                    tssMensajePrinciapl.Text = _Mensaje;
                    break;
            }
        }

        #region Accesos
        private void frmMain_Load(object sender, EventArgs e)
        {
            String cUsuario = Environment.UserName.ToString().ToUpper();
            int nNivel = 0;
            int nPerfil = 0;

            //if (!verificarPermisosLocal(cUsuario, lcPass, ref nNivel, ref nPerfil))
            //{

            //}
        }

        public bool verificarPermisosLocal(string usuario, string psTxtPass, ref int nNivel, ref int nPerfil)
        {
            try
            {
                bool esGrupoPermitido = true;
                ObtenerPermisosLocal(usuario, ref esGrupoPermitido, ref nNivel, ref nPerfil);

                return esGrupoPermitido;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool verificarPermisos(string usuario, string psTxtPass, ref int nNivel, ref int nPerfil)
        {
            try
            {
                DirectoryEntry entry = new DirectoryEntry("LDAP://" + "CMACCUSCO" + "", usuario, psTxtPass, System.DirectoryServices.AuthenticationTypes.Secure);
                DirectorySearcher searcher = new DirectorySearcher(entry);

                searcher.Filter = "(SAMAccountName=" + usuario + ")";
                searcher.PropertiesToLoad.Add("MemberOf");
                SearchResult result = searcher.FindOne();

                int n = result.Properties["MemberOf"].Count - 1;

                string item = string.Empty;

                string[] grupos_usuario = new string[n + 1];

                while (n >= 0)
                {
                    item = result.Properties["MemberOf"][n] + "";
                    item = item.Substring(0, item.IndexOf(",", 0));
                    item = item.Replace("CN=", "");
                    item = item.Trim();
                    grupos_usuario[n] = item;
                    n--;
                }

                bool esGrupoPermitido = false;
                //ObtenerPermisos(grupos_usuario, ref esGrupoPermitido, ref nNivel, ref nPerfil);
                esGrupoPermitido = true;

                return esGrupoPermitido;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public void ObtenerPermisos(string[] grupos_usuario, ref bool esGrupoPermitido, ref int nNivel, ref int nPerfil)
        {
            //DataTable dtGruposUsu = new DataTable();
            //int nEstado = -1;
            //dtGruposUsu = oRegistro.ObtenerPermisos(ref nEstado);

            //if (nEstado == 0)
            //{
            //    esGrupoPermitido = false;
            //    nNivel = -1;
            //    nPerfil = -1;

            //    for (int i = 0; i < grupos_usuario.Length; i++)
            //    {
            //        for (int j = 0; j < dtGruposUsu.Rows.Count; j++)
            //        {
            //            if (grupos_usuario[i].Equals(dtGruposUsu.Rows[j][0].ToString()))
            //            {
            //                // mayor nivel
            //                if (Convert.ToInt32(dtGruposUsu.Rows[j][1].ToString()) > nNivel)
            //                {
            //                    nPerfil = Convert.ToInt32(dtGruposUsu.Rows[j][1].ToString());
            //                    AsignarAcceso(nPerfil);
            //                }
            //                esGrupoPermitido = true;
            //            }
            //        }
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("Error Acceso");
            //}
        }
        public void ObtenerPermisosLocal(string cUsuario, ref bool esGrupoPermitido, ref int nNivel, ref int nPerfil)
        {
            //DataTable dtGruposUsu = new DataTable();
            //int nEstado = -1;
            //dtGruposUsu = oRegistro.ObtenerPermisosUsuario(ref nEstado, cUsuario);

            //if (nEstado == 0)
            //{
            //    esGrupoPermitido = false;
            //    nNivel = -1;
            //    nPerfil = -1;

            //    for (int j = 0; j < dtGruposUsu.Rows.Count; j++)
            //    {
            //        nPerfil = Convert.ToInt32(dtGruposUsu.Rows[j][1].ToString());
            //        AsignarAcceso(nPerfil);
            //        esGrupoPermitido = true;
            //    }

            //}
        }

        public void AsignarAcceso(int nMenu)
        {
            mStrMenu.Items[nMenu].Visible = true;

            mStrMenu.Items[0].Visible = true;
            mStrMenu.Items[1].Visible = true;
            mStrMenu.Items[2].Visible = true;
            mStrMenu.Items[3].Visible = true;
        }
        #endregion Accesos

        private void importarReportesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmImportarArchivos oImportar = new frmImportarArchivos();
            oImportar.ShowDialog(Owner);
        }

        private void detalleCargaArchivosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.frmDetalleCargaArchivos oDetalecargaArchivos = new frmDetalleCargaArchivos();
            oDetalecargaArchivos.ShowDialog(Owner);
        }
        private void rutasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.frmConfiguracion oConfiguraciones = new frmConfiguracion();
            oConfiguraciones.ShowDialog(Owner);
        }

        private void accesosUsuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.frmAccesos oGruposUsuarios = new frmAccesos();
            oGruposUsuarios.ShowDialog(Owner);
        }

        private void generarArchivosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.frmGeneracionArchivos oGruposUsuarios = new frmGeneracionArchivos();
            oGruposUsuarios.ShowDialog(Owner);
        }
    }
}