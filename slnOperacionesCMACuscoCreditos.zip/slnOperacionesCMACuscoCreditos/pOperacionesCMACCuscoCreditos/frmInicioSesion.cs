﻿using CapaNegocio;
using System;
using System.DirectoryServices;
using System.Windows.Forms;

namespace pOperacionesCMACCuscoCreditos
{
    public partial class frmInicioSesion : Form
    {
        int vgContador = 0;
        DateTime vgFechaSesion;
        public String vgDominio;

        [System.Runtime.InteropServices.DllImport("advapi32.dll")]
        public static extern bool LogonUser(string puserName, string pdomainName, string ppassword, int plogonType, int plogonProvider, ref IntPtr pToken);
        public frmInicioSesion()
        {
            InitializeComponent();
            CargarinformacionSistema();
        }

        /// <summary>
        /// Carga informacion del sistema y del ususario, para ser motrada en el pie de pagina
        /// </summary>
        private void CargarinformacionSistema()
        {
            string vInformacion = "Carga Info";
            try
            {
                vInformacion = string.Concat(
                " Usuario: " + Environment.UserName.ToUpper(),
                " Ordenador: " + Environment.MachineName.ToString(),
                " [ " + cSistema.Modo.ToUpper() + " ] ",
                " Version: " + cSistema.Version.ToUpper());
            }
            catch
            {
                vInformacion = "Error en Carga Info";
            }
            lblInformacion.Text = vInformacion;
        }

        /// <summary>
        /// asigna el suaurio, inicializa el dominio
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Login_Load(object sender, EventArgs e)
        {
            txtUsuario.Text = Environment.UserName.ToString().ToUpper();
            vgDominio = Environment.UserDomainName.ToUpper();
            txtClave.Focus();
        }

        public static bool ValidarClave(string pUsuario, string pClave)
        {            
            try
            {
                DirectoryEntry vdentry = new DirectoryEntry("LDAP://CMACCUSCO", pUsuario, pClave, AuthenticationTypes.Secure);
                object vobjeto = vdentry.NativeObject;
                DirectorySearcher vdsearch = new DirectorySearcher(vdentry);
                vdsearch.Filter = "(SAMAccountName=" + pUsuario + ")";
                vdsearch.PropertiesToLoad.Add("cn");
                SearchResult sresult = vdsearch.FindOne();
                if (sresult == null)
                    throw new Exception();
                return true;
            }
            catch
            {
                return false;
            }
        }        

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pUsuario"></param>
        /// <param name="pClave"></param>
        /// <param name="pDominio"></param>
        /// <returns></returns>
        private bool ValidarUsuarioClaveLocal(string pUsuario, string pClave, string pDominio)
        {
            bool vEsCorrecto = false;
            string vUsernameYDominio = ObtenerUsuarioYDominio();

            if (vUsernameYDominio.ToLowerInvariant().Contains(vUsernameYDominio.Trim().ToLowerInvariant()) && vUsernameYDominio.ToLowerInvariant().Contains(pDominio.Trim().ToLowerInvariant()))
            {
                vEsCorrecto = ValidarCreddenciales(pUsuario.Trim(), pClave.Trim(), pDominio.Trim());
            }
            return vEsCorrecto;
        }

        /// <summary>
        /// obtiene el nombre del usuario junto al dominio (CMACCusco\user)
        /// </summary>
        /// <returns></returns>
        private string ObtenerUsuarioYDominio()
        {
            System.Security.Principal.WindowsIdentity vUsuarioActual = System.Security.Principal.WindowsIdentity.GetCurrent();
            return vUsuarioActual.Name;
        }

        /// <summary>
        /// Valida la sesion de Usuario
        /// </summary>
        /// <param name="pUserName"></param>
        /// <param name="pPassword"></param>
        /// <param name="pDomain"></param>
        /// <returns></returns>
        private bool ValidarCreddenciales(string pUserName, string pPassword, string pDomain)
        {
            IntPtr tokenHandler = IntPtr.Zero;
            bool isValid = LogonUser(pUserName, pDomain, pPassword, 2, 0, ref tokenHandler);
            return isValid;
        }

        private void bSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bIngresar_Click(object sender, EventArgs e)
        {
            String vUsuario = txtUsuario.Text.Trim();

            int vExisteDominio = txtUsuario.Text.Trim().IndexOf("\\", 0);
            if (vExisteDominio != -1)
                vUsuario = txtUsuario.Text.Substring(vExisteDominio + 1, 4);

            if (ValidarUsuarioClaveLocal(vUsuario, txtClave.Text.Trim(), vgDominio.Trim()))
            {
                vgFechaSesion = DateTime.Now;
                Forms.frmPrincipal oMain = new Forms.frmPrincipal(txtClave.Text);
                txtClave.Clear();
                this.Hide();
                oMain.ShowDialog(Owner);
                this.Close();
            }
            else
            {
                if (ValidarClave(txtUsuario.Text, txtClave.Text) == true)
                {
                    vgFechaSesion = DateTime.Now;
                    Forms.frmPrincipal oMain = new Forms.frmPrincipal(txtClave.Text);
                    txtClave.Clear();
                    this.Hide();
                    oMain.ShowDialog(Owner);
                    this.Close();
                }
                else
                {
                    vgContador++;
                    if (vgContador > 3)
                        lblMensaje.Text = "Revise que no este bloqueda su cuenta.";
                    if (vgContador == 4)
                        this.Close();
                    else
                    {
                        txtClave.Clear();
                        lblMensaje.Text = "Ingrese su usuario y contraseña de dominio correctos - Numero Intentos: " + vgContador.ToString();
                        txtClave.Focus();
                    }
                }
            }
        }

        private void bIngresar_KeyPress(object sender, KeyPressEventArgs e)
        {
            bIngresar_Click(sender, e);
        }

        /// <summary>
        /// Se ejecuta cuado presionan enter en el el cuadro del password
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtClave_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                bIngresar_Click(sender, e);
            }
        }
    }
}